<?php


/**
 * monta array de acesso de menus
 *
 *
 * @param string $perfil
 * @access public
 * @return string
 */
function montaMenu($perfil) {
    $CI = & get_instance();
    if(!$perfil){
        header('Location: '.base_url().'sair' );
    }

    $menu = [
        '268' => [//ADM
            ['desc'=> 'Baixar Relatório de Organizações' , 'url'    => 'cadastro/listarOrganizacoes'],
            ['desc'=> 'Cadastrar Escola' , 'url'                    => 'cadastro/listarEscola'],
            ['desc'=> 'Configurações Escola' , 'url'                => 'cadastro/cadastrarConfiguracoes'],
            ['desc'=> 'Configurações Escola ADM' , 'url'            => 'cadastro/cadastrarConfigLD'],
            ['desc'=> 'Cadastrar Diretor' , 'url'                   => 'cadastro/listarDiretor'],
            ['desc'=> 'Cadastrar Turma' , 'url' => 'cadastro/listarTurma'],
            ['desc'=> 'Cadastrar Coordenador' , 'url' => 'cadastro/listarCoordenador'],
            ['desc'=> 'Cadastrar Professor' , 'url' => 'cadastro/listarProfessor'],
            ['desc'=> 'Cadastrar Aluno' , 'url' => 'cadastro/listarAluno'],
            ['desc'=> 'Cadastrar Responsável' , 'url' => 'cadastro/listarResponsavel'],
            ['desc'=> 'Gerenciar FAQ' , 'url' => 'faq'],
            ['desc'=> 'Portal AVA' , 'url' => 'central/portalava_jarvis'],
            ['desc'=> 'Importação de Questões' , 'url' => 'importacao/index'],
            ['desc'=> 'Central de Marretas' , 'url' => 'cadastro/central-marretas'],
            ['desc'=> 'Versões do conteúdo' , 'url' => 'versoes-estruturas'],
            ['desc'=> 'Cadastrar Prova' , 'url' => 'cadastro/cadastrarProvaIndex'],
            ['desc'=> 'Cadastrar grupo de questões' , 'url' => 'cadastro/cadastrarQuestoesIndex'],
            ['desc'=> 'Editar questão' , 'url' => 'cadastro/editarQuestaoIndex'],
            ['desc'=> 'Contas Demonstrativas' , 'url' => 'demonstravio/usuarios'],
            ['desc'=> 'Encurtador' , 'url' => 'cadastro/encurtador'],
        ],
        '269' => [//Escola
            ['desc'=> 'API Tokens', 'url' => 'cadastro/tokens'],
            ['desc'=> 'Configurações Escola' , 'url' => 'cadastro/cadastrarConfiguracoes'],
            ['desc'=> 'Cadastrar Diretor' , 'url' => 'cadastro/listarDiretor'],
            ['desc'=> 'Cadastrar Turma' , 'url' => 'cadastro/listarTurma'],
            ['desc'=> 'Cadastrar Coordenador' , 'url' => 'cadastro/listarCoordenador'],
            ['desc'=> 'Cadastrar Professor' , 'url' => 'cadastro/listarProfessor'],
            ['desc'=> 'Cadastrar Aluno' , 'url' => 'cadastro/listarAluno'],
            ['desc'=> 'Cadastrar Responsável' , 'url' => 'cadastro/listarResponsavel'],
            ['desc'=> 'Relatório de Acesso' , 'url' => 'log'],
            ['desc'=> 'Ativar Livro Digital' , 'url' => 'cadastro/ativarLivroDigitalIndex'],
            ['desc'=> 'Escola em Movimento', 'url' => 'cadastro/escolamovimento'],
        ],
        '270' => [//Diretor
            ['desc'=> 'Relatórios' , 'url' => 'relatorio'],
            ['desc'=> 'Configurações Escola' , 'url' => 'cadastro/cadastrarConfiguracoes'],
            ['desc'=> 'Cadastrar Turma' , 'url' => 'cadastro/listarTurma'],
            ['desc'=> 'Cadastrar Coordenador' , 'url' => 'cadastro/listarCoordenador'],
            ['desc'=> 'Cadastrar Professor' , 'url' => 'cadastro/listarProfessor'],
            ['desc'=> 'Cadastrar Aluno' , 'url' => 'cadastro/listarAluno'],
            ['desc'=> 'Cadastrar Responsável' , 'url' => 'cadastro/listarResponsavel'],
        ]
    ,
        '271' => [//Coordenador
            ['desc'=> 'Relatórios' , 'url' => 'relatorio'],
            ['desc'=> 'Cadastrar Professor' , 'url' => 'cadastro/listarProfessor'],
            ['desc'=> 'Cadastrar Aluno' , 'url' => 'cadastro/listarAluno'],
            ['desc'=> 'Cadastrar Responsável' , 'url' => 'cadastro/listarResponsavel'],
        ],
        '272' => [//Professor
            ['desc'=> 'Relatórios' , 'url' => 'relatorio'],
            ['desc'=> 'Questões Discursivas' , 'url' => 'cadastro/plataformaliteraria']
        ],
        '273' => [//Aluno
            ['desc'=> 'Relatórios' , 'url' => 'relatorio']
        ],
        '274' => [//Responsável
            ['desc'=> 'Relatórios' , 'url' => 'relatorio']
        ],
        '275' => [//Conteudo
            ['desc'=> 'Portal AVA' , 'url' => 'central/portalava_jarvis'],
            ['desc'=> 'Editar questão' , 'url' => 'cadastro/editarQuestaoIndex']
        ]

    ];

    $acessoLD = $CI->session->userdata('acessoLD');
    $exibeMenuLD = $CI->session->userdata('ExibeMenuLD') ? $CI->session->userdata('ExibeMenuLD') : 'S';

    if(($acessoLD === 'S' && $exibeMenuLD == 'S' && ($perfil == '271' || $perfil == '272' || $perfil == '273')) || $perfil == '274'){
        array_push($menu[$perfil], array('desc'=> 'Livro Digital - Dispositivos' , 'url' => 'livrodigital/dispositivos'), array('desc'=> 'Livro Digital' , 'url' => 'livrodigital'));
    }

    $escolaid = $CI->session->userdata('escola');
    if(($perfil == PERFIL_DIRETOR || $perfil == PERFIL_COORDENADOR || $perfil == PERFIL_ESCOLA) && $escolaid == '976de9cb2ed34e6162f720eb10d399aa'){
        array_push($menu[$perfil], array('desc'=> 'Relatório Exclusivo UP' , 'url' => 'relatorio/relatorio-escola-up'));
    }

    return isset($menu[$perfil]) ? $menu[$perfil] : array();
}


function header_presentation($caminho, $texto, $extra='', $ultimo = false) {

    echo '<li role="presentation"><a href="' . base_url() . $caminho . '" ' . $extra . ' >' . $texto . '</a></li>';
    if(!$ultimo){
        echo '<li role="presentation" class="divider"></li>';
    }
}
