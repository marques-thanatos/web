<?php
	
	function log_user_action($message, $extra_data = null)
	{
		log_message('user_action', $message, $extra_data);
	}

	function log_system_action($message, $extra_data = null)
	{
		log_message('system_action', $message, $extra_data);
	}

	function log_error($message, $extra_data = null)
	{
		log_message('error', $message, $extra_data);
	}

	function log_debug($message, $extra_data = null)
	{
		log_message('debug', $message, $extra_data);
	}

	function log_info($message, $extra_data = null)
	{
		log_message('info', $message, $extra_data);
	}

?>