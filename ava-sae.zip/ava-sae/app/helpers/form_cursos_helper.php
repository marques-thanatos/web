<?php

/**
 * Formata Array de home
 *
 *
 *
 * @access	public
 * @param	array           array contento para cada item um objeto .
 * @return	array           retorna dados no formato de um array.
 */
function form_home($form, $formid, $dadosCursos,$params) {
    $html = '';

    $encrypt_v2 = new CI_Encrypt();
    $CI = & get_instance();
    //$session = new CI_Session();

    // campos para renovar assinatura:
    $btnIniciar[1] = null;

    // iniciar
    $btnIniciar[2]['href'] = '#';
    $btnIniciar[2]['attr'] = array('title' => 'Entrar','class' => 'btn btn-primary');
    $btnIniciar[2]['label'] = 'Entrar';

    $html .= open_tag('div', array('class' => 'geral ' . $formid . ''));
    // Criando form
    if (empty($dadosCursos['bloqueado']) && $CI->session->userdata('situacaoSessao') === 'A' && ! empty($dadosCursos['linkCurso'])) {
        $attributesForm = array('id' => $formid, 'method' => 'GET');
        $html .= form_open($dadosCursos['linkCurso'], $attributesForm);
    }

    if ($dadosCursos['ClassificacaoID'] == 11) {
        $html .= open_tag('div', array('class' => 'curso enem borda6'));
    } else {
        $html .= open_tag('div', array('class' => 'curso borda6'));
    }
    $html .= open_tag('p', array('class' => 'nome museo700'));
    $html .= anchor('#', $dadosCursos['DescricaoPacote'], array('title' => $dadosCursos['DescricaoPacote'], 'onclick'=>"return false;"));
    $html .= close_tag('p');
    $html .= open_tag('div', array('class' => 'info borda4'));
    $html .= open_tag('div', array('class' => 'datas ' . $dadosCursos['bloqueado']));
    // labels

    $qtdAssuntos = ' 0 assuntos';
    if ($dadosCursos['QtdAssuntos'] == 1) {
    	$qtdAssuntos = $dadosCursos['QtdAssuntos'].' assunto';
    } else if($dadosCursos['QtdAssuntos'] > 1 ) {
    	$qtdAssuntos = $dadosCursos['QtdAssuntos'].' assuntos';
    }

    $html .= '<ul><li><p class="assuntos">Nesta disciplina:<span>'.$qtdAssuntos.'</span></p></li></ul>';

    // botao
    if (!empty($dadosCursos['btnIniciar'])) {
        if (is_array($dadosCursos['btnIniciar'])) {
            $html .= open_tag('p', array('class' => 'bt'));
            foreach ($dadosCursos['btnIniciar'] as $key) {
                if (isset($btnIniciar[$key]) && $btnIniciar[$key] != null) {
                    $html .= anchor($btnIniciar[$key]['href'], $btnIniciar[$key]['label'], $btnIniciar[$key]['attr']);
                }
            }
            $html .= close_tag('p');
        } else if (isset($btnIniciar[$dadosCursos['btnIniciar']])) {
            $btnIniciar[$dadosCursos['btnIniciar']]['attr']['onclick'] = 'return false;';
            $html .= open_tag('p', array('class' => 'bt'));
            $html .= anchor($btnIniciar[$dadosCursos['btnIniciar']]['href'], $btnIniciar[$dadosCursos['btnIniciar']]['label'], $btnIniciar[$dadosCursos['btnIniciar']]['attr']);
            $html .= close_tag('p');
        }
    }

    $html .= close_tag('div');
    $html .= open_tag('div', array('class' => 'clearfix'));
    $html .= close_tag('div');

    $html .= close_tag('div');
    $html .= close_tag('div');

    $html .= form_hidden('turmaID', $dadosCursos['Turma']);

    if (empty($dadosCursos['bloqueado']) && $CI->session->userdata('situacaoSessao') === 'A' && ! empty($dadosCursos['linkCurso'])) {
        $html .= form_close();
    }
    $html .= close_tag('div');

    return $html;
}

function form_home_prep($form, $formid, $dadosCursos,$params) {
    $html = '';
    $encrypt_v2 = new CI_Encrypt();
    //$session = new CI_Session();
    //$Secure_url_params = new Secure_url_params();

    // campos para renovar assinatura:
    $btnIniciar[1] = null;
    //print_pre($dadosCursos);die;
    if ($dadosCursos['ValorPacote'] != '') {
        $fields = new stdClass();
        $fields->id = $dadosCursos['GrupoAulaID'];
        $fields->nome = utf8_encode(trim($dadosCursos['DescricaoPacote']));
        $fields->ancora = trim($dadosCursos['Ancora']);
        $fields->prazo = $dadosCursos['Duracao'];
        $fields->dtFimPacote = "";
        $fields->ClassificacaoID = "";
        $fields->qtdPacotes = "1";
        $fields->tipoProduto = "renovacao";
        $fields->valor = $dadosCursos['ValorPacote'];
        $fields->apikey = 'ef6fbb81bd6a4f26a3283988230e6f871e54c9e1';
        $fields->assinaturamatriculaid = $dadosCursos['itemName'];

        $dadosPostGateway = json_encode($fields);
        $dadosPostGateway = trim($dadosPostGateway, '=');

        $dadosCursos['AssinaturaSistemaID'] = isset($dadosCursos['AssinaturaSistemaID']) ? $dadosCursos['AssinaturaSistemaID'] : 0;
    }

    // iniciar
    $btnIniciar[2]['href'] = 'javascript:void(0)';
    $btnIniciar[2]['attr'] = array('title' => 'Iniciar','class' => 'btn btn-primary');
    $btnIniciar[2]['label'] = 'Iniciar';

    // Verifica permissao
    $btnIniciar[3]['href'] = 'javascript:void(0)';
    $btnIniciar[3]['attr'] = array('title' => 'Iniciar','class' => 'btn btn-primary'/*,'onclick' => 'verificaPermissao(true);'*/);
    $btnIniciar[3]['label'] = 'Iniciar';

    // botao desativado
    $btnIniciar[4]['href'] = 'javascript:void(0)';
    $btnIniciar[4]['attr'] = array('title' => 'Iniciar','class' => 'btn disabled');
    $btnIniciar[4]['label'] = 'Iniciar';

    /* Contador quando aparece inicia em */
    $dtAtual = date_create(date('Y-m-d H:i:s'));

    $classcountdown = '';
    if (isset($dadosCursos['dtInicioPacote']) && $dadosCursos['dtInicioPacote'] != '-') {
        $diffDtAtual = $dtAtual->diff($dadosCursos['dtInicioPacote']);
        $dataInicio = $diffDtAtual->days . ' dias';
        if ($diffDtAtual->days == 0) {
            $dataInicio = str_pad($diffDtAtual->h, 2, 0, STR_PAD_LEFT) . ':' . $diffDtAtual->i . ':' . $diffDtAtual->s;
            $classcountdown = 'data-countdown="' . $dadosCursos['dtInicioPacote']->format('Y-m-d H:i:s') . '"';
        }
    }

    /* Contador quando aparece restam */
    $classcountdownfim = '';
    if (isset($dadosCursos['DiasRestantesPacote'])) {
        $temporestante = $dadosCursos['DiasRestantesPacote']->days . ' dias';
        if ($dadosCursos['DiasRestantesPacote']->days == 0 && empty($dadosCursos['bloqueado']) && $dadosCursos['DtFim'] != '-') {
            $dateformat = date_create($dadosCursos['DtFim']);
            $classcountdownfim = 'data-countdown="' . date_format($dateformat, 'Y-m-d H:i:s') . '"';
        }
    }

    // Labels
    if ($form == 1) {
        $labels[] = '<p class="liberado-em">Liberado em <span>' . $dadosCursos['dtInicioPacote']->format('d/m/Y') . ' </span></p>';
        $labels[] = '<p class="expira-em">Expira em <span>' . $dadosCursos['dtFimPacote']->format('d/m/Y') . '</span></p>';
        $labels[] = '<p class="restam">Restam  <span ' . $classcountdownfim . '>' . (($dadosCursos['bloqueado']) ? 'Acesso Bloqueado' : ($temporestante)) . '</span></p>';
    } else if ($form == 3) {
        $labels[] = '<p>Início do curso <span>' . $dadosCursos['dtInicioPacote']->format('d/m/Y') . ' </span></p>';
        if ($dadosCursos['DtFim'] == '-') {
            $labels[] = '<p>Término do curso <span class="info">' . $dadosCursos['dtFimPacote'] . '</span></p>';

            // quantos dias faltam para o inicio do curso
            if ($dadosCursos['DiasRestantesPacote']->invert == 0) {
                $labels[] = '<p>Inicia em  <span ' . $classcountdown . '>' . $dadosCursos['DiasRestantesPacote']->days . ' dias' . '</span></p>';
            }
        } else {
            $labels[] = '<p>Término do curso <span>' . $dadosCursos['dtFimPacote'] . '</span></p>';
            // dtInicio maior que dtAtual, exibimos Inicia em
            if (strtotime(date('Y-m-d H:i:s')) > strtotime($dadosCursos['DtInicio'])) {
                $labels[] = '<p>Restam  <span ' . $classcountdownfim . '>' . (($dadosCursos['bloqueado']) ? 'Acesso Bloqueado' : ($temporestante)) . '</span></p>';
            } else {
                $labels[] = '<p>Inicia em  <span ' . $classcountdown . '>' . (($dadosCursos['bloqueado']) ? 'Acesso Bloqueado' : $dataInicio) . '</span></p>';
            }
        }
    } elseif ($form == 4) {
        $labels[] = '<p><span>Aguardamos você no aulão presencial </span>  Dúvidas ligue 0800 606 8889</p>';
    } else {
        $labels[] = '<p>Liberado em <span>' . date('d/m/Y') . ' </span></p>';
    }

    $html .= open_tag('div', array('class' => 'geral ' . $formid . ''));

    $attributesForm = array('id' => $formid, 'method' => 'GET');
    $html .= form_open($dadosCursos['linkCurso'], $attributesForm);

    //GRUPOAULAS QUE DEVEM CONTER O BOX VERDE.

    if ($dadosCursos['ClassificacaoID'] == 12) {
        $html .= open_tag('div', array('class' => 'curso enem borda6'));
    }else{
        $html .= open_tag('div', array('class' => 'curso borda6'));
    }

    $html .= open_tag('p', array('class' => 'nome museo700'));
    $html .= anchor('javascript:void(0)', $dadosCursos['DescricaoPacote'], array('title' => $dadosCursos['DescricaoPacote']));
    $html .= close_tag('p');
    $html .= open_tag('div', array('class' => 'info borda4'));
    $html .= open_tag('div', array('class' => 'datas ' . $dadosCursos['bloqueado']));
    // labels
    $html .= ul($labels);

    // botao
    if (!empty($dadosCursos['btnIniciar'])) {
        if (is_array($dadosCursos['btnIniciar'])) {
            $html .= open_tag('p', array('class' => 'bt'));
            foreach ($dadosCursos['btnIniciar'] as $key) {
                if (isset($btnIniciar[$key]) && $btnIniciar[$key] != null) {
                    $html .= anchor($btnIniciar[$key]['href'], $btnIniciar[$key]['label'], $btnIniciar[$key]['attr']);
                }
            }
            $html .= close_tag('p');
        } else if (isset($btnIniciar[$dadosCursos['btnIniciar']])) {
            $html .= open_tag('p', array('class' => 'bt'));
            $html .= anchor($btnIniciar[$dadosCursos['btnIniciar']]['href'], $btnIniciar[$dadosCursos['btnIniciar']]['label'], $btnIniciar[$dadosCursos['btnIniciar']]['attr']);
            $html .= close_tag('p');
        }
    }
    $html .= close_tag('div');
    $html .= open_tag('div', array('class' => 'clearfix'));
    $html .= close_tag('div');

    $html .= close_tag('div');
    $html .= close_tag('div');

    $html .= form_close();

    $html .= close_tag('div');

    return $html;
}

function newFormCurso($dadosCurso, $turmaid)
{
    $CI = & get_instance();

    $html = '';
    $ativo = 1;

    if($dadosCurso){
        foreach ($dadosCurso as $disciplina => $dados)
        {
            if (count($dados) > 2)
            {
                if(isset($dados['Assuntos']))
                {
                    foreach($dados['Assuntos'] as $assuntos)
                    {
                        if($assuntos['DtFim'] < date('Y-m-d'))
                        {
                            $ativo = 0;
                        }
                        else
                        {
                            $ativo = 1;
                            break;
                        }
                    }
                }

                $html .= open_tag('div', array('class' => 'geral ' . $disciplina . ''));
                $attributesForm = array('id' => $disciplina, 'method' => 'GET');
                $html .= form_open(base_url(). $dados['Controller'] .'/'. $dados['Ancora'], $attributesForm);

                if ($dados['Classificacao'] == 12 || $dados['Classificacao'] == 11)
                {
                    $html .= open_tag('div', array('class' => 'curso enem borda6'));
                }
                else
                {
                    if($CI->session->userdata('perfil') == 273)
                    {
                        if($ativo == 1)
                        {
                            $html .= open_tag('div', array('class' => 'curso borda6 TarefaAberta'));
                        }
                        else
                        {
                            $html .= open_tag('div', array('class' => 'curso borda6 TarefaVencida'));
                        }
                    }
                    else
                    {
                        $html .= open_tag('div', array('class' => 'curso borda6'));
                    }
                }

                $html .= open_tag('p', array('class' => 'nome museo700'));
                $html .= anchor('#', $dados['DescricaoDisciplina'], array('title' => $dados['DescricaoDisciplina'], 'onclick'=>"return false;"));
                $html .= close_tag('p');
                $html .= open_tag('div', array('class' => 'info borda4'));
                $html .= open_tag('div', array('class' => 'datas' . ''));

                if (isset($dados['Assuntos']))
                {
                    //$dados['Assuntos'] = array_unique($dados['Assuntos']);

                    if (count($dados['Assuntos']) > 1)
                    {
                        $html .= '<ul><li><p class="assuntos">Nesta disciplina:<span>'. count($dados['Assuntos']) .' assuntos</span></p></li></ul>';
                    }
                    else
                    {
                        $html .= '<ul><li><p class="assuntos">Nesta disciplina:<span>'. count($dados['Assuntos']) .' assunto</span></p></li></ul>';
                    }
                }
                else
                {
                    $labels = array();
                    $dataAtual = date_create(date('Y-m-d H:i:s'));
                    $dataInicio = date_create($dados['DataInicio']);
                    $dataFim = date_create($dados['DataFim']);
                    $diasRestantes = date_diff($dataAtual, $dataFim);
                    $labels[] = '<p class="liberado-em">Liberado em <span>' . $dataInicio->format('d/m/Y') . ' </span></p>';
                    $labels[] = '<p class="expira-em">Expira em <span>' . $dataFim->format('d/m/Y') . '</span></p>';

                    if ($diasRestantes->days > 1) {
                        $labels[] = '<p class="restam">Restam  <span>' . $diasRestantes->days . ' dias</span></p>';
                    } else {
                        $labels[] = '<p class="restam restam-1-dia">Restam  <span>' . $diasRestantes->days . ' dia</span></p>';
                    }

                    $html .= ul($labels);
                }

                $html .= open_tag('p', array('class' => 'bt'));
                $html .= anchor('#', 'Entrar', 'class="btn btn-primary" onClick="return false;"');
                $html .= close_tag('p');

                $html .= close_tag('div');
                $html .= open_tag('div', array('class' => 'clearfix'));
                $html .= close_tag('div');

                $html .= close_tag('div');
                $html .= close_tag('div');

                $html .= form_hidden('turmaID', $turmaid);

                $html .= form_close();
                $html .= close_tag('div');
            }
        }
    }

    return $html;
}


/**
 * Retorna o box em html do arrase no enem
 *
 * @return string
 */
function boxArraseNoEnemGlobal() {

    $dateStart = new \DateTime('first day of january this year');
    $dateEnd   = new \DateTime('last day of december this year');
    $days      = (new \DateTime())->diff($dateEnd);

    $html = <<<EOD
            <div class="geral arraseNoEnem">
                <div class="curso enem borda6">
                    <p class="nome museo700">
                        <a href="#" title="SAE - Arrase no Enem" onclick="boxShowArraseNoEnem();">SAE - Arrase no Enem</a>
                    </p>
                    <div class="info borda4">
                        <div class="datas">
                            <ul>
                                <li><p class="liberado-em">Liberado em <span>:liberado</span></p></li>
                                <li><p class="expira-em">Expira em <span>:expira</span></p></li>
                                <li><p class=":class">Restam <span>:dias</span></p></li>
                            </ul>
                            <p class="bt">
                                <a href="#" class="btn btn-primary" onclick="boxShowArraseNoEnem();">Entrar</a>
                            </p>
                        </div>
                        <div class="clearfix">
                        </div>
                    </div>
                </div>
            </div>
EOD;

    $strDias = 'dia';
    $class = 'restam restam-1-dia';

    if (($days->days+1) > 1) {
        $strDias = 'dias';
        $class = 'restam';
    }

    $html = str_replace(':liberado', $dateStart->format('d/m/Y'), $html);
    $html = str_replace(':expira', $dateEnd->format('d/m/Y'), $html);
    $html = str_replace(':expira', $dateEnd->format('d/m/Y'), $html);
    $html = str_replace(':dias', ($days->days+1) . ' ' . $strDias, $html);
    $html = str_replace(':class', $class, $html);

    return $html;

}
