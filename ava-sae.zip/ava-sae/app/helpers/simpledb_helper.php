<?php

/**
 * Formata Array de Objetos
 *
 * Recebe um array, onde para cada item dentro do array é um novo objeto,
 * e formata os array para que esteja em estrutura de array e suas posições para cada item(retirando o objeto)
 *
 * @access	public
 * @param	array           array contento para cada item um objeto .
 * @return	array           retorna dados no formato de um array.
 */
function formataArraydeObjetos($result) {

    $i = 0;
    $return = array();
    foreach ($result as $key => $value) {
    	if(isset($value['Attributes'])){
	        foreach ($value['Attributes'] as $attr) {
	            $return[$i][$attr['Name']] = utf8_decode($attr['Value']);
	        }
    	}
        $return[$i]["ItemName"] = utf8_decode((string) $value['Name']);

        $i++;
    }

     return $return;
}

/**
 * Formata Array de Objetos
 *
 * Recebe um array, onde para cada item dentro do array é um novo objeto,
 * e formata os array para que esteja em estrutura de array retornada pela mssql
 *
 * @access	public
 * @param	array           array contento para cada item um objeto .
 * @return	array           retorna dados no formato de um array.
 */
function formataArraydeObjetosSql($result) {

	$i = 0;
	$return = array();
	foreach ($result as $key => $value) {
		$return[$i] = new stdClass();
		foreach ($value as $name=>$attr) {
			$atrrname = $name;
			$return[$i][$atrrname] = utf8_decode($attr);
			$i++;
		}

		//$return[$i]->ItemName = utf8_decode((string) $value->Name);

		$i++;
	}
	p($return);die;
	return $return;
}
