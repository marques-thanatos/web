<?php

    /**
     * VerificaURL
     *
     * Verifica se a URL do parâmetro existe.
     *
     * @param	string $url     recebe uma string no formato de url http/https.
     * @access	public
     * @return	string
     */
    function verificaURL($url = null) {
        $site = @fopen($url, "r");
        $statusURL = (($site) ? $url : '');

        return $statusURL;
    }

    /**
     * encodeString
     *
     * Remove acentuaçôes de toda string
     *
     * @param string $string  palavra ao qual deseja remover acentuações
     * @access public
     * @return string
     */
    function encodeString($string) {

        $string = preg_replace("`\[.*\]`U", "", $string);
        $string = preg_replace('`&(amp;)?#?[a-z0-9]+;`i', '-', $string);
        $string = htmlentities($string, ENT_COMPAT, 'utf-8');
        $string = preg_replace("`&([a-z])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);`i", "\\1", $string);
        $string = preg_replace(array("`[^a-z0-9]`i", "`[-]+`"), "-", $string);

        return strtolower(trim($string, '-'));
    }

   /**
    * removeAcentos
    *
    * remove acentos das strings
    *
    * @param string $string  palavra
    * @access public
    * @return string
    */
    function removeAcentos($string) {

        $a = "áàãâäÁÀÃÂÄéèêëÉÈÊËíìîïÍÌÎÏóòõôöÓÒÕÔÖúùûüÚÙÛÜñÑ";
        $b = "aaaaaaaaaaeeeeeeeeiiiiiiiioooooooooouuuuuuuunn";
        $string = utf8_decode($string);
        $string = strtr($string, ($a), $b);
        $string = strtolower($string);

        return $string;
    }
    /**
     * retorna a data no padrão sql
     *
     *
     * @param string $string  data  d/m/yyyy
     * @access public
     * @return string yyyy-mm-dd
     */
    function dataBrParaSQL($data){
        $newdate = join('-',array_reverse(explode('/',$data)));
        return $newdate;
    }
    /**
     * retorna o dia da semana por extenso da data informada
     *
     *
     * @param string $string  data  YYYY-mm-dd
     * @access public
     * @return string
     */
    function diasemana($data) {

    	$dt = explode('-',$data);
    	$ano = $dt[0];
    	$mes = $dt[1];
    	$dia = $dt[2];

    	$diasemana = @date("w", mktime(0,0,0,$mes,$dia,$ano) );

    	switch($diasemana) {
    		case"0": $diasemana = "Domingo";	   break;
    		case"1": $diasemana = "Segunda-Feira"; break;
    		case"2": $diasemana = "Terça-Feira";   break;
    		case"3": $diasemana = "Quarta-Feira";  break;
    		case"4": $diasemana = "Quinta-Feira";  break;
    		case"5": $diasemana = "Sexta-Feira";   break;
    		case"6": $diasemana = "Sábado";		break;
    	}

    	return $diasemana;
    }
    function p($param){
        print_pre($param);
    }
	function configPaginacao($url, $totalLinhas, $porPagina = 5, $segmento = 2, $numeroLinks = 3) {
		$config['base_url'] = $url;
		$config['total_rows'] = $totalLinhas;
		$config['per_page'] = $porPagina;
		$config['uri_segment'] = $segmento;
		$config['num_links'] = $numeroLinks;

		$config['full_tag_open'] = '<ul class="pages">';
		$config['full_tag_close'] = '</ul>';

		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li class="prev">';
		$config['prev_tag_close'] = '<\li>';
		$config['next_tag_open'] = '<li class="next">';
		$config['next_tag_close'] = '</li>';

		$config['first_link'] = '&lt;&lt;';
		$config['prev_link'] = '&lt;';
		$config['next_link'] = '&gt;';
		$config['last_link'] = '&gt;&gt;';

		$config['cur_tag_open'] = '<li class="ativo"><a href="#">';
		$config['cur_tag_close'] = '</a></li>';

		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';

		return $config;
	}


	/**
	 * Funçao para conectar e consumir serviços da api
	 * de questoes para concursos.
	 */
	function api_use($servico, $dados, $action = 0) {

		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$strCookie = 'PHPSESSID= ""; path=/';

		$ch = curl_init();

		if($action == 5){
			$api = 'https://www.aprovaconcursos.com.br/questoes-de-concurso';
		}else{
			$api = API;
		}

		curl_setopt($ch, CURLOPT_URL, API."/api/v1/".$servico."?apikey=".KEY_QUESTOES);

		curl_setopt ( $ch, CURLOPT_HTTPHEADER, array('Accept: application/json','Content-Type: application/json'));
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		//açoes sem necessidade de estar logado
		if($action == 0 || $action == 2){
			curl_setopt($ch, CURLOPT_VERBOSE, 1);
		}
		curl_setopt($ch,CURLOPT_USERAGENT, $useragent);
		curl_setopt( $ch, CURLOPT_COOKIE, $strCookie );
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		//curl_setopt($ch, CURLOPT_COOKIEJAR, "cookies.txt");
		//curl_setopt($ch, CURLOPT_COOKIEFILE, "cookies.txt");
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		//curl_setopt($ch, CURLOPT_COOKIESESSION, false);

		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode( $dados ));

		// receive server response ...
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$server_output = curl_exec($ch);

		curl_close ($ch);

		$resposta = json_decode($server_output, true);




		return $resposta;
	}

	function arrayDistinct($dados) {

	    $array = array();

	    if($dados){

	    	for($i = 0 ; $i < count($dados) ; $i++){
	    		$existeValor = false;
	    		for($x = 0 ; $x < count($array) ; $x++){
	    			if(isset($array[$x]['Login']) && isset($dados[$i]['Login']) && $array[$x]['Login'] == $dados[$i]['Login']){
	    				 $existeValor = true;
	    			}
	    		}

	    		if($existeValor == false){
	    			$array[] = $dados[$i];
	    		}
	    	}
	    }

            return $array;
	}

	function base64url_encode($data) {
		return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
	}

	function base64url_decode($data) {
		return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
	}

	function validaEmail($email) {
		if(preg_match("/^([[:alnum:]_.-]){3,}@([[:lower:][:digit:]_.-]{3,})(.[[:lower:]]{2,3})(.[[:lower:]]{2})?$/", $email)) {
			return true;
		}else{
			return false;
		}
	}
	/*
	Troca a extensão do arquivo
	*/
	function replace_extension($filename, $new_extension) {
    return preg_replace('/\..+$/', '.' . $new_extension, $filename);
	}
	function obtemAlunos() {

		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$strCookie = 'PHPSESSID= ""; path=/';

		$dados = array('token' => "XqNjaTciZ2HqF76WA1OTXZOQxDU4FTwt");

		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, "http://www.sistemamv1.com.br/Webservice.asmx/ObtemAlunos");

		curl_setopt ( $ch, CURLOPT_HTTPHEADER, array('text/xml; charset=utf-8'));
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		//açoes sem necessidade de estar logado
		curl_setopt($ch, CURLOPT_VERBOSE, 1);
		curl_setopt($ch,CURLOPT_USERAGENT, $useragent);
		curl_setopt( $ch, CURLOPT_COOKIE, $strCookie );
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query( $dados ));

		// receive server response ...
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$server_output = curl_exec($ch);

		curl_close ($ch);

		$resposta = $server_output;

		return $resposta;
	}
