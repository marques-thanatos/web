<?php

/**
 * Essa função retira as tags indevidas, deixando apenas as formatações tradicionais realizadas pelo
 * editor de texto utilizado. No segundo parametro recebe as tags permitidas.
 *
 * @param string $codigo
 * @param array $listaBranca
 *
 * @return string
 */
function permissaoTags(
    $codigo,
    array $listaBranca = ['<img>', '<span>', '<strong>', '<ul>', '<u>', '<ol>', '<p>', '<s>', '<em>', '<h1>', '<h2>',
                          '<h3>', '<h4>', '<h5>', '<h6>', '<adress>', '<pre>', '<sup>', '<sub>', '<b>']
) {
    $lista = implode('', $listaBranca);

    return strip_tags(
        htmlspecialchars_decode(
            htmlentities($codigo, ENT_NOQUOTES, 'UTF-8', false),
            ENT_NOQUOTES),
        $lista
    );
}

?>