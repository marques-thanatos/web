<?php

function icon($message, $icon){
    return '<a href="javascript: void(0)" data-toggle="tooltip" title="" data-original-title="'.$message.'"><span class="glyphicon '.$icon.'" aria-hidden="true"></span></a>';
}

function icon_ok($message){
    return icon($message, 'glyphicon-ok');
}

function icon_success($message){
    return icon($message, 'glyphicon-ok success');
}

function icon_remove($message){
    return icon($message, 'glyphicon-remove');
}

function icon_video($message){
    return icon($message, 'glyphicon-facetime-video');
}

function td($text = ''){
    return '<td>'.$text.'</td>';
}

function exportarBtns($urlCSV, $urlExcel){
    return <<<TAG
        <div class="row">
            <div class="exportar pull-right no-print col-md-12">
                <div class="btn-group pull-right" role="group">
                  <a href="{$urlCSV}" class="btn csv" role="button" aria-pressed="true"><span class="glyphicon glyphicon-circle-arrow-down" aria-hidden="true"></span> Exportar CSV</a>
                  <a href="{$urlExcel}" class="btn xls" role="button" aria-pressed="true"><span class="glyphicon glyphicon-circle-arrow-down" aria-hidden="true"></span> Exportar XLS</a>
                  <a href="javascript:void(0)" onclick="window.print();" class="btn  print"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Imprimir</a>
                </div>
            </div>
            <div class="col-md-12">
                <div class="alert alert-danger " style="display: none;" role="alert" id="processing-file">
                  <strong>Atenção!</strong> Aguarde enquanto seu arquivo é processado
                </div>
            </div>
        </div>
TAG;
}

function dataGeracaoRelatorio($data = false){
    if(!$data) {
        $data = date_create();
    }
    $dataFormatada = date_format($data, 'd/m/Y H:m:s');
    return <<<TAG
        <div class="row">
            <div class="col-md-6 col-md-offset-6">
                <p class="pull-right text-right lead">Relatório gerado em {$dataFormatada}</p>
            </div>
        </div>
TAG;
}
