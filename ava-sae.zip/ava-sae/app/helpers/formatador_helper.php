<?php

    /**
     * str_reduce
     *
     * Reduz uma string sem cortar palavras ao meio. Pode-se reduzir a string pela
     * extremidade direita (padr�o da fun��o), esquerda, ambas ou pelo centro. Por
     * padr�o, ser�o adicionados tr�s pontos (...) � parte reduzida da string, mas
     * pode-se configurar isto atrav�s do par�metro $append.
     * Mantenha os cr�ditos da fun��o.
     *
     * @access	public	
     * @return string
     * @autor: Carlos Reche
     * @data:  Jan 21, 2005
     */

    function str_reduce($str, $max_length, $append = NULL, $position = STR_REDUCE_RIGHT, $remove_extra_spaces = true) {
        
        if (!is_string($str)) {
            echo "<br /><strong>Warning</strong>: " . __FUNCTION__ . "() expects parameter 1 to be string.";
            return false;
        } else if (!is_int($max_length)) {
            echo "<br /><strong>Warning</strong>: " . __FUNCTION__ . "() expects parameter 2 to be integer.";
            return false;
        } else if (!is_string($append) && $append !== NULL) {
            echo "<br /><strong>Warning</strong>: " . __FUNCTION__ . "() expects optional parameter 3 to be string.";
            return false;
        } else if (!is_int($position)) {
            echo "<br /><strong>Warning</strong>: " . __FUNCTION__ . "() expects optional parameter 4 to be integer.";
            return false;
        } else if (($position != STR_REDUCE_LEFT) && ($position != STR_REDUCE_RIGHT) &&
                ($position != STR_REDUCE_CENTER) && ($position != (STR_REDUCE_LEFT | STR_REDUCE_RIGHT))) {
            echo "<br /><strong>Warning</strong>: " . __FUNCTION__ . "(): The specified parameter '" . $position . "' is invalid.";
            return false;
        }


        if ($append === NULL) {
            $append = "...";
        }


        $str = html_entity_decode($str);


        if ((bool) $remove_extra_spaces) {
            $str = preg_replace("/\s+/s", " ", trim($str));
        }


        if (strlen($str) <= $max_length) {
            return htmlentities($str);
        }


        if ($position == STR_REDUCE_LEFT) {
            $str_reduced = preg_replace("/^.*?(\s.{0," . $max_length . "})$/s", "\\1", $str);

            while ((strlen($str_reduced) + strlen($append)) > $max_length) {
                $str_reduced = preg_replace("/^\s?[^\s]+(\s.*)$/s", "\\1", $str_reduced);
            }

            $str_reduced = $append . $str_reduced;
        } else if ($position == STR_REDUCE_RIGHT) {
            $str_reduced = preg_replace("/^(.{0," . $max_length . "}\s).*?$/s", "\\1", $str);

            while ((strlen($str_reduced) + strlen($append)) > $max_length) {
                $str_reduced = preg_replace("/^(.*?\s)[^\s]+\s?$/s", "\\1", $str_reduced);
            }

            $str_reduced .= $append;
        } else if ($position == (STR_REDUCE_LEFT | STR_REDUCE_RIGHT)) {
            $offset = ceil((strlen($str) - $max_length) / 2);

            $str_reduced = preg_replace("/^.{0," . $offset . "}|.{0," . $offset . "}$/s", "", $str);
            $str_reduced = preg_replace("/^[^\s]+|[^\s]+$/s", "", $str_reduced);

            while ((strlen($str_reduced) + (2 * strlen($append))) > $max_length) {
                $str_reduced = preg_replace("/^(.*?\s)[^\s]+\s?$/s", "\\1", $str_reduced);

                if ((strlen($str_reduced) + (2 * strlen($append))) > $max_length) {
                    $str_reduced = preg_replace("/^\s?[^\s]+(\s.*)$/s", "\\1", $str_reduced);
                }
            }

            $str_reduced = $append . $str_reduced . $append;
        } else if ($position == STR_REDUCE_CENTER) {
            $pattern = "/^(.{0," . floor($max_length / 2) . "}\s)|(\s.{0," . floor($max_length / 2) . "})$/s";

            preg_match_all($pattern, $str, $matches);

            $begin_chunk = $matches[0][0];
            $end_chunk = $matches[0][1];

            while ((strlen($begin_chunk) + strlen($append) + strlen($end_chunk)) > $max_length) {
                $end_chunk = preg_replace("/^\s?[^\s]+(\s.*)$/s", "\\1", $end_chunk);

                if ((strlen($begin_chunk) + strlen($append) + strlen($end_chunk)) > $max_length) {
                    $begin_chunk = preg_replace("/^(.*?\s)[^\s]+\s?$/s", "\\1", $begin_chunk);
                }
            }

            $str_reduced = $begin_chunk . $append . $end_chunk;
        }

        return htmlentities($str_reduced);
    }
    
     function dataextenso($data) {

        $data = explode("-",$data);

        $dia = intval($data[2]);
        $mes = $data[1];
        $ano = $data[0];

        switch ($mes){

            case 1: $mes = "Janeiro"; break;
			case 2: $mes = "Fevereiro"; break;
			case 3: $mes = "Março"; break;
			case 4: $mes = "Abril"; break;
			case 5: $mes = "Maio"; break;
			case 6: $mes = "Junho"; break;
			case 7: $mes = "Julho"; break;
			case 8: $mes = "Agosto"; break;
			case 9: $mes = "Setembro"; break;
			case 10: $mes = "Outubro"; break;
			case 11: $mes = "Novembro"; break;
			case 12: $mes = "Dezembro"; break;

        }

        return ("$dia de $mes de $ano");
    }
    
    /**
     * chamada do player pela nova api: "https://player.sae.digital"
     * @param string $video
     * @return mixed
     */
    function player($params = '')
    {
        $api_server = PATH_API_PLAYER;
        $api_http_user = USER_API_PLAYER;
        $api_http_pass = PASS_API_PLAYER;
         
        $metodo = 'player/version1';
        $format = 'serialized';

        $params['site'] = base_url();
        $params['largura'] = '100%'; // a altura é ajustada proporcionalmente
        $params['altura'] = '100%';
        $params['tabela'] = '';
        $params['origem'] = 'avasae';
        $params['path-upx'] = 'sae.r.worldssl.net';

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, "{$api_server}{$metodo}/format/{$format}");
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
        curl_setopt($curl, CURLOPT_USERPWD, "{$api_http_user}:{$api_http_pass}");
        curl_setopt($curl, CURLOPT_NOBODY, 1);
        curl_exec($curl);
        
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        $output = curl_exec($curl);
         
        return (unserialize($output));
    }

    /**
     *  Receber credenciais do player externo
     * @param string $video
     * @return url externa com secure codes
     */
    function credentialsPlayerExternal($pathVideo)
    {
        $linkVideo = null;
        try{
            $keyHash = '1awkurL';
            $pathSecureSSL = 'https://sslcdn.r.worldssl.net/videos/';
            $pathVideoDecode = $pathVideo;
            $secure = generateHashLink('videos/aulas/' . $pathVideoDecode, $keyHash, time() + 7200);
            $linkVideo = $pathSecureSSL .'aulas/' . $pathVideoDecode . '?' . $secure;
        }catch (\Exception $e){
            //TODO: tratar erro quando nao gerar link externo
        }

        return $linkVideo;
    }

    function generateHashLink($filePath, $secretKey, $expiryTimestamp = NULL)
    {

        // NOTE [    yasir 20110331  ] + and ? are some of represented chars	of based64 encoding (8 bits)
        // + is 62 and / is 63 . and These char should be replaced by other predefined chars.
        $searchChars = array('+','/');
        $replaceChars = array('-','_');

        if($filePath[0] != '/'){
            $filePath = "/{$filePath}";
        }

        if($pos = strpos($filePath, '?')){
            $filePath = substr($filePath,     0,     $pos);
        }

        $hashStr = $filePath.$secretKey;

        if($expiryTimestamp){
            $hashStr = $expiryTimestamp.$hashStr;
            $expiryTimestamp = ",{$expiryTimestamp}";
        }

        return "secure=".str_replace($searchChars,   $replaceChars,base64_encode(md5($hashStr,TRUE))).$expiryTimestamp;

    }
    
