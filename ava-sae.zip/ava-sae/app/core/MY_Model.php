<?php


class MY_Model extends CI_Model
{
    
    function __construct(){
        parent::__construct();
        

    }
    protected $_ava = null;
    protected $_avaMySQL = null;
    protected $_avaMySQLQuestoes = null;
    protected $_logAcesso = null;


    /**
     * @return CI_DB_driver
     */
    public function getAvaMySQL(){
        if(!$this->_avaMySQL){
            $this->_avaMySQL = $this->load->database('avaMySQL', TRUE);
//            var_dump($this->_avaMySQL);
        }
        return $this->_avaMySQL;
    }

    /**
     * @return CI_DB_driver
     */
    public function getAvaMySQLQuestoes(){
        if(!$this->_avaMySQLQuestoes){
            $this->_avaMySQLQuestoes = $this->load->database('avaMySQLQuestoes', TRUE);
        }
        return $this->_avaMySQLQuestoes;
    }

    
    /**
     * @return CI_DB_driver
     */
    public function getLogAcesso(){
        if(!$this->_logAcesso){
            $this->_logAcesso = $this->load->database('logAcesso', TRUE);
        }
        return $this->_logAcesso;
    }
}