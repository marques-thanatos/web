<?php
class MY_ControllerInformativo extends CI_Controller {

    public $sdb;
    public $configuracoes;
    public $sessao;
    public $header = '';
    public $menu_vertical = '';
    
    public function __construct() { 
		parent::__construct();
		
        if (function_exists("date_default_timezone_set")) {
            date_default_timezone_set("America/Sao_Paulo");
        }
        
        $this->load->model('configuracoes_model', 'configuracoes');
        $this->load->model('home_model', 'home');
        $this->load->model('Logs_model', 'logs');
        $this->load->helper('menu_helper');
        

        $logado = $this->session->userdata("logado");
        if ($this->uri->segment(1) == 'publico') {
                // deixar passar - ambiente publico
        } else if ($this->uri->segment(1) == 'cadastro' && ($this->uri->segment(2) == 'cadastroLogin' || $this->uri->segment(2) == 'salvarLogin' || $this->uri->segment(2) == 'cadDadosPrimeiroLogin' || $this->uri->segment(2) == 'salvarPrimeiroLogin')) {
            // deixa passar - cadastro de login
        } else if (!$logado) {
            redirect('login');
        } else {
            // verifica login simultaneo:
            if ($this->session->userdata('situacaoSessao') != 'I' && $this->session->userdata('SM') != 'S') {
                $this->load->library('acesso_lib');
                if (ENVIRONMENT != 'development' /*&& !$this->session->userdata('registradoLog') */) {
                    //print_pre(session_id());die;
                    //$this->session->set_userdata('registradoLog', 'S');
                    if (!$this->session->userdata('sistemaid')) {
                        $this->session->set_userdata('sistemaid', $this->logs->getSistemaID(base_url()));
                    }
//                    $dados['sistemaid'] = $this->session->userdata('sistemaid');
//                    $dados['usuarioid'] = $this->session->userdata('pessoaid');
                   
                    $params = array(
                        'sistemaid' => $this->session->userdata('sistemaid'),
                        'usuarioid' => $this->session->userdata('pessoaid'),
                        'servico' => 'login'
                    );
                    $api_http_user = '910026f84209f258ef9a15b80127514d9c9690b0';
                    $api_http_pass = 'e841eb2a5db56401fbe9af3cc79be4167d2d1da3';
                    $chave_acesso = 'f7627f4518c49bcd9e2facd7a9a2ta85ad645147';
                    $api_server = PATH_API_IESDE;
                    $chave_name = 'IESDE-API-KEY';
                    $format = 'json';
                    $metodo = 'logsacesso/logs';

                    $curl = curl_init();
                    curl_setopt($curl, CURLOPT_URL, "{$api_server}/{$metodo}/format/{$format}");
                    curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
                    curl_setopt($curl, CURLOPT_USERPWD, "{$api_http_user}:{$api_http_pass}");
                    curl_setopt($curl, CURLOPT_HTTPHEADER, array("{$chave_name}:{$chave_acesso}"));
                    curl_setopt($curl, CURLOPT_NOBODY, 1);
                    curl_exec($curl);

                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($curl, CURLOPT_HEADER, 0);
                    curl_setopt($curl, CURLOPT_POST, 1);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params));
                    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);

                    curl_exec($curl);

                }
            }
            
            $this->configuracoes = $this->configuracoes->configuracoes();
            //configura��es do header

            // $logo = $this->home->buscaLogo($this->session->userdata('escola'));

            $data['logo'] = 'logos/'.$this->configuracoes[0]['Logo'];
            if(isset($logo[0]['Logo']) && $logo[0]['Logo'] != ''){
                $data['logo'] = $logo[0]['Logo'];
            }
            $data['topo'] = isset($this->configuracoes[0]['ImagemTopo']) ? $this->configuracoes[0]['ImagemTopo'] : '';
            $data['fone'] = $this->configuracoes[0]['Telefone'];
            $data['site'] = $this->configuracoes[0]['ItemName'];
            
            $this->header = $this->load->view('view_header', $data, true);
        }
        if (!defined('PERFIL_RESPONSAVEL')) {
            define('PERFIL_RESPONSAVEL', 274);
        }
        if (!defined('PERFIL_ALUNO')) {
            define('PERFIL_ALUNO', 273);
        }
        if (!defined('PERFIL_PROFESSOR')) {
            define('PERFIL_PROFESSOR', 272);
        }
        if (!defined('PERFIL_COORDENADOR')) {
            define('PERFIL_COORDENADOR', 271);
        }
        if (!defined('PERFIL_DIRETOR')) {
            define('PERFIL_DIRETOR', 270);
        }
        if (!defined('PERFIL_ESCOLA')) {
            define('PERFIL_ESCOLA', 269);
        }
        
    }
	
}