<?php


use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\Monitoramento\Sentry;
use Ava\App\Support\Perfil;

/**
 * Class MY_Controller
 * @property Curso_model $curso
 * @property Home_model $home
 * @property Logs_model $logs
 * @property Ticket_model $tickets
 * @property Login_model $login
 * @property Configuracoes_model $configuracoes
 * @property CI_Input $input
 * @property CI_Session $session
 * @property CI_Loader $load
 * @property CI_URI $uri
 */
class MY_Controller extends CI_Controller
{

    public $sdb;
    public $configuracoes;
    public $sessao;
    public $header = '';
    public $menu_vertical = '';

    public function __construct()
    {
        parent::__construct();

        $sentryClient = SaeDigital::make(Sentry::class)->handle();

        $error_handler = new Raven_ErrorHandler($sentryClient);
        $error_handler->registerExceptionHandler();
        $error_handler->registerErrorHandler();

        $this->js[] = 'clicks';

        $this->load->model('configuracoes_model', 'configuracoes');
        $this->load->model('home_model', 'home');
        $this->load->model('Logs_model', 'logs');
        $this->load->model('login_model', 'login');
        $this->load->model('ticket_model', 'tickets');
        $this->load->helper('menu_helper');
        $this->load->helper('log_helper');

        $pagina = base_url() . $this->uri->uri_string;

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            log_system_action("Requisição AJAX em $pagina");
        } else {
            log_user_action("Entrou na página $pagina");
        }

        $logado = $this->session->userdata("logado");
        if (in_array($this->uri->segment(1), ['publico', 'ajuda'])) {
            // deixar passar - ambiente publico
        } else if ($this->uri->uri_string === 'demonstravio/usuarios/delete' || $this->uri->uri_string === 'jarvis/show-item' || $this->uri->uri_string === 'saenotifica/relatorio' || $this->uri->uri_string === 'curso/answer-structure' || $this->uri->uri_string === 'api/health-check') {
            // deixar passar - ambiente publico
        } else if ($this->uri->segment(1) == 'cadastro' && in_array($this->uri->segment(2), ['cadastroLogin', 'salvarLogin', 'cadDadosPrimeiroLogin', 'salvarPrimeiroLogin'])) {
            // deixa passar - cadastro de login
        } else if (!$logado) {
            redirect('login');
        } else {
            if (!$this->session->userdata('Serie')) {

                $aluno = $this->login->getUsuario($this->session);
                $this->session->set_userdata('Serie', $aluno['Serie']);
            }

            $this->configuracoes = $this->configuracoes->configuracoes();
            //configurações do header

            // $logo = $this->home->buscaLogo($this->session->userdata('escola'));
            $data['logo'] = 'logos/' . $this->configuracoes[0]['Logo'];
            if (isset($logo['Logo']) && $logo['Logo'] != '') {
                $data['logo'] = $logo['Logo'];
            }
            $data['topo'] = isset($this->configuracoes[0]['ImagemTopo']) ? $this->configuracoes[0]['ImagemTopo'] : '';
            $data['fone'] = $this->configuracoes[0]['Telefone'];
            $data['site'] = $this->configuracoes[0]['id'];

            $usuario = $this->login->getUsuario($this->session);
            $data['EmailBounced'] = $usuario['EmailBounced'];

            if ($this->uri->segment(1) != 'qrcode' &&
                $this->uri->segment(1) != 'central' &&
                $this->uri->segment(1) != 'corrigirquestoes') {
                $this->header = $this->load->view('view_header', $data, true);
            }
        }
    }


    /**
     * @return \Twig_Environment
     */
    protected function twig()
    {
        return SaeDigital::make('twig');
    }

    /**
     * @param $file
     * @param array $data
     * @throws Twig_Error_Loader
     * @throws Twig_Error_Runtime
     * @throws Twig_Error_Syntax
     */
    protected function twigRender($file, array $data = [])
    {
        $this->layout = false;

        echo $this->twig()->render($file, $data);
    }

    /**
     * @param array $body
     * @param int $statusCode
     */
    protected function responseJson(array $body, $statusCode = 200)
    {

        header('Content-Type: application/json');
        http_response_code($statusCode);

        $this->layout = false;

        echo json_encode($body);
    }


    /**
     * @param int|array $profiles
     * @return bool
     */
    protected function allowProfile($profiles)
    {
        if (!is_array($profiles)) {
            $profiles = (array)$profiles;
        }

        $myProfile = $this->session->userdata('perfil');

        if (!in_array($myProfile, $profiles)) {
            if ($myProfile == Perfil::ALUNO) {
                $this->redirect('/aluno');
                die;
            } else if ($myProfile == Perfil::RESPONSAVEL) {
                $this->redirect('/responsavel');
                die;
            } else if ($myProfile == Perfil::PROFESSOR) {
                $this->redirect('/professor');
                die;
            } else if ($myProfile == Perfil::COORDENADOR) {
                $this->redirect('/coordenador');
                die;
            } else {
                throw new NotAllowedException("Access denied for this page", 403);
            }
        }

        return true;
    }

    protected function allowAuthorization($hash)
    {
        $hash = trim(str_replace(['Bearer', 'bearer', 'Bearer:', 'bearer:'], '', $hash));
        $headers = $this->input->request_headers();

        if (!isset($headers['Authorization']) || $headers['Authorization'] !== $hash) {
            throw new \Exception("Access denied for this page", 403);
        }

        return true;
    }


    /**
     * Redirect page
     * @param string $route
     *
     * @return void
     */
    protected function redirect($route)
    {
        $this->layout = false;

        header("location: " . $route);
    }

    protected function getJsonRequestData()
    {
        return \GuzzleHttp\json_decode(trim($this->input->raw_input_stream), true);
    }
}
