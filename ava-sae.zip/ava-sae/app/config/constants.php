<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0755);

/*
Buckets S3 - Entregavel dos PDS
*/
define('PDFS', 'http://avasae.s3-website-sa-east-1.amazonaws.com/pdf');
define('SIMULADO_CONDICOES', 'http://avasae.s3-website-sa-east-1.amazonaws.com/simulado/2017/simulado-enem-2017-condicoes.pdf');
define('SIMULADO_INSCRICAO', 'http://bit.ly/simuladosaedigital');
define('SIMULADO_HOTSITE', 'http://bit.ly/simu2017saedigital');
define('SIMULADO_CALENDARIO', 'http://bit.ly/2vm7IIm');

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ', 'rb');
define('FOPEN_READ_WRITE', 'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE', 'ab');
define('FOPEN_READ_WRITE_CREATE', 'a+b');
define('FOPEN_WRITE_CREATE_STRICT', 'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
define('EXIT_SUCCESS', 0); // no errors
define('EXIT_ERROR', 1); // generic error
define('EXIT_CONFIG', 3); // configuration error
define('EXIT_UNKNOWN_FILE', 4); // file not found
define('EXIT_UNKNOWN_CLASS', 5); // unknown class
define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
define('EXIT_USER_INPUT', 7); // invalid user input
define('EXIT_DATABASE', 8); // database error
define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code

/*
 | Constants Gerais de Sistema que não mudam conforme o ambiente development,testing e production
 */

define('VERSIONCSSCDN','6.7');
define('VERSIONJSCDN','V14.6.2');

// Formatador string.
define("STR_REDUCE_LEFT", 1);
define("STR_REDUCE_RIGHT", 2);
define("STR_REDUCE_CENTER", 4);


// Player
define('KEY_PLAYER', 'N0vOpl@Y3er');
define('KEY_QUESTOES', '24773cdf9e1130980ca7f25cb0791dd6');

//900 = Número em segundos em 15 minutos
define('TEMPO_MEMCACHED', 900);

define('CLEAN_SESSION_TOKEN', "AxD87WEbaSI@w546#C%");
define('COLEGIO_SANTO_ANJO', '6a05926dc211749512f0eb22f2266f18');
define('DOM_BOSCO_BALSAS', 'dae1e5d16ceecbbc14586bb1b8a9b418');


define('ZENDESK_ESCOLAS_TESTE', '-' . COLEGIO_SANTO_ANJO . '-' . DOM_BOSCO_BALSAS . '-'
    . '6b32cb21-b81a-492c-a8af-f04de16595eb' . '-'
);

if (!defined('PERFIL_RESPONSAVEL')) {
    define('PERFIL_RESPONSAVEL', 274);
}
if (!defined('PERFIL_ALUNO')) {
    define('PERFIL_ALUNO', 273);
}
if (!defined('PERFIL_PROFESSOR')) {
    define('PERFIL_PROFESSOR', 272);
}
if (!defined('PERFIL_COORDENADOR')) {
    define('PERFIL_COORDENADOR', 271);
}
if (!defined('PERFIL_DIRETOR')) {
    define('PERFIL_DIRETOR', 270);
}
if (!defined('PERFIL_ESCOLA')) {
    define('PERFIL_ESCOLA', 269);
}
if (!defined('PERFIL_INFORMATIVO_ERROS')) {
    define('PERFIL_INFORMATIVO_ERROS', 290);
}


if (!defined('TIPO_VIDEO')) {
    define('TIPO_VIDEO', 'N');
}

define('ZENDESK_ESCOLAS_TESTE_ARRAY', 
	serialize (array (
		"6a05926dc211749512f0eb22f2266f18", //Santo anjo
		"dae1e5d16ceecbbc14586bb1b8a9b418", // Dom bosco balsas
		"e45599e00bb5c97641e1607d07fb15b9", // Menino Jesus
		"84119065c175ad4aec23f40d8025d2fa", //Coperil
		"87ce23f70bc64f32a364ed0d29b97ac9", //Lazi
		"ccaaf2e04926482e3fb644c47c1ef321"  //Unica master
	))
);

/*
 * AWS CONFIG
 */
define('AWS_DEFAULT_REGION', env('AWS_DEFAULT_REGION', ''));
define('AWS_DEFAULT_BUCKET', env('AWS_DEFAULT_BUCKET', ''));
define('AWS_DEFAULT_PATH_IMAGE_QUESTIONS', 'avasae/images/questions/');

if (!defined('DS')) {
    define('DS', DIRECTORY_SEPARATOR);
}

if (!defined('TMP')) {
    define('TMP', dirname(__DIR__) . DS . 'tmp' . DS) ;
}
