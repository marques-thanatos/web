<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Minify
*
* Author: Slawomir Jasinski
*		  slav123@gmail.com
*         @slavomirj
*
* Location: http://www.spidersoft.com.au/projects/codeigniter-minify/
 *          https://github.com/slav123/CodeIgniter-minify origin
*
* Created:  07.02.2011
*
* Description:
*
*/

$config['assets_dir'] = base_url() . '/assets';
$config['css_dir'] = 'public/css';
$config['js_dir'] = 'public/js';

/* End of file minify.php */
/* Location: ./application/config/minify.php */
