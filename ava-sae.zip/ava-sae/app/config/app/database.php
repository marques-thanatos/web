<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the 'Database Connection'
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['dsn']      The full DSN string describe a connection to the database.
|	['hostname'] The hostname of your database server.
|	['username'] The username used to connect to the database
|	['password'] The password used to connect to the database
|	['database'] The name of the database you want to connect to
|	['dbdriver'] The database driver. e.g.: mysqli.
|			Currently supported:
|				 cubrid, ibase, mssql, mysql, mysqli, oci8,
|				 odbc, pdo, postgre, sqlite, sqlite3, sqlsrv
|	['dbprefix'] You can add an optional prefix, which will be added
|				 to the table name when using the  Query Builder class
|	['pconnect'] TRUE/FALSE - Whether to use a persistent connection
|	['db_debug'] TRUE/FALSE - Whether database errors should be displayed.
|	['cache_on'] TRUE/FALSE - Enables/disables query caching
|	['cachedir'] The path to the folder where cache files should be stored
|	['char_set'] The character set used in communicating with the database
|	['dbcollat'] The character collation used in communicating with the database
|				 NOTE: For MySQL and MySQLi databases, this setting is only used
| 				 as a backup if your server is running PHP < 5.2.3 or MySQL < 5.0.7
|				 (and in table creation queries made with DB Forge).
| 				 There is an incompatibility in PHP with mysql_real_escape_string() which
| 				 can make your site vulnerable to SQL injection if you are using a
| 				 multi-byte character set and are running versions lower than these.
| 				 Sites using Latin-1 or UTF-8 database character set and collation are unaffected.
|	['swap_pre'] A default table prefix that should be swapped with the dbprefix
|	['encrypt']  Whether or not to use an encrypted connection.
|	['compress'] Whether or not to use client compression (MySQL only)
|	['stricton'] TRUE/FALSE - forces 'Strict Mode' connections
|							- good for ensuring strict SQL while developing
|	['failover'] array - A array with 0 or more data for connections if the main should fail.
|	['save_queries'] TRUE/FALSE - Whether to "save" all executed queries.
| 				NOTE: Disabling this will also effectively disable both
| 				$this->db->last_query() and profiling of DB queries.
| 				When you run a query, with this setting set to TRUE (default),
| 				CodeIgniter will store the SQL statement for debugging purposes.
| 				However, this may cause high memory usage, especially if you run
| 				a lot of SQL queries ... disable this to avoid that problem.
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the 'default' group).
|
| The $query_builder variables lets you determine whether or not to load
| the query builder class.
*/

$active_group = 'ava';
$active_record = true;

// MYSQL do Novo Banco (Substituição do SimpleDB)
$db['avaMySQL'] = [
    'dsn'	       => env('DB_DEFAULT_DNS', ''),
    'hostname'     => env('DB_DEFAULT_HOSTNAME', 'localhost'),
    'username'     => env('DB_DEFAULT_USERNAME', 'username'),
    'password'     => env('DB_DEFAULT_PASSWORD', 'password'),
    'database'     => env('DB_DEFAULT_DATABASE', 'database'),
    'dbdriver'     => env('DB_DEFAULT_DRIVER', 'mysqli'),
    'dbprefix'     => env('DB_DEFAULT_PREFIX', ''),
    'pconnect'     => env('DB_DEFAULT_PCONNECT', false),
    'db_debug'     => env('DB_DEFAULT_DEBUG', true),
    'cache_on'     => env('DB_DEFAULT_CACHE_ON', false),
    'cachedir'     => env('DB_DEFAULT_CACHE_DIR', ''),
    'char_set'     => env('DB_DEFAULT_CHAR_SET', 'utf8'),
    'dbcollat'     => env('DB_DEFAULT_COLLAT', 'utf8_unicode_ci'),
    'swap_pre'     => env('DB_DEFAULT_SWAP_PRE', ''),
    'encrypt'      => env('DB_DEFAULT_ENCRYPT', false),
    'compress'     => env('DB_DEFAULT_COMPRESS', false),
    'stricton'     => env('DB_DEFAULT_STRICTON', false),
    'failover'     => env('DB_DEFAULT_FAILOVER', []),
    'save_queries' => env('DB_DEFAULT_SAVE_QUERIES', true),
];
$db['ava'] = $db['avaMySQL'];

// MYSQL para registro de usuarios online
$db['logAcesso'] = [
    'dsn'	       => env('DB_LOG_DNS', ''),
    'hostname'     => env('DB_LOG_HOSTNAME', 'localhost'),
    'username'     => env('DB_LOG_USERNAME', 'username'),
    'password'     => env('DB_LOG_PASSWORD', 'password'),
    'database'     => env('DB_LOG_DATABASE', 'database'),
    'dbdriver'     => env('DB_LOG_DRIVER', 'mysqli'),
    'dbprefix'     => env('DB_LOG_PREFIX', ''),
    'pconnect'     => env('DB_LOG_PCONNECT', false),
    'db_debug'     => env('DB_LOG_DEBUG', true),
    'cache_on'     => env('DB_LOG_CACHE_ON', false),
    'cachedir'     => env('DB_LOG_CACHE_DIR', ''),
    'char_set'     => env('DB_LOG_CHAR_SET', 'utf8'),
    'dbcollat'     => env('DB_LOG_COLLAT', 'utf8_unicode_ci'),
    'swap_pre'     => env('DB_LOG_SWAP_PRE', ''),
    'encrypt'      => env('DB_LOG_ENCRYPT', false),
    'compress'     => env('DB_LOG_COMPRESS', false),
    'stricton'     => env('DB_LOG_STRICTON', false),
    'failover'     => env('DB_LOG_FAILOVER', []),
    'save_queries' => env('DB_LOG_SAVE_QUERIES', true),
];

$db['avaMySQLQuestoes'] = [
    'dsn'	       => env('DB_QUESTOES_DNS', ''),
    'hostname'     => env('DB_QUESTOES_HOSTNAME', 'localhost'),
    'username'     => env('DB_QUESTOES_USERNAME', 'username'),
    'password'     => env('DB_QUESTOES_PASSWORD', 'password'),
    'database'     => env('DB_QUESTOES_DATABASE', 'database'),
    'dbdriver'     => env('DB_QUESTOES_DRIVER', 'mysqli'),
    'dbprefix'     => env('DB_QUESTOES_PREFIX', ''),
    'pconnect'     => env('DB_QUESTOES_PCONNECT', false),
    'db_debug'     => env('DB_QUESTOES_DEBUG', true),
    'cache_on'     => env('DB_QUESTOES_CACHE_ON', false),
    'cachedir'     => env('DB_QUESTOES_CACHE_DIR', ''),
    'char_set'     => env('DB_QUESTOES_CHAR_SET', 'utf8'),
    'dbcollat'     => env('DB_QUESTOES_COLLAT', 'utf8_unicode_ci'),
    'swap_pre'     => env('DB_QUESTOES_SWAP_PRE', ''),
    'encrypt'      => env('DB_QUESTOES_ENCRYPT', false),
    'compress'     => env('DB_QUESTOES_COMPRESS', false),
    'stricton'     => env('DB_QUESTOES_STRICTON', false),
    'failover'     => env('DB_QUESTOES_FAILOVER', []),
    'save_queries' => env('DB_QUESTOES_SAVE_QUERIES', true),
];
