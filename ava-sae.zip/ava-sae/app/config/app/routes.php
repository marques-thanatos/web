<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$rota = 'login';
$route['default_controller'] = $rota;
$route['sair'] = "login/sair";

//$route['dev'] = "login/index_dev";

// controle de acessos.
$route['logoutControleAcesso'] = 'login/logoutControleAcesso';

//$route[$ind] = $rota;

$route['materialadicional'] = "materialadicional/index";
$route['materialadicional/incluirmaterial'] = "materialadicional/uploadMaterialAdicional";
$route['materialadicional/download/(:any)'] = "materialadicional/download/$1";
$route['preparatorio'] = "preparatorio/index/$1";
$route['preparatorio/(:any)'] = "preparatorio/index/$1";
$route['preparatorio/(:any)/(:any)'] = "preparatorio/video/$1";
$route['preparatorio/(:any)/(:any)/(:any)/(:any)'] = "preparatorio/video/$1/$2/$3/$4";
$route['preparatorio/(:any)/(:any)/(:any)/(:any)/(:any)'] = "preparatorio/video/$1/$2/$3/$4/$5";
$route['preparatorio/buscaAulasDisciplinas'] = "preparatorio/buscaAulasDisciplinas";
$route['preparatorio/download/pdf/(:any)'] = "preparatorio/download/$1";

$route['curso-plataforma-literaria/(:any)'] = "curso/index/$1";
$route['curso-plataforma-literaria/questoes_discursivas_aluno/(:any)/(:any)/(:any)'] = "cursoplataformaliteraria/questoesDiscursivasAluno/$1/$2/$3";
$route['literaria/buscaAulasDisciplinas'] = "cursoplataformaliteraria/buscaAulasDisciplinas";
$route['literaria/salvaQuestoesDiscursivas'] = "cursoplataformaliteraria/salvaQuestoesDiscursivas";
$route['literaria/salvarRespostaDiscursivasAluno'] = "cursoplataformaliteraria/salvarRespostaDiscursivasAluno";
$route['relatorio-plataforma/buscarAssuntoPorAluno'] = "relatorioPlataformaLiteraria/buscarAssuntoPorAluno";
$route['relatorio-plataforma/buscarAssuntoPorTurma'] = "relatorioPlataformaLiteraria/buscarAssuntoPorTurma";
$route['relatorio-plataforma/exportar/(:any)/(:any)'] = "relatorioPlataformaLiteraria/exportarRelatorio/$1/$2";
$route['relatorio-plataforma/exportar-aluno/(:any)/(:any)'] = "relatorioPlataformaLiteraria/exportarRelatorioAluno/$1/$2";

// Verificar para demais ambientes antes de subir
$route['reforco/(:any)/(:any)'] = "reforco/video/$1";
$route['reforco/(:any)/(:any)/(:any)/(:any)'] = "reforco/video/$1/$2/$3/$4";
$route['reforco/(:any)/(:any)/(:any)/(:any)/(:any)'] = "reforco/video/$1/$2/$3/$4/$5";
$route['reforco/(:any)'] = "reforco/index/$1";

$route['curso/responderQuestao'] = "curso/responderQuestao";
$route['reforco/responderQuestao'] = "reforco/responderQuestao";
$route['curso/salva-agendamento'] = "curso/salvaAgendamento";
$route['curso/carrega-modal-agendamento'] = "curso/carregarModalAgendamento";
$route['curso/carrega-modal-agendamento-alunos'] = "curso/carregarModalAgendamentoAlunos";
$route['curso/removeAgendamentos'] = "curso/removeAgendamentos";
$route['curso/notificacao'] = "curso/notificacao";
$route['curso/verificaAtingiuMeta'] = "curso/verificaAtingiuMeta";
$route['curso/logVideoSeek'] = "curso/logVideoSeek";
$route['curso/logCloseTab'] = "curso/logCloseTab";
$route['curso/logEndedVideo'] = "curso/logEndedVideo";
$route['curso/salva-agendamento-alunos'] = "curso/salvaAgendamentoAlunos";
$route['curso/remover-agendamento-aluno'] = 'curso/removerAgendamento';

$route['paramsContentQuestao/curso/(:any)/(:any)/(:any)/(:any)/(:any)'] = "curso/paramsContentQuestao/$1/$2/$3/$4/$5";
$route['paramsContentVideo/(:any)/(:any)/(:any)/(:any)/(:any)'] = "curso/paramsContentVideo/$1/$2/$3/$4/$5";

$route['paramsContentQuestao/preparatorio/(:any)/(:any)/(:any)/(:any)/(:any)'] = "preparatorio/paramsContentQuestao/$1/$2/$3/$4/$5";
$route['paramsContentVideoPrep/(:any)/(:any)/(:any)/(:any)/(:any)'] = "preparatorio/paramsContentVideo/$1/$2/$3/$4/$5";

// Verificar para demais ambientes antes de subir
$route['paramsContentQuestao/reforco/(:any)/(:any)/(:any)/(:any)/(:any)'] = "reforco/paramsContentQuestao/$1/$2/$3/$4/$5";
$route['paramsContentVideo/(:any)/(:any)/(:any)/(:any)/(:any)'] = "reforco/paramsContentVideo/$1/$2/$3/$4/$5";

$route['videoSmil/(:any)'] = "curso/videoSmil/$1";
$route['downloadPDF/(:any)'] = "curso/downloadPDF/$1";
$route['downloadPDFPrep/(:any)/(:any)'] = "preparatorio/downloadPDF/$1/$2";
$route['downloadPDFPrepAjax/(:any)/(:any)'] = "preparatorio/downloadPDFAjax/$1/$2";
$route['minhaConta'] = "login/minhaConta";
$route['minhaConta/(:any)'] = "login/minhaConta/$1";
$route['minhasAnotacoes/(:any)'] = "curso/minhasAnotacoes/$1";
$route['baixarAnotacoes'] = "curso/baixarAnotacoes";
$route['exportarAnotacoes'] = "curso/exportarAnotacoes";
$route['busca'] = "curso/buscar";
$route['busca/(:any)'] = "curso/buscar/$1";
$route['resultadoBusca/(:any)'] = "curso/resultadoBusca/$1";
$route['listaVideoAulasDisciplina'] = "curso/listaVideoAulasDisciplina";
$route['ajuda/(:any)'] = "ajuda/$1";
$route['finalizarVideoAula'] = "preparatorio/finalizarVideoAula";
$route['tutorial-portalava'] = "ajuda/tutorialPortalava";
$route['questoes-e-simulados'] = "curso/questoesEsimulados";
$route['esqueceu-senha'] = "login/index";
$route['relatorios'] = "relatorio/index";
$route['cadastro'] = "cadastro/index";
$route['cadastro/questoes_discursivas'] = "cadastro/questoes_discursivas";
$route['cadastro/questoes_discursivas_lista/(:any)/(:any)/(:any)'] = "cadastro/questoes_discursivas_lista/$1/$2/$3";
$route['cadastro/questoes_discursivas_cadastro/(:any)'] = "cadastro/questoes_discursivas_cadastro/$1";
$route['cadastro/salvarEscola'] = "cadastro/salvarEscola";
$route['cadastro/buscaQuestaoDiscursivaPorTurma'] = "cadastro/buscaQuestaoDiscursivaPorTurma";
$route['cadastro/salvarDiretor'] = "cadastro/salvarDiretor";
$route['cadastro/salvarTurma'] = "cadastro/salvarTurma";
$route['cadastro/disciplinaExclusiva'] = "cadastro/disciplinaExclusiva";
$route['cadastro/verificaEscolasExclusivas'] = "cadastro/verificaEscolasExclusivas";
$route['cadastro/salvarDisciplina'] = "cadastro/salvarDisciplina";
$route['cadastro/cadastroLogin/(:any)'] = "cadastro/cadastroLogin/$1";
$route['cadastro/comboLimite'] = "cadastro/comboLimite";
$route['cadastro/central-marretas'] = "cadastro/centralMarretaz";
$route['cadasto/correcaoAtividades/(:any)/(:any)/(:any)/(:any)'] = 'cadastro/correcaoAtividades/$1/$2/$3/$4';

$route['aluno/(:any)'] = "aluno/index/$1";
$route['professor/componente-curricular'] = "home/index";
$route['professor/plataforma-literaria'] = "home/index";
$route['professor/audio-lingua-estrangeira'] = "home/index";
$route['professor/arrase-no-enem'] = "preparatorio/index";
// $route['coordenador'] = "home/index";
$route['professor/(:any)'] = "home/index/$1";
$route['professor/plataforma-literaria/(:any)'] = "home/index/$1";
$route['professor/audio-lingua-estrangeira/(:any)'] = "home/index/$1";
$route['professor/arrase-no-enem/(:any)'] = "home/index/$1";
$route['coordenador/(:any)'] = "home/index/$1";
$route['agendamento'] = "agendamento/index";
$route['agendamento/(:any)'] = "agendamento/index/$1";
$route['responsavel'] = "responsavel/index";

$route['api-video'] = "curso/carregavideo";
$route['translate_uri_dashes'] = false;
$route['material-adicional-disciplinas'] = "curso/materialAdicionalDisciplinas";
$route['calendario-por-semana'] = "curso/calendarioPorSemana";
$route['salva-calendario-por-semana'] = "curso/salvaCalendarioPorSemana";
$route['informar-erro'] = "informarerro";

//Rotas WebServices
// $route['ws'] = "ws/getAlterarSenha/index";
// $route['ws/alterasenha'] = "ws/getAlterarSenha/index";
// $route['ws/cadastrarescola'] = "ws/getCadastroEscola/index";
// $route['ws/cadastrarturma'] = "ws/getCadastroTurma/index";
// $route['ws/cadastraraluno'] = "ws/getCadastroAluno/index";
// $route['ws/loginsistema'] = "ws/LoginSistema/index";
// $route['ws/enviarNotificacaoPush'] = "ws/EnviarNotificacaoPush/index";

$route['publico/zendeskNotificationHook']['post'] = 'tickets/zendeskNotificationHook';

$route['alteracaosenha'] = "cadastro/AlteracaoSenha";

$route['tickets/add-comment'] = "tickets/addTicketComment/";
$route['mural/tickets/(:any)'] = "tickets/TicketView/$1";
$route['mural/tickets'] = "tickets/ListTicketsView";
$route['mural'] = "mensagemsae/MuralRecados";
$route['mural/lista'] = "mensagemsae/MuralRecados";
$route['mural/lista/(:any)'] = "mensagemsae/MuralRecados/$1";
$route['mural/read/(:any)'] = "mensagemsae/LendoMensagem/$1";
$route['mural/erros'] = "mensagemsae/ListaErros";
$route['mural/erros/(:any)'] = "mensagemsae/ListaErros/$1";
$route['mural/triagem'] = "mensagemsae/TriagemErros";
$route['mural/triagem/(:any)'] = "mensagemsae/TriagemErros/$1";
$route['mural/concluidos'] = "mensagemsae/ErrosConcluidos";
$route['mural/dashboard'] = "mensagemsae/Dashboard";

$route['mural/erros/exportacao'] = "mensagemsae/Exportacao";
$route['mural/erros/exportacao_geral'] = "mensagemsae/ExportacaoGeral";

$route['log'] = "log/RelatorioLog";

$route['central'] = "ConsultaQuestoes/index";
$route['central/lista'] = "ConsultaQuestoes/principal";
$route['central/similares'] = "ConsultaQuestoes/similares";
$route['central/prof'] = "ConsultaQuestoes/professores";
// Portalava para criação da plataforma literária
$route['central/portalava_pl'] = "ConsultaQuestoes/portalava";
$route['central/portalava_jarvis'] = "ConsultaQuestoes/portalavaJarvis";
$route['questoes/(:any)'] = "ConsultaQuestoes/questao/$1";
$route['questoes/(:any)/(:any)'] = "ConsultaQuestoes/questao/$1/$2";
//$route['marreta/(:any)'] = "ConsultaQuestoes/marreta/$1";
$route['RelacaoAula/(:any)'] = "ConsultaQuestoes/RelacaoAula/$1";
$route['AssuntoQuestoes/(:any)'] = "ConsultaQuestoes/RelatorioQuestaoAssunto/$1";
//$route['importar/(:any)'] = "ConsultaQuestoes/insereEstruturasSae/$1";
//$route['importar_old/(:any)'] = "ConsultaQuestoes/insereEstruturasSae2/$1";



$route['qrcode'] = "ConsultaQuestoes/InsereQRCode";
$route['qrcode/cadastro'] = "ConsultaQuestoes/InsereQRCode";
$route['qrcode/listagem'] = "ConsultaQuestoes/ListaQRCode";
$route['qrcode/obter/(:any)'] = "Api/QRCode/getQRCodeLink/$1";

$route['central/disciplinas'] = 'ConsultaQuestoes/getDisciplinas';
$route['central/disciplinas/create'] = 'ConsultaQuestoes/novaDisciplina';
$route['central/disciplinas/store'] = 'ConsultaQuestoes/salvarDisciplina';
$route['central/disciplinas/serie'] = 'ConsultaQuestoes/pegaDisciplinasSerie';

$route['central/bimestres/move-assunto'] = 'ConsultaQuestoes/moverAssuntoPorBimestre';
$route['central/bimestres/move-assunto-update'] = 'ConsultaQuestoes/moverAssuntoPorBimestreUpdate';

$route['relatorio/relatorio-escola-up'] = "ConsultaQuestoes/relatorioExclusivoColegioUP";
$route['relatorio/exportarColegioUP'] = "ConsultaQuestoes/exportarRelatorioExclusivoColegioUP";
$route['relatorio/gerarXLSExclusivo'] = "ConsultaQuestoes/gerarXLSExclusivo";
$route['relatorio/exportacao/(:any)/(:any)/(:any)'] = "Relatorio/ExportacaoRelatorio/$1/$2/$3";
$route['relatorio/exportar-geral/(:any)/(:any)/(:any)'] = "Relatorio/ExportacaoRelatorioGeral/$1/$2/$3";
$route['relatorio/exportacaoDiarioAluno/(:any)/(:any)'] = "Relatorio/ExportacaoRelatorioAlunoDiario/$1/$2";

$route['simulado-2017/aluno'] = "Simulado/homeAluno";
$route['simulado-2017/professor'] = "Simulado/homeProfessor";
$route['simulado-2017/coordenador'] = "Simulado/homeCoordenador";
$route['simulado-2017/diretor'] = "Simulado/homeDiretor";
$route['simulado-2017/responsavel'] = "Simulado/homeResponsavel";

$route['versoes-estruturas'] = "VersoesEstruturas/index";
$route['versoes-estruturas/cadastrar'] = "VersoesEstruturas/create";
$route['versoes-estruturas/editar'] = "VersoesEstruturas/edit";
$route['versoes-estruturas/store'] = "VersoesEstruturas/store";
$route['versoes-estruturas/update'] = "VersoesEstruturas/update";
$route['versoes-estruturas/troca-status'] = "VersoesEstruturas/toggleStatus";
$route['versoes-estruturas/json/list'] = "VersoesEstruturas/getAll";
$route['versoes-estruturas/migrate-from-jarvis'] = "VersoesEstruturas/migrateFromJarvis";

$route['cadastro/ativar-zendesk'] = "cadastro/cadastrarProva";
$route['cadastro/ativar-zendesk'] = "cadastro/consultaGruposQuestoes";

$route['cadastro/buscar-series-por-segmento-escola']['get'] = "cadastro/seriesPorSegmentoEscolar";
$route['cadastro/migrar-alunos'] = "cadastro/migrarAlunos";
$route['cadastro/inativar-alunos'] = "cadastro/inativarAlunos";
$route['cadastro/exportar-turma'] = "cadastro/exportarTurma";
$route['cadastro/busca-alunos-turma'] = "cadastro/buscaAlunosTurma";
$route['cadastro/imagem'] = "cadastro/cadastrarImagem";
$route['livrodigital/buscar-links-livro-digital'] = "livrodigital/buscarLinksLivroDigital";
$route['jarvis/show-item']['post'] = "jarvis/showItem";


/* ROTAS USUÁRIOS DEMONSTRATIVOS */
$route['demonstravio/usuarios']['get'] = "Demonstrativo/indexAction";
$route['demonstravio/usuarios/novo']['get'] = "Demonstrativo/newAction";
$route['demonstravio/usuarios/salvar']['post'] = "Demonstrativo/storeAction";
$route['demonstravio/usuarios/preview']['get'] = "Demonstrativo/previewAction";
$route['demonstravio/usuarios/export']['get'] = "Demonstrativo/exportAction";
$route['demonstravio/usuarios/delete']['get'] = "Demonstrativo/deleteAction";

//Rotas API
$route['jarvis/versions']['get'] = "jarvisSync/VersionsJarvis/index";
$route['jarvis/modules']['get'] = "jarvisSync/ModulesJarvis/index";
$route['jarvis/modules/(:any)']['get'] = "jarvisSync/ModulesJarvis/get/$1";
$route['jarvis/series']['get'] = "jarvisSync/SeriesJarvis/index";
$route['jarvis/disciplines']['get'] = "jarvisSync/DisciplinesJarvis/index";
$route['saenotifica/relatorio']['get'] = "Relatorio/relatorioNotifica";
$route['curso/answer-structure']['post'] = "Curso/gerarEstrutura";
$route['api/corrigeBugEstruturaPorAssunto']['get'] = "Curso/corrigeBugEstruturaPorAssunto";

$route['cadastro/tokens'] = 'cadastro/tokens';
$route['tokens/list'] = 'ApiAuthToken/listTokens';
$route['tokens/create']['post'] = 'ApiAuthToken/createToken';
$route['tokens/delete/(:any)'] = 'ApiAuthToken/deleteToken/$1';

$route['cadastro/escolamovimento'] = 'cadastro/escolaMovimento';
$route['escolaemovimento/list']['get'] = 'escolaEmovimento/listToken';
$route['escolaemovimento/delete']['get'] = 'escolaEmovimento/deleteToken';
$route['escolaemovimento/save']['post'] = 'escolaEmovimento/saveToken';
$route['escolaemovimento/turmas']['get'] = 'escolaEmovimento/listTurmas';
$route['escolaemovimento/alunos/(:any)']['get'] = "escolaEmovimento/listAlunos/$1";
$route['escolaemovimento/savealunos']['post'] = 'escolaEmovimento/saveAlunos';

$route['aula-ao-vivo']['get'] = 'AulaAoVivo/index';
$route['escola-digital']['get'] = 'EscolaDigital/index';
$route['professor']['get'] = 'PastaDoProfessor/index';
$route['coordenador']['get'] = 'SalaCoordenacao/index';
// $route['pasta-do-professor']['get'] = 'PastaDoProfessor/index';
$route['mochila-do-aluno']['get'] = 'MochilaDoAluno/index';

// Rotas nova API
$route['api/mochila']['post'] = "Api/RelatorioHome/mochilaAluno";
$route['api/pasta']['post'] = "Api/RelatorioHome/pastaProfessor";
$route['api/mochila']['get'] = "Api/RelatorioHome/mochilaAluno";
$route['api/pasta']['get'] = "Api/RelatorioHome/pastaProfessor";
$route['api/terms']['post'] = "Api/AcceptTermController/index";

$route['api/consolidate-teams-data']['get'] = "Api/RelatorioHome/consolidate";

$route['plataforma-literaria']['get'] = 'RedirectController/plataformaLiteraria';
$route['audios-lingua-estrangeira']['get'] = 'RedirectController/audiosLinguaEstrangeira';
$route['arrase-no-enem']['get'] = 'RedirectController/arraseNoEnem';

$route['api/docs']['get'] = 'Api/IndexController/index';
$route['loginNextAva']['post'] = 'Login/loginNextAva';
$route['api/swagger.json']['get'] = 'Api/IndexController/swaggerJson';
$route['api/grades']['get'] = 'Api/GradesController/index';
$route['api/curricular-components']['get'] = 'Api/CurricularComponentsController/index';
$route['api/curricular-components/(:num)/modules']['get'] = 'Api/CurricularComponentsController/showModules/$1';
$route['api/teams']['get'] = 'Api/TeamsController/index';
$route['api/students/teams']['get'] = 'Api/Students/TeamController/index';
$route['api/students/curricular-components']['get'] = 'Api/Students/CurricularComponentsController/index';
$route['api/students/schedules']['get'] = 'Api/Students/SchedulesController/index';
$route['api/schedules']['post'] = 'Api/SchedulesController/create';
$route['api/schedules/verify']['post'] = 'Api/SchedulesController/verifySchedules';
$route['api/schedules/(:any)']['get'] = 'Api/SchedulesController/index/$1';
$route['api/schedules/(:any)']['put'] = 'Api/SchedulesController/update/$1';
$route['api/schedules/updateSchedules']['post'] = 'Api/SchedulesController/updateSchedules';
$route['api/schedules/carregarModal']['get'] = 'Api/SchedulesController/carregarModal';
$route['api/schedules/(:any)']['delete'] = 'Api/SchedulesController/delete/$1';
$route['api/schedules/(:any)/(:any)/(:any)']['delete'] = 'Api/SchedulesController/deleteSchedule/$1/$2/$3';
$route['api/reports/teams']['get'] = 'Relatorio/buscarTurmas';
$route['api/reports/teams/(:any)/curricular-components']['get'] = 'Relatorio/buscarDisciplinasPorTurma/$1';
$route['api/reports/grades/(:any)/curricular-components']['get'] = 'Relatorio/buscarDisciplinasPorSerie/$1';
$route['api/calendar']['get'] = 'Api/CalendarController/index';
$route['api/library/videos']['get'] = 'Api/LibraryController/videos';
$route['api/library/escola-digital']['get'] = 'Api/EscolaDigitalController/index';
$route['api/health-check']['get'] = 'Api/HealthCheckController/index';
$route['portalprofessor/retornarUserFromItemName']['get'] = 'Login/retornarUserFromItemName';

// Rotas para os endpoints da nova página de componente curricular
$route['api/activities/(:any)/(:any)']['get'] = 'Api/TeacherActivitiesController/index/$1/$2';
$route['api/activity/(:any)/(:any)']['get'] = 'Api/TeacherActivitiesController/details/$1/$2';
$route['api/activities/(:any)']['get'] = 'Api/StudentActivitiesController/index/$1';
$route['api/activity/(:any)']['get'] = 'Api/StudentActivitiesController/details/$1';

$route['curso/(:any)'] = "curso/index/$1";
$route['curso/(:any)/(:any)'] = "curso/video/$1";
$route['curso/(:any)/(:any)/(:any)/(:any)'] = "curso/video/$1/$2/$3/$4";
$route['curso/(:any)/(:any)/(:any)/(:any)/(:any)'] = "curso/video/$1/$2/$3/$4/$5";
$route['curso/buscaAulasDisciplinas'] = "curso/buscaAulasDisciplinas";

// Aprova + | Trilhas Adaptativas
$route['aprova-mais']['get'] = 'AprovaMais/index'; // Home
$route['aprova-mais/trilha/(:any)']['get'] = 'AprovaMais/trilha/$1'; // Trilha
$route['aprova-mais/trilha/(:any)/(:any)']['get'] = 'AprovaMais/modulo/$1/$2'; // Módulo
$route['aprova-mais/trilha/(:any)/(:any)/(:any)']['get'] = 'AprovaMais/questoes/$1/$2/$3'; // Questões

// Aprova + Redação
$route['aprova-mais-redacao']['get'] = 'AprovaMaisRedacao/index'; // Home
$route['novocadastro/alunos']['get'] = 'NextAVA/Student/index';

// Ler e Produzir
$route['ler-produzir']['get'] = 'LerProduzir/index'; // Home

// Rotas públicas
$route['public/resetar-senha']['get'] = 'Pub/ResetPasswordUser';

$route['sso/(:any)']['get'] = "LoginSso/verifica/$1";