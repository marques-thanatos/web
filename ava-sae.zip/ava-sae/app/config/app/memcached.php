<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Memcached settings
| -------------------------------------------------------------------------
| Your Memcached servers can be specified below.
|
|	See: http://codeigniter.com/user_guide/libraries/caching.html#memcached
|
*/
$config = [
	'default' => [
		'hostname' => env('MEMCACHED_HOSTNAME', 'localhost'),
		'port'     => env('MEMCACHED_PORT', 11211),
		'weight'   => env('MEMCACHED_WEIGHT', 1)
    ]
];
