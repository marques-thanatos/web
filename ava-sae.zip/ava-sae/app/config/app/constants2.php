<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Constantes Sistema
define('ASSINATURASITEID', '5');
define('HOST', 'ava.portalsae.com.br'); //$_SERVER['HTTP_HOST']-'ava.portalsae.com.br'

define('LIGUE', ' Ligue (41) 2105 8769');
define('PATH_PDF', 'http://arquivoscdn.portalava.com.br/videos/aulas/');
define('PATH_BANNER', 'http://docs.aprovaconcursos.com.br/aprova/banners/');

// Caminho CSS
define('PATH_CSS_SITE', 'https://d1nbs4qq7l2vyp.cloudfront.net/master/public/css/');

// Caminho Imagens
define('PATH_IMG_SITE', 'https://d1nbs4qq7l2vyp.cloudfront.net/master/public/imagens/');
define('PATH_IMG_S3', "https://s3.sa-east-1.amazonaws.com/avasae/avasae/");

// Caminho Javascripts
define('PATH_JS_SITE', 'https://d1nbs4qq7l2vyp.cloudfront.net/master/public/js/');

//caminho api questoes
define('API', 'https://www.aprovaconcursos.com.br/questoes-de-concurso');

//chave player
define('KEY_LOGO_PLAYER_HTML5', '$142083526457949');
define('KEY_LOGO_PLAYER_FLASH', '#$6734ca2c670bd19c6de');

// API do player
define('PATH_API_PLAYER', 'https://player.iesde.com.br/');
define('USER_API_PLAYER', '1590e99c63d124e374345de71205ddb7c63a0b8d');
define('PASS_API_PLAYER', 'afb94979f63f3038b84344d7ac37febe39748167');

define('AMAZON_SIMPLEDB_ENVIRONMENT', 'us-east-1');

define('PATH_API_IESDE','https://api.iesde.com.br');
