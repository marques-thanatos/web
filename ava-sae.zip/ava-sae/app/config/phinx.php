<?php

use Dotenv\Dotenv;

define('ROOT_DIR', dirname(dirname(__DIR__)));

require_once ROOT_DIR . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';

$dotenv = new Dotenv(ROOT_DIR);
$dotenv->overload();

return [
    'paths' => [
        'migrations' => [
            ROOT_DIR . '/app/Migrations'
        ]
    ],
    'environments' => [
        'default_migration_table' => 'migrations',
        'default_database' => getenv('CI_ENV'),
        getenv('CI_ENV') => [
            'adapter' => 'mysql',
            'host' => getenv('DB_DEFAULT_HOSTNAME'),
            'name' => getenv('DB_DEFAULT_DATABASE'),
            'user' => getenv('DB_DEFAULT_USERNAME'),
            'pass' => getenv('DB_DEFAULT_PASSWORD'),
            'charset' => 'utf8',
            'collation' => 'utf8_unicode_ci'
        ]
    ]
];