<?php

namespace Ava\App\Entities;

use Ava\App\Collections\AlternativesCollection;

/**
 * Class QuestionEntity
 *
 * @package Ava\App\Entities
 */
class QuestionEntity extends AbstractEntity
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var int
     */
    private $question;

    /**
     * @var string
     */
    private $resume;

    /**
     * @var AlternativesCollection
     */
    private $alternatives;


    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }


    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }


    /**
     * @return int
     */
    public function getQuestion()
    {
        return $this->question;
    }


    /**
     * @param int $question
     *
     * @return $this
     */
    public function setQuestion($question)
    {
        $this->question = $question;

        return $this;
    }


    /**
     * @return string
     */
    public function getResume()
    {
        return $this->resume;
    }


    /**
     * @param string $resume
     *
     * @return $this
     */
    public function setResume($resume)
    {
        $this->resume = $resume;

        return $this;
    }


    /**
     * @return AlternativesCollection
     */
    public function getAlternatives()
    {
        return $this->alternatives;
    }


    /**
     * @param AlternativesCollection $alternatives
     *
     * @return $this
     */
    public function setAlternatives(AlternativesCollection $alternatives)
    {
        $this->alternatives = $alternatives;

        return $this;
    }
}
