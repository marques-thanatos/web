<?php

namespace Ava\App\Entities;

/**
 * Class AlternativeEntity
 *
 * @package Ava\App\Entities
 */
class AlternativeEntity extends AbstractEntity
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var string
     */
    private $option;

    /**
     * @var string
     */
    private $text;

    /**
     * @var bool
     */
    private $correct;


    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }


    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }


    /**
     * @return string
     */
    public function getOption()
    {
        return $this->option;
    }


    /**
     * @param string $option
     *
     * @return $this
     */
    public function setOption($option)
    {
        $this->option = $option;

        return $this;
    }


    /**
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }


    /**
     * @param string $text
     *
     * @return $this
     */
    public function setText($text)
    {
        $this->text = $text;

        return $this;
    }


    /**
     * @return bool
     */
    public function isCorrect()
    {
        return $this->correct;
    }


    /**
     * @param bool $correct
     *
     * @return $this
     */
    public function setCorrect($correct)
    {
        $this->correct = $correct;

        return $this;
    }
}
