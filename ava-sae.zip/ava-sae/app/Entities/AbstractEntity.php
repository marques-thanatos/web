<?php

namespace Ava\App\Entities;


abstract class AbstractEntity
{

}
