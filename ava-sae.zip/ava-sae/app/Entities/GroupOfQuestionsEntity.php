<?php

namespace Ava\App\Entities;

use Ava\App\Collections\QuestionsCollections;

/**
 * Class GroupOfQuestionsEntity
 *
 * @package Ava\App\Entities
 */
class GroupOfQuestionsEntity extends AbstractEntity
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var int
     */
    private $group;

    /**
     * @var QuestionsCollections
     */
    private $questions;


    /**
     * GroupOfQuestionsEntity constructor.
     */
    public function __construct()
    {
        $this->questions = new QuestionsCollections;
    }


    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }


    /**
     * @param int $id
     *
     * @return $this
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }


    /**
     * @return int
     */
    public function getGroup()
    {
        return $this->group;
    }


    /**
     * @param int $group
     *
     * @return $this
     */
    public function setGroup($group)
    {
        $this->group = $group;

        return $this;
    }


    /**
     * @return QuestionsCollections
     */
    public function getQuestions()
    {
        return $this->questions;
    }


    /**
     * @param QuestionsCollections $questions
     *
     * @return $this
     */
    public function setQuestions(QuestionsCollections $questions)
    {
        $this->questions = $questions;

        return $this;
    }
}
