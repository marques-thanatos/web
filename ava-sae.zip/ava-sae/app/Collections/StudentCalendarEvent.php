<?php

namespace Ava\App\Collections;

use DateTime;

/**
 * Class StudentCalendarEvent
 *
 * @package Ava\App\Collections
 */
class StudentCalendarEvent
{
    /**
     * @var $id string
     */
    private $id;

    /**
     * @var $title string
     */
    private $title;

    /**
     * @var $allDay string
     */
    private $allDay;

    /**
     * @var $start DateTime
     */
    private $start;

    /**
     * @var $end DateTime
     */
    private $end;

    /**
     * @var $options array
     */
    private $options = [];

    /**
     * @param string $title
     * @param string $allDay
     * @param string|DateTime $start
     * @param string|DateTime $end
     * @param int|string|null $id
     * @param array $options
     */
    public function __construct($title, $allDay, $start, $end, $id = null, array $options = [])
    {
        $this->title = $title;
        $this->allDay = $allDay;
        $this->start = $start instanceof DateTime ? $start : new DateTime($start);
        $this->end = $start instanceof DateTime ? $end : new DateTime($end);
        $this->id = $id;
        $this->options = $options;
    }

    /**
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @codeCoverageIgnore
     * @param string $id
     * @return StudentCalendarEvent
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @codeCoverageIgnore
     * @param string $title
     * @return StudentCalendarEvent
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * @return string
     */
    public function getAllDay()
    {
        return $this->allDay;
    }

    /**
     * @codeCoverageIgnore
     * @param string $allDay
     * @return StudentCalendarEvent
     */
    public function setAllDay($allDay)
    {
        $this->allDay = $allDay;

        return $this;
    }

    /**
     * @return DateTime
     */
    public function getStart()
    {
        return $this->start;
    }

    /**
     * @codeCoverageIgnore
     * @param DateTime $start
     * @return StudentCalendarEvent
     */
    public function setStart($start)
    {
        $this->start = $start;

        return $this;
    }

    /**
     * @return DateTime
     */
    public function getEnd()
    {
        return $this->end;
    }

    /**
     * @codeCoverageIgnore
     * @param DateTime $end
     * @return StudentCalendarEvent
     */
    public function setEnd($end)
    {
        $this->end = $end;

        return $this;
    }

    /**
     * @return array
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * @codeCoverageIgnore
     * @param array $options
     * @return StudentCalendarEvent
     */
    public function setOptions(array $options = [])
    {
        $this->options = $options;

        return $this;
    }

}
