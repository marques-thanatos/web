<?php

namespace Ava\App\Collections;

use Doctrine\Common\Collections\ArrayCollection;

/**
 * Class QuestionsCollections
 *
 * @package Ava\App\Collections
 */
class QuestionsCollections extends ArrayCollection
{

}
