<?php

namespace Ava\App\Collections;

use Illuminate\Support\Collection;

/**
 * Class StudentCalendarCollection
 *
 * @package Ava\App\Collections
 */
class StudentCalendarCollection
{

    /**
     * @var Collection
     */
    protected $events;

    public function __construct()
    {
        $this->events = new Collection();
    }

    /**
     * @param StudentCalendarEvent $event
     * @param array $attributes
     */
    public function push(StudentCalendarEvent $event, array $attributes = [])
    {
        $this->events->push($this->convertToArray($event, $attributes));
    }

    /**
     * @param StudentCalendarEvent $event
     * @param $attributes
     * @return array
     */
    private function convertToArray(StudentCalendarEvent $event, $attributes)
    {
        $arr = [
            'id' => $event->getId(),
            'title' => $event->getTitle(),
            'allDay' => $event->getAllDay(),
            'start' => $event->getStart()->format('c'),
            'end' => $event->getEnd()->format('c'),
            'options' => $event->getOptions()
        ];

        return array_merge($arr, $attributes);
    }

    /**
     * @return string
     */
    public function toJson()
    {
        return $this->events->toJson();
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return $this->events->toArray();
    }
}
