<?php

namespace Ava\App\Collections;

use Doctrine\Common\Collections\ArrayCollection;

/**
 * Class GroupOfQuestionsCollection
 *
 * @package Ava\App\Collections
 */
class GroupOfQuestionsCollection extends ArrayCollection
{

}
