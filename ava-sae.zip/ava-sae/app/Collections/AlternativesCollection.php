<?php

namespace Ava\App\Collections;

use Doctrine\Common\Collections\ArrayCollection;


/**
 * Class AlternativesCollection
 *
 * @package Ava\App\Collections
 */
class AlternativesCollection extends ArrayCollection
{

}
