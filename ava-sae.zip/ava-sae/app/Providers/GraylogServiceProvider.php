<?php


namespace Ava\App\Providers;


use Gelf\Publisher;
use Gelf\Transport\UdpTransport;

class GraylogServiceProvider extends AbstractServiceProvider
{
    /**
     * @return $this
     */
    public function boot()
    {
        $transport = new UdpTransport(
            env('GRAYLOG_ENDPOINT', 'graylog.sae.digital'),
            env('GRAYLOG_PORT', 12202),
            UdpTransport::CHUNK_SIZE_LAN
        );

        $publisher = new Publisher();
        $publisher->addTransport($transport);

        $this->getContainer()->share('Graylog', $publisher);

        return $this;
    }

    /**
     * @return $this
     */
    public function register()
    {
        return $this;
    }
}