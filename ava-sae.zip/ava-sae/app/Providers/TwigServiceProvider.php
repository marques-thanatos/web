<?php

namespace Ava\App\Providers;

use Twig_Environment;
use Twig_Loader_Filesystem;

/**
 * Class TwigServiceProvider
 *
 * @package Ava\App\Providers
 * @author Ronaldo Matos Rodrigues <ronaldo@whera.com.br>
 */
class TwigServiceProvider extends AbstractServiceProvider
{

    /**
     * @return $this
     */
    public function boot()
    {
        $loader = new Twig_Loader_Filesystem($this->getPathTemplates());

        $twig = new Twig_Environment($loader, [
            'cache' => false,
        ]);

        $this->getContainer()->share('twig', $twig);

        return $this;
    }

    /**
     * @return $this
     */
    public function register()
    {
        return $this;
    }

    /**
     * @return string
     */
    private function getPathTemplates()
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'views' . DIRECTORY_SEPARATOR . 'twig';
    }

    /**
     * @return string
     */
    private function getPathCache()
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'cache';
    }
}
