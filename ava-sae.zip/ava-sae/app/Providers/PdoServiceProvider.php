<?php

namespace Ava\App\Providers;

use PDO;

/**
 * Class PdoServiceProvider
 *
 * @package Ava\App\Providers
 * @author Ronaldo Matos Rodrigues <ronaldo@whera.com.br>
 */
class PdoServiceProvider extends AbstractServiceProvider
{

    private $config;

    public function boot()
    {
        $dsn = sprintf('mysql:host=%s;dbname=%s', $this->getConfig()->hostname, $this->getConfig()->database);

        $dbh = new PDO(
            $dsn,
            $this->getConfig()->username,
            $this->getConfig()->password,
            [PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"]
        );
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->getContainer()->share(PDO::class, $dbh);

        return $this;
    }

    /**
     * @return $this
     */
    public function register()
    {
        return $this;
    }

    /**
     * @return object
     */
    protected function getConfig()
    {
        $this->config = (object) [
            'username' => getenv('DB_DEFAULT_USERNAME'),
            'password' => getenv('DB_DEFAULT_PASSWORD'),
            'hostname' => getenv('DB_DEFAULT_HOSTNAME'),
            'database' => getenv('DB_DEFAULT_DATABASE')
        ];

        return $this->config;
    }
}
