<?php


namespace Ava\App\Providers;

use Illuminate\Cache\CacheManager;
use Illuminate\Container\Container;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Redis\RedisManager;

/**
 * Class CacheServiceProvider
 * @package Ava\App\Providers
 */
class CacheServiceProvider extends AbstractServiceProvider
{
    private $cacheContainer = null;

    /**
     * @return $this
     */
    public function boot()
    {
        if (!$this->cacheContainer instanceof Container) {
            $this->cacheContainer = new Container;
        }

        $this->cacheContainer['config'] = $this->getConfig();

        switch (env('SAE_CACHE_ADAPTER')) {
            case 'redis':
                $this->cacheContainer['redis'] = new RedisManager('predis', $this->getConfig()['database.redis']);
                break;
            default:
                $this->cacheContainer['files'] = new Filesystem;
                break;
        }

        $cacheManager = new CacheManager($this->cacheContainer);

        $cache = $cacheManager->store();

        $this->getContainer()->share('cache', $cache);

        return $this;
    }

    /**
     * @return $this
     */
    public function register()
    {
        return $this;
    }

    /**
     * @return array
     */
    protected function getConfig()
    {
        $config = [
            'redis' => [
                'cache.default' => 'redis',
                'cache.stores.redis' => [
                    'driver' => 'redis',
                    'connection' => 'default'
                ],
                'cache.prefix' => 'sae_cache',
                'database.redis' => [
                    'cluster' => false,
                    'default' => [
                        'host' => env('SAE_CACHE_HOST'),
                        'port' => env('SAE_CACHE_PORT'),
                        'database' => env('SAE_CACHE_DB'),
                    ],
                ]
            ],
            'memcached' => [
                'cache.default' => 'memcached',
                'cache.stores.memcached' => [
                    'driver' => 'memcached',
                    'servers' => [
                        [
                            'host' => env('SAE_CACHE_HOST'),
                            'port' => env('SAE_CACHE_PORT'),
                            'weight' => 100,
                        ],
                    ],
                ],
                'cache.prefix' => 'sae_cache'
            ],
            'file' => [
                'cache.default' => 'file',
                'cache.stores.file' => [
                    'driver' => 'file',
                    'path' => '/tmp'
                ]
            ]
        ];

        return $config[env('SAE_CACHE_ADAPTER', 'file')];
    }
}