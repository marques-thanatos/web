<?php

namespace Ava\App\Providers;

use Aws\S3\S3Client;
use League\Flysystem\AwsS3v3\AwsS3Adapter;

class FlySystemServiceProvider extends AbstractServiceProvider
{

    /**
     * Method will be invoked on registration of a service provider implementing
     * this interface. Provides ability for eager loading of Service Providers.
     *
     * @return $this
     */
    public function boot()
    {
        $client = new S3Client([
            'region' => getenv('AWS_DEFAULT_REGION'),
            'version' => 'latest'
        ]);

        $adapter = new AwsS3Adapter($client, env('AWS_DEFAULT_BUCKET'));

        $this->getContainer()->share(AwsS3Adapter::class, $adapter);

        return $this;
    }

    /**
     * Use the register method to register items with the container via the
     * protected $this->container property or the `getContainer` method
     * from the ContainerAwareTrait.
     *
     * @return $this
     */
    public function register()
    {
        return $this;
    }
}