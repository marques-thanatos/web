<?php

namespace Ava\App\Providers;

use League\Container\ServiceProvider\AbstractServiceProvider as ServiceProviderContainer;
use League\Container\ServiceProvider\BootableServiceProviderInterface;

/**
 * Class AbstractServiceProvider
 *
 * @package Ava\App\Providers
 * @author Ronaldo Matos Rodrigues <ronaldo@whera.com.br>
 */
abstract class AbstractServiceProvider extends ServiceProviderContainer implements BootableServiceProviderInterface
{

}
