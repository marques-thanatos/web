<?php

namespace Ava\App\Providers;

use Cocur\Slugify\Slugify;

/**
 * Class SlugifyServiceProvider
 *
 * @package Ava\App\Providers
 */
class SlugifyServiceProvider extends AbstractServiceProvider
{

    /**
     * @return $this
     */
    public function boot()
    {
        $slug = new Slugify();
        $this->getContainer()->share('slug', $slug);

        return $this;
    }


    /**
     * @return $this
     */
    public function register()
    {
        return $this;
    }
}
