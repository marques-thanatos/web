<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Disciplina_lib {


    function __construct() {
        $this->CI = & get_instance();
        $this->CI->load->model('disciplina_model', 'disciplina');
        $this->CI->load->model('plataformaliteraria_model', 'literaria');
        //$this->CI->load->model('acesso_model');
    }

    /**
     * @param $grupoAulaID
     * @param null $turma
     * @param int|false $tipoAgendamento
     * @return array
     */
    public function arrayDisciplinas($grupoAulaID, $turma = NULL, $tipoAgendamento = false) {
            $perfil = $this->CI->session->userdata('perfil');
            $escola = $this->CI->session->userdata('escola');
            if ($turma == NULL) {
                $turma = $this->CI->session->userdata('TurmaID');
            }
            $pessoaid = $this->CI->session->userdata('pessoaid');

            $videoaulas = array();

            if ($grupoAulaID) {
                $categorias = $this->CI->disciplina->verificaCategoria($grupoAulaID);
                if ($categorias) {
                    $a = 0;
                    foreach ($categorias as $key => $cat) {
                        $disciplina = $this->CI->disciplina->verificaDisciplinas($grupoAulaID, $cat['CategoriaID']);

                        if ($disciplina) {
                            foreach ($disciplina as $key2 => $subcategoria) {
                                $dadosDis[$a]['DtFimAluno'] = '';
                                $dadosDis[$a]['DtInicio'] = $subcategoria['DtInicio'];
                                $dadosDis[$a]['Descricao'] = $subcategoria['Descricao'];
                                $dadosDis[$a]['GrupoAulaID'] = $subcategoria['GrupoAulaID'];
                                $dadosDis[$a]['DisciplinaID'] = $subcategoria['DisciplinaID'];
                                $dadosDis[$a]['DescricaoCategoria'] = $cat['Descricao'];
                                //$dadosDis[$a]['CategoriaID'] = $cat['LivroID'];
                                $dadosDis[$a]['CategoriaID'] = $cat['CategoriaID'];
                                $dadosDis[$a]['ItemName'] = $subcategoria['ItemName'];
                                $dadosDis[$a]['TemMensagem'] = isset($subcategoria['TemMensagem']) ? $subcategoria['TemMensagem'] : '';
                                $a++;
                            }
                        }
                    }
                }

                //print_pre($categorias);die();

                if (isset($dadosDis)) {
                    foreach ($dadosDis as $key => $value) {
                        $videoaulas[$value['CategoriaID']]['DescricaoCategoria'] = $value['DescricaoCategoria'];
                        $videoaulas[$value['CategoriaID']][$value['Descricao']]['info'] = array(
                            'DisciplinaID' => $value['DisciplinaID']
                        );

                        $agendamento = null;
                        // verifica agendamento específico para o aluno:
                        if ($perfil == PERFIL_ALUNO) {
                            $agendamento = $this->CI->disciplina->getAgendamento($escola, $value['GrupoAulaID'], $value['CategoriaID'], $value['DisciplinaID'], $turma, $pessoaid, $tipoAgendamento);
                            if ( isset($agendamento[0]) && strtotime($agendamento[0]['DtInicio']) <= strtotime("2020-01-01") ){
                                continue;
                            }
                            if ($agendamento) {
                                if (isset($agendamento[1]['DtFim'])) {
                                    $DtFimAluno = $agendamento[1]['DtFim'] ?: '';
                                } else if (isset($agendamento[0]['DtFim'])) {
                                    $DtFimAluno = $agendamento[0]['DtFim'] ?: '';
                                }

                                $videoaulas[$value['CategoriaID']][$value['Descricao']]['info']['ItemName'] = $agendamento[0]['ItemName'];
                                $videoaulas[$value['CategoriaID']][$value['Descricao']]['info']['DtInicio'] = $agendamento[0]['DtInicio'];
                                $videoaulas[$value['CategoriaID']][$value['Descricao']]['info']['DtFim'] = $agendamento[0]['DtFim'];
                                $videoaulas[$value['CategoriaID']][$value['Descricao']]['info']['DtFimAluno'] = $DtFimAluno;
                            }
                        }

                        //verifica agendamento por turma
                        if (!$agendamento) {
                            $agendamento = $this->CI->disciplina->getAgendamento($escola, $value['GrupoAulaID'], $value['CategoriaID'], $value['DisciplinaID'], $turma, '', $tipoAgendamento);
                            if ( isset($agendamento[0]) && strtotime($agendamento[0]['DtInicio']) <= strtotime("2020-01-01") ){
                                continue;
                            }
                            if ($agendamento && isset($agendamento[0]['ItemName'])) {
                                $videoaulas[$value['CategoriaID']][$value['Descricao']]['info']['ItemName'] = $agendamento[0]['ItemName'];
                            }
                            if ($agendamento && $agendamento[0]['DtInicio'] != '-') {
                                $videoaulas[$value['CategoriaID']][$value['Descricao']]['info']['DtInicio'] = $agendamento[0]['DtInicio'];
                                $videoaulas[$value['CategoriaID']][$value['Descricao']]['info']['DtFim'] = $agendamento[0]['DtFim'];
                            }
                            $videoaulas[$value['CategoriaID']][$value['Descricao']]['info']['DtCad'] = $agendamento[0]['DtCad'];
                        }
                    }
                }
            }
            //&& ( strtotime($dadosDis[$a]['DtInicio']) <= strtotime( (date('Y')."-12-31") ) )

            return $videoaulas;
	}

	public function arrayAulas($GrupoAulaID,$DisciplinaID,$CategoriaID, $prep = false) {
            $perfil = $this->CI->session->userdata('perfil');
            $escola = $this->CI->session->userdata('escola');
            $turma = $this->CI->session->userdata('TurmaID');
            $pessoaid = $this->CI->session->userdata('pessoaid');

            $dadosAula = $this->CI->disciplina->buscaDadosAulas($DisciplinaID,'N', 'ASC');

            $qtdVideos = count($dadosAula);

            //questoes alunos
            $videos = $this->CI->disciplina->buscaQuestoesAluno($pessoaid, $GrupoAulaID, null, false, true, 'N', null, $DisciplinaID);

            //print_pre($videos);die;
            $qtdVideosAssistidos = $videos ? count($videos) : 0;

            $videoaulas['info'] = array(
                'DisciplinaID' =>$DisciplinaID,
                'QtdVideos' => $qtdVideos,
                'QtdVideosAssistidos' => $qtdVideosAssistidos
            );

            $agendamento = null;
		// verifica agendamento específico para o aluno:
                if ($perfil == PERFIL_ALUNO) {
                    $agendamento = $this->CI->disciplina->getAgendamento($escola, $GrupoAulaID, $CategoriaID, $DisciplinaID, $turma, $pessoaid);
                    if ($agendamento) {
                        $videoaulas['info']['DtInicio'] = $agendamento[0]['DtInicio'];
                        $videoaulas['info']['DtFimAluno'] = isset($agendamento[1]['DtFim']) ? $agendamento[1]['DtFim'] : '';
                    }
                }

		//verifica agendamento por turma
		if (!$agendamento) {
			$agendamento = $this->CI->disciplina->getAgendamento($escola,$GrupoAulaID, $CategoriaID, $DisciplinaID, $turma);
                        if ($agendamento) {
				$videoaulas['info']['DtInicio'] = $agendamento[0]['DtInicio'];
				$videoaulas['info']['DtFim'] = $agendamento[0]['DtFim'];
			}
		}

		$videoaulas['aulas'] = array();
		//calcula duraçao dos videos
		$videoaulas['info']['TempoTotalVideos'] = $this->calculoDuracaoVideo($DisciplinaID);

		$aulasVideo = $this->CI->disciplina->buscaDadosAulas($DisciplinaID,null,'asc', $prep);

		$videoaulas['aulas'] = array_merge($videoaulas['aulas'],$aulasVideo);

		//busca questoes discursivas
		$AulasQuestoesDisc = $this->CI->disciplina->buscaDadosAulas($DisciplinaID,'D','asc');

		if ($AulasQuestoesDisc) {

			foreach ($AulasQuestoesDisc as $key_qd => $value_qd) {
				$questoesDiscursivas =  $this->CI->literaria->getQuestoesDiscursivas($GrupoAulaID, null, $DisciplinaID);

				$videoaulas['aulas'] = $AulasQuestoesDisc;
				$videoaulas['aulas'][$key_qd]['questoes-discursivas'] = array();
				if (count($questoesDiscursivas) >= 1) {
					$videoaulas['info']['totalQuestoesDiscursivas'] = count ($questoesDiscursivas);
					$videoaulas['aulas'][$key_qd]['questoes-discursivas'] = $questoesDiscursivas;
				}
			}
		}

		for ($i = 0; count($videoaulas['aulas']) > $i; $i++) {
			$aula = $videoaulas['aulas'][$i]['AulaID'];
            
			// tratamento para as questões similares:
			$questoesSDB = $this->CI->disciplina->buscaQuestoesAula($aula,$GrupoAulaID);

			if (!empty($questoesSDB) && $perfil == PERFIL_ALUNO) {
				$grupo = -1;
				$cont = 0;
				foreach ($questoesSDB as $val) {//
					if (!isset($val['Similar']) || $val['Similar'] == 'N') {
						$cont++;
					} else { // similar = 'S'
						if ($grupo != $val['GrupoSimilar']) {
							$cont++;
							$grupo = $val['GrupoSimilar'];
						}
					}
				}
				$questoesSDB = array('0' => array('Count' => $cont));
			}else{
				$cont = count($questoesSDB);
				$questoesSDB = array('0' => array('Count' => $cont));
			}

			$questoes = $this->CI->disciplina->buscaQuestoesAluno($pessoaid, $GrupoAulaID, $aula);

			if ($questoes != '') {

				if (count($questoes) != 0) {

					$questoesRespondidas = $this->CI->disciplina->buscaQuestoesAluno($pessoaid, $GrupoAulaID, $aula, true);
					$questoesCorretas = $this->CI->disciplina->buscaQuestoesAluno($pessoaid, $GrupoAulaID, $aula, true, null, null, true);

					//grava a ultima aula que possui questao
					$ultAulaQuestao = ($i + 1);

					$videoaulas['aulas'][$i]['QtdQuestoes'] = isset($questoesSDB[0]['Count']) ? $questoesSDB[0]['Count'] : 0;
					$videoaulas['aulas'][$i]['QtdQuestoesRespondidas'] = count($questoesRespondidas);
					$videoaulas['aulas'][$i]['QtdRespostaCorretas'] = count($questoesCorretas);
				} else {
					$videoaulas['aulas'][$i]['QtdQuestoes'] = isset($questoesSDB[0]['Count']) ? $questoesSDB[0]['Count'] : 0;
					$videoaulas['aulas'][$i]['QtdQuestoesRespondidas'] = 0;
					$videoaulas['aulas'][$i]['QtdRespostaCorretas'] = 0;
				}
			}
		}

        $videoaulas['ancora'] = $this->CI->session->userdata('Ancora');
		return $videoaulas;
	}

	public function calculoDuracaoVideo($DisciplinaID){

		//calculo duracao video
		$aulasVideo = $this->CI->disciplina->buscaDadosAulas($DisciplinaID,null,'asc');

		if ($aulasVideo != '') {

			// calcula duração das videoaulas em segundos:
			$duracaoTotal = 0;
			foreach ($aulasVideo as $k => $v) {
				if ($v['Duracao'] && $v['Duracao'] != '' && $v['Tipo'] == "N") {
					$duracao = $v['Duracao'];

					// tempo em segundos:
					$array = explode(':', $duracao);

					if (count($array) == 2) {
						$h = 0;
						$m = (isset($array[1])) ? $array[1] : 0;
						$s = (isset($array[2])) ? $array[2] : 0;
					} else if (count($array) == 3) {
						$h = (isset($array[0])) ? $array[0] : 0;
						$m = (isset($array[1])) ? $array[1] : 0;
						$s = (isset($array[2])) ? $array[2] : 0;
					}

					// duração do vídeo em segundos
					$tempoTotal = $h * 60 * 60 + $m * 60 + $s;
					$duracaoTotal += $tempoTotal;
				}
			}
		}
            return $duracaoTotal;
	}

	public function htmlListaQuestoes($video, $literaria = false){
            $html = '';
            $ClassificacaoID = $this->CI->session->userdata('ClassificacaoID');
            $perfil = $this->CI->session->userdata('perfil');
            $meta = $this->CI->session->userdata('meta');
            $ancora = $this->CI->session->userdata('Ancora');

		//if ($exibirDisciplina ) {
            $cont = count($video['aulas']);
            $totalAulas = 0;
            for ($i = 0; $i < $cont; $i++) {

                $reforcoUrl[] = $ancora .'/'. encodeString($video['aulas'][$i]['Tema']) .'/'. str_pad($video['aulas'][$i]['DisciplinaID'], 7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0', 0);

                $SequenciaI = $i + 1;

                $j = 0;
                $achou = false;
                $assistida = '';
                $anotacoes = '';
                $novaAula = false;
                $liberarQuestao = true;

                //caso a media de respostas corretas do aluno for menor que a meta mostra a revisao
                //mostra com o cadeado, sem o link para acesar a pagina
                $media = 0;
                if ($meta != '-' && $video['aulas'][$i]['Tipo'] == 'Q') {
                    if ($video['aulas'][$i]['QtdQuestoes'] == $video['aulas'][$i]['QtdQuestoesRespondidas']) {
                        $media = round((($video['aulas'][$i]['QtdRespostaCorretas'] * 100) /  $video['aulas'][$i]['QtdQuestoes']),0);
                        $liberaRevisao = $media < $meta ? true : false;
                    } else {
                        $liberaRevisao = false;
                    }
		}

                //liberar revisão se a mídia dos vídeos assistidos alcançara o Percentual configurado para a escola
                $aulaid = $video['aulas'][$i]['AulaID'];
                $percAula = 0;
                if (isset($percentual[$aulaid]) && isset($video['aulas'][$i]['Duracao'])) {
                    $duracao = $video['aulas'][$i]['Duracao'];

                    // tempo em segundos:
                    $array = explode(':', $duracao);

                    if (count($array) == 2) {
                        $h = 0;
                        $m = (isset($array[1])) ? $array[1] : 0;
                        $s = (isset($array[2])) ? $array[2] : 0;
                    } else if (count($array) == 3) {
                        $h = (isset($array[0])) ? $array[0] : 0;
                        $m = (isset($array[1])) ? $array[1] : 0;
                        $s = (isset($array[2])) ? $array[2] : 0;
                    }

                    $tempoTotal = $h*60*60 + $m*60 + $s;

                    $percAula = round(($percentual[$aulaid] * 100) / $tempoTotal, 1);
                    if ($percAula > 100) {
                        $percAula = 100;
                    }
                    @$percentualMedio['qtd'] +=1;
                    @$percentualMedio['perc'] += $percAula;
                }else if( isset($video['info']['TempoTotalVideos']) && $video['aulas'][$i]['Tipo'] == 'N' ){
                    $duracao = $video['aulas'][$i]['Duracao'];

                    // tempo em segundos:
                    $array = explode(':', $duracao);

                    if (count($array) == 2) {
                        $h = 0;
                        $m = (isset($array[1])) ? $array[1] : 0;
                        $s = (isset($array[2])) ? $array[2] : 0;
                    } else if (count($array) == 3) {
                        $h = (isset($array[0])) ? $array[0] : 0;
                        $m = (isset($array[1])) ? $array[1] : 0;
                        $s = (isset($array[2])) ? $array[2] : 0;
                    }

                    $tempoTotal = $h*60*60 + $m*60 + $s;

                    $percAula = round(($video['info']['TempoTotalVideos'] * 100) / $tempoTotal, 1);
                    if ($percAula > 100) {
                        $percAula = 100;
                    }
                    @$percentualMedio['qtd'] +=1;
                    @$percentualMedio['perc'] += $percAula;
                }

                if ($video['aulas'][$i]['Tipo'] == 'Q') {
                    $qtdRespondidas = @$video['aulas'][$i]['QtdQuestoesRespondidas'] ? $video['aulas'][$i]['QtdQuestoesRespondidas'] : 0;
                    $qtdQuestoes = @$video['aulas'][$i]['QtdQuestoes'] ? $video['aulas'][$i]['QtdQuestoes'] : 0;

                    $html .= '<li class="etapa  $assistida ">
                                            <div class="block-ui" style="opacity: 1;">
                                            <p class="icoNovaAula">';
                    if ($novaAula) {
                        $html .= '<span class="alert-unread">!</span>';
                    }

                    $vl = !empty($totalAulas) ? str_pad($totalAulas, 2, "0", STR_PAD_LEFT) : '0';
                    $html .= '<input type="hidden" id="totalNovaAulas" value="'.$vl.'" >
                                    </p>
                                    <p class="icoVid"><a title="Ver vídeo" ></a></p>
                                    <p class="icoAnot">'. $anotacoes.'</p>

                            <div class="aula">';

                    if ($liberarQuestao) {
                        $html .= '<p class="nome"><a href="'.base_url().'curso/'.$ancora.'/'.encodeString($video['aulas'][$i]['Tema']).'/'.str_pad($video['aulas'][$i]['DisciplinaID'], 7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0', 0) .'/'.$SequenciaI .'?questao=true" title="'.($video['aulas'][$i]['Tema']).'">'.($video['aulas'][$i]['Tema']).'</a></p>';
                    } else {
                        $html .= '<p class="nome"><a title="'.($video['aulas'][$i]['Tema']).'">'.($video['aulas'][$i]['Tema']).'</a></p>';
                    }
                    if ($perfil == PERFIL_ALUNO) {
                        $html .= '<p class="tempo">'.$qtdRespondidas.' de '.$video['aulas'][$i]['QtdQuestoes'].' </p>';
                    } else {
                        $html .= '<p class="tempo">'.$video['aulas'][$i]['QtdQuestoes'].' </p>';
                    }

                    $html .= '	</div>
                                </div>
                            </li>';
                } else if ($video['aulas'][$i]['Tipo'] == 'N') {
                    //if (($qtdRespondidas >= $qtdQuestoes) && $qtdQuestoes != 0 || $perfil != PERFIL_ALUNO) {
                    $html .= '<li class="etapa'.$assistida.'">
                            <div class="block-ui" style="opacity: 1;">
                            <p class="icoNovaAula">';
                    if ($novaAula) {
                        $html .= '<span class="alert-unread">!</span>';
                    }
                    $totalaulas = !empty($totalAulas) ? str_pad($totalAulas, 2, "0", STR_PAD_LEFT) : '0';
                    $html .= '<input type="hidden" id="totalNovaAulas" value="'.$totalaulas.'" >
                                            </p>
                                            <p class="icoVid"><a title="Ver vídeo" href="'.base_url().'curso/'.$ancora.'/'.encodeString($video['aulas'][$i]['Tema']).'/'.str_pad($video['aulas'][$i]['DisciplinaID'], 7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0', 0).'/"></a></p>
                                            <p class="icoAnot">'.$anotacoes.'</p>
                                            <div class="aula questoes">';
                    if ($liberarQuestao) {
                        $html .='<p class="nome"><a href="'.base_url().'curso/'.$ancora.'/'.encodeString($video['aulas'][$i]['Tema']).'/'.str_pad($video['aulas'][$i]['DisciplinaID'], 7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0', 0).'/'.$SequenciaI.'" title="'.($video['aulas'][$i]['Tema']).'">'.($video['aulas'][$i]['Tema']).'</a></p>';
                    } else {
                        $html .= '<p class="nome"><a title="'.($video['aulas'][$i]['Tema']).'">'.($video['aulas'][$i]['Tema']).'</a></p>';
                    }

                    $perc = isset($percentual[$video['aulas'][$i]['AulaID']]['assistido']) ? $percentual[$video['aulas'][$i]['AulaID']]['assistido'] : '';
                    $html .= '<p class="tempo">'.$perc.'</p>
                                            <p class="tempo">'.$video['aulas'][$i]['Duracao'].'</p>';
                    if ($perfil == PERFIL_ALUNO && !$literaria):
                        $perAula = isset($percAula) ? $percAula : 0;
                        $html .= '<p class="tempo">'.$perAula.'%</p>';
                    endif;
                    $html .= '	</div>
                                    </div>
                            </li>';

                } else if ($video['aulas'][$i]['Tipo'] == 'R') {
                    if ($metaPercentual > 0 && $percentualMedio['perc'] > 0) {
                        // percentual médio: soma dos percentuais dividido pela quantidade de vídeos
                        $percMedio = round($percentualMedio['perc'] / $percentualMedio['qtd'], 2);
                        $liberaRevisao = ($percMedio >= $metaPercentual);
                    }

                    if ($liberaRevisao || $perfil != PERFIL_ALUNO) {
                        $qtdRespondidas = @$video['aulas'][$i]['QtdQuestoesRespondidas'] ? $video['aulas'][$i]['QtdQuestoesRespondidas'] : 0;

                        if ($video['info']['QtdVideosAssistidos'] >= $video['info']['QtdVideos'] || $perfil != PERFIL_ALUNO) {
                            $html .= '<li class="etapa'.$assistida.'">
                                        <div class="block-ui" style="opacity: 1;">
                                        <p class="icoNovaAula">';
                            if ($novaAula) {
                                $html .= '<span class="alert-unread">!</span>';
                            }
                            $html .= '</p>
                                            <p class="icoVid"><a title="Ver vídeo" ></a></p>
                                            <p class="icoAnot">	
                                            <div class="aula questoes">
                                            <!-- libera o link da revisao apaenas se o aluno assistiu todas as vidoaulas -->';
                            if ($liberarQuestao) {
                                $html .= '<p class="nome"><a href="'.base_url().'curso/'.$ancora.'/'.encodeString($video['aulas'][$i]['Tema']).'/'.str_pad($video['aulas'][$i]['DisciplinaID'], 7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0', 0).'/'.$SequenciaI.'?questao=true" title="'.$video['aulas'][$i]['Tema'].'">'.($video['aulas'][$i]['Tema']).'</a></p>';
                            } else {
                                $html .='<p class="nome"><a title="'.($video['aulas'][$i]['Tema']).'">'.($video['aulas'][$i]['Tema']).'</a></p>';
                            }

                            if ($perfil == PERFIL_ALUNO) {
                                $html .='<p class="tempo">'.$qtdRespondidas.' de '.$video['aulas'][$i]['QtdQuestoes'].'</p>';
                            } else {
                                $html .='<p class="tempo">'.$video['aulas'][$i]['QtdQuestoes'].'</p>';
                            }

                            $html .='</div>
                                    </li>';

                        } else {
                            $html .='<li class="etapa'.$assistida.'">
                                            <span class="etapa-bloqueada"></span>
                                            <div class="block-ui">
                                                    <p class="icoNovaAula">';
                            if ($novaAula) {
                                $html .='<span class="alert-unread">!</span>';
                            }
                            $html .='</p>
                                    <p class="icoVid"><a title="Ver vídeo" ></a></p>
                                    <p class="icoAnot">	
                                    <div class="aula questoes">
                                    <!-- libera o link da revisao apaenas se o aluno assistiu todas as vidoaulas -->
                                    <p class="nome">'.$video['aulas'][$i]['Tema'].'</p>';
                            if ($perfil == PERFIL_ALUNO) {
                                $html .='<p class="tempo">'.$qtdRespondidas.' de '.$video['aulas'][$i]['QtdQuestoes'].'</p>';
                            } else {
                                $html .='<p class="tempo">'.$video['aulas'][$i]['QtdQuestoes'].'</p>';
                            }

                            $html .='</div>
                                            </li>';
                        }
                    }
                } else if ($video['aulas'][$i]['Tipo'] == 'D') {
                    foreach ($video['aulas'] as $key_aulas => $value_aulas) {
                        $html .='<li class="etapa ">
                                <div style="opacity: 1;" class="block-ui">
                                        <p class="icoNovaAula">
                                        <input type="hidden" value="0" id="totalNovaAulas">
                                        </p>
                                        <p class="icoVid"><a title="Ver v&iacute;deo"></a></p>
                                        <p class="icoAnot"></p>
                                        <div class="aula">
                                                <p class="nome"><a title="'.($video['aulas'][$i]['Tema']).'" href="javascript:void(0)">'.($video['aulas'][$i]['Tema']).'</a></p>
                                                <p class="tempo">'.$video['info']['totalQuestoesDiscursivas'].' de 5</p>';
                        if (isset($ClassificacaoID) && $ClassificacaoID = 11 && $perfil == PERFIL_ALUNO ) {
                            $html .='<p class="tempo"><a class="icon-acompanhar" title="Visualizar" href="'.base_url().'curso-plataforma-literaria/questoes_discursivas_aluno/'.$this->CI->session->userdata('grupoAulaID').'/'.$video['aulas'][$i]['DisciplinaID'].'"></a></p>';
                        } else if (isset($ClassificacaoID) && $ClassificacaoID = 11) {
                            $html .='<p class="tempo"><a class="icon-acompanhar" title="Visualizar" href="'.base_url().'cadastro/questoes_discursivas_lista/'.$this->CI->session->userdata('grupoAulaID').'/'.$video['aulas'][$i]['DisciplinaID'].'"></a></p>';
									}
                        $html .='</div>
                                </div>
                                </li>';

						if (isset($video['aulas'][$i]['questoes-discursivas']) && $ClassificacaoID != 11) {
							$totalQuestoesDiscursivas = count($video['aulas'][$i]['questoes-discursivas']);

							if (is_array($video['aulas'][$i]['questoes-discursivas'])) {
								foreach ($video['aulas'][$i]['questoes-discursivas'] as $keyqd => $valueqd) {

									//falta enviar as questões criada e restantes
									$html .='<li class="etapa ">
			                    			<div style="opacity: 1;" class="block-ui">
												<p class="icoNovaAula">
													<input type="hidden" value="0" id="totalNovaAulas">
													</p>
													<p class="icoVid"><a href="javascript:void(0)" title="Ver vídeo"></a></p>
													<p class="icoAnot"></p>
													<div class="aula questoes">
														<p class="nome"><a title="'.($keyqd+1).' Questão" href="javascript:void(0)">'.($keyqd+1).'Questão</a></p>
														<p class="tempo"></p>
														<p class="tempo"><a class="icon-acompanhar" title="Visualizar" href="'.base_url().'cadastro/questoes_discursivas_editar/'.$this->CI->session->userdata('grupoAulaID').'/'.$video['aulas'][$i]['DisciplinaID'].'/'.$video['aulas'][$i]['AulaID'].'/'.$valueqd['QuestaoDiscursivaID'].'/'.$ancora.'"></a></p>
													</div>
											</div>
										</li>';
								}
							} else {
								$totalQuestoesDiscursivas = 0;
							}
						}
					}
				}
			}

			//e datafim
			if ($perfil == PERFIL_ALUNO && isset($video['info']['DtFimAluno']))  {
				if ($video['info']['DtFimAluno'] != '' && strtotime($video['info']['DtFimAluno']) < strtotime(date('Y-m-d'))) {
					$html .='<li class="etapa "> 
							<div style="opacity: 1;" class="block-ui"> 
								<p class="icoNovaAula"> <input type="hidden" value="0" id="totalNovaAulas"> </p> 
								<p class="icoVid"><a title="Ver vídeo"></a></p> 
								<p class="icoAnot"></p> 
								<div class="aula"> 
									<p class="nome"><a title="Reforço" href="'.base_url().'reforco/'.$ancora.'/'.encodeString($video['aulas'][$position]['Tema']).'/'.str_pad($video['aulas'][$position]['DisciplinaID'], 7, '0', 0) . str_pad($video['aulas'][$position]['AulaID'], 7, '0', 0).'/1?questao=true">Reforço</a></p> 
									<p class="tempo">'.$video['reforco']['TotalReforco'].'</p> 
									</div> 
							</div> 
						</li>';
					$position = $position++;
				} else if ($perfil == PERFIL_ALUNO && isset($video['info']['DtInicio'])) {
					$htm .='<li class="etapa "> 
								<div style="opacity: 1;" class="block-ui"> 
									<p class="icoNovaAula"> <input type="hidden" value="0" id="totalNovaAulas"> </p> 
									<p class="icoVid"><a title="Ver vídeo"></a></p> 
									<p class="icoAnot"></p> 
									<div class="aula"> 
										<p class="nome"><a title="Reforço" href="'.base_url().'reforco/'.$ancora.'/'.encodeString($video['aulas'][$position]['Tema']).'/'.str_pad($video['aulas'][$position]['DisciplinaID'], 7, '0', 0) . str_pad($video['aulas'][$position]['AulaID'], 7, '0', 0).'/1?questao=true">Reforço</a></p> 
										<p class="tempo">'.$video['reforco']['TotalReforco'].'</p> 
									</div> 
								</div> 
							</li>';
					$position = $position++;
				}
			}

			if ($cont == 0) {
				$html .= '<li class="">
								<p class="icoVid"></p>
								<div class="aula"><p class="nome">Aula não importada até o momento! Desculpe pelo transtorno!</p></div>
								<input type="hidden" id="totalNovaAulas" value="0" > 
							</li>';
			}

		/*}else if(!$exibirDisciplina){
			$html .='<li class="">
					<p class="icoVid"></p>';

			if (isset($video['info']['DtInicio'])) {
				$html.='<div class="aula"><p class="nome">Aula disponível a partir de '.date('d/m/Y', strtotime($video['info']['DtInicio'])).'</p></div>';
			}else{
				$html.='<div class="aula"><p class="nome">Questões e Aulas indisponíveis no momento.</p></div>';
			}
			$html.='<input type="hidden" id="totalNovaAulas" value="0" >
					</li>';

		}*/

		return $html;
	}

	public function htmlListaAulas($video){

		$html = '';
		$ClassificacaoID = $this->CI->session->userdata('ClassificacaoID');
		$perfil = $this->CI->session->userdata('perfil');
		$meta = $this->CI->session->userdata('meta');
		$ancora = $this->CI->session->userdata('Ancora');


		//if ($exibirDisciplina) {
			$cont = count($video['aulas']);
			$totalAulas = 0;
			for ($i = 0; $i < $cont; $i++) {

				$SequenciaI = $i + 1;

				$j = 0;
				$achou = false;
				//$aux = count($videosAssistidosAnotacoes);
				$assistida = '';
				$anotacoes = '';
				$novaAula = false;

				if ((isset($video['aulas'][$i]['DtCad'])) && !$achou) {
					$novaAula = true;
					$totalAulas += 1;
				}

				$tAulas = !empty($totalAulas) ? str_pad($totalAulas, 2, "0", STR_PAD_LEFT) : 0;

				$html .= '<li class="<?= $assistida ?>">
						<p class="icoNovaAula">';
					if ($novaAula) {
						//$html .= '<span class="alert-unread">!</span>';
					}
				$html .= '<input type="hidden" id="totalNovaAulas" value="'.$tAulas.'" >
						</p>
						<p class="icoVid"><a title="Ver vídeo" href="'.base_url().'preparatorio/'.$ancora.'/'.encodeString($video['aulas'][$i]['Tema']).'/'.str_pad($video['aulas'][$i]['DisciplinaID'], 7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0', 0).'/"></a></p>
						<p class="icoAnot">'.$anotacoes.'</p>
						
						<div class="aula">
							<p class="num">'.str_pad($SequenciaI, 2, '0', 0).'-&nbsp;</p>
							<p class="nome"><a href="'.base_url().'preparatorio/'.$ancora.'/'.encodeString($video['aulas'][$i]['Tema']).'/'.str_pad($video['aulas'][$i]['DisciplinaID'], 7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0', 0).'/'.$SequenciaI.'" title="'.($video['aulas'][$i]['Tema']).'">'.($video['aulas'][$i]['Tema']).'</a></p>
							<p class="tempo">'.$video['aulas'][$i]['Duracao'].'</p>
						</div>
					</li>';
			 }
			 if ($cont == 0) {
				$html .= '<li class="">
					<p class="icoVid"></p>
						<div class="aula"><p class="nome">Aula não importada até o momento! Desculpe pelo transtorno!</p></div>
						<input type="hidden" id="totalNovaAulas" value="0" > 
				</li>';
			 }

		return $html;
	}

    /**
     * @param $video
     * @param false $exibirDisciplina
     * @param false $liberarQuestao
     * @param $metaPercentual
     * @param $percentual
     * @param $metaQuestao
     * @param array $dadosRelatorio
     * @param $bimestre
     * @param array $metadata
     * @return string
     */
    public function htmlListaAulasCurso(
        $video,
        $exibirDisciplina = false,
        $liberarQuestao = false,
        $metaPercentual,
        $percentual,
        $metaQuestao,
        array $dadosRelatorio = [],
        $bimestre,
        $metadata = []
    ) {
        $perfil = $this->CI->session->userdata('perfil');

        $metaVideo = $metaPercentual;
        $allowProfile = [\Ava\App\Support\Perfil::PROFESSOR, \Ava\App\Support\Perfil::COORDENADOR];
        $hideSchedules = $metadata['hasSchedules'] || in_array($perfil, $allowProfile) ? '' : 'hidde';
        $hideReviews = $metadata['hasReviews'] || in_array($perfil, $allowProfile) ? '' : 'hidde';

        if ($metadata['tipoAgendamento'] && $metadata['tipoAgendamento'] == \Ava\App\Support\TipoAgendamento::TRILHA) {
            $hideReviews = 'hidde';
        }

        if ($metadata['tipoAgendamento'] && $metadata['tipoAgendamento'] == \Ava\App\Support\TipoAgendamento::REFORCO) {
            $hideSchedules = 'hidde';
        }

        $liberarVideo = false;
        if ($video['info']['DtFim'] && $perfil == PERFIL_ALUNO) {
            $dataAgendamentoFim = \DateTime::createFromFormat('Y-m-d', $video['info']['DtFim']);
            $dataAgendamentoFim = $dataAgendamentoFim->setTime(0, 0, 0);
            $hoje = new \DateTime();
            $hoje = $hoje->setTime(0, 0, 0);
            $liberarVideo = ($dataAgendamentoFim < $hoje);
        }

        $html = '';
        $position = 0;
        $ClassificacaoID = $this->CI->session->userdata('ClassificacaoID');

        //$meta = $this->CI->session->userdata('meta');
        $ancora = $this->CI->session->userdata('Ancora');
        $usuarioid = $this->CI->session->userdata('pessoaid');
        $qtdRespondidas = 0;
        $percentualMedio = array(
            'qtd' => 0,
            'perc' => 0
        ); //calcula o percentual médio de vídeos assistidos para liberar revisão
        if ($exibirDisciplina) {
            $cont = count($video['aulas']);
            $totalAulas = 0;

            for ($i = 0; $i < $cont; $i++) {
                //print_pre($video['aulas'][$i]);
                if ($video['aulas'][$i]['QtdQuestoesRespondidas'] > 0) {

                    // AVA-285: Modificado para ele pegar a meta de video
                    // pois antes ele pegava a meta de acerto da questao
                    $metaPercentual = $this->CI->disciplina->getMetaAluno($usuarioid,
                        $video['aulas'][$i]['DisciplinaID']);
                }

                $SequenciaI = $i + 1;

                $anotacoes = '';
                $semQuestoes = isset($video['info']['SemQuestoes']) ? $video['info']['SemQuestoes'] : 'N';
                //caso a media de respostas corretas do aluno for menor que a meta mostra a revisao
                //mostra com o cadeado, sem o link para acesar a pagina
                $media = 0;

                if ($metaQuestao != '-' && $video['aulas'][$i]['Tipo'] == 'Q') {
                    if ($video['aulas'][$i]['QtdQuestoes'] > 0 && $video['aulas'][$i]['QtdQuestoes'] == $video['aulas'][$i]['QtdQuestoesRespondidas']) {
                        $media = round((($video['aulas'][$i]['QtdRespostaCorretas'] * 100) / $video['aulas'][$i]['QtdQuestoes']),
                            0);
                        $liberaRevisao = $media < $metaQuestao ? true : false;
                    } else {
                        $liberaRevisao = false;
                    }
                }

                //liberar revisão se a média dos vídeos assistidos alcançara o Percentual configurado para a escola

                if ($video['aulas'][$i]['Tipo'] != 'N') {
                    $qtdRespondidas = $video['aulas'][$i]['QtdQuestoesRespondidas'] ? $video['aulas'][$i]['QtdQuestoesRespondidas'] : 0;
                    $qtdQuestoes = $video['aulas'][$i]['QtdQuestoes'] ? $video['aulas'][$i]['QtdQuestoes'] : 0;
                }
                if ($video['aulas'][$i]['Tipo'] == 'Q' && $semQuestoes == 'N') {

                    $html .= "<li class=\"etapa etapa-1 {$hideSchedules}\">
                                 <div class=\"block-ui\" style=\"opacity: 1;\">
                            	 <p class=\"icoNovaAula\">";

                    $html .= '<input type="hidden" id="totalNovaAulas" value="' . (!empty($totalAulas) ? str_pad($totalAulas,
                            2, "0", STR_PAD_LEFT) : '0') . '" >
                                </p>
                                <p class="icoVid"><a title="Ver vídeo" ></a></p>
                                <p class="icoAnot">' . $anotacoes . '</p>
                                <div class="aula">';

                    if ($liberarQuestao) {
                        $html .= '<p class="nome"><a href="' . base_url() . 'curso/' . $ancora . '/' . encodeString($video['aulas'][$i]['Tema']) . '/' . str_pad($video['aulas'][$i]['DisciplinaID'],
                                7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0',
                                0) . '/' . $SequenciaI . '?questao=true" title="' . ($video['aulas'][$i]['Tema']) . '">' . ($video['aulas'][$i]['Tema']) . '</a></p>';
                    } else {
                        $html .= '<p class="nome"><a title="' . ($video['aulas'][$i]['Tema']) . '">' . ($video['aulas'][$i]['Tema']) . '</a></p>';
                    }
                    if ($perfil == PERFIL_ALUNO) {
                        $informativo = $dadosRelatorio['relatorio'][$dadosRelatorio['idDisciplina']]['bimestres'][$dadosRelatorio['idBimestre']]['assuntos'][$dadosRelatorio['idAssunto']]['alunos'][$dadosRelatorio['idAluno']]['msg']['questoes'];

                        $html .= '<p class="tempo">' . $qtdRespondidas . ' de ' . $video['aulas'][$i]['QtdQuestoes'] . "<span class='{$informativo['icone']}' title='{$informativo['msg']}' style='float: right !important; margin-top: 0.375rem; margin-left: 0.5rem;'></span>" . '</p>';
                    }

                    $html .= '</div>
                                    </div>
								</li>';
                } else {
                    if ($video['aulas'][$i]['Tipo'] == 'N') {
                        if (((isset($qtdRespondidas) && isset($qtdQuestoes) && ($qtdRespondidas >= $qtdQuestoes) && ($qtdQuestoes != 0) || true) || $perfil != PERFIL_ALUNO || $semQuestoes == 'S' || $video['info']['QtdVideosAssistidos'] > 0 || $ClassificacaoID == 11) || $liberarVideo) {
                            $html .= "<li class=\"etapa etapa-2 {$hideSchedules}\">
                                        <div class=\"block-ui\" style=\"opacity: 1;\">
                                        <p class=\"icoNovaAula\">";

                            $html .= '<input type="hidden" id="totalNovaAulas" value="' . (!empty($totalAulas) ? str_pad($totalAulas,
                                    2, "0", STR_PAD_LEFT) : '0') . '" >
							</p>
		                    <p class="icoVid"><a title="Ver vídeo" href="' . base_url() . 'curso/' . $ancora . '/' . encodeString($video['aulas'][$i]['Tema']) . '/' . str_pad($video['aulas'][$i]['DisciplinaID'],
                                    7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0', 0) . '/"></a></p>
		                    <p class="icoAnot">' . $anotacoes . '</p>
							<div class="aula questoes">';
                            if ($liberarQuestao) {
                                $html .= '<p class="nome"><a href="' . base_url() . 'curso/' . $ancora . '/' . encodeString($video['aulas'][$i]['Tema']) . '/' . str_pad($video['aulas'][$i]['DisciplinaID'],
                                        7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0',
                                        0) . '/' . $SequenciaI . '" title="' . ($video['aulas'][$i]['Tema']) . '">' . ($video['aulas'][$i]['Tema']) . '</a></p>';
                            } else {
                                $html .= '<p class="nome"><a title="' . ($video['aulas'][$i]['Tema']) . '">' . ($video['aulas'][$i]['Tema']) . '</a></p>';
                            }

                            $html .= '<p class="tempo">' . (isset($percentual[$video['aulas'][$i]['AulaID']]['assistido']) ? $percentual[$video['aulas'][$i]['AulaID']]['assistido'] : '') . '</p>
							  <p class="tempo">' . $video['aulas'][$i]['Duracao'] . '</p>';


                            if ($perfil == PERFIL_ALUNO) {
                                $informativo = $dadosRelatorio['relatorio'][$dadosRelatorio['idDisciplina']]['bimestres'][$dadosRelatorio['idBimestre']]['assuntos'][$dadosRelatorio['idAssunto']]['alunos'][$dadosRelatorio['idAluno']]['msg']['videos'];

                                $html .= '<p class="tempo">' . (isset($video['percentualVideo']) ? $video['percentualVideo'] : 0) . "<span class='{$informativo['icone']}' title='{$informativo['msg']}' style='float: right !important; margin-top: 0.375rem; margin-left: 0.5rem;'></span>" . ' %</p>';
                            }

                            $html .= '</div>
		            		 </div>
		                    </li>';
                        } else {
                            $html .= '<li class="etapa etapa-3">
                                        <span class="etapa-bloqueada"></span>
                                        <div class="block-ui">
                                        <p class="icoNovaAula">';

                            $html .= '<input type="hidden" id="totalNovaAulas" value="' . (!empty($totalAulas) ? str_pad($totalAulas,
                                    2, "0", STR_PAD_LEFT) : '0') . '" >
							</p>
                            <p class="icoVid"></p>
                            <p class="icoAnot">' . $anotacoes . '</p>

							<div class="aula questoes">
                            	<p class="nome"><a> ' . ($video['aulas'][$i]['Tema']) . '</a></p>
                                <p class="tempo">' . (isset($percentual[$video['aulas'][$i]['AulaID']]['assistido']) ? $percentual[$video['aulas'][$i]['AulaID']]['assistido'] : '') . '</p>
                                <p class="tempo">' . $video['aulas'][$i]['Duracao'] . '</p>
                                <p class="tempo">' . (isset($percAula) ? $percAula : 0) . ' %</p>
							</div>
							</div>
						</li>';
                        }
                    } else {
                        if ($video['aulas'][$i]['Tipo'] == 'R' && $semQuestoes == 'N') {
                            $liberaRevisaoVideo = false;

                            if ((isset($video['percentualVideo']) && $video['percentualVideo'] >= $metaVideo) || $perfil != PERFIL_ALUNO) {
                                $liberaRevisaoVideo = true;
                            }

                            if ((isset($liberaRevisao) && $liberaRevisao) || $perfil != PERFIL_ALUNO) {
                                if ($liberaRevisaoVideo || $perfil != PERFIL_ALUNO) {
                                    $html .= '<li class="etapa etapa-4">
                                        <div class="block-ui" style="opacity: 1;">
                                        <p class="icoNovaAula">';

                                    $html .= '</p>
                                        <p class="icoVid"><a title="Ver vídeo" ></a></p>
                                    <p class="icoAnot">	
                                    <div class="aula questoes">
                                    <!-- libera o link da revisao apaenas se o aluno assistiu todas as vidoaulas -->';
                                    if ($liberarQuestao) {
                                        $html .= '<p class="nome"><a href="' . base_url() . 'curso/' . $ancora . '/' . encodeString($video['aulas'][$i]['Tema']) . '/' . str_pad($video['aulas'][$i]['DisciplinaID'],
                                                7, '0', 0) . str_pad($video['aulas'][$i]['AulaID'], 7, '0',
                                                0) . '/' . $SequenciaI . '?questao=true" title="' . ($video['aulas'][$i]['Tema']) . '">' . ($video['aulas'][$i]['Tema']) . '</a></p>';
                                    } else {
                                        $html .= '<p class="nome"><a title="' . $video['aulas'][$i]['Tema'] . '">' . ($video['aulas'][$i]['Tema']) . '</a></p>';
                                    }

                                    if ($perfil == PERFIL_ALUNO) {
                                        $informativo = $dadosRelatorio['relatorio'][$dadosRelatorio['idDisciplina']]['bimestres'][$dadosRelatorio['idBimestre']]['assuntos'][$dadosRelatorio['idAssunto']]['alunos'][$dadosRelatorio['idAluno']]['msg']['revisoes'];

                                        $html .= '<p class="tempo">' . $qtdRespondidas . ' de ' . $video['aulas'][$i]['QtdQuestoes'] ."<span class='{$informativo['icone']}' title='{$informativo['msg']}' style='float: right !important; margin-top: 0.375rem; margin-left: 0.5rem;'></span>" .'</p>';
                                    }

                                    $html .= '</div>
                                </li>';
                                } else {
                                    $html .= '<li class="etapa etapa-5">
                                            <span class="etapa-bloqueada"></span>
                                            <div class="block-ui">
                                            <p class="icoNovaAula">';

                                    $html .= '</p>
			        			<p class="icoVid"><a title="Ver vídeo" ></a></p>
			                    <p class="icoAnot">	
			                    <div class="aula questoes">
			                    	<!-- libera o link da revisao apaenas se o aluno assistiu todas as vidoaulas -->
			                        <p class="nome">' . ($video['aulas'][$i]['Tema']) . '</p>';
                                    if ($perfil == PERFIL_ALUNO) {
                                        $informativo = $dadosRelatorio['relatorio'][$dadosRelatorio['idDisciplina']]['bimestres'][$dadosRelatorio['idBimestre']]['assuntos'][$dadosRelatorio['idAssunto']]['alunos'][$dadosRelatorio['idAluno']]['msg']['revisoes'];

                                        $html .= '<p class="tempo">' . $qtdRespondidas . ' de ' . $video['aulas'][$i]['QtdQuestoes'] . "<span class='{$informativo['icone']}' title='{$informativo['msg']}' style='float: right !important; margin-top: 0.375rem; margin-left: 0.5rem;'></span>".'</p>';
                                    }

                                    $html .= '</div>
                                </li>';
                                }
                            }
                        } else {
                          if ($video['aulas'][$i]['Tipo'] == 'D') {
                            $url = base_url() . 'cadastro/questoes_discursivas_lista/' . $video['aulas'][$i]['AulaID'] . '/' . $this->CI->session->userdata('grupoAulaID') . '/' . $video['aulas'][$i]['DisciplinaID'];
                            foreach ($video['aulas'] as $key_aulas => $value_aulas) {
                              $html .= '<li class="etapa etapa-6">
                                          <div style="opacity: 1;" class="block-ui">
                                            <p class="icoNovaAula">
                                              <input type="hidden" value="0" id="totalNovaAulas">
                                            </p>
                                            <p class="icoVid"><a title="Ver questão discursiva"></a></p>
                                            <p class="icoAnot"></p>
                                            <div class="aula">
                                              <p class="nome"><a title="' . ($video['aulas'][$i]['Tema']) . '" href="' . $url . '">' . ($video['aulas'][$i]['Tema']) . '</a></p>
                                              <p class="tempo">' . $video['info']['totalQuestoesDiscursivas'] . ' de 5</p>  ';
                                              if (isset($ClassificacaoID) && $ClassificacaoID = 11) {
                                                $html .= '<p class="tempo"><a class="icon-acompanhar" title="Visualizar questão discursiva" href="' . $url . '"></a></p>';
                                              }
                                $html .= '</div></div></li>';

                              if (isset($video['aulas'][$i]['questoes-discursivas']) && $ClassificacaoID != 11) {
                                $totalQuestoesDiscursivas = count($video['aulas'][$i]['questoes-discursivas']);

                                if (is_array($video['aulas'][$i]['questoes-discursivas'])) {
                                  foreach ($video['aulas'][$i]['questoes-discursivas'] as $keyqd => $valueqd) {
                                    $html .= '<li class="etapa etapa-7">
                                                <div style="opacity: 1;" class="block-ui">
                                                <p class="icoNovaAula">
                                                  <input type="hidden" value="0" id="totalNovaAulas">
                                                </p>
                                                <p class="icoVid"><a href="javascript:void(0)" title="Ver vídeo"></a></p>
                                                <p class="icoAnot"></p>
                                                <div class="aula questoes">
                                                  <p class="nome"><a title="' . ($keyqd + 1) . ' Questão" href="javascript:void(0)">' . ($keyqd + 1) . 'Questão</a></p>
                                                  <p class="tempo"></p> 
                                                  <p class="tempo"><a class="icon-acompanhar" title="Visualizar" href="' . base_url() . 'cadastro/questoes_discursivas_editar/' . $this->session->userdata('grupoAulaID') . '/' . $video['aulas'][$i]['DisciplinaID'] . '/' . $video['aulas'][$i]['AulaID'] . '/' . $valueqd['QuestaoDiscursivaID'] . '/' . $this->CI->uri->segment(2) . '"></a></p>
                                                </div>
                                                </div>
                                            </li>';
                                  }
                                } else {
                                  $totalQuestoesDiscursivas = 0;
                                }
                              }
                            }
                          }
                        }
                    }
                }
            }
            if ($perfil == PERFIL_ALUNO && isset($video['info']['DtFimAluno'])) {
                if ($video['info']['DtFimAluno'] != '' && strtotime($video['info']['DtFimAluno']) < strtotime(date('Y-m-d'))) {
                    $html .= '<li class="etapa etapa-8"> 
                                                    <div style="opacity: 1;" class="block-ui"> 
                            <p class="icoNovaAula"> <input type="hidden" value="0" id="totalNovaAulas"> </p> 
                            <p class="icoVid"><a title="Ver vídeo"></a></p> 
                            <p class="icoAnot"></p> 
                                    <div class="aula"> 
                                    <p class="nome"><a title="Reforço" href="' . base_url() . 'reforco/' . $ancora . '/' . encodeString($video['aulas'][$position]['Tema']) . '/' . str_pad($video['aulas'][$position]['DisciplinaID'],
                            7, '0', 0) . str_pad($video['aulas'][$position]['AulaID'], 7, '0', 0) . '/1?questao=true">Reforço</a></p> 
                                    <p class="tempo">' . $video['reforco']['TotalReforco'] . '</p> 
                                                                    </div> 
                                                    </div> 
                                            </li>';
                    $position = $position++;
                } else {
                    if ($perfil == PERFIL_ALUNO && isset($video['info']['DtInicio'])) {
                        $html .= "<li class=\"etapa etapa-9 {$hideReviews}\">";
                        $html .= '<div style="opacity: 1;" class="block-ui"> 
	                            <p class="icoNovaAula"> <input type="hidden" value="0" id="totalNovaAulas"> </p> 
	                            <p class="icoVid"><a title="Ver vídeo"></a></p> 
	                            <p class="icoAnot"></p> 
	                            <div class="aula"> 
									<p class="nome"><a title="Refor&ccedil;o" href="' . base_url() . 'reforco/' . $ancora . '/' . encodeString($video['aulas'][$position]['Tema']) . '/' . str_pad($video['aulas'][$position]['DisciplinaID'],
                                7, '0', 0) . str_pad($video['aulas'][$position]['AulaID'], 7, '0', 0) . '/1?questao=true">Refor&ccedil;o</a></p> 
	                                <p class="tempo">' . (isset($video['reforco']['TotalReforco']) ? $video['reforco']['TotalReforco'] : '') . '</p> 
	                            </div> 
	                        </div> 
	                     </li>';
                        $position = $position++;
                    }
                }
            }

            if ((int)$perfil !== \Ava\App\Support\Perfil::ALUNO && (int)$video['disciplina']['ClassificacaoID'] === \Ava\App\Support\ClassificacaoConteudo::CONTEUDO_GERAL) {
                if (isset($qtdQuestoes) && $qtdQuestoes !=0)
                    $html .= '<li class="etapa etapa-10" style="border-top: 1px solid #eaeaea;"> 
                            <div style="opacity: 1;" class="block-ui"> 
                                <p class="icoNovaAula"> <input type="hidden" value="0" id="totalNovaAulas"> </p> 
                                <p class="icoVid"><a title="Ver vídeo"></a></p> 
                                <p class="icoAnot"></p> 
                                    <div class="aula"> 
                                        <p class="nome">
                                            <a title="Reforço" href="' . base_url() . 'reforco/' . $ancora . '/' . encodeString($video['aulas'][$position]['Tema']) . '/' . str_pad($video['aulas'][$position]['DisciplinaID'],
                        7, '0', 0) . str_pad($video['aulas'][$position]['AulaID'], 7, '0', 0) . '/1?questao=true">Reforço</a>
                                        </p> 
                                        <p class="tempo"></p> 
                                    </div> 
                            </div>
                        </li>';
            }

            if ($cont == 0) {
                $html .= '<li class="">
                                        <p class="icoVid"></p>
                        <div class="aula"><p class="nome">Aula não importada até o momento! Desculpe pelo transtorno!</p></div>
                                <input type="hidden" id="totalNovaAulas" value="0" > 
                                  </li>';
            }
        } else {
            if (!$exibirDisciplina) {
                $html .= '<li class="">
                    <p class="icoVid"></p>';
                if (isset($video['info']['DtInicio'])) {
                    $html .= '<div class="aula"><p class="nome">Aula disponível a partir de ' . date('d/m/Y',
                            strtotime($video['info']['DtInicio'])) . '</p></div>';
                } else {
                    $html .= '<div class="aula"><p class="nome">Questões e Aulas indisponíveis no momento.</p></div>';
                }

                $html .= '<input type="hidden" id="totalNovaAulas" value="0" > 
				</li>';
            }
        }

        return $html;
    }

    public function getHtmlDetalhesCurso($percentualMetaEscola, $percentualMetaQuestao, $exibirDisciplina = false, $liberarQuestao = false){

    }
}
