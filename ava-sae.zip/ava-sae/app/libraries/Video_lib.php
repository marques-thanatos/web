<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Video_lib {


    function __construct() {
            $this->CI = & get_instance();
            //FIXME:  remover instancia do dynamoDB
//            $this->CI->load->model('video_model', 'video');
            $this->CI->load->model('disciplina_model', 'disciplina');
            $this->CI->load->model('curso_model', 'curso');
            //$this->CI->load->model('acesso_model');
    }
	
    public function porcentagemVideo($array, $paramVideo, $metaPercentual, $grupoaulaid) {
        $logs = $this->CI->video->getPlayerLogs($paramVideo);
        if ($logs) {
            $aula = $this->aula($logs);
            $percentual = $this->percentual($aula);
        }
        
        $duracaoTotal = 0;
        if (isset($array['info']['TempoTotalVideos'])) {
            $duracaoTotal = $array['info']['TempoTotalVideos'];
        }
        // considera somente os v�deos:
        if (isset($array['aulas']) && $array['info']['QtdVideos'] > 0) {
            foreach ($array['aulas'] as $item) {
                if ($item['Tipo'] == 'N') {
                    //print_pre($item);die;
                    // calcula percentual assistido:
                    $aulaid = $item['AulaID'];
                    $percAula = 0;
                    if (isset($percentual[$aulaid])) {
                        // percentual assistido do v�deo em rela��o ao total da aula:
                       $percAula = $this->calculaPorcentagem($percentual[$aulaid], $duracaoTotal );
                    }
                    
                    if ($percAula >= $metaPercentual) {
                        // salva como aula assistida:
                        $fields['DtAlt'] = date('Y-m-d H:i:s');
                        $fields['VideoAulaAssistida'] = 'S';
                        $fields['DtConclusao'] = date('Y-m-d H:i:s');

                        $where['UsuarioID'] = $this->CI->session->userdata('pessoaid');
                        $where['AulaID'] = $aulaid;
                        $where['AssuntoID'] = $item['DisciplinaID'];
                        $where['DisciplinaID'] = $grupoaulaid; //grupoaulaid
                        $where['VideoAulaAssistida'] = NULL;

                        $this->CI->curso->gravaRespostaAluno($fields, $where);
                    }
                }
            }
        }
                
        //$array['metaPercentual_' . $paramVideo['turmaid']] = $metaPercentual;
        //$array['percentual_' . $paramVideo['turmaid']] = isset($percentual) ? $percentual : 0;
        $array['percentualVideo'] = isset($percAula) ? $percAula : 0;
        
        return $array;
    }
    
    function aula($logs){
        $aula = array();
        foreach ($logs as $v) {
            list($dtcad, $hora) = explode(' ', $v['datacadastro']);
            list($h, $m, $s) = explode(':', $hora);
            $hc = $h * 60 * 60 + $m * 60 + $s; // hora cadastro

            list($h, $m, $s) = explode(':', $v['tempocorrente']);
            $tc = $h * 60 * 60 + $m * 60 + $s; //tempo corrente assistido

            if (isset($v['aulaid']) && $v['evento'] != 'resume') {
                $aula[$v['aulaid']][$dtcad][$hc] = array(
                    'evento' => $v['evento'], 
                    'tempocorrente' => $tc,
                    'tempode' => (isset($v['tempode'])) ? $v['tempode'] : 0,
                    'tempopara' => (isset($v['tempopara'])) ? $v['tempopara'] : 0
                );
            }
        }
        return $aula;
    }
    
    function percentual($aula){
        $percentual = array();
        
        foreach ($aula as $id => $dt) {
            ksort($dt);
            $percentual[$id] = 0;

            foreach ($dt as $tempo) {
                ksort($tempo);
                $anterior = 0;
                $perc = 0;
                $percAux = 0;

                foreach ($tempo as $p) {
//                    if ($p['evento'] == 'resume') continue; // pula

                    if ($p['tempode'] == 0) {
                        $anterior = 0; // reinicia
                    }
                    
                    $percAux = $p['tempode'] - $anterior;
                    if ($percAux > 0) $perc += $percAux;
                    
                    if ($p['evento'] == 'seek') {
                        $anterior = $p['tempopara'];
                    } else {
                        $anterior = $p['tempode'];
                    }
                }
                $percentual[$id] += $perc;
            }
        }
        return $percentual;
    }
    
    function calculaPorcentagem($percentualAssistido, $duracaoTotal){
        $percAula = round(($percentualAssistido * 100) / $duracaoTotal, 1);
        
        if($percAula >= 20)
        {
            $percAula += 5;
        }

        if ($percAula > 100) {
            $percAula = 100;
        }
        return $percAula;
    }
    
    public function totalVideoAula($DisciplinaID){
        //calculo duracao video
        $aulasVideo = $this->CI->disciplina->buscaDadosAulas($DisciplinaID,null,'asc');
        if ($aulasVideo != '') {
            // calcula dura��o das videoaulas em segundos:
            $duracaoTotal = 0;
            foreach ($aulasVideo as $k => $v) {
                if ($v['Duracao'] && $v['Duracao'] != '') {
                    if ( $v['Tipo'] != "N" ){ continue; }
                    $duracao = $v['Duracao'];

                    // tempo em segundos:
                    $array = explode(':', $duracao);

                    if (count($array) == 2) {
                        $h = 0;
                        $m = (isset($array[1])) ? $array[1] : 0;
                        $s = (isset($array[2])) ? $array[2] : 0;
                    } else if (count($array) == 3) {
                        $h = (isset($array[0])) ? $array[0] : 0;
                        $m = (isset($array[1])) ? $array[1] : 0;
                        $s = (isset($array[2])) ? $array[2] : 0;
                    }

                    // dura��o do v�deo em segundos
                    $tempoTotal = $h * 60 * 60 + $m * 60 + $s;
                    $duracaoTotal += $tempoTotal;
                }
            }
        }
        return $duracaoTotal;
    }
	
}
