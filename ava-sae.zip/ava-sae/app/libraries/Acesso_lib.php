<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Acesso_Lib {

    /**
     * Acesso
     *
     * Verifica se o usuário possui acesso simult�neo com o mesmo login
     *
     * @access  public
     * @return  boolean
     *
     *
     */
    public function Acesso_Lib() {
        $this->CI = & get_instance();
        $this->CI->load->model('login_model');
        
        $sessionId = session_id();
        
        // In this case, $_SESSION['id'] is the id on table D019, 
        // not the session id on ci_session
        $session = $this->CI->login_model->getSessions(
            $_SERVER['REMOTE_ADDR'],
            $_SESSION['id'],
            $sessionId
        );

        if ($session)
        {
            $this->CI->session->set_userdata("pcc", "S");
        }
        else
        {
            $this->CI->session->set_userdata("pcc", "N");
            $this->CI->session->set_userdata("session_id", $session["id"]);
        }

    }
}


/* End of file Acesso.php */
/* Location: ./system/application/libraries/Acesso.php */
