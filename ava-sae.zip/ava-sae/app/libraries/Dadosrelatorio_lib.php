<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dadosrelatorio_lib {


	function __construct() {
		$this->CI = & get_instance();
		$this->CI->load->model('cadastro_model', 'cadastro');
		//$this->CI->load->model('acesso_model');
	}

    /**
     * Dados Relat�rio
     *
     * Insere no banco os dados do aluno necess�rios para a gera��o de relat�rios
     *
     * @access	public
     * @return	boolean
     *
     *
     */
    public function insereDados($fields) {

    	$insert = array();

    	//agrupa todos os dados comuns as disciplinas
    	$dados = array( 'UsuarioID' => $fields['PessoaID'],
                        'NomeAluno' => utf8_decode($fields['Nome']),
                        'TurmaID' => $fields['Turma'],
                        'DescTurma' => utf8_decode($fields['DescricaoTurma']),
                        'EscolaID' => $fields['Escola'],
                        'NomeEscola' => utf8_decode($fields['NomeEscola']),
                        'SerieID' => $fields['Serie'],
                        'DescSerie' => utf8_decode($fields['DescricaoSerie']),
                        'VigenciaTurma' => $fields['VigenciaTurma'],
                        'DtCad' => date('Y-m-d H:i:s'),
                        'DtAlt'  => date('Y-m-d H:i:s')
                        );

    	//busca meta (meta � geral para a serie da escola)
    	$meta = $this->CI->cadastro->verificaMeta($dados['SerieID'],$dados['EscolaID']);
    	if ($meta) {
            $dados['Meta'] = $meta[0]['Meta'];
            $percentualvideo = $meta[0]['Percentual'];
    	} else {
            $dados['Meta'] = 60;
            $percentualvideo = 60;
            /* SALVA A CONFIGURACAO DA SERIE PARA A ESCOLA */
            $fieldsSerie = array(
                'UsuarioAlt' => $this->CI->session->userdata('itemName'),
                'UsuarioCad' => $this->CI->session->userdata('itemName'),
                'Tipo' => 'S',
                'EscolaID' => $dados['EscolaID'],
                'DtCad' => date('Y-m-d H:i:s'),
                'NomeEscola' => utf8_decode($fields['NomeEscola']),
                'DtAlt' => date('Y-m-d H:i:s'),
                'Meta' => $dados['Meta'],
                'Serie' => $dados['SerieID'],
                'Percentual' => $percentualvideo
            );
            $this->CI->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $dados['EscolaID'].$dados['SerieID'], $fieldsSerie, true);
    	}

    	//busca as disciplinas
    	$disciplina = $this->CI->cadastro->verificaDisciplina($dados['SerieID'], $dados['VigenciaTurma']);
        $existeQuestao = $this->CI->cadastro->verificaExisteQuestao($dados['UsuarioID']);
    	$a = 0;
    	if (!empty($disciplina) && $existeQuestao->Existe < 1 ) {
            foreach ($disciplina as $k => $val) {
                //busca as frentes de cada disciplina
                $frente = $this->CI->cadastro->verificaFrente($val['itemName']);
                if ($frente) {
                    foreach ($frente as $keyf => $fre) {
                        //busca os assuntos de cada frente
                        $assuntos = $this->CI->cadastro->verificaAssuntos($val['itemName'],$fre['CategoriaID']);
                        if ($assuntos) {
                            foreach ($assuntos as $keyA => $as) {
                                //Agenda aluno
                                $agenda = $this->CI->cadastro->getAgendamentoAluno($dados['EscolaID'],$val['ItemName'],$fre['CategoriaID'],$as['DisciplinaID'],$dados['TurmaID'],$dados['UsuarioID']);

                                //busca data de inicio e fim do assunto
                                if (empty($agenda)) {
                                    $agenda = $this->CI->cadastro->getAgendamento($dados['EscolaID'],$val['ItemName'],$fre['CategoriaID'],$as['DisciplinaID'],$dados['TurmaID']);
                                }
                                $aulas = $this->CI->cadastro->getAulas($as['DisciplinaID']);
                                $videoAulas = $this->CI->cadastro->getAulas($as['DisciplinaID'],'N');

                                //busca as questoes de cada aula
                                foreach ($aulas as $keyAu => $aula) {
                                    $questoes = $this->CI->cadastro->getQuestoesAula($val['itemName'],$aula['AulaID']);

                                    if ($questoes) {
                                        // tratamento para questoes similares:
                                        $questoesSimilares = array();
                                        foreach ($questoes as $i => $item) {
                                            if (isset($item['Similar']) && $item['Similar'] == 'S') {
                                                $questoesSimilares[$item['GrupoSimilar']][] = $item;
                                                // retira as quest�es similares do array
                                                unset($questoes[$i]);
                                            }
                                        }

                                        foreach ($questoesSimilares as $grupo => $qt) {
                                            // randomiza o array
                                            shuffle($qt);
                                            $umaQuestao = $qt[0];
                                            // verifica se j� est� no array de cadastro
                                            $key = array_search($umaQuestao['QuestaoID'], array_column($insert, 'QuestaoID'));
                                            if ($key !== FALSE) {
                                                $umaQuestao = $qt[1]; // pega a pr�xima questao da lista
                                            }

                                            // adiciona a quest�o escolhida aleatoriamente dentre as similares
                                            $questoes[] = $umaQuestao;
                                        }
                                        foreach ($questoes as $keyQ => $que) {
                                            $insert[$a] = $dados;
                                            $insert[$a]['DisciplinaID'] = $val['itemName'];
                                            $insert[$a]['DescDisciplina'] = $val['Descricao'];
                                            $insert[$a]['FrenteID'] = $fre['CategoriaID'];
                                            $insert[$a]['DescFrente'] = $fre['Descricao'];
                                            $insert[$a]['AssuntoID'] = $as['DisciplinaID'];
                                            $insert[$a]['DescAssunto'] = $as['Descricao'];
                                            $insert[$a]['DtAgendaInicio'] = (isset($agenda[0]['DtInicio']) && $agenda[0]['DtInicio'] != '-') ? $agenda[0]['DtInicio'] : null;
                                            $insert[$a]['DtAgendaFim'] = (isset($agenda[0]['DtFim']) && ($agenda[0]['DtFim'] != '-' && $agenda[0]['DtFim'] != '--'))? $agenda[0]['DtFim'] : null;
                                            $insert[$a]['AulaID'] = $aula['AulaID'];
                                            $insert[$a]['DescAula'] = $aula['Tema'];
                                            $insert[$a]['Tipo'] = $aula['Tipo'];
                                            $insert[$a]['QuestaoID'] = $que['QuestaoID'];
                                            $insert[$a]['TotalQuestoesAula'] = count($questoes);

                                            $a++;
                                        }
                                    }
                                }

                                if ($videoAulas) {
                                     $dados['Meta'] = $percentualvideo;
                                    //videoaulas nao precisa buscar questoes
                                    foreach ($videoAulas as $keyV => $video) {

                                        $insert[$a] = $dados;
                                        $insert[$a]['DisciplinaID'] = $val['itemName'];
                                        $insert[$a]['DescDisciplina'] = $val['Descricao'];
                                        $insert[$a]['FrenteID'] = $fre['CategoriaID'];
                                        $insert[$a]['DescFrente'] = $fre['Descricao'];
                                        $insert[$a]['AssuntoID'] = $as['DisciplinaID'];
                                        $insert[$a]['DescAssunto'] = $as['Descricao'];
                                        $insert[$a]['DtAgendaInicio'] = (isset($agenda[0]['DtInicio']) && $agenda[0]['DtInicio'] != '-') ? $agenda[0]['DtInicio'] : null;
                                        $insert[$a]['DtAgendaFim'] = isset($agenda[0]['DtFim']) && ($agenda[0]['DtFim'] != '-' && $agenda[0]['DtFim'] != '--') ? $agenda[0]['DtFim'] : null;
                                        $insert[$a]['AulaID'] = $video['AulaID'];
                                        $insert[$a]['DescAula'] = $video['Tema'];
                                        $insert[$a]['Tipo'] = $video['Tipo'];

                                        $a++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
    	}
    	$result = null;
    	foreach ($insert as $key => $val) {
            $result = $this->CI->cadastro->gravaDadosRelatorio($val);
    	}
    	return $result;
    }

    /**
     * Insere uma quest�o individualmente
     * @param number $grupoAulaID
     * @param number $aulaID
     * @param number $categoriaID
     * @param string $cursoNome
     * @param string $descAssunto
     * @param string $dados
     * @return string
     */
    function insereQuestao($grupoAulaID = 0, $aulaID = 0, $categoriaID = 0, $cursoNome = '', $descAssunto = '', $dados = null,$meta = null, $dadosBaseUsuario = null, $isPlataformaLiteraria = false) {
        // cadastra as quest�es:
        $questoes = [];
        if( !$isPlataformaLiteraria ) 
            $questoes = $this->CI->curso->getQuestoesAula($grupoAulaID,$aulaID);
        else
            $questoes = $this->CI->curso->getQuestoesPlataformaLiteraria($grupoAulaID,$aulaID);
		// Puxando dados do usuário através de argumento, por que o app não utiliza a session do AVA
		if ( empty($dadosBaseUsuario) ){
			$perfil 		= $this->CI->session->userdata('perfil');
			$usuarioid 		= $this->CI->session->userdata('usuarioid');
			$idUsuario 		= $this->CI->session->userdata('pessoaid');
			$turmaid 		= $this->CI->session->userdata('TurmaID');
			$escolaid 		= $this->CI->session->userdata('escola');	
			$nomeAluno 		= $this->CI->session->userdata('nome');	
		} else {
			$perfil 		= $dadosBaseUsuario['perfilid'];
			$usuarioid 		= $dadosBaseUsuario['pessoaid'];
			$idUsuario 		= $dadosBaseUsuario['pessoaid'];
			$turmaid 		= $dadosBaseUsuario['turmaid'];
			$escolaid 		= $dadosBaseUsuario['escolaid'];
			$nomeAluno 		= $dadosBaseUsuario['nomeAluno'];
		}

        // tratamento para questoes similares
        if (!empty($questoes) && $perfil == PERFIL_ALUNO && !$isPlataformaLiteraria) {
            $questoesSimilares = array();
            foreach ($questoes as $i => $item) {
                if (isset($item['Similar']) && $item['Similar'] == 'S') {
                    $questoesSimilares[$item['GrupoSimilar']][] = $item;
                    // retira as quest�es similares do array
                    unset($questoes[$i]);
                }
            }

            foreach ($questoesSimilares as $grupo => $qt) {
                // randomiza o array
                shuffle($qt);
                // pega a primeira quest�o do array misturado
                $umaQuestao = $qt[0];
                // verifica se j� est� cadastrada para o aluno
                $cadastro = $this->CI->curso->verificaExisteQuestao($usuarioid, $umaQuestao['JarvisItemID'] ?: $umaQuestao['QuestaoID']);
                if ($cadastro->Existe != FALSE) {
                    $umaQuestao = $qt[1]; // pega a pr�xima questao da lista
                }

                // adiciona a quest�o escolhida aleatoriamente dentre as similares
                $questoes[] = $umaQuestao;
            }
        }

        $categoria = $this->CI->curso->verificaCategoriaOrdem($grupoAulaID, $categoriaID);
        $agendamento = $this->CI->curso->getAgendamento($escolaid, $grupoAulaID, $categoria[0]['CategoriaID'], $dados['DisciplinaID'], $turmaid);
        $dadosUsuario['DtAgendaInicio'] = null;
        $dadosUsuario['DtAgendaFim'] = null;
        if (!empty($agendamento) ) {
            $dadosUsuario['DtAgendaInicio'] = $agendamento[0]['DtInicio'];
            $dadosUsuario['DtAgendaFim'] = $agendamento[0]['DtFim'];

            if ($agendamento[0]['DtInicio'] == '-' || $agendamento[0]['DtInicio'] == '--') {
                $dadosUsuario['DtAgendaInicio'] = null;
            }

            if($agendamento[0]['DtFim'] == '-' || $agendamento[0]['DtFim'] == '--'){
                $dadosUsuario['DtAgendaFim'] = null;
            }
        }

        if (!empty($questoes)) {
            reset($questoes); // posiciona no primeiro registro
            $atual = current($questoes); // extrai o primeiro registro
            $result['questaoAtual'] = $atual['JarvisItemID'] ?: $atual['QuestaoID'];
        } else {
            $result['questaoAtual'] = 0;
        }

        $result['qtdQuestoes'] = count($questoes);

        $meta = collect($this->CI->cadastro->getConfiguracoes($escolaid))->where('Serie', $this->CI->session->teams[0]->grade_id)->first()['Meta'];

        $questoesArray = collect($questoes)->pluck('QuestaoID')->toArray();
        // grava dados no AVA, se for ALUNO
        if ($perfil == PERFIL_ALUNO && !empty($questoes)) {
            // $dadosAluno = $this->CI->curso->buscaDadosUsuario($idUsuario);
            $VigenciaTurma = $this->CI->session->teams[0]->school_year_id == 2 ? '2021' : '2020';
            $dadosUsuario['UsuarioID'] = $idUsuario;
            $dadosUsuario['NomeAluno'] = $nomeAluno;
            $dadosUsuario['AulaID'] = $aulaID;
            $dadosUsuario['DescAula'] = $dados['Tema'];
            $dadosUsuario['AssuntoID'] = $dados['DisciplinaID'];
            $dadosUsuario['DescAssunto'] = $descAssunto;
            $dadosUsuario['DisciplinaID'] = $grupoAulaID;
            $dadosUsuario['DescDisciplina'] = $cursoNome;
            $dadosUsuario['EscolaID'] = $escolaid;
            $dadosUsuario['FrenteID'] = $categoria[0]['CategoriaID'];
            $dadosUsuario['DescFrente'] = $categoria[0]['Descricao'];
            $dadosUsuario['NomeEscola'] = $this->CI->session->nomeEscola;
            $dadosUsuario['TurmaID'] = $turmaid;
            $dadosUsuario['DescTurma'] = $this->CI->session->teams[0]->name;
            $dadosUsuario['SerieID'] = $this->CI->session->teams[0]->grade_id;
            $dadosUsuario['descSerie'] = $this->CI->session->teams[0]->name;
            $dadosUsuario['VigenciaTurma'] = $VigenciaTurma;
            $dadosUsuario['Tipo'] = $dados['Tipo'];
            $dadosUsuario['TotalQuestoesAula'] = count($questoes);
            $dadosUsuario['DtCad'] = date('Y-m-d H:i:s');
            $dadosUsuario['DtAlt'] = date('Y-m-d H:i:s');
            $dadosUsuario['Meta'] = $meta;

            $questoesUsuario = collect($this->CI->curso->verificarQuestoesAlunos($questoesArray, $idUsuario))->pluck('QuestaoID')->toArray();
            // grava os dados:
            foreach ($questoes as $qt) {
              
                $dadosUsuario['QuestaoID'] = $qt['JarvisItemID'] ?: $qt['QuestaoID'];
                if ($dadosUsuario['DtAgendaFim'] == '-' || $dadosUsuario['DtAgendaFim'] == '--') {
                    $dadosUsuario['DtAgendaFim'] = null;
                }

                if(!in_array($dadosUsuario['QuestaoID'], $questoesUsuario)){
                    $this->CI->curso->gravaQuestoesAluno($dadosUsuario);
                }
            }
        }

        return $result;
    }

    /**
     * Insere uma videoaula individualmente
     * @param number $grupoAulaID
     * @param number $aulaID
     * @param number $categoriaID
     * @param string $cursoNome
     * @param string $descAssunto
     * @param string $dados
     * @return string
     */
    function insereVideo($grupoAulaID = 0, $aulaID = 0, $categoriaID = 0, $cursoNome = '', $descAssunto = '', $dados = null, $dadosBaseUsuario = null)
    {
		// Puxando dados do usuário através de argumento, por que o app não utiliza a session do AVA
       
		if ( empty($dadosBaseUsuario) ){
			$perfil 		= $this->CI->session->userdata('perfil');
			$usuarioid 		= $this->CI->session->userdata('usuarioid');
			$idUsuario 		= $this->CI->session->userdata('pessoaid');
			$turmaid 		= $this->CI->session->userdata('teams')[0]->id;
			$escolaid 		= $this->CI->session->userdata('escola');	
			$nomeAluno 		= $this->CI->session->userdata('nome');	
		} else {
			$perfil 		= $dadosBaseUsuario['perfilid'];
			$usuarioid 		= $dadosBaseUsuario['pessoaid'];
			$idUsuario 		= $dadosBaseUsuario['pessoaid'];
			$turmaid 		= $dadosBaseUsuario['turmaid'];
			$escolaid 		= $dadosBaseUsuario['escolaid'];
			$nomeAluno 		= $dadosBaseUsuario['nomeAluno'];
		}

        $categoria = $this->CI->curso->verificaCategoriaOrdem($grupoAulaID, $categoriaID);
        $dadosAluno = $this->CI->curso->buscaDadosUsuario($idUsuario);
        $agendamento = $this->CI->curso->getAgendamento($escolaid, $grupoAulaID, $categoria[0]['CategoriaID'], $dados['DisciplinaID'], $turmaid);
  
        if($agendamento)
        {
            $dadosUsuario['DtAgendaInicio'] = $agendamento[0]['DtInicio'];
            $dadosUsuario['DtAgendaFim'] = $agendamento[0]['DtFim'];

            if($agendamento[0]['DtInicio'] == '-' || $agendamento[0]['DtInicio'] == '--'){
                $dadosUsuario['DtAgendaInicio'] = null;
            }

            if($agendamento[0]['DtFim'] == '-' || $agendamento[0]['DtFim'] == '--'){
                $dadosUsuario['DtAgendaFim'] = null;
            }
        }

        if($dadosUsuario['DtAgendaFim'] == '-' || $dadosUsuario['DtAgendaFim'] == '--'){
            $dadosUsuario['DtAgendaFim'] = null;
        }
        
        $VigenciaTurma = $this->CI->session->userdata('teams')[0]->school_year_id == 2 ? '2021' : '2020';

        $dadosUsuario['UsuarioID'] = $idUsuario;
        $dadosUsuario['NomeAluno'] = $nomeAluno;
        $dadosUsuario['AulaID'] = $aulaID;
        $dadosUsuario['DescAula'] = $dados['Tema'];
        $dadosUsuario['AssuntoID'] = $dados['DisciplinaID'];
        $dadosUsuario['DescAssunto'] = $descAssunto;
        $dadosUsuario['DisciplinaID'] = $grupoAulaID;
        $dadosUsuario['DescDisciplina'] = $cursoNome;
        $dadosUsuario['EscolaID'] = $escolaid;
        $dadosUsuario['FrenteID'] = $categoria[0]['CategoriaID'];
        $dadosUsuario['DescFrente'] = $categoria[0]['Descricao'];
        $dadosUsuario['NomeEscola'] = $this->CI->session->userdata('nomeEscola');
        $dadosUsuario['TurmaID'] = $turmaid;
        $dadosUsuario['DescTurma'] = $dadosAluno->DescricaoTurma;
        $dadosUsuario['SerieID'] = $dadosAluno->DescricaoSerie;
        $dadosUsuario['descSerie'] = isset($dadosAluno->DescricaoSerie) ? $dadosAluno->DescricaoSerie : '';
        $dadosUsuario['VigenciaTurma'] = $VigenciaTurma;
        $dadosUsuario['Tipo'] = $dados['Tipo'];
        $dadosUsuario['DtCad'] = date('Y-m-d H:i:s');
        $dadosUsuario['DtAlt'] = date('Y-m-d H:i:s');

        $meta = $this->CI->cadastro->getConfiguracoesSerie($escolaid,$dadosUsuario['SerieID'])->Percentual;
        $dadosUsuario['Meta'] = isset($meta) ? $meta : 100;

        $this->CI->curso->gravaQuestoesAluno($dadosUsuario);
    }


    function montaComboTurma($turmas, $turmaSel = ''){
            //monta o combo das turmas com os dados da tabela D019
            $data['comboTurma'] = '<option value="">Selecione uma turma</option>';
            foreach($turmas as $key => $dados) {
                $data['comboTurma'] .= '<optgroup label="'.$key.'">';
                foreach($dados as $k => $value) {
                        $selected = $k == $turmaSel ? 'selected' : '';
                        $data['comboTurma'] .= '<option value="'.$k.'" '.$selected.'>'.$value['DescricaoTurma'] .'</option>';
                }
                $data['comboTurma'] .= '</optgroup>';
            }
            return $data['comboTurma'];

    }

    function unique_multidim_array($array, $key){
        $temp_array = array();
        $i = 0;
        $key_array = array();
		foreach($array as $val){
            if(!in_array($val[$key],$key_array)){
                $key_array[$i] = $val[$key];
                $temp_array[$i] = $val;
            }
            $i++;
        }
        return $temp_array;
    }

    /**
     * Insere uma quest�o individualmente
     * @param number $grupoAulaID
     * @param number $aulaID
     * @param number $categoriaID
     * @param string $cursoNome
     * @param string $descAssunto
     * @param string $dados
     * @return string
     */
    function insereQuestaoReforco($grupoAulaID = 0, $aulaID = 0, $categoriaID = 0, $cursoNome = '', $descAssunto = '', $dados = null, $questoesReforco)
    {

        $questoes = $questoesReforco;


        $idUsuario = $this->CI->session->userdata('pessoaid');
        $turmaid = $this->CI->session->userdata('TurmaID');
        $escolaid = $this->CI->session->userdata('escola');

        $categoria = $this->CI->curso->verificaCategoriaOrdem($grupoAulaID, $categoriaID);
        $agendamento = $this->CI->curso->getAgendamento($escolaid, $grupoAulaID, $categoria[0]['CategoriaID'], $dados['DisciplinaID'], $turmaid);

        if($agendamento)
        {
            $dadosUsuario['DtAgendaInicio'] = $agendamento[0]['DtInicio'];
            $dadosUsuario['DtAgendaFim'] = $agendamento[0]['DtFim'];

            if($agendamento[0]['DtInicio'] == '-' || $agendamento[0]['DtInicio'] == '--'){
                $dadosUsuario['DtAgendaInicio'] = null;
            }

            if($agendamento[0]['DtFim'] == '-' || $agendamento[0]['DtFim'] == '--'){
                $dadosUsuario['DtAgendaFim'] = null;
            }
        }

        if (!empty($questoes))
        {
            reset($questoes); // posiciona no primeiro registro
            $atual = current($questoes); // extrai o primeiro registro
            $result['questaoAtual'] = $atual['QuestaoID'];
        }
        else $result['questaoAtual'] = 0;

        $result['qtdQuestoes'] = count($questoes);

        // grava dados no AVA, se for ALUNO
        if ($this->CI->session->userdata('perfil') == PERFIL_ALUNO && !empty($questoes))
        {
            $dadosAluno = $this->CI->curso->buscaDadosUsuario($idUsuario);

            $dadosUsuario['UsuarioID'] = $idUsuario;
            $dadosUsuario['NomeAluno'] = $this->CI->session->userdata('nome');
            $dadosUsuario['AulaID'] = $aulaID;
            $dadosUsuario['DescAula'] = $dados['Tema'];
            $dadosUsuario['AssuntoID'] = $dados['DisciplinaID'];
            $dadosUsuario['DescAssunto'] = $descAssunto;
            $dadosUsuario['DisciplinaID'] = $grupoAulaID;
            $dadosUsuario['DescDisciplina'] = $cursoNome;
            $dadosUsuario['EscolaID'] = $this->CI->session->userdata('escola');
            $dadosUsuario['FrenteID'] = $categoria[0]['CategoriaID'];
            $dadosUsuario['DescFrente'] = $categoria[0]['Descricao'];
            $dadosUsuario['NomeEscola'] = $dadosAluno->NomeEscola;
            $dadosUsuario['TurmaID'] = $dadosAluno->Turma;
            $dadosUsuario['DescTurma'] = $dadosAluno->DescricaoTurma;
            $dadosUsuario['SerieID'] = $dadosAluno->DescricaoSerie;
            $dadosUsuario['DescSerie'] = isset($dadosAluno->DescricaoSerie) ? $dadosAluno->DescricaoSerie : '';
            $dadosUsuario['VigenciaTurma'] = isset($dadosAluno->versao_conteudo_id) ? $dadosAluno->versao_conteudo_id : '';
            //$dadosUsuario['Tipo'] = $dados['Tipo'];
            $dadosUsuario['TotalQuestoesAula'] = count($questoes);
            $dadosUsuario['DtCad'] = date('Y-m-d H:i:s');
            $dadosUsuario['DtAlt'] = date('Y-m-d H:i:s');
            $dadosUsuario['Meta'] = $this->CI->session->userdata('meta');
            $dadosUsuario['TipoQuestaoID'] = 4; // Refor�o

            // grava os dados:
            foreach ($questoes as $qt)
            {
                $dadosUsuario['QuestaoID'] = $qt['QuestaoID'];
                if($dadosUsuario['DtAgendaFim'] == '-' || $dadosUsuario['DtAgendaFim'] == '--'){
                    $dadosUsuario['DtAgendaFim'] = null;
                }

               $this->CI->curso->gravaQuestoesAlunoReforco($dadosUsuario);
            }
        }

        return $result;
    }
}
/* End of file Acesso.php */
/* Location: ./system/application/libraries/Acesso.php */
