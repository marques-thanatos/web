<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Classe Simpledb_lib
 * Library com fun��es pertinentes a facilitar a utiliza��o do simpleDB
 * Created: 05/11/2013
 * 
 * @author Maria C. Dadalt
 */
class Simpledb_lib {

    private $_sdb;
    private $_selectResponse; // Last response sent
    private $_dados = array();
    private $_format = array();

    function __construct() {
        $CI = & get_instance();

        // instancia a conec��o com o simpledb
        // a lib awslib � instanciada no autoload
        $this->_sdb = $CI->awslib->get_sdb();
    }

    /**
     * Fun��o que verifica se a consulta possui um next token. Em caso positivo,
     * a mesma armazena faz a consulta novamente at� que não existam mais quebras
     * na consulta do next token.
     * ver: http://docs.aws.amazon.com/AWSSDKforPHP/latest/index.html
     * @param string $select_expression
     * @return array | FALSE se vazio
     */
    function get_all_responses($select_expression, $limit = 0) {

        $this->_dados = array();
        $next_token = null;

        do {
            if ($next_token) {
                $response = $this->_sdb->select($select_expression, array(
                    'NextToken' => $next_token,
                ));
                $this->format_response($response);
            } else {
                $response = $this->_sdb->select($select_expression);
                $this->format_response($response);
            }

            $next_token = isset($this->_selectResponse->SelectResult->NextToken) ?
                    (string) $this->_selectResponse->SelectResult->NextToken : null;
        } while ($next_token);

        if ($this->_dados) {
            return $this->_dados;
        }

        return FALSE;
    }

    /**
     * Fun��o que verifica se a resposta dada pelo SimpleDB � correta. Caso contr�rio,
     * lan�a excess�o e o c�digo do erro.
     * ver: http://docs.aws.amazon.com/AmazonSimpleDB/latest/DeveloperGuide/APIError.html
     * @param CFResponse $response
     * @throws Exception
     */
    function format_response($response) {

        if ($response->isOk()) {
            $this->_selectResponse = $response->body;
            $merge = $this->gerar_array($this->_selectResponse->SelectResult);
            if ($merge !== FALSE) {
                $this->_dados = array_merge($this->_dados, $merge);
            }
        } else {
            $this->_selectResponse = $response->body;
            throw new Exception("Ocorreu um erro com sua solicita��o. C�digo {$response->status}: {$this->_selectResponse->Errors->Error->Message}");
        }
    }

    /**
     * Fun��o que mostra a resposta da amazon em um var_dump
     */
    function show_error() {

        var_dump($this->_selectResponse);
    }

    /**
     * Fun��o que gera um array a partir da resposta da Amazon SDB
     * @param CFSimpleXML $result
     * @return array | FALSE if empty
     */
    function gerar_array($result) {

        $i = 0;
        $return = array();

        if (!isset($result->Item)) {
            return FALSE;
        }

        foreach ($result->Item as $key => $value) {
            foreach ($value->Attribute as $attr) {
                $return[$i]["{$attr->Name}"] = $this->formatCampo($attr->Name, $attr->Value);
            }
            $return[$i]['ItemName'] = utf8_decode((string) $value->Name);
            $i++;
        }

        return $return;
    }
    
    /**
     * Fun��o que cadastra uma formata��o para um campo.
     * passar em $type ('date', 'string', 'int')
     * @param string $type
     * @param string $campo
     * @param string $formato
     */
    function setFormat($type, $campo, $formato){
        $this->_format[] = array(
            'type' => $type,
            'campo' => $campo,
            'formato' => $formato
        );
    }
    
    /**
     * Fun��o que formata o campo passado por parametro de acordo com o que foi
     * cadastrado no formato global.
     * @param string $name
     * @param string $value
     * @return date, string
     */
    function formatCampo($name, $value){
        if(empty($this->_format)){
            return utf8_decode($value);
        }
        foreach ($this->_format as $format) {
            if($name == $format['campo']){
                switch ($format['type']) {
                    case 'date':
                        $data = new DateTime($value);
                        return date_format($data, $format['formato']);
                    default:
                        return utf8_decode($value);
                }
            }
        }
        return utf8_decode($value);
    }

}

/* End of file simpledb_lib.php */
/* Location: ./app/libraries/simpledb_lib.php */