<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Servicos3_lib {

    public $ip;
    public $subip;
    
    public function __construct() {

        $this->CI = & get_instance();
        $this->s3 = $this->CI->iesdesdk2aws->get_service('s3avasae', 'S3', 'sa-east-1');

    }

    /**
     * Verifica Intervalo
     *
     * Verifica se o intervalo de tempo entre a hora atual e horario servidor.
     *
     * @param time $horario  tempo 
     * @access	public
     * @return	boolean
     */
    public function upload_s3($bucket = null,$key = null, $body = null  , $arrayimg = null) {
        if (empty($arrayimg)) {
            $result = $this->s3->putObject(array(
                'Bucket' => $bucket,
                'Key'    => $key,
                'Body'   => $body,
                'ACL' => 'private'//arquivo privado
            ));
        } else {
            $result = $this->s3->putObject($arrayimg);
        }
        return $result;
    }
    
    public function getListIterator($escolaid, $turmaid){
        $iterator = $this->s3->ListObjects(array(
            'Bucket' => 'avasae',
            'Prefix' => 'avasae/xlslogin/'.$escolaid.'/'.$turmaid,
        ));
        return $iterator;
        /*
        echo '<pre>';
         foreach ($iterator as $object) {

                 print_r(end(explode('/', $object['Key'])));
                 // Get a pre-signed URL for an Amazon S3 object
                 $signedUrl = $client->getObjectUrl('arquivos-sae', $object['Key'], '+10 minutes');
                 print_r($signedUrl); echo '<br />';
         //echo $object['Key'] . "\n";
         }
        die;*/
    }
    
    public function getUrlObject($file, $time = '+60 minutes'){
        $signedUrl = $this->s3->getObjectUrl('avasae', $file, $time);
        return $signedUrl;
    }
}

/* End of file Acesso.php */
/* Location: ./system/application/libraries/Acesso.php */
