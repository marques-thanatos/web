<?php

use Ava\App\Services\Assuntos\PegaAssuntoPeloId;
use Ava\App\Services\Bimestres\PegaBimestrePeloId;
use Ava\App\Services\Disciplinas\PegaDisciplinaPeloId;
use Ava\App\Services\Faq\BuscarDadosChamado;
use Ava\App\Services\Respostas\BuscarRespostasAlunoPorAssunto;
use Ava\App\Services\Usuario\BuscarUsuarioPorLogin;
use Ava\App\Support\Perfil;

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Class Informarerro
 */
class Informarerro extends MY_Controller
{

    public $layout = 'relatorio';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $cssMinify = array('style_avasae_bootstrap3', 'mensagem');
    public $css = array();
    public $js = array(
        'jquery/dist/jquery.min',
        'bootstrap/dist/js/bootstrap.min',
        'informarerro',
        'jquery.cookie',
        'mensagem',
        'get-connection-info',
        'ua-parser'
    );
    public $keywords = array('avasae', 'curso');
    public $metaAcertos = 0;

    private $disciplinas = array(
        'Arte' => 'Arte',
        'Biologia' => 'Biologia',
        'Ciências' => 'Ciências',
        'Educação Física' => 'Educação Física',
        'Educação Infantil' => 'Educação Infantil',
        'Espanhol' => 'Língua Espanhola',
        'Filosofia' => 'Filosofia',
        'Física' => 'Física',
        'Geografia' => 'Geografia',
        'História' => 'História',
        'Literatura' => 'Literatura',
        'Língua Espanhola' => 'Língua Espanhola',
        'Língua Inglesa' => 'Língua Inglesa',
        'Língua Portuguesa' => 'Língua Portuguesa',
        'Matemática' => 'Matemática',
        'Química' => 'Química',
        'Sociologia' => 'Sociologia',
        'Plataforma Literária' => 'Plataforma Literária',
        'Arrase no Enem' => 'Arrase no Enem'
    );

    /**
     * @var Ticket_model
     */
    private $ticketClient;

    const TICKET_AREA = 114096252531;

    const TICKET_LIDO = 114096189771;

    const TICKET_NAVEGADOR = 114096253551;

    const TICKET_CONEXAO = 114096253571;

    const TICKET_SEGMENTO = 114096255091;

    const TICKET_SERIE = 114096255391;

    const TICKET_CAMINHO = 114096524951;

    const TICKET_QUESTAO = 114097188431;

    const TICKET_ASSUNTO = 114097188871;

    const TICKET_ID_ERP = 114097972252;

    const TICKET_DISCIPLINA = 114100186832;

    const TICKET_ANO_SERIE = 114101295791;

    const TICKET_SEGMENTO_DESCRICAO = 114099334452;

    const TICKET_OBSERVACAO = 360014817491;

    const TICKET_BIMESTRE = 114100241251;

    const TICKET_E_CLIENTE = 360014734592;

    const TICKET_MOTIVO_CONTATO = 114100056252;

    const TICKET_CATEGORIA_CHAMADO = 360014738052;

    const TICKET_TIPO_PRODUTO = 360014789971;

    const TICKET_PRODUTO_DIGITAL = 114096497852;


    public function __construct()
    {

        parent::__construct();

        $this->load->model('ticket_model', 'tickets');

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $dados['menu_com_legenda'] = false;
        $this->menu_vertical = $this->load->view('view_menurelatorio', $dados, true);

        $this->ticketClient = new Ticket_model();
    }

    function index()
    {
        $liberar = in_array($this->session->userdata('perfil'), [
            PERFIL_PROFESSOR,
            PERFIL_COORDENADOR,
            PERFIL_DIRETOR,
            PERFIL_ESCOLA
        ]);

        if (isset($_SESSION['grupoAulaID']) || $liberar) {

            $questao_id = $this->input->post('questao_id');
            $conteudo = $this->input->post('conteudo');
            $curso = $this->input->post('curso');
            $video = $this->input->post('video');

            $this->load->model('mensagemsae_model', 'mensagem');
            $this->css[] = $this->minify->getCSS('informarerro.min', $this->cssMinify, ENVIRONMENT);

            $array_desc = $this->mensagem->CarregaDescricaoTurmaByLogin($this->session->userdata['login']);
            $data['turmaDesc'] = $array_desc[0]['DescricaoTurma'];
            $data['turmaID'] = $array_desc[0]['Turma'];

            $data['questao_id'] = $questao_id;
            $data['conteudo'] = $conteudo;
            $data['curso'] = $curso;
            $data['video'] = $video;

            $data['assuntoerroid'] = $this->input->post('assuntoerroid');
            /*Verifica se é professor e adiciona a combo de turma*/
            if ($this->session->userdata['perfil'] == PERFIL_PROFESSOR) {
                $fields['Login'] = $this->session->userdata('login');
                $retornoDados = $this->home->verificaDisciplinas($fields, $this->configuracoes[0]['Base'], 'A');
                if (!empty($retornoDados)) {
                    $data['comboTurma'] .= '<option value="" selected>Selecione uma turma</option>';
                    foreach ($retornoDados as $key => $dados) {
                        $data['comboTurma'] .= '<option value="' . $key . '">' . $dados['DescricaoTurma'] . ' (' . $dados['Serie'] . ')' . '</option>';
                    }
                }
            } else {
                $data['comboTurma'] .= '';
            }

            $this->load->view('informarerro', $data);
        } else {
            $redirecionar = $this->session->userdata('redirecionar') ?: '/';

            Redirect($redirecionar);
        }
    }

    /**
     * @throws Exception
     */
    public function reportarErro()
    {
        $this->css[] = $this->minify->getCSS('informarerro.min', $this->cssMinify, ENVIRONMENT);

        $ref = $this->input->get('ref');
        $idQuestao = $this->input->get('idQuestao');
        $dados = $this->buscarDadosUrl($ref, $idQuestao);

        $dados['ref'] = $ref;
        $dados['csrf'] = [
            'name' => $this->security->get_csrf_token_name(),
            'hash' => $this->security->get_csrf_hash()
        ];
        $dados['form'] = $this->getCreateTicketFormFields();

        $this->load->view('informarerro', $dados);
    }

    /**
     * @return array
     * @throws Exception
     */
    private function getCreateTicketFormFields()
    {
        $allFields = $this->ticketClient->getFields();

        return array_filter($allFields, function ($field) {
            return in_array(
                $field['id'],
                [
                    self::TICKET_OBSERVACAO,
                    self::TICKET_DISCIPLINA,
                    self::TICKET_QUESTAO,
                    self::TICKET_ANO_SERIE,
                    self::TICKET_BIMESTRE,
                    self::TICKET_ASSUNTO
                ]
            );
        });
    }

    /**
     * Function to create Zendesk Ticket
     */
    function registrarErro()
    {
        $this->load->model('curso_model', 'curso');
        header('Content-Type: application/json');
        $result = array();

        try {
            $this->load->model('mensagemsae_model', 'mensagem');
            $this->layout = '';

            $data = $this->buscarDadosUrl($this->input->post('href'));

            $origem = $this->input->post('origem');
            if ($origem == 1) {
                $dados['ocorrencia'] = 'Vídeos';
            } elseif ($origem == 2) {
                $dados['ocorrencia'] = 'Questões';
            } else {
                $dados['ocorrencia'] = 'Relatórios';
            }

            $perfil = ($this->session->userdata("perfil") != PERFIL_ALUNO) ? false : true;
            // User data
            $dados["usuario_id"] = $this->session->userdata("pessoaid");
            $dados["escola_id"] = $this->session->userdata("escola");
            $dados["turma_id"] = $this->session->userdata("TurmaID");
            // Ticket data
            $dados['email_reclamante'] = $this->session->userdata('usuario');
            $dados['assunto_erro_id'] = $data['assuntoId'];
            $dados['assunto'] = $data['assunto'] . " | " . $this->input->post('categoria');
            $dados['descricao_erro'] = trim($this->input->post('descricao'));
            $dados['usuario'] = $data['usuario']['Login'];
            $dados['escola'] = $dados["escola_id"];
            $dados['turma'] = $dados["turma_id"];
            $dados['cat_erro'] = $this->input->post('categoria');
            $dados['user_agent'] = $this->input->post('userAgent');
            $dados['txt_error_desc'] = trim($this->input->post('descricao'));;
            $dados['descricao_serie'] = $data['usuario']['DescricaoSerie'];
            $dados['connection_info'] = $this->input->post('conexao');
            $dados['caminho'] = $this->input->post('href');
            $dados['setor'] = $this->input->post('area');

            $dados['questao'] = $this->input->post('questao');
            $dados['curso'] = $data['questao']['disciplina'];

            $dados['idDisciplina'] = $this->input->post('idDisciplina');
            $dados['descDisciplina'] = SaeDigital::make(PegaDisciplinaPeloId::class)->handle(
                $dados['idDisciplina']
            )['Descricao'];
            $dados['idBimestre'] = $this->input->post('idBimestre');
            $dados['descBimestre'] = SaeDigital::make(PegaBimestrePeloId::class)->handle(
                $dados['idBimestre']
            )['Descricao'];
            $dados['idAssunto'] = $this->input->post('idAssunto');
            $dados['descAssunto'] = SaeDigital::make(PegaAssuntoPeloId::class)->handle(
                $dados['idAssunto']
            )['Descricao'];

            $dados['idQuestao'] = $this->input->post('idQuestao');
            $dados['respostaAluno'] = $this->input->post('respostaAluno');

            $array_turma = $this->mensagem->CarregaDescricaoTurmaByLogin($dados['usuario']);

            $dados['dados_turma'] = $array_turma[0];
            $dados['serie'] = $this->input->post('serie');
            $dados['disciplina'] = $this->input->post('disciplina');
            $dados['bimestre'] = $this->input->post('livro');
            $dados['observacao'] = $this->input->post('observacao');
            $dados['conteudo'] = $this->input->post('assunto');

            $turmaId = $this->session->userdata('TurmaID');
            $assuntoID = $this->input->post('idAssunto');
            
            $agendamento = $this->curso->buscarAgendamentoTurmaAssunto($turmaId, $assuntoID, null,  $perfil ? $dados["usuario_id"] : null);
            if (empty($agendamento) && !is_null($assuntoID) && $perfil) {
                throw new \Ava\App\Exceptions\NotFoundException('Vocẽ não possui agendamento para a atividade reportada');
            }

            $dados["ticket"] = $this->criaTicketZendesk($dados);

            return $this->responseJson([
                    'title' => 'Sucesso',
                    'status' => 'success',
                    'message' => 'Ticket criado com sucesso! Em até 72 horas você receberá uma resposta.'
                ], 200);
            }

            catch (\Ava\App\Exceptions\NotFoundException $e) {
                return $this->responseJson([
                    "title" => "Erro",
                    "message" => $e->getMessage(),
                    "status" => "error"
                ], 404);
            } catch (Exception $e) {
                return $this->responseJson([
                    "title" => "Erro",
                    "status" => "error",
                    "message" => "Houve um erro ao criar seu ticket. 
                Por favor contate a assesoria da SAE Digital. Código 2",
                    "error_message" => $e->getMessage()
                ], 500);

            }
    }


    private function criaTicketZendesk($dados)
    {
        $id_erp = (int)$this->session->userdata["id_erp"];

        $client = $this->tickets->getClient();

        $ocorrencia = $dados['ocorrencia'];

        $perfil = $this->session->userdata['perfil'];

        if ($perfil == PERFIL_ALUNO) {
            $subject = '[A] ';
        } elseif ($perfil == PERFIL_RESPONSAVEL) {
            $subject = '[R] ';
        } elseif ($perfil == PERFIL_PROFESSOR) {
            $subject = '[P] ';
        } elseif ($perfil == PERFIL_COORDENADOR) {
            $subject = '[C] ';
        } elseif ($perfil == PERFIL_DIRETOR) {
            $subject = '[D] ';
        } else {
            $subject = '';
        }

        $subject .= $dados["curso"] . ' - ' . $ocorrencia;

        $posicao = strpos(strtolower($dados["curso"]), 'extensivo') !== false ? 1 : 0;
        $pos1 = strpos(strtolower($dados["curso"]), 'mega') !== false ? 2 : 1;
        $descricao = trim(explode(':', explode('-', $dados["curso"])[$pos1])[$posicao]);

        if (!is_null($dados['idQuestao']) && $dados['idQuestao'] !== 'null' && !empty($dados['idQuestao'])) {
            $body = $dados['descBimestre'] . ' - ' . $dados['descAssunto'] . ' - Questão <a href="https://questoes.sae.digital/adm/questao/visualizar/' . $dados['idQuestao'] . '">Q' . $dados['idQuestao'] . "</a><br><br>";
        }

        $body .= 'Caminho: <a href="' . base_url() . 'login?usuariosae=' . $dados['usuario'] . '&redirectsae=' . urlencode($dados['caminho']) . '">' . $dados['caminho'] . "</a><br><br>";

        if (!is_null($dados['descDisciplina']) && $dados['descDisciplina'] !== 'null' && !empty($dados['descDisciplina'])) {
            $body .= 'Disciplina: ' . $dados['descDisciplina'] . "<br><br>";
        }
        if (!is_null($dados['descBimestre']) && $dados['descBimestre'] !== 'null' && !empty($dados['descBimestre'])) {
            $body .= 'Livro: ' . $dados['descBimestre'] . "<br><br>";
        }
        if (!is_null($dados['descAssunto']) && $dados['descAssunto'] !== 'null' && !empty($dados['descAssunto'])) {
            $body .= 'Assunto: ' . $dados['descAssunto'] . "<br><br>";
        }
        if (!is_null($dados['idQuestao']) && $dados['idQuestao'] !== 'null' && !empty($dados['idQuestao'])) {
            $body .= 'Questão: ' . $dados['idQuestao'] . "<br><br>";
        }
        if (!is_null($dados['respostaAluno']) && $dados['respostaAluno'] !== 'null' && !empty($dados['respostaAluno'])) {
            $body .= 'Resposta Aluno: ' . $dados['respostaAluno'] . "<br><br>";
        }

        $body .= 'Ocorrência: ' . $ocorrencia . "<br><br>";
        $body .= 'Problema relatado: ' . $dados['cat_erro'] . "<br><br>";
        $body .= 'Login do usuário: ' . $dados['usuario'] . "<br><br>";
        $body .= 'Turma: ' . $dados['dados_turma']['DescricaoTurma'] . "<br><br>";

        if (strtolower($dados["setor"]) === "editorial") {
            // ID do agente principal do editorial
            $setor = 114351168771;
        } else {
            // ID do agente principal da TI
            $setor = 114350272431; //old
            // $setor = 114094364232; //new
        }

        $ticket = $client->tickets()->create([
            'type' => 'problem',
            'assignee_id' => $setor,
            'tags' => array(),
            'subject' => $subject,
            'comment' => array(
                'html_body' => $body,
                'public' => false

            ),
            'requester' => $this->tickets->getRequester(),
            'priority' => 'normal',
            "custom_fields" => [
                [
                    "id" => self::TICKET_AREA,
                    "value" => strtolower($dados["setor"]) === "editorial" ? 'editorial' : 'ti'
                ],
                [
                    "id" => self::TICKET_LIDO,
                    "value" => false
                ],
                [
                    "id" => self::TICKET_NAVEGADOR,
                    "value" => $dados['user_agent']
                ],
                [
                    "id" => self::TICKET_CONEXAO,
                    "value" => $dados['connection_info']
                ],
                [
                    "id" => self::TICKET_SEGMENTO,
                    "value" => $dados['segmento']
                ],
                [
                    "id" => self::TICKET_SERIE,
                    "value" => $dados['descricao_serie']
                ],
                [
                    "id" => self::TICKET_CAMINHO,
                    "value" => $dados['caminho']
                ],
                [
                    "id" => self::TICKET_QUESTAO,
                    "value" => $dados['questao']
                ],
                [
                    "id" => self::TICKET_ASSUNTO,
                    "value" => isset($dados['conteudo']) ? $dados['conteudo'] : ''
                ],
                [
                    "id" => self::TICKET_ID_ERP,
                    "value" => $id_erp
                ],
                [
                    "id" => self::TICKET_SEGMENTO_DESCRICAO,
                    "value" => $dados['segmento']
                ],
                [
                    "id" => self::TICKET_ANO_SERIE,
                    "value" => $dados['serie']
                ],
                [
                    "id" => self::TICKET_DISCIPLINA,
                    "value" => $dados['disciplina']
                ],
                [
                    "id" => self::TICKET_BIMESTRE,
                    "value" => $dados['bimestre']
                ],
                [
                    "id" => self::TICKET_OBSERVACAO,
                    "value" => $dados['observacao']
                ],
                [
                    "id" => self::TICKET_E_CLIENTE,
                    "value" => 'sim_cliente'
                ],
                [
                    "id" => self::TICKET_MOTIVO_CONTATO,
                    "value" => 'solicitação'
                ],
                [
                    "id" => self::TICKET_CATEGORIA_CHAMADO,
                    "value" => 'produto'
                ],
                [
                    "id" => self::TICKET_TIPO_PRODUTO,
                    "value" => 'produtos_digitais'
                ],
                [
                    "id" => self::TICKET_PRODUTO_DIGITAL,
                    "value" => 'plataforma_adaptativa_ava'
                ]
            ],
        ]);

        $client->tickets()->update($ticket->ticket->id, [
            'comment' => [
                'body' => $dados["descricao_erro"],
                'public' => true,
                'author_id' => $ticket->ticket->requester_id

            ],

        ]);

        return $ticket;
    }

    private function buscarDadosUrl($url, $idQuestao = null)
    {
        $data = [];

        $url = explode('/', $url);

        if (strpos($url[7], '?questao=true') !== false || strpos($url[8],
                '?questao=true') !== false) { //Questão e revisão
            $data['ancora'] = $url[4];
            $data['assuntoId'] = ltrim(substr($url[6], 0, 7), '0');
            $data['aulaId'] = substr($url[6], 8, 14);
            $data['tipoAula'] = ($url[5] === 'questao' || strpos($url[4], 'literaria') !== false) ? 'Q' : 'R';
            $data['questaoOrdem'] = strpos($url[7], '?questao=true') !== false ? 0 : explode('?', $url[8])[0];
        } elseif ($url[3] === 'curso' && strpos($url[7], '?questao=true') === false) { //vídeo geral
            $data['ancora'] = $url[4];
            $data['assuntoId'] = ltrim(substr($url[6], 0, 7), '0');
            $data['aulaId'] = substr($url[6], 8, 14);
            $data['tipoAula'] = 'N';
        } elseif ($url[3] === 'preparatorio') {
            $data['ancora'] = $url[4];
            $data['assuntoId'] = ltrim(substr($url[6], 0, 7), '0');
            $data['aulaId'] = substr($url[6], 8, 14);
            $data['tipoAula'] = 'N';
        }
        
        $data['assunto'] = SaeDigital::make(PegaAssuntoPeloId::class)->handle($data['assuntoId'])['Descricao'];
        $data['usuario'] = SaeDigital::make(BuscarUsuarioPorLogin::class)->handle($this->session->userdata('login'));
        $data['questao'] = [];

        if ((int)$this->session->userdata('perfil') === Perfil::ALUNO && $data['tipoAula'] != 'R') {
            $data['questao'] = SaeDigital::make(BuscarRespostasAlunoPorAssunto::class)->handle(
                $this->session->userdata('pessoaid'), $data['assuntoId'], $data['tipoAula'], !is_null($idQuestao) ? $idQuestao : null
            )[$data['questaoOrdem']];

            if (!empty($data['questao']['DescFrente'])
                && preg_match('/(livro (\d)|(\d)º bimestre)/i', $data['questao']['DescFrente'], $matches)
            ) {
                $data['bimestre'] = array_pop($matches) . 'o';
            }

            $data['serie'] = isset($data['questao']['DescSerie']) ? trim($data['questao']['DescSerie']) : '';
            $data['questao_id'] = isset($data['questao']['QuestaoID']) ? $data['questao']['QuestaoID'] : '';

            $data['disciplina'] = '';
            if (isset($data['questao']['DescDisciplina'])) {
                $questaoDisciplina = $data['questao']['DescDisciplina'];
                $data['disciplina'] = array_shift(array_filter($this->disciplinas, function ($key) use ($questaoDisciplina) {
                    if (intval(strpos($questaoDisciplina, $key)) > 0) {
                        return true;
                    }
                    return false;
                }, ARRAY_FILTER_USE_KEY));
            }

        } else {
            $data['questao'] = SaeDigital::make(BuscarDadosChamado::class)->handle($data['assuntoId'], !is_null($idQuestao) ? $idQuestao : null)[$data['questaoOrdem']];

            if (!empty($data['questao']['bimestre'])
                && preg_match('/(livro (\d)|(\d)º bimestre)/i', $data['questao']['bimestre'], $matches)
            ) {
                $data['bimestre'] = array_pop($matches) . 'o';
            }

            $data['serie'] = isset($data['questao']['serie']) ? trim($data['questao']['serie']) : '';
            $data['questao_id'] = isset($data['questao']['questaoId']) ? $data['questao']['questaoId'] : '';

            $data['disciplina'] = '';
            if (isset($data['questao']['disciplina'])) {

                $questaoDisciplina = $data['questao']['disciplina'];
                $data['disciplina'] = array_shift(array_filter($this->disciplinas, function ($key) use ($questaoDisciplina) {
                    if (intval(strpos($questaoDisciplina, $key)) > 0) {
                        return true;
                    }
                    return false;
                }, ARRAY_FILTER_USE_KEY));
            }
        }

        return $data;
    }

}
