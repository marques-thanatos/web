<?php

use Ava\App\Services\Aluno\BuscarAlunosPorResponsavel;
use Ava\App\Services\NextAVA\AlunosResponsavelNextAva;
use Ava\App\Services\Relatorios\VerificaPlataformaLit;

class Responsavel extends MY_Controller
{
    public $cssMinify = ['style_avasae_bootstrap3', 'botao_imprimir', 'mensagem'];
    public $js = ['jquery/dist/jquery.min', 'bootstrap/dist/js/bootstrap.min', 'mensagem'];

    public function __construct()
    {
        parent::__construct();
        $this->layout = 'relatorio';
        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menurelatorio', $dados, true);
        $this->css[] = $this->minify->getCSS('relatorio_index.min', $this->cssMinify, ENVIRONMENT);
    }

    /**
     *
     * @throws Exception
     */
    public function index()
    {
        try {
            $this->allowProfile(PERFIL_RESPONSAVEL);
            $alunos = SaeDigital::make(AlunosResponsavelNextAva::class)->handle($this->session->userdata('pessoaid'));
            
            foreach ($alunos as $aluno) {
                $plataforma = SaeDigital::make(VerificaPlataformaLit::class)->handle($aluno->id);
                if ($plataforma) {
                    break;
                }
            }

            $this->layout = 'new-ava';
            $this->title = 'AVA SAE';
            $this->description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
            $this->load->view('relatorios/aluno', ['perfil' => (int)$this->session->userdata('perfil'),
                'perfil' => (int)$this->session->userdata('perfil'),
                'plataforma' => $plataforma
            ]);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }
}
