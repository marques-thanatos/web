<?php

use Ava\App\Exceptions\DuplicatedEntryException;
use Ava\App\Exceptions\NotFoundException;
use Ava\App\Services\Assuntos\CalcularDesempenhoAlunoPorAssunto;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracaoEscolaPorSerie;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracaoGeralEscola;
use Ava\App\Services\Disciplinas\PegaDisciplinaPeloId;
use Ava\App\Services\Questoes\BuscaEstruturaQuestoesReforco;
use Ava\App\Services\Respostas\GravarRespostasAlunoReforco;
use Ava\App\Services\Respostas\VerificaRespostaReforco;
use Ava\App\Services\Questoes\BuscaEstatisticasQuestao;
use Ava\App\Support\Perfil;
use Ava\App\Support\Situacao;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property Reforco_model reforco
 */
class Reforco extends MY_Controller {

    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'curso.min', 'redactor.min', 'pt_pt', 'redactor_special_character', 'redactor.fontcolor', 'redactor.fontsize', 'jquery.cookie',); //'curso.min','chosen'
    public $keywords = array('sae', 'curso');

    public function __construct() {
        parent::__construct();

        $this->load->model('curso_model', 'curso');

        // define os arquivos para juntar e comprimir
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'mensagem');

        $this->load->model('curso_model');
        $this->load->model('reforco_model','reforco');
        $this->load->model('disciplina_model', 'disciplina');
        $this->load->library('disciplina_lib');
    }

    /**
     * @param $idAluno
     * @param $idAssunto
     *
     * @return bool
     */
    private function validaAgendamentoReforco($idAluno, $idAssunto, $turmaId=null)
    {
        $agendamentoReforco = $this->reforco->buscarAgendamentoReforco($idAluno, $idAssunto, $turmaId);

        return count($agendamentoReforco) > 0;
    }

    private function urlRetorno($ancora, $turma, $classificacaoId)
    {
        $param = "curso/{$ancora}?turmaID={$turma}";
        if ((int)$this->session->userdata('perfil') === \Ava\App\Support\Perfil::ALUNO && (int)$classificacaoId === 11) {
            $param = "curso-plataforma-literaria/{$ancora}?turmaID={$turma}";
        }

        return $param;
    }


    public function video($Ancora = null)
    {
        $this->cssMinify[] = 'mensagem';
        $this->cssMinify[] = 'style';
        $this->cssMinify[] = 'redactor/redactor';
        $this->cssMinify[] = 'glyphicon';
        $this->cssMinify[] = 'css-responsive';

        $this->css[] = $this->minify->getCSS('video_curso.min', $this->cssMinify, ENVIRONMENT);

        $this->js[] = 'jquery.oembed.min';
        $this->js[] = 'jquery.paginate.min';
        $this->js[] = 'bootstrap-tooltip';

        $this->load->library('dadosrelatorio_lib');
        // widgets class esquerda
        $configuracoes = $this->curso->getConfiguracoesescola($this->session->userdata('escola'));

        //seta valores padrao caso a escola ainda nao tenha cadastrado as configuraçoes
        $data['dadoComplementar'] = '';
      
        $retornoVerificaPacotesAluno = $this->home->verificaGrupoAulaAncora($Ancora);
        if (count($retornoVerificaPacotesAluno) == 0) {
            $retornoVerificaPacotesAluno = $this->home->verificaGrupoAulaAncora(str_replace("a-ano","-ordm-ano",$Ancora));
        }


        if ($configuracoes && isset($configuracoes[0])) {
            $data['RespostaFinalAgendamentoAluno'] = isset($configuracoes[0]['RespostaFinalAgendamentoAluno']) ? $configuracoes[0]['RespostaFinalAgendamentoAluno'] : 'N';
        }

        $data['cursoNome'] = isset($retornoVerificaPacotesAluno[0]['Descricao']) ? $retornoVerificaPacotesAluno[0]['Descricao'] : '';
        $dados = $this->curso->verificaVideoAula();
        $data['serieID'] = $retornoVerificaPacotesAluno[0]['SerieID'];
        $data['perfil'] = $this->session->userdata('perfil');
       
        if (!empty($retornoVerificaPacotesAluno) && !empty($dados)) {
            $turmaId = $this->session->userdata('TurmaID');

            $urlRetorno = $this->urlRetorno($Ancora, $turmaId, $retornoVerificaPacotesAluno[0]['ClassificacaoID']);
            $data['urlRetorno'] = $urlRetorno;

            $session = $this->session->userdata();
            $idUsuario = $session['id'];
            $classificacaoID = $this->session->userdata('ClassificacaoPacotePai');
            $grupoAulaID = $retornoVerificaPacotesAluno[0]['itemName'];
            $disciplinaID = $dados[0]['DisciplinaID'];

            $aulaID = $dados[0]['AulaID'];
            $linkVideoaula = $dados[0]['Video'];

            $data['videoNome'] = $dados[0]['Tema'];
            $data['aulaID'] = $aulaID;
            $data['grupoAulaID'] = $grupoAulaID;
            $data['pdf'] = str_replace('.mp4', '.pdf', $dados[0]['Video']);

            $result = $this->curso->verificaDisciplina($disciplinaID, $grupoAulaID);

            $data['disciplinaNome'] = $result[0]['Descricao'];
            $data['assuntoID'] = $result[0]['DisciplinaID'];
            $data['frenteID'] = $result[0]['CategoriaID'];

            $frente = $this->curso->verificaCategoriaOrdem($grupoAulaID, $result[0]['CategoriaID']);
            $data['DescFrente'] = $frente[0]['Descricao'];

            $data['situacaoVideoAula'] = '';

            // monta todas v?deos aulas relacionadas a disciplina para que posssa ir para os pr?ximos.
            $data['videoaulas'] = $this->curso->verificaVideoAulasDisciplinaVideo($grupoAulaID, $disciplinaID, 'N', false );
            $data['videoPlayer'] = $linkVideoaula;
            $data['videoAulaVer'] = $this->uri->segment(5) ? $this->uri->segment(5) : 1;

            $data['Ancora'] = $Ancora;

            $data['possuiQuestoes'] = 0;
           
            if (!$this->validaAgendamentoReforco($idUsuario, $data['assuntoID'], $turmaId) && $this->session->userdata('perfil') == PERFIL_ALUNO) {
                $data['bloqueiaQuestoes'] = true;
                $data['mensagemBloqueioQuestoes'] = 'Você não possui agendamento de reforço para este assunto.';
                $this->load->view('questao', $data);
                return;
            }

            //verifica se ja foram gravadas as questoes do aluno
            $questoesUsuario = $this->reforco->getQuestoesAlunoReforco($idUsuario, $grupoAulaID, $disciplinaID, $aulaID);
           
            //abre tela de questoes
            if ($this->input->get('questao') == 'true') {
                $questoes = 0;
                $data['qtdQuestoes'] = count($questoesUsuario);
                if (!$questoesUsuario) {

                    /*
                     * Verifica Questões de Reforço - Retorna array pronto
                     */
                    $dadosReforco = $result;

                    $dadosReforco[0]['AulaID'] = $data['aulaID'];
                    $dadosReforco[0]['Tipo'] = 4; // Reforço de Questões

                    $questoesReforco = $this->questoesReforco($dadosReforco, $grupoAulaID);
                    array_multisort($questoesReforco, SORT_NUMERIC);
                    // cadastra as questões:
                    $retorno = $this->dadosrelatorio_lib->insereQuestaoReforco($grupoAulaID, $aulaID, $result[0]['CategoriaID'], $data['cursoNome'], $result[0]['Descricao'], $dados[0], $questoesReforco);


                    $data['qtdQuestoes'] = $retorno['qtdQuestoes'];
                    $data['possuiQuestoes'] = ($retorno['qtdQuestoes'] > 0) ? 1 : 0;
                    $data['questaoAtual'] = 0;
                    $questaoAtual = $retorno['questaoAtual'];
                    // busca a questão inserida
                    $questoesUsuario = $this->reforco->getQuestoesAlunoReforco($idUsuario, $grupoAulaID, $dados[0]['DisciplinaID'], $aulaID);
                } else {
                    $indice = $this->uri->segment(6) ? $this->uri->segment(6) : 0;

                    foreach ($questoesUsuario as $key => $questao) {
                        if (is_null($questao->Resposta)) {
                            $questaoAtual = $questao->QuestaoID;
                            $data['questaoAtual'] = $key;
                            break;
                        } else {
                            $questaoAtual = $questoesUsuario[$indice]->QuestaoID;
                            $data['questaoAtual'] = $indice;
                            $dataResposta = \DateTime::createFromFormat('Y-m-d H:i:s', $questoesUsuario[$indice]->DtConclusao);
                            if ($dataResposta instanceof DateTime) {
                                $data['DataConclusao'] = $dataResposta->format('d-m-Y');
                                $data['HoraConclusao'] = $dataResposta->format('H:i:s');
                            }
                        }
                    }
                }
                //dados questao
                $array = array('questao' => $questaoAtual);

                $resultApi = $this->curso->CarregaQuestaoAPI(
                    $array['questao'],
                    $retornoVerificaPacotesAluno[0]['ClassificacaoID'],
                    $dados[0]['DisciplinaID']
                );

                if (isset($resultApi['success']) && $resultApi['success'] == 1) {
                    $data['ultimaQuestao'] = count($questoesUsuario) == ($data['questaoAtual'] + 1) ? 1 : 0;
                    $data['dadosQuestao'] = $resultApi['message'];

                    //salva a alternativa correta
                    for ($a = 0; count($data['dadosQuestao']['questao']['alternativas']) > $a; $a++) {
                        if ($data['dadosQuestao']['questao']['alternativas'][$a]['opcaoCorreta'] == 1) {
                            $data['altCorreta'] = $data['dadosQuestao']['questao']['alternativas'][$a]['id'];
                            $data['opcaoCorreta'] = $data['dadosQuestao']['questao']['alternativas'][$a]['valorOpcao'];
                        }
                    }

                    $data['aulaID'] = $aulaID;
                    $data['disciplinaID'] = $dados[0]['DisciplinaID'];

                    $data['questaoRespondida'] = isset($questoesUsuario[$data['questaoAtual']]->RespostaCorreta);//isset($questoesUsuario[$data['questaoAtual']]->RespostaCorreta) || $this->session->userdata('perfil') != 273 ? 1 : 0;

                    $data['respostaCorreta'] = isset($questoesUsuario[$data['questaoAtual']]->RespostaCorreta) ? $questoesUsuario[$data['questaoAtual']]->RespostaCorreta : '';

                    $data['respostaAluno'] = isset($questoesUsuario[$data['questaoAtual']]->Resposta) ? $questoesUsuario[$data['questaoAtual']]->Resposta : null;

                    $agendamento = $this->disciplina->getAgendamento(
                        $this->session->userdata('escola'), $grupoAulaID, $data['frenteID'],
                        $data['disciplinaID'], $turmaId, $idUsuario, false
                    );

                    $data['RespostaFinalAgendamentoAluno'] = 'S';

                    if(isset($agendamento) && $agendamento[0]['DtFim']) {
                        $finalizado = strtotime($agendamento[0]['DtFim']) < (strtotime(date('Y-m-d')));

                        if ((int)$this->session->userdata('perfil') === \Ava\App\Support\Perfil::ALUNO) {
                            $configResposta = $configuracoes[0]['RespostaFinalAgendamentoAluno'];
                            $dataExpiracao = \DateTime::createFromFormat('Y-m-d', $agendamento[0]['DtFim'])->setTime(0, 0, 0);
                            $data['RespostaFinalAgendamentoAluno'] = $this->exibirRespostaCorreta(
                                $configResposta,
                                $dataExpiracao
                            );
                        }
                    } else {
                        $finalizado = strtotime($questoesUsuario[$data['questaoAtual']]->DtAgendaFim) < (strtotime(date('Y-m-d')));
                    }

                    $data['finalizado'] = $finalizado;
                }

                $perfil = (int)$this->session->userdata('perfil');

                $data['exibirOpcaoCorreta'] = in_array($perfil, [\Ava\App\Support\Perfil::PROFESSOR, \Ava\App\Support\Perfil::COORDENADOR]);
                if ($perfil === \Ava\App\Support\Perfil::ALUNO && isset($questoesUsuario[$data['questaoAtual']]->RespostaCorreta)) {
                    $data['exibirOpcaoCorreta'] = true;
                }

                //Um para primeira questão
                $data['pag_reforco'] = true;
                $data['respostaAlunoAnterior'] = null;
                foreach($questoesUsuario as $quest){
                    if($quest->QuestaoID == $resultApi['message']['questao']['id']){
                        $data['respostaAlunoAnterior'] = $quest->Resposta;
                    }
                }

                $this->load->view('questao', $data);
            }
        }
    }

    /**
     * Conteúdo Questão
     *
     * Realiza a atualização do conteúdo da página html sem necessidade de refresh
     *
     * @param string $controller  identificador da ação
     * @param string $ancora      identificador da disciplina
     * @access private
     * @return json
     */
    function paramsContentQuestao($controller = null, $ancora = null)
    {
        $this->layout = '';
        $perfil = (int)$this->session->userdata('perfil');
        $ancora = $this->uri->segment(3);

        $dadosQuestao = [];
        $configuracoes = $this->curso->getConfiguracoesescola($this->session->userdata('escola'));
        //seta valores padrao caso a escola ainda nao tenha cadastrado as configura?oes
        $RespostaFinalAgendamentoAluno = '';
        if ($configuracoes && isset($configuracoes[0])) {
            $RespostaFinalAgendamentoAluno = isset($configuracoes[0]['RespostaFinalAgendamentoAluno']) ? $configuracoes[0]['RespostaFinalAgendamentoAluno'] : 'N';
        }

        $data['AssinaturaMatriculaID'] = $this->session->userdata('assinaturaMatriculaID');
        $retornoVerificaPacotesAluno = $this->home->verificaGrupoAulaAncora(str_replace("a-ano","-ordm-ano", $ancora));

        if (!empty($retornoVerificaPacotesAluno)) {
            $grupoAulaID = $retornoVerificaPacotesAluno[0]['itemName'];
            $dados = $this->curso->verificaVideoAula(5);
            $aulaID = $dados[0]['AulaID'];

            //busca dados da questao
            $data['questaoAtual'] = $this->uri->segment(7) ? $this->uri->segment(7) : 0;
            $session = $this->session->userdata();
            $idUsuario = $session['id'];

            //busca as questoes do aluno
            if ($perfil === Perfil::ALUNO) {
                $questoesUsuario = $this->reforco->getQuestoesAlunoReforco($idUsuario, $grupoAulaID, $dados[0]['DisciplinaID'], $aulaID);

                foreach ($questoesUsuario as $item) {
                    if ($item->QuestaoID == $questoesUsuario[$data['questaoAtual']]->QuestaoID) {
                        $dataConclusao = $item->DtConclusao;
                    }
                }
            } else {
                $questoesUsuario = SaeDigital::make(BuscaEstruturaQuestoesReforco::class)->handle($grupoAulaID, $aulaID);
            }

            $questaoUsuario = $questoesUsuario[$data['questaoAtual']];
            $data['qtdQuestoes'] = count($questoesUsuario);

            $date = new DateTime($dataConclusao);
            $dataOnly = date_format($date,"d/m/Y");
            $horaOnly = date_format($date,"H:i:s");

            $array = array('questao' => is_array($questaoUsuario) ? $questaoUsuario['QuestaoID'] : $questaoUsuario->QuestaoID);

            $result = $this->curso->CarregaQuestaoAPI(
                $array['questao'],
                $retornoVerificaPacotesAluno[0]['ClassificacaoID'],
                $dados[0]['DisciplinaID']
            );

            if ($result['success'] === 0) {
                header("Content-type:application/json");
                $obj['titulo'] = $result['message'];
                $obj['code'] = $result['code'];
                exit(json_encode($obj));
            }

            $ult = count($questoesUsuario) == ($data['questaoAtual'] + 1) ? 1 : 0;
            $obj['#ult'] = utf8_encode('<input type="hidden" id="ultimaQuestao" value="' . $ult . '" />');

            if (isset($result['success']) && $result['success'] == 1) {
                //dados da questao
                $dadosQuestao = $result['message'];

                $questaoAtual = $this->uri->segment(7) ? ($this->uri->segment(7) + 1) : 1;
                $qtdQuestoes = count($questoesUsuario);
            }
        } else {

            $obj['.titulo'] = utf8_encode("Nenhum quest&atilde;o encontrada para sequ&ecirc;ncia!");
            print(json_encode($obj));
            die;
        }

        //monta o html que sera utilizado
        //cabeçalho da questao
        $assunto = (isset($dadosQuestao['questao']['assunto'][0]['nome'])) ? utf8_decode($dadosQuestao['questao']['assunto'][0]['nome']) : '';

        $obj['.prova'] = utf8_encode("Prova: <a>" . utf8_decode(@$dadosQuestao['questao']['prova'][0]['nome']) . " </a><br>");
        $obj['#disciplinaAssunto'] = utf8_encode("Disciplina: <a>" . utf8_decode($dadosQuestao['questao']['disciplina'][0]['nome']) . "</a> | Assuntos: <a> " . $assunto . "</a>");
        $obj['#idQuestao'] = utf8_encode("Q" . utf8_decode($dadosQuestao['questao']['id']));
        $obj['#jarvisItemId'] = $dadosQuestao['questao']['jarvisItemId'];
        $obj['.spanQuestoes'] = utf8_encode($questaoAtual . " de " . $qtdQuestoes);


        //pergunta e alternativas
        if ($dadosQuestao['questao']['textoAssociado'] != '') {
            $obj['.texto-associado'] = utf8_encode('<a onClick="toogleTxtAssociado();" class="btn btn-mini btn-default" style="width: 230px;"><span class="icon-align-left"></span> <em id="btnAssociado">Mostrar texto associado à questão</em></a><br>
													<div class="texto-associado-content" style="display: none;">
														' . utf8_decode($dadosQuestao['questao']['textoAssociado']) . '
													</div><br/>');
        } else {
            $obj['.texto-associado'] = '';
        }

        $obj['.enunciado'] = $dadosQuestao['questao']['enunciado'];

        $altHTML = '';

        $respondida = 0;//$questaoUsuario->RespostaCorreta || $this->session->userdata('perfil') != 273 ? 1 : 0;

        $respostaCorreta = $questaoUsuario->RespostaCorreta ? $questaoUsuario->RespostaCorreta : '';

        for ($i = 0; count($dadosQuestao['questao']['alternativas']) > $i; $i++) {

            $altHTML .= '<li>';
            // if($questaoUsuario->Resposta == $dadosQuestao['questao']['alternativas'][$i]['id']) {
            $altHTML .= '<div class="alert alert-primary" style="margin: 0px 0px 0px -5px;padding: 2px 2px 2px 3px;width:69%;">';
            // }
            if ($respondida == 0)
                $altHTML .= '<input id="alternativa_q' . $dadosQuestao['questao']['id'] . '_' . $dadosQuestao['questao']['alternativas'][$i]['id'] . '" class="radio-resposta" name="questao-' . $dadosQuestao['questao']['id'] . '" type="radio" data-opcao="' . $dadosQuestao['questao']['alternativas'][$i]['valorOpcao'] . '" value="' . $dadosQuestao['questao']['alternativas'][$i]['id'] . '" data-correta="' . $dadosQuestao['questao']['alternativas'][$i]['opcaoCorreta'] . '" name="questao-' . $dadosQuestao['questao']['id'] . '" data-exibirac="sim">';

            $altHTML .= '<label for="alternativa_q' . $dadosQuestao['questao']['id'] . '_' . $dadosQuestao['questao']['alternativas'][$i]['id'] . '">';

            if ($dadosQuestao['questao']['tipoResposta']['nome'] == 'Certo/Errado') {
                $altHTML .= $dadosQuestao['questao']['alternativas'][$i]['opcao'];
            } else {
                $altHTML .= '<span class="option-letter">' . $dadosQuestao['questao']['alternativas'][$i]['valorOpcao'] . '</span> ' . $dadosQuestao['questao']['alternativas'][$i]['opcao'];
            }
            if($questaoUsuario->Resposta == $dadosQuestao['questao']['alternativas'][$i]['id']) {
                $dataResposta = \DateTime::createFromFormat('Y-m-d H:i:s', $questaoUsuario->DtConclusao);

                $altHTML .= '<span class="anterior-response">(<b>Resposta do aluno em </b>'. $dataResposta->format('d-m-Y') .' <b>as</b> '. $dataResposta->format('H:i:s') .')</span>';
            }
            $altHTML .= '</label></li>';
        }

        $obj['#alternativas'] = $altHTML;

        //hiddens da questao
        //resposta
        for ($a = 0; count($dadosQuestao['questao']['alternativas']) > $a; $a++) {
            if ($dadosQuestao['questao']['alternativas'][$a]['opcaoCorreta'] == 1) {
                $altCorreta = $dadosQuestao['questao']['alternativas'][$a]['id'];
                $opcaoCorreta = $dadosQuestao['questao']['alternativas'][$a]['valorOpcao'];
            }
        }

        $perfil = (int)$this->session->userdata('perfil');

        $obj['exibirOpcaoCorreta'] = in_array($perfil, [Perfil::PROFESSOR, Perfil::COORDENADOR]);
        if ($perfil === Perfil::ALUNO && isset($questaoUsuario->Resposta)) {
            $obj['exibirOpcaoCorreta'] = true;
        }

        if ($obj['exibirOpcaoCorreta']) {
            $obj['opcaoCorreta'] = $opcaoCorreta;
        }


        $obj['#dadosQuestao'] = utf8_encode('<input id="questaoID" type="hidden" value="' . $dadosQuestao['questao']['id'] . '">
												<input id="questaoRespondida" type="hidden" value="' . $respondida . '">
												<input id="jarvisItemId" type="hidden" value="' . $dadosQuestao['questao']['jarvisItemId'] . '">
												<input id="respostaCorreta" type="hidden" value="' . $respostaCorreta . '">
                                                <input id="RespostaFinalAgendamentoAluno" type="hidden" value="' . $RespostaFinalAgendamentoAluno . '">    
												<input id="quest" type="hidden" value="' . $altCorreta . '_' . $opcaoCorreta . '">');

        $obj['#slugDisciplina'] = $dadosQuestao['questao']['disciplina'][0]['slug'];

        $obj['#aulaID'] = $aulaID;
        $obj['#disciplinaID'] = $dados[0]['DisciplinaID'];

        header("Content-type:application/json");
        exit(json_encode($obj));
    }

    function questoesReforco($params, $GrupoAulaID) {
        $disciplinaID = $params[0]['DisciplinaID'];

        $questoesSDB = $this->reforco->tratamentoQuestoes($GrupoAulaID, $disciplinaID);

        // format response questões com a questãoid como chave array
        foreach ($questoesSDB as $key => $value) {
            $questoesSDBFormat[isset($value['JarvisItemID']) ? $value['JarvisItemID'] : $value['QuestaoID']] = $value;
        }

        for ($i = 0; count($params) > $i; $i++) {

            if ($params[$i]['Tipo'] === 'R' || $params[$i]['Tipo'] === 'Q' || $params[$i]['Tipo'] === 4) {
                $session = $this->session->userdata();
                $result = $this->curso_model->buscaQuestoesAluno($session['id'], $GrupoAulaID /*, $params[$i]['AulaID']*/);
                if (count($result) >= 1) {
                    foreach ($result as $key => $value) {
                        if (!is_null($value->Resposta)) {
                            // remove questões reservadas que foram respondidas
                            unset($questoesSDBFormat[$result[$key]->QuestaoID]);
                        }
                    }
                }
            }
        }

        return array_values($questoesSDBFormat);
    }

    function responderQuestao()
    {
        try {
            $this->load->model('curso_model', 'curso');
            $usuarioId = $this->session->userdata('pessoaid');
            $disciplinaID = $this->input->post('grupoaulaID');
            $assuntoID = $this->input->post('disciplinaId');
            $questaoID = $this->input->post('questaoId', true);
            $jarvisItemId = $this->input->post('jarvisItemId', true);

            $session = $this->session->userdata();
            $usuarioId = $session['id'];
            $login = $session['login'];
            $nomeEscola = $session['nomeEscola'];

            $legacyQuestaoId = $questaoID;
            $questaoID = isset($jarvisItemId) && !empty($jarvisItemId) ? (int)$jarvisItemId : (int)$questaoID;
            $disciplina = SaeDigital::make(PegaDisciplinaPeloId::class)->handle($disciplinaID);
            $questao = $this->curso->CarregaQuestaoAPI($questaoID, $disciplina['ClassificacaoID'], $assuntoID);
            if ($questao['success'] === 0) {
                throw new NotFoundException($questao['message'], 400);
            }

            $where['AulaID'] = $this->input->post('aulaId', true);
            $where['AssuntoID'] = $assuntoID;
            $where['DisciplinaID'] = $disciplinaID;
            $where['UsuarioID'] = $session['id'];
            $where['QuestaoID'] = $questaoID;

            $resposta = SaeDigital::make(VerificaRespostaReforco::class)->handle(
                $usuarioId, $assuntoID, $questaoID, $legacyQuestaoId
            );
            if (is_array($resposta) && count($resposta) > 0) {
                $dtConclusao = DateTime::createFromFormat('Y-m-d H:i:s', $resposta['DtConclusao']);
                $message = 'Questão já foi respondida em ' . $dtConclusao->format('d/m/Y H:i:s');
                throw new DuplicatedEntryException($message, 422);
            }
            $respostaCorreta = array_filter($questao['message']['questao']['alternativas'],
                function ($resposta) {
                    return (strval($resposta['opcaoCorreta']) === '1');
                }
            );
            $respostaCorreta = array_pop($respostaCorreta);

            $dados['Resposta'] = $this->input->post('resposta', true);
            $dados['Gabarito'] = $respostaCorreta["id"];
            $dados['DtAlt'] = date('Y-m-d H:i:s');
            $dados['DtConclusao'] = date('Y-m-d H:i:s');

            if ($dados['Resposta'] == $respostaCorreta["id"]) {
                $dados['RespostaCorreta'] = 'S';
                $message = 'Parabéns, você acertou... Aguarde um instante!';
                $result['acertou'] = TRUE;
            } else {
                $dados['RespostaCorreta'] = 'N';
                $result['acertou'] = FALSE;
                $message = 'Você errou!';
            }

            $configuracao = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle(
                $this->session->userdata('escola')
            );

            $configuracaoSerie = SaeDigital::make(BuscarConfiguracaoEscolaPorSerie::class)->handle(
                $this->session->userdata('escola'), $this->session->userdata('Serie')
            );

            $result['exibirMsgRespostaFinalAgendamento'] = false;
            if ($configuracao['RespostaFinalAgendamentoAluno'] > 0) {
                $result['exibirMsgRespostaFinalAgendamento'] = true;
                $result['letra_correta'] = $respostaCorreta["valorOpcao"];
            }

            $result['retorno'] = SaeDigital::make(GravarRespostasAlunoReforco::class)->handle(
                $dados, $where, $questaoID, $legacyQuestaoId
            );

            $desempenho = SaeDigital::make(CalcularDesempenhoAlunoPorAssunto::class)->handle(
                $where['UsuarioID'], $where['AssuntoID'], true
            );

            $result['atingiuMeta'] = false;
            if ((int)$desempenho >= (int)$configuracaoSerie['Meta']) {
                $result['atingiuMeta'] = true;
            }

			$stats = SaeDigital::make(BuscaEstatisticasQuestao::class)->handle( $where['UsuarioID'], $where['AssuntoID'], $where['QuestaoID'], true );
            $result['acertos'] 					= intval( $stats['acertosQuestoes'] );
			$result['erros'] 					= intval( $stats['errosQuestoes'] );
			$result['quantidade_questoes']		= intval( $stats['quantidade_questoes'] );
			$result['tipo'] 					= 'Reforço';
			$result['revisao']					= false;

            $result['message'] = $message;
            return $this->responseJson([
                $result
            ], 200);
        } catch (NotFoundException $e) {
            return $this->responseJson([
                'message' => $e->getMessage()
            ], 404);
        } catch (DuplicatedEntryException $e) {
            return $this->responseJson([
                'message' => $e->getMessage()
            ], 422);
        } catch (Exception $e) {
            dd($e);
        }
    }

    private function exibirRespostaCorreta($configuracao, DateTime $dataExpiracaoAgendamento)
    {
        if ($configuracao == 0) {
            return 'N';
        } elseif ($configuracao == 1) {
            $hoje = new DateTime();
            $hoje->setTime(0, 0, 0);

            return $hoje > $dataExpiracaoAgendamento ? 'S' : 'N';
        } elseif ($configuracao == 2) {
            return 'S';
        }

        return 'N';
    }

}
