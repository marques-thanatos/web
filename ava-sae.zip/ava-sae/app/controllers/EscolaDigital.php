<?php

use Ava\App\Services\Assuntos\PegaAssuntoPeloId;
use Ava\App\Services\Notificacoes\MarcarNotificacoesComoLida;

class EscolaDigital extends MY_Controller
{
    public $layout = 'new-ava';
    public $title = 'Escola Digital | AVA';
    public $description = 'Escola Digital | Ambiente Virtual de Aprendizagem | AVA SAE';
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        try {
            $userData = $this->session->userdata();
            $data = [
                'jwtToken' => $userData['jwtToken'],
                'sessionData' => $userData,
                'saeMsMeetUrl' => env('SAE_MS_MEET_URL')
            ];

            return $this->load->view('escola-digital', $data);
        } catch (\Exception $e) {
            log_error($e->getMessage());
        }
    }
}
