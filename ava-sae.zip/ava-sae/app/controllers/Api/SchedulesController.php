<?php

use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\Agendamentos\AtualizarAgendamentoPorItemName;
use Ava\App\Services\Agendamentos\AtualizarAgendamentoPorAluno;
use Ava\App\Services\Agendamentos\AtualizarAgendamentoPorTurma;
use Ava\App\Services\Agendamentos\BuscarAgendamentosAlunosNextAva;
use Ava\App\Services\Agendamentos\BuscarAgendamentoPorItemName;
use Ava\App\Services\Agendamentos\BuscarAgendamentoPorTurmaAssunto;
use Ava\App\Services\Agendamentos\BuscarAgendamentosUsuarioPorEscolaSerie;
use Ava\App\Services\Agendamentos\CriarAgendamentoEmMassaPorTurmaUsuario;
use Ava\App\Services\Agendamentos\RemoverAgendamentoPorItemName;
use Ava\App\Services\Agendamentos\BuscarAgendamentosPorTurmaAlunos;
use Ava\App\Services\Agendamentos\RemoverAgendamentoPorTurmaAssunto;
use Ava\App\Services\Disciplinas\BuscarDadosDisciplinas;
use Ava\App\Services\Turma\BuscarTurmasAlunosDisciplinasNextAva;
use Ava\App\Services\Turma\BuscarTurmasPorLoginComAlunos;
use Ava\App\Services\Turma\BuscarDadosTurma;
use Ava\App\Services\Disciplinas\BuscarComponentesCurricularesPorLogin;
use Ava\App\Services\Disciplinas\BuscarDisciplinasPorSerieVersao;
use Ava\App\Services\Agendamentos\VerificaAgendamentoEmMassaPorTurmaUsuario;
use Ava\App\Services\Disciplinas\VerificaDisciplinaPorLogin;
use Ava\App\Services\Assuntos\AssuntosPorDisciplinaAssunto;
use Ava\App\Services\Usuario\BuscarUsuarioPorItemName;
use Ava\App\Services\Usuario\ObterUsuarioNextAva;
use Ava\App\Support\DataAgendamento;
use Ava\App\Support\Perfil;
use Illuminate\Support\Collection;
use Ava\App\Support\Situacao;
use Carbon\Carbon;
use Swagger\Annotations as SWG;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class SchedulesController extends MY_Controller
{

    /** @var bool */
    public $layout = false;

    /**
     * @SWG\GET(
     *     path="/schedules/{idSerie}",
     *     summary="Lista agendamentos de uma série",
     *     description="Busca agendamentos da série informada baseando nas turmas vinculadas ao usuário",
     *     tags={"Agendamentos"},
     *     produces={"application/json"},
     *     @SWG\Parameter(
     *          name="idSerie",
     *          in="path",
     *          description="Série a ser consultada",
     *          required=true
     *     ),
     *     @SWG\Parameter(
     *          name="idTurma",
     *          in="query",
     *          description="Filtra dados por turma",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="idAluno",
     *          in="query",
     *          description="Filtra dados por aluno",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="idDisciplina",
     *          in="query",
     *          description="Filtra dados por disciplina",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="idAssunto",
     *          in="query",
     *          description="Filtra dados por modulo de estudo",
     *          required=false
     *     ),
     *     @SWG\Response(
     *          response=400,
     *          description="Bad Request"
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     *
     * @param $idSerie
     */
    public function index($idSerie)
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $login = $this->session->userdata('login');
            $idSchool = $this->session->userdata('escola');

            $idTurma = $this->input->get('idTurma');
            $idAssunto = $this->input->get('idAssunto');
            $idDisciplina = $this->input->get('idDisciplina');
            $idAluno = $this->input->get('idAluno');

            /** @var BuscarAgendamentosUsuarioPorEscolaSerie $schedulesService */
            $schedulesService = SaeDigital::make(BuscarAgendamentosUsuarioPorEscolaSerie::class);
            $schedules = $schedulesService->handle($login, $idSchool, $idSerie, $idTurma, $idAluno, $idDisciplina, $idAssunto);

            return $this->responseJson([
                'success' => true,
                'count' => count($schedules),
                'data' => $schedules
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para listar agendamentos.'
            ], 403);
        }
    }

    /**
     * @SWG\Post(
     *     path="/schedules",
     *     summary="Cria novos agendamentos",
     *     description="Cria novos agendamentos com os dados informados.",
     *     tags={"Agendamentos"},
     *     consumes={"application/json"},
     *     produces={"application/json"},
     *     @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="Objeto obrigatório para criação de agendamentos em massa.",
     *          required=true,
     *          @SWG\Schema(ref="#/definitions/SchedulesCreateRequest")
     *     ),
     *     @SWG\Response(
     *          response=400,
     *          description="Bad Request"
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     *
     * @return string
     * @throws Exception
     */
    public function create()
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $jsonData = $this->getJsonRequestData();

            $idProfile = $this->session->userdata('perfil');

            $idSerie = $jsonData['idSerie'];
            if (empty($idSerie))
                throw new InvalidArgumentException('Obrigatório informar a série.');

            $idCurricularComponent = $jsonData['idComponenteCurricular'];
            if (empty($idCurricularComponent))
                throw new InvalidArgumentException('Obrigatório informar o componente curricular.');

            $modules = $jsonData['modulos'];
            if (empty($modules) or !is_array($modules))
                throw new InvalidArgumentException('Obrigatório informar ao menos um modulo de estudo');

            $startDate = Carbon::createFromFormat(DataAgendamento::FORMAT, $jsonData['dtInicio'])->toDateString();
            $endDate = Carbon::createFromFormat(DataAgendamento::FORMAT, $jsonData['dtFim'])->toDateString();
            if (empty($startDate) or empty($endDate))
                throw new InvalidArgumentException('Obrigatório informar data de inicio e fim do agendamento');

            $teams = $jsonData['turmas'] ?: [];
            $students = $jsonData['alunos'] ?: [];
            if (empty($teams) && empty($students))
                throw new InvalidArgumentException('Obrigatório informar ao menos um aluno ou turma.');

            $user = $this->session->userdata;

            if ($idProfile == Perfil::PROFESSOR) {
                /** @var VerificaDisciplinaPorLogin $verificaDisciplinaService */
                //$verificaDisciplinaService = SaeDigital::make(VerificaDisciplinaPorLogin::class);
                //$acessoDisciplina = $verificaDisciplinaService->handle($user['Login'], $idCurricularComponent);

                //if (!$acessoDisciplina)
                  //  throw new NotAllowedException('Você não tem permissão de criar uma agendamento para este componente curricular.');
            }

            /** @var CriarAgendamentoEmMassaPorTurmaUsuario $scheduleService */
            $scheduleService = SaeDigital::make(CriarAgendamentoEmMassaPorTurmaUsuario::class);
            $schedules = $scheduleService->handle(
                $idSerie, $idCurricularComponent, $startDate, $endDate, $modules, $user, $teams, $students, $jsonData['review']
            );

            return $this->responseJson([
                'success' => true,
                'data' => $schedules
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para criar agendamentos.'
            ], 403);
        } catch (Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * @SWG\Put(
     *     path="/schedules/{idAgendamento}",
     *     tags={"Agendamentos"},
     *     summary="Atualiza agendamento",
     *     description="Atualiza um agendamento com os novos dados passados",
     *     consumes={"application/json"},
     *     produces={"application/json"},
     *     @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="Dados para atualização de agendamento",
     *          required=true,
     *          @SWG\Schema(ref="#/definitions/SchedulesUpdateRequest")
     *     ),
     *     @SWG\Parameter(
     *          name="idAgendamento",
     *          in="path",
     *          description="Identificação do agendamento",
     *          required=true
     *     ),
     *     @SWG\Response(
     *          response=400,
     *          description="Bad Request"
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     *
     * @param $idSchedule
     * @return string
     * @throws Exception
     */
    public function update($idSchedule)
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $jsonData = $this->getJsonRequestData();

            $login = $this->session->userdata('login');
            $idUser = $this->session->userdata('pessoaid');
            $userSchool = $this->session->userdata('escola');
            $idProfile = $this->session->userdata('perfil');

            $dtInicio = Carbon::createFromFormat(DataAgendamento::FORMAT, $jsonData['dtInicio']);
            if (empty($jsonData['dtInicio']) || $dtInicio->lt(Carbon::today()))
                throw new InvalidArgumentException('Data informada para inicio do agendamento é inválida');

            $dtFim = Carbon::createFromFormat(DataAgendamento::FORMAT, $jsonData['dtFim']);
            if (empty($jsonData['dtFim']) || $dtFim->lt(Carbon::today()))
                throw new InvalidArgumentException('Data informada para encerramento do agendamneto é inválida');

            /** @var BuscarAgendamentoPorItemName $schedulesService */
            $schedulesService = SaeDigital::make(BuscarAgendamentoPorItemName::class);
            $schedule = $schedulesService->handle($idSchedule);

            if ($idProfile == Perfil::PROFESSOR) {
                // /** @var VerificaDisciplinaPorLogin $verificaDisciplinaService */
                // $verificaDisciplinaService = SaeDigital::make(VerificaDisciplinaPorLogin::class);
                // $acessoDisciplina = $verificaDisciplinaService->handle($login, $schedule['DisciplinaID']);

                // if (empty($acessoDisciplina) || $schedule['EscolaID'] !== $userSchool)
                //     throw new NotAllowedException();
            }

            /** @var AtualizarAgendamentoPorItemName $updateScheduleService */
            $updateScheduleService = SaeDigital::make(AtualizarAgendamentoPorItemName::class);
            $update = $updateScheduleService->handle($schedule['itemName'], $dtInicio->toDateString(), $dtFim->toDateString(), $idUser);

            if (!$update)
                throw new Exception('Erro ao atualizar agendamento, tente novamente.');

            return $this->responseJson([
                'success' => $update,
                'message' => 'Agendamento atualizado com sucesso.'
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão atualizar este agendamentos.'
            ], 403);
        } catch (Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * @SWG\Delete (
     *     path="/schedules/{idAgendamento}",
     *     tags={"Agendamentos"},
     *     summary="Deleta agendamento",
     *     description="Deleta um agendamento",
     *     @SWG\Parameter(
     *          name="idAgendamento",
     *          in="path",
     *          description="Identificação do agendamento",
     *          required=true,
     *     ),
     *     @SWG\Response(
     *          response=400,
     *          description="Bad Request"
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     *
     * @param $idSchedule
     * @return string
     * @throws Exception
     */
    public function delete($idSchedule)
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $login = $this->session->userdata('login');
            $userSchool = $this->session->userdata('escola');
            $idProfile = $this->session->userdata('perfil');

            /** @var BuscarAgendamentoPorItemName $schedulesService */
            $schedulesService = SaeDigital::make(BuscarAgendamentoPorItemName::class);
            $schedule = $schedulesService->handle($idSchedule);

            if ($idProfile == Perfil::PROFESSOR) {
                // /** @var VerificaDisciplinaPorLogin $verificaDisciplinaService */
                // $verificaDisciplinaService = SaeDigital::make(VerificaDisciplinaPorLogin::class);
                // $acessoDisciplina = $verificaDisciplinaService->handle($login, $schedule['DisciplinaID']);

                // if (!$acessoDisciplina || $schedule['EscolaID'] !== $userSchool)
                //     throw new NotAllowedException();
            }

            /** @var RemoverAgendamentoPorItemName $deleteScheduleService */
            $deleteScheduleService = SaeDigital::make(RemoverAgendamentoPorItemName::class);
            $delete = $deleteScheduleService->handle($schedule['itemName']);

            if (!$delete)
                throw new Exception('Erro ao remover agendamento, tente novamente mais tarde.');

            return $this->responseJson([
                'success' => true,
                'message' => 'Agendamento removido com sucesso.'
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Vocẽ não tem permissão para remover o agendamento.'
            ]);
        } catch (Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    public function deleteSchedule($idTurma, $idAssunto, $tipoAgendamento)
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $login = $this->session->userdata('login');
            $userSchool = $this->session->userdata('escola');
            $idProfile = $this->session->userdata('perfil');

            /** @var BuscarAgendamentoPorItemName $schedulesService */
            $schedulesService = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class);
            $schedule = $schedulesService->handle($idTurma, $idAssunto, null, null, $tipoAgendamento);

            if ($idProfile == Perfil::PROFESSOR) {
                /** @var VerificaDisciplinaPorLogin $verificaDisciplinaService */
                /*$verificaDisciplinaService = SaeDigital::make(VerificaDisciplinaPorLogin::class);
                $acessoDisciplina = $verificaDisciplinaService->handle($login, $schedule['DisciplinaID']);

                if (!$acessoDisciplina || $schedule['EscolaID'] !== $userSchool)
                    throw new NotAllowedException();*/
            }

            /** @var RemoverAgendamentoPorTurmaAssunto $deleteScheduleService */
            $deleteScheduleService = SaeDigital::make(RemoverAgendamentoPorTurmaAssunto::class);
            $delete = $deleteScheduleService->handle($idTurma, $idAssunto, $tipoAgendamento);

            if (!$delete)
                throw new Exception('Erro ao remover agendamento, tente novamente mais tarde.');

            return $this->responseJson([
                'success' => true,
                'message' => 'Agendamento removido com sucesso.'
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Vocẽ não tem permissão para remover o agendamento.'
            ]);
        } catch (Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    /**
     * Update 2020-09-06: Agendamento de atividade para aluno de forma individual ou para turma.
     *      ALTER TABLE `avasae`.`D024_Ava_Sae_Agenda`
     *      ADD UNIQUE INDEX `AlunoID_3` (
     *          `AlunoID` ASC, `AssuntoID` ASC, `DisciplinaID` ASC,
     *          `EscolaID` ASC, `FrenteID` ASC, `TurmaID` ASC, `tipo_agendamento` ASC
     *      );
     *
     *      ALTER TABLE `avasae`.`D024_Ava_Sae_Agenda`
     *      DROP INDEX `AlunoID_2` ;
     *
     * @SWG\Post(
     *     path="/schedules/verify",
     *     summary="Verifica existência de agendamentos previamente.",
     *     description="Verifica se agendamentos informados já existem ou será criado com base nos dados informados.",
     *     tags={"Agendamentos"},
     *     consumes={"application/json"},
     *     produces={"application/json"},
     *     @SWG\Parameter(
     *          name="body",
     *          in="body",
     *          description="Objeto obrigatório para criação de agendamentos em massa.",
     *          required=true,
     *          @SWG\Schema(ref="#/definitions/SchedulesCreateRequest")
     *     ),
     *     @SWG\Response(
     *          response=400,
     *          description="Bad Request"
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     *
     * @return string
     * @throws Exception
     */
    public function verifySchedules()
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $jsonData = $this->getJsonRequestData();

            $idProfile = $this->session->userdata('perfil');

            $idSerie = $jsonData['idSerie'];
            if (empty($idSerie))
                throw new InvalidArgumentException('Obrigatório informar a série.');

            $idCurricularComponent = $jsonData['idComponenteCurricular'];
            if (empty($idCurricularComponent))
                throw new InvalidArgumentException('Obrigatório informar o componente curricular.');

            $modules = $jsonData['modulos'];
            if (empty($modules) or !is_array($modules))
                throw new InvalidArgumentException('Obrigatório informar ao menos um modulo de estudo');

            $startDate = Carbon::createFromFormat(DataAgendamento::FORMAT, $jsonData['dtInicio'])->toDateString();
            $endDate = Carbon::createFromFormat(DataAgendamento::FORMAT, $jsonData['dtFim'])->toDateString();
            if (empty($startDate) or empty($endDate))
                throw new InvalidArgumentException('Obrigatório informar data de inicio e fim do agendamento');

            $teams = $jsonData['turmas'] ?: [];
            $students = $jsonData['alunos'] ?: [];
            if (empty($teams) && empty($students))
                throw new InvalidArgumentException('Obrigatório informar ao menos um aluno ou turma.');

            $user = $this->session->userdata;

            if ($idProfile == Perfil::PROFESSOR) {
                /** @var VerificaDisciplinaPorLogin $verificaDisciplinaService */
                // $verificaDisciplinaService = SaeDigital::make(VerificaDisciplinaPorLogin::class);
                //$acessoDisciplina = $verificaDisciplinaService->handle($user['Login'], $idCurricularComponent);

                //if (!$acessoDisciplina)
                  //  throw new NotAllowedException('Você não tem permissão de criar uma agendamento para este componente curricular.');
            }

            /** @var VerificaAgendamentoEmMassaPorTurmaUsuario $scheduleService */
            $scheduleService = SaeDigital::make(VerificaAgendamentoEmMassaPorTurmaUsuario::class);
            $schedules = $scheduleService->handle(
                $idSerie, $idCurricularComponent, $startDate, $endDate, $modules, $user, $teams, $students, $jsonData['review']
            );

            return $this->responseJson([
                'success' => true,
                'data' => $schedules
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para criar agendamentos.'
            ], 403);
        } catch (InvalidArgumentException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        } catch (Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }

    public function updateSchedules() {

        try {
      //      $this->allowProfile([Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $jsonData = $this->getJsonRequestData();

            $idProfile = $this->session->userdata('perfil');

            $idSerie = $jsonData['idSerie'];
            if (empty($idSerie))
                throw new InvalidArgumentException('Obrigatório informar a série.');

            $idCurricularComponent = $jsonData['idComponenteCurricular'];
            if (empty($idCurricularComponent))
                throw new InvalidArgumentException('Obrigatório informar o componente curricular.');

            $modules = $jsonData['modulos'];
            if (empty($modules) or !is_array($modules))
                throw new InvalidArgumentException('Obrigatório informar ao menos um modulo de estudo');


            $teams = $jsonData['turmas'] ?: [];
            $students = $jsonData['alunos'] ?: [];
            if (empty($teams) && empty($students))
                throw new InvalidArgumentException('Obrigatório informar ao menos um aluno ou turma.');

            $usuarioItemName = $this->session->userdata('pessoaid');

            /** @var BuscarUsuarioPorItemName $loginServide */
            // $loginServide = SaeDigital::make(BuscarUsuarioPorItemName::class);
            // $user = $loginServide->handle($usuarioItemName);
            $user = $this->session->userdata;

           /* if ($idProfile == Perfil::PROFESSOR) {
                $verificaDisciplinaService = SaeDigital::make(VerificaDisciplinaPorLogin::class);
                $acessoDisciplina = $verificaDisciplinaService->handle($user['Login'], $idCurricularComponent);

                if (!$acessoDisciplina)
                    throw new NotAllowedException('Você não tem permissão de criar uma agendamento para este componente curricular.');
            } */

            // Criar uma service para atualizar por turma
            $scheduleService = SaeDigital::make(AtualizarAgendamentoPorTurma::class);
            $schedules = $scheduleService->handle(
                $idSerie, $idCurricularComponent, $modules, $user, $teams, $jsonData['review']
            );

            // Criar uma service para atualizar por aluno

            // Verificar se o agendamento ja existe, se sim, atualizar o registro existente, senao, inserir.
            $scheduleService = SaeDigital::make(AtualizarAgendamentoPorAluno::class);
            $schedules = $scheduleService->handle(
                $idSerie, $idCurricularComponent, $modules, $user, $students , $jsonData['review']
            );



            return $this->responseJson([
                'success' => true,
                'data' => 'Agendamento atualizado com sucesso.'
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para criar agendamentos.'
            ], 403);
        } catch (InvalidArgumentException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        } catch (Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }


    public function carregarModal() {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $login        = $this->session->userdata('login');
            $groupBy      = $this->input->get('groupBy');
            $idSerie      = $this->input->get('idSerie');
            $idTurma      = $this->input->get('idTurma');
            $idAssunto    = $this->input->get('idAssunto');
            $idDisciplina = $this->input->get('idDisciplina');
            $escolaDigital = $this->input->get('escolaDigital');
            $review        = $this->input->get('review');
            // $frenteId        = $this->input->get('frenteId');
            $idFrente        = $this->input->get('idFrente');

            $token = $this->session->userdata('token');

            $service = SaeDigital::make(BuscarTurmasAlunosDisciplinasNextAva::class);
            $teamsStudentsData = $service->handle($token);
            $collectionTeams = collect($teamsStudentsData);
            $teams=[];

            if( $idAssunto ) {
            /** @var BuscarAgendamentoPorTurmaAlunos $teamsService */
                if($idSerie)
                    $collectionTeams = $collectionTeams->where('serieid', '=', $idSerie);

                if($idTurma)
                    $collectionTeams = $collectionTeams->filter(function ($teamItem) use ($idTurma) {
                        return ($teamItem->itemName == $idTurma || $teamItem->team_id == $idTurma);
                    });

                // Turmas estão com ID incorreto. Corrigindo
                $turmas = $collectionTeams->toArray();
                foreach( $turmas as $i=>$team ){
                    $turmas[$i]->id = (int) $i;
                }
                $turmasIds = array_keys($turmas);

                $teamsService = SaeDigital::make(BuscarAgendamentosAlunosNextAva::class);
                $teamsBase = $teamsService->handle($login, $groupBy, $idSerie, $idTurma, $idAssunto, $review, $frenteId, $escolaDigital, $idDisciplina,$collectionTeams, $turmasIds);
                $teams = [];
                foreach($teamsBase as $t)
                    if ( $t['quantAluno'] > 0 ) 
                        $teams[] = $t;
                
                    }else {
                /*
                'idTurma' => $turma['idTurma'],
                'descricaoTurma' => $turma['descricaoTurma'],
                'descricaoSerie' => $turma['descricaoSerie'],
                'idSerie' => (int)$turma['idSerie'],
                'quantAluno' => $alunos->count(),
                'alunos' => $alunos->map(function(array $aluno) {
                    return [
                        'idAluno' => $aluno['idAluno'],
                        'nomeAluno' => $aluno['nomeAluno'],
                    ];
                })->values()->all()

                */
                foreach($teamsStudentsData as $dadoAlunoTurma) {
                    $studentsArray = [];
                    $alunos = $dadoAlunoTurma->students;



                    foreach($alunos as $aluno) {
                        array_push($studentsArray, array(
                            'idAluno' => $aluno->itemName ? $aluno->itemName : $aluno->id,
                            'nomeAluno' => $aluno->full_name
                        ));
                    }
                    array_push($teams, array(
                        'idTurma' => $dadoAlunoTurma->itemName ? $dadoAlunoTurma->itemName : $dadoAlunoTurma->id,
                        'descricaoTurma' => $dadoAlunoTurma->descricaoturma,
                        'descricaoSerie' => $dadoAlunoTurma->descricaoserie,
                        'idSerie' => (int)  $dadoAlunoTurma->serieid,
                        'quantAluno' => sizeof($studentsArray),
                        'alunos' => $studentsArray
                    ));
                }

                $teamsService = SaeDigital::make(BuscarTurmasPorLoginComAlunos::class);
                $teams = $teamsService->handle($login, $groupBy, $idSerie, $idTurma, null, (bool) $review);
            }

            $idProfile = $this->session->userdata('perfil');
            $idContentVersion = $this->session->userdata('versao_conteudo_id');

            $idClassificacao = $this->input->get('idClassificacao') ?: 10;

            $grades = [];
            if ($idProfile == Perfil::PROFESSOR) {
                /** @var BuscarComponentesCurricularesPorLogin $service */
               // $service = SaeDigital::make(BuscarComponentesCurricularesPorLogin::class);
                // $grades = $service->handle($login, $idSerie, $idTurma, $idClassificacao);




                $nextAvaData = collect($teamsStudentsData);

                if($idSerie)
                    $nextAvaData = collect($teamsStudentsData)->where("SerieID", "=", $idSerie);

                if($idTurma) {
                    $nextAvaData = collect($teamsStudentsData)->filter(function ($teamItem) use ($idTurma) {
                        return ($teamItem->itemName == $idTurma || $teamItem->team_id == $idTurma);
                    });
                }

                if($idClassificacao == 11) {
                    $nextAvaData = array_values($nextAvaData->toArray());

                    for($countDados = 0; $countDados < sizeof($nextAvaData); $countDados++) {
                        $subjectsArray = $nextAvaData[$countDados]->subjects;

                        $subjectsPlataformaLiteraria = array_values(collect($subjectsArray)->where('disciplinaidnextava', '=', 52)->toArray());
                        if(sizeof($subjectsPlataformaLiteraria) > 0)
                            $nextAvaData[$countDados]->subjects = $subjectsPlataformaLiteraria;
                    }
                }
                else if($idClassificacao == 10) {
                    $nextAvaData = array_values($nextAvaData->toArray());

                    for($countDados = 0; $countDados < sizeof($nextAvaData); $countDados++) {
                        $subjectsArray = $nextAvaData[$countDados]->subjects;

                        $subjectsPlataformaLiteraria = array_values(collect($subjectsArray)->where('disciplinaidnextava', '!=', 52)->toArray());
                        if(sizeof($subjectsPlataformaLiteraria) > 0)
                            $nextAvaData[$countDados]->subjects = $subjectsPlataformaLiteraria;
                    }
                }

                foreach($nextAvaData as $tsd) {
                    if ( $tsd->vigenciaturma == 2020 ) {
                        $service = SaeDigital::make(BuscarComponentesCurricularesPorLogin::class);
                        $disciplinaArray = $service->handle($login, $tsd->SerieID, $tsd->itemName, $idClassificacao);
                        if(sizeof($disciplinaArray) > 0) {
                            foreach($disciplinaArray as $disciplina){
                                array_push($grades, $disciplina);
                            }
                        }
                    }
                    else {
                        $serieId = $tsd->SerieID;
                        $subjectsNextAva = $tsd->subjects;

                        foreach( $subjectsNextAva as $subject) {
                            $serviceDisciplinas = SaeDigital::make(BuscarDadosDisciplinas::class);

                            $disciplinaID = $subject->disciplinaid;

                            $disciplinaData = $serviceDisciplinas->handle($serieId, $idContentVersion, [$idClassificacao], $disciplinaID);

                            if( $disciplinaData != null ) {
                                $disciplinaArray = array(
                                    'Ancora' => $disciplinaData[0]['Ancora'],
                                    'descricao' => $disciplinaData[0]['Descricao'],
                                    'idClassificacao' => $disciplinaData[0]['ClassificacaoID'],
                                    'componenteNome' => $subject->nomedisciplina,
                                    'SerieID' => $serieId,
                                    'idDisciplina' => $subject->disciplinaid
                                );
                            }
                            else {
                                $disciplinaArray = array(
                                    'Ancora' => $subject->slug,
                                    'descricao' => $subject->nomedisciplina,
                                    'idClassificacao' => 10,
                                    'componenteNome' => $subject->nomedisciplina,
                                    'SerieID' => $serieId,
                                    'idDisciplina' => $subject->disciplinaid
                                );
                            }

                            array_push($grades, $disciplinaArray);
                        }
                    }
                }
            } else if ($idProfile == Perfil::COORDENADOR) {
                /** @var BuscarDadosTurma $teamService */
                $teamService = SaeDigital::make(BuscarDadosTurma::class);
                $team = $teamService->handle($idTurma, Situacao::ATIVO, \Carbon\Carbon::now()->year);

                $idSerie = $team['SerieID'] ?: $idSerie;

                /** @var BuscarDisciplinasPorSerieVersao $service */
                $service = SaeDigital::make(BuscarDisciplinasPorSerieVersao::class);
                $grades = $service->handle(
                    \Carbon\Carbon::now()->year,
                    $idSerie,
                    $idContentVersion,
                    [$idClassificacao]
                );

                $grades = collect($grades)->map(function ($item) {
                    return [
                        'Ancora' => $item['Ancora'],
                        'SerieID' => (int)$item['SerieID'],
                        'componenteNome' => $item['componenteNome'],
                        'descricao' => $item['Descricao'],
                        'idClassificacao' => (int)$item['ClassificacaoID'],
                        'idDisciplina' => (int)$item['itemName']
                    ];
                })->values()->toArray();
            }

            $modulos = $this->showModules($idDisciplina, $idAssunto, $escolaDigital);


            return $this->responseJson([
                'success' => true,
                'countTeams' => count($teams),
                'turmas' => $teams,
                'countGrades' => count($teams),
                'disciplinas' => $grades,
                'countModulos' => count($modulos),
                'modulos'     => $modulos,
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        }
    }

    public function showModules($idDisciplina, $idAssunto, $escolaDigital)
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $login = $this->session->userdata('login');
            $idPerfil = $this->session->userdata('perfil');

            if ($idPerfil == Perfil::PROFESSOR) {
                /** @var VerificaDisciplinaPorLogin $verificaDisciplinaService */
                //$verificaDisciplinaService = SaeDigital::make(VerificaDisciplinaPorLogin::class);
                //$acessoDisciplina = $verificaDisciplinaService->handle($login, $idDisciplina);
                /*
                if (!$acessoDisciplina) {
                    throw new NotAllowedException('Você não tem permissão de acesso a este componente curricular.');
                }
                */
            }

            $filterEscolaDigital = filter_var($escolaDigital, FILTER_VALIDATE_BOOLEAN);
           // $idAssunto = $this->input->get('idAssunto');

            /** @var AssuntosPorDisciplinaAssunto $assuntosService */
            $assuntosService = SaeDigital::make(AssuntosPorDisciplinaAssunto::class);
            $subjects = $assuntosService->handle($idDisciplina, $idAssunto, $filterEscolaDigital);

            return $subjects;
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ], 403);
        }
    }

}
