<?php

use Ava\App\Domain\Controllers\BaseController;
use Ava\App\Services\Agendamentos\BuscarCalendarioLogin;
use Swagger\Annotations as SWG;
use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Support\Perfil;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class CalendarController extends BaseController
{

    /**
     * @SWG\Get(
     *     path="/calendar",
     *     summary="Retorna dados para calendário",
     *     description="Busca calendário do usuário constando dados das turmas vinculadas",
     *     produces={"application/json"},
     *     tags={"Calendário"},
     *     @SWG\Response(
     *          response=200,
     *          description="Success",
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     */
    public function index()
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::PROFESSOR, Perfil::ALUNO]);

            $ignoreCache = filter_var($this->input->get('ignoreCache'), FILTER_VALIDATE_BOOLEAN);
            $cacheKey = implode('', [
                'api:calendar:index:',
                $this->session->userdata('pessoaid')
            ]);

            // $data = $this->cache()->get($cacheKey);

            if (!$data || $ignoreCache) {
                /** @var BuscarCalendarioLogin $service */
                $service = SaeDigital::make(BuscarCalendarioLogin::class);

                $alunoId = null;
                if ($this->session->userdata('perfil') == Perfil::ALUNO) {
                    $alunoId = $this->session->userdata('id');
                }
                $idsTurmas = array_unique(array_map(function($val) {
                    return $val->id;
                }, $this->session->userdata('teams')));

                if (count($idsTurmas) > 0) {
                    $data = $service->handle($idsTurmas, $alunoId);
                } else {
                    $data = [];
                }

                $this->cache()->put($cacheKey, $data, env('SAE_DEFAULT_CACHE_TTL', 15));
            }

            return $this->responseJson([
                'success' => true,
                'count' => count($data),
                'data' => $data
            ], 200);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        }
    }
}
