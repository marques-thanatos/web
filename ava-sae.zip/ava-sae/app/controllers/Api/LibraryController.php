<?php

use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\NextAVA\UsuarioNextAVA;
use Ava\App\Services\EscolaDigital\VideoaulasEscolaDigital;
use Ava\App\Services\NextAVA\TurmasPorProfessor;
use Ava\App\Support\Perfil;
use Swagger\Annotations as SWG;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class LibraryController extends MY_Controller
{

    /** @var bool */
    public $layout = false;

    /**
     * @SWG\Get(
     *     path="/library/videos",
     *     summary="Retorna listagem de videoaulas disponíveis para Escola Digital",
     *     description="Busca as videoaulas disponíveis para a Escola Digital com filtragem de informações.",
     *     produces={"application/json"},
     *     tags={"Biblioteca"},
     *     @SWG\Parameter(
     *          name="idSerie",
     *          in="query",
     *          type="integer",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="idTurma",
     *          in="query",
     *          type="string",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="descDisciplina",
     *          in="query",
     *          type="integer",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="descLivro",
     *          in="query",
     *          type="integer",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="escolaDigital",
     *          in="query",
     *          type="boolean",
     *          required=false,
     *          default=true
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     ),
     *     @SWG\Response(
     *          response=400,
     *          description="BadRequest"
     *     )
     * )
     *
     * @return string
     */
    public function videos()
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::ALUNO]);

            // $userId = $this->session->userdata('pessoaid');
            $userId = $this->session->userdata('id');
            $userLogin = $this->session->userdata('login');
            $profileId = (int)$this->session->userdata('perfil');

            $idSerie = $this->input->get('idSerie');
            $idTurma = $this->input->get('idTurma');
            $descDisciplina = $this->input->get('descDisciplina');
            $descLivro = $this->input->get('descLivro');
            $escolaDigital = $this->input->get('escolaDigital');

            if ($profileId === Perfil::ALUNO) {
                $user = SaeDigital::make(UsuarioNextAVA::class)->get($userId);
                $idTurma = $user->team;
                $idSerie = $user->grade;
                $versao_conteudo_id = $user->versao_conteudo_id;
            }

            if ($profileId === Perfil::PROFESSOR) {
                if (empty($idSerie)) throw new Exception('É obrigatório informar uma série.');

                // $teams = SaeDigital::make(TurmasPorProfessor::class)->handle($userId);


                // if (count($teams) === 0) throw new Exception('Você não tem acesso a este conteúdo.');
                // $idTurma = array_shift($teams);

                // $user = SaeDigital::make(UsuarioNextAVA::class)->get($userId);
                // $versao_conteudo_id = $user->versao_conteudo_id;
                $versao_conteudo_id = 21;
                if ( $schoolId==12018 ) $versao_conteudo_id = 17;
                else if ( $schoolId==12570 ) $versao_conteudo_id = 18;
            }

            /** @var VideoaulasEscolaDigital $service */
            $service = SaeDigital::make(VideoaulasEscolaDigital::class);
            $data = $service->handle($idSerie, $escolaDigital, $versao_conteudo_id);

            return $this->responseJson([
                'success' => true,
                'count' => count($data),
                'data' => $data
            ], 200);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        } catch (Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }

}
