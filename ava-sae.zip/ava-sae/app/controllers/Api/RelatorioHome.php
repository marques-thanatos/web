<?php

use Illuminate\Support\Collection;

use Ava\App\Support\Perfil;
use Ava\App\Services\Turma\BuscarTurmasPorLoginProfessor;
use Ava\App\Services\Turma\BuscarTurmaPorAluno;
use Ava\App\Services\Turma\VerificarAgendamentoRealizado;
use Ava\App\Services\Turma\CalcularEngajamentoTurmas;
use Ava\App\Services\Turma\CalcularIndiceAcertosErrosTurmas;
use Ava\App\Services\Metabase\Client;

use Ava\App\Services\Metabase\StudentReportService;

use Ava\App\Services\Aluno\BuscarAluno;
use Ava\App\Services\Relatorios\RelatorioDesempenhoIndividual;
use Ava\App\Services\Relatorios\Calculos\CalcularCoeficienteDesempenhoAcademico;
use Ava\App\Services\Relatorios\RelatorioDesempenhoTurma;
use Ava\App\Services\Relatorios\RelatorioDesempenhoHome;
use Ava\App\Services\Turma\BuscarDadosTurma;
use Ava\App\Services\Metabase\FullClassReport;
use Ava\App\Services\Metabase\ClassIdLevel;


if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class RelatorioHome extends MY_Controller {

	/** @var Client */
	private $metabaseService;
	
	/** @var bool */
	public $layout = false;

    public function __construct() {
		parent::__construct();
		
        $this->metabaseService = new Client();
	}
	
	public function consolidate(){
		$t0  = microtime(true);

    $turma = $this->input->get('turma');
		$escola = $this->input->get('escola');
		$msg = [
			'team_id' => $turma,
			'school_id' => $escola
		];

		$consolidacao = SaeDigital::Make(RelatorioDesempenhoHome::class)->handle($msg);

		// MANTER DURANTE TESTES, DEPOIS APAGAR
		// SaeDigital::Make(RelatorioDesempenhoHome::class)->handle('c639e11ae34b412a7522ba24daf75db8', 'b3b8fd4c5161c3a1ba7f38e493e30efc');
		// SaeDigital::Make(RelatorioDesempenhoHome::class)->handle('098b37c7528f45c9ac7b989c560790f8', 'c37583ada557da3fae05eda1f39895cc');

		$t1 = microtime(true);
		$consolidacao['tempoConsolidacao'] = $t1-$t0;
		return $this->responseJson($consolidacao, 200);
	}

	public function pastaProfessor(){
		$this->allowProfile([Perfil::PROFESSOR]);

		$t0 = microtime(true);

		$loginProfessor = $this->session->userdata('login');
		$turmas = SaeDigital::Make(BuscarTurmasPorLoginProfessor::class)->handle($loginProfessor);

		$retorno = SaeDigital::Make(RelatorioDesempenhoHome::class)->handlePasta($turmas);
		$retorno['success'] = true;

		$t1 = microtime(true);
		$retorno['tempoCarregamento'] = $t1-$t0;

		return $this->responseJson($retorno, 200);
	}

	public function mochilaAluno(){
		$this->allowProfile(Perfil::ALUNO);

		$t0 = microtime(true);

		$idAluno = $this->session->userdata('pessoaid');
		$aluno = SaeDigital::make(BuscarAluno::class)->handle($idAluno);
		$turma = SaeDigital::Make(BuscarTurmaPorAluno::class)->handle($idAluno);
		$idEscolaLevel = $this->obterIdEscolaLevel($aluno['Escola']);
		$idLevel = SaeDigital::make(StudentReportService::class)->getLevelData( $aluno['Login'], $idEscolaLevel);
		$id = count($idLevel)>0 ? $idLevel[0]['id'] : $idAluno;

		$retorno = [
			"success" 					=> true,
			"infoTurma"					=> [
				'categoria'				=> $turma['DescricaoSerie'],
				'descricao'				=> $turma['DescricaoCategoriaTurma'],
				'escola'				=> $turma['NomeEscola'],
			],
			"posicaoAlunoTurma"			=> "1",
			"maiorMediaTurma"			=> "0",
			"mediaTurma"				=> "0"
		];

		$turma = SaeDigital::make(BuscarDadosTurma::class)->handle($aluno['Turma'], ['A'], Date('Y'));
		$medias = SaeDigital::make(RelatorioDesempenhoHome::class)->handleMochila( $turma['itemName'], $turma['EscolaID'], $aluno, 24*3600);

		$retorno['coeficienteAcademico'] = isset($medias[$id]) ? $medias[$id] : '0';

		if ( count($medias)>0 ) {
			usort($medias, function($a, $b){  return $a>$b ? -1 : 1;  });
			$media = array_sum($medias) / max( count($medias), 1 );
			
			$retorno['posicaoAlunoTurma'] = array_search($retorno['coeficienteAcademico'], $medias) + 1;
			$retorno['maiorMediaTurma'] = max($medias);
			$retorno['mediaTurma'] = number_format($media, 0);
		}

		$t1 = microtime(true);
		$retorno['tempoCarregamento'] = $t1-$t0;

		return $this->responseJson($retorno, 200);
	}

	public function getCoefAcademicoByTurma($idTurma)
    {
        $params = [
            [
                "type" => "category",
                "value" => $idTurma,
                "target" => [
                    "variable",
                    ["template-tag", "turma"]
                ]
            ]
        ];

         $requestParams = [
            'form_params' => [
                'parameters' => \GuzzleHttp\json_encode($params)
            ]
        ];

        $request = $this->metabaseService->post(
            'api/card/84/query/json',
            $requestParams
        );

        $response = \GuzzleHttp\json_decode($request->getBody()->getContents(), true);

        return $response;
    }

	public function getDesempenhoTurmas($idEscola, $turmas)
    {
		$turmas = is_array($turmas) ? implode(',', $turmas) : $turmas;

        $params = [
            [
                "type" => "category",
                "value" => $idEscola,
                "target" => [
                    "variable",
                    ["template-tag", "escola"]
				]
			],
			[
				"type" => "category",
				"value" => $turmas,
				"target" => [
					"variable",
					["template-tag", "turmas"]
				]
			]
	
        ];

         $requestParams = [
            'form_params' => [
                'parameters' => \GuzzleHttp\json_encode($params)
            ]
        ];

        $request = $this->metabaseService->post(
            'api/card/78/query/json',
            $requestParams
        );

        $response = \GuzzleHttp\json_decode($request->getBody()->getContents(), true);

		return $response;
    }

	public function getTurmasProfessor($idProfessor){
        $params = [
            [
                "type" => "category",
                "value" => $idProfessor,
                "target" => [
                    "variable",
                    ["template-tag", "Usuario"]
				]
			]	
        ];

         $requestParams = [
            'form_params' => [
                'parameters' => \GuzzleHttp\json_encode($params)
            ]
        ];

        $request = $this->metabaseService->post(
            'api/card/87/query/json',
            $requestParams
        );

        $response = \GuzzleHttp\json_decode($request->getBody()->getContents(), true);

		return $response;
    }

	public function getEngajamentoTurmas($turmas){
		$turmas = is_array($turmas) ? implode(',', $turmas) : $turmas;
        $params = [
            [
                "type" => "category",
                "value" => $turmas,
                "target" => [
                    "variable",
                    ["template-tag", "Turmas"]
				]
			]	
        ];

         $requestParams = [
            'form_params' => [
                'parameters' => \GuzzleHttp\json_encode($params)
            ]
        ];

        $request = $this->metabaseService->post(
            'api/card/88/query/json',
            $requestParams
        );

		$response = \GuzzleHttp\json_decode($request->getBody()->getContents(), true);
		
		if ( count($response)==0 ) return 0;
		
		return $response[0];
	}
	

	public function getDesempenhoTurmasLevel($turmas, $disciplinas){
		$turmas = is_array($turmas) ? implode(',', $turmas) : $turmas;
		$disciplinas = is_array($disciplinas) ? implode(',', $disciplinas) : $disciplinas;
        $params = [
            [
                "type" => "category",
                "value" => $turmas,
                "target" => [
                    "variable",
                    ["template-tag", "Turmas"]
				]
			],
			[
				"type" => "category",
				"value" => $disciplinas,
				"target" => [
					"variable",
					["template-tag", "Disciplinas"]
				]
			]
        ];

         $requestParams = [
            'form_params' => [
                'parameters' => \GuzzleHttp\json_encode($params)
            ]
        ];

        $request = $this->metabaseService->post(
            'api/card/82/query/json',
            $requestParams
        );

		$response = \GuzzleHttp\json_decode($request->getBody()->getContents(), true);

		return $response;
	}
	
	public function getNomeTurmas($turmas){
		$turmas = is_array($turmas) ? implode(',', $turmas) : $turmas;
        $params = [
            [
                "type" => "category",
                "value" => $turmas,
                "target" => [
                    "variable",
                    ["template-tag", "Turmas"]
				]
			]
        ];

         $requestParams = [
            'form_params' => [
                'parameters' => \GuzzleHttp\json_encode($params)
            ]
        ];

        $request = $this->metabaseService->post(
            'api/card/90/query/json',
            $requestParams
        );

		$response = \GuzzleHttp\json_decode($request->getBody()->getContents(), true);
		
		if ( count($response)==0 ) return [['description'=>'']];
		
		return $response;
	}
	
	public function getErrosAcertosTurmas($turmas){
		$turmas = is_array($turmas) ? implode(',', $turmas) : $turmas;
        $params = [
            [
                "type" => "category",
                "value" => $turmas,
                "target" => [
                    "variable",
                    ["template-tag", "Turmas"]
				]
			]
        ];

         $requestParams = [
            'form_params' => [
                'parameters' => \GuzzleHttp\json_encode($params)
            ]
        ];

        $request = $this->metabaseService->post(
            'api/card/91/query/json',
            $requestParams
        );

		$response = \GuzzleHttp\json_decode($request->getBody()->getContents(), true);
		
		if ( count($response)==0 ) return [['description'=>'']];
		
		return $response;
	}
	
	private function obterIdEscolaLevel($itemNameEscola){
		$escolas = [
			'7159697ec35b996c30bbc853cc7637f8'	=> 1,		// integracao.dombosco
			'd07e0a07387e91cde8c81768443f235b'	=> 1,		// new_integracao.dombosco
			'6a05926dc211749512f0eb22f2266f18'	=> 2,		// santo.anjo
			'c37583ada557da3fae05eda1f39895cc'	=> 2,		// new_santo.anjo
			'dae1e5d16ceecbbc14586bb1b8a9b418'	=> 4,		// dombosco.balsas
			'9618df4005ddc7d05a384b22553fd393'	=> 4,		// new_dombosco.balsas
		];

		return isset($escolas[$itemNameEscola]) ? $escolas[$itemNameEscola] : 0;
	}
}