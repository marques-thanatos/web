<?php

use Swagger\Annotations as SWG;
use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\Series\BuscarSeriesPorLogin;
use Ava\App\Support\Perfil;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class GradesController extends MY_Controller
{

    public $layout = false;

    /**
     * @SWG\Get(
     *     path="/grades",
     *     summary="Retorna as séries disponíveis para o usuário logado.",
     *     description="Busca as séries disponíveis para o usuário logado utilizando as séries vinculadas.",
     *     produces={"application/json"},
     *     tags={"Séries"},
     *     @SWG\Response(
     *          response=200,
     *          description="Success",
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     */
    public function index()
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR, Perfil::ALUNO]);

            //$login = $this->session->userdata('login');
            
            /** @var BuscarSeriesPorLogin $service */
            /*$service = SaeDigital::make(BuscarSeriesPorLogin::class);
            $grades = $service->handle($login);*/
            $teamsArray = $this->session->userdata('teams');
            $gradesArray = [];
            $listaFiltrada = [];
            foreach ( $teamsArray as $item){
                $listaFiltrada[ $item->grade_id ] = $item;
            }

            $teamsArray = array_values($listaFiltrada);

            
            foreach($teamsArray as $team) {
                $obj = array(
                    'AcessoLD' => $this->session->userdata('acessoLD'),
                    'CategoriaID' => $team->categoriaid,
                    'Descricao' => $team->descricaoserie,
                    'ExibeMenuLD' => $this->session->userdata('ExibeMenuLD'),
                    'SerieID' => $team->grade_id,
                    'id' => $team->id,
                );
                array_push($gradesArray, $obj);
            }

            $grades = array_values($gradesArray);
            array_multisort(array_column($grades, 'SerieID'), SORT_ASC, $grades);

            return $this->responseJson($grades, 200);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        }
    }
}
