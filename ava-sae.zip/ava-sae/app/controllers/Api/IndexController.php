<?php

use Swagger\Annotations as SWG;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @SWG\Swagger(
 *     schemes=SWG_SCHEMAS,
 *     host=SWG_API_HOST,
 *     basePath=SWG_BASE_PATH,
 *     produces={"text/html"},
 *     @SWG\Info(
 *          title="API Plataforma SAE Digital",
 *          version=SWG_VERSION
 *     )
 * )
 */
class IndexController extends MY_Controller
{

    /** @var bool */
    public $layout = false;

    /**
     * Return User Grades by Login.
     * @return string
     */
    public function index()
    {
        try {
            return $this->twigRender('api/doc/index.twig');
        } catch (Twig_Error_Loader $e) {
        } catch (Twig_Error_Runtime $e) {
        } catch (Twig_Error_Syntax $e) {
        }
    }

    /**
     * Return Swagger json string.
     * @return string
     */
    public function swaggerJson()
    {
        $dirs = [
            getcwd() . DIRECTORY_SEPARATOR . 'app'
        ];

        $serializer = \Swagger\scan($dirs);
        header('Content-Type: application/json');
        print($serializer); die;
    }
}
