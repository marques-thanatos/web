<?php

use Illuminate\Support\Collection;

use Ava\App\Services\Usuario\AceitarTermosUso;
use Ava\App\Services\Usuario\AceitarTermosUsoNextAva;
use Ava\App\Services\Usuario\BuscarUsuarioPorLogin;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class AcceptTermController extends CI_Controller {

	public $configuracoes;

	public $layout = false;

	public function __construct()
	{
		parent::__construct();

		SaeDigital::make(\Ava\App\Services\Monitoramento\Sentry::class)->handle();

		$this->load->model('configuracoes_model', 'configuracoes');
		$this->configuracoes = $this->configuracoes->configuracoes();
	}

	/**
     * Aceitar termos
     *
     * Salva a data em que o usuário aceitou os termos de uso
     *
     * @access public
     * @return object
     */
	public function index() 
	{
		$this->layout = '';

		$retorno = new stdClass();
		$retorno->success = false;
		$retorno->error = "";

		$user_id = $this->session->userdata('id');
		if ( $user_id ) {

			$retorno->success = true;
			$exec = SaeDigital::make(AceitarTermosUsoNextAva::class)->handle($user_id);
			if(!$exec) {
				$retorno->success = false;
			}
		}

		// Para o acesso direto não foi possível herdar da MY_Controller, por isso CI_Controller
		// CI_Controller não tem responseJson, por isso cabeçalhos setados aqui
		
		$this->session->sess_destroy();
        header('Content-Type: application/json');
        http_response_code( 200 );
        echo json_encode($retorno);
  }

}