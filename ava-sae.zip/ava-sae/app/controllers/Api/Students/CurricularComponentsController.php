<?php

use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\Agendamentos\BuscarAgendamentosPorTurma;
use Ava\App\Services\Turma\BuscarTurmaPorAluno;
use Ava\App\Support\Perfil;
use Swagger\Annotations as SWG;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class CurricularComponentsController extends MY_Controller
{

    /** @var bool */
    public $layout = false;

    /**
     * @SWG\Get(
     *     path="/students/curricular-components",
     *     summary="Retornas a lista de componentes curriculares disponíveis para o Aluno",
     *     description="Busca os componentes curriculares disponíveis para o Aluno logado utilizando as turmas atribuidas como filtro",
     *     produces={"application/json"},
     *     tags={"Alunos"},
     *     @SWG\Parameter(
     *          name="idClassificacao",
     *          in="query",
     *          type="integer",
     *          required=false
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     *
     * @return string
     */
    public function index()
    {
        try {
            $this->allowProfile(Perfil::ALUNO);

            $userId = $this->session->userdata('id');
            $classificacaoId = $this->input->get('idClassificacao');

            /** @var BuscarTurmaPorAluno $teamService */
            //$teamService = SaeDigital::make(BuscarTurmaPorAluno::class);
            //$team = $teamService->handle($userId, true);


            $team = (array) $this->session->userdata('teams')[0];


            /** @var BuscarAgendamentosPorTurma $teamScheduleService */
            $teamScheduleService = SaeDigital::make(BuscarAgendamentosPorTurma::class);
            $schedules = $teamScheduleService->handle($team['id'], $userId, $classificacaoId, true);
            
            /** @var BuscarTurmaPorAluno $studentTeamService */
            //$studentTeamService = SaeDigital::make(BuscarTurmaPorAluno::class);
            //$turma = $studentTeamService->handle($userId);



            $schedules = collect($schedules)->map(function ($schedule) use ($team) {
                $schedule['RedirectPage'] = "/curso/{$schedule['Slug']}?turmaID={$team['id']}";
                return $schedule;
            });

            return $this->responseJson([
                'success' => true,
                'count' => count($schedules),
                'data' => $schedules
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);

        }
    }

}
