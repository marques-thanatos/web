<?php

use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\Agendamentos\BuscarAgendamentosPorTurma;
use Ava\App\Services\Turma\BuscarTurmaPorAluno;
use Ava\App\Support\Perfil;
use Swagger\Annotations as SWG;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class TeamController extends MY_Controller
{

    /** @var bool */
    public $layout = false;

    /**
     * @SWG\Get(
     *     path="/students/teams",
     *     summary="Retorna as turmas do aluno",
     *     description="Buscar as turmas vinculadas ao aluno.",
     *     tags={"Alunos"},
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     */
    public function index()
    {
        try {
            $this->allowProfile(Perfil::ALUNO);

            $login = $this->session->userdata('pessoaid');

            /** @var BuscarTurmaPorAluno $teamService */
            $teamService = SaeDigital::make(BuscarTurmaPorAluno::class);
            $team = $teamService->handle($login, true);

            return $this->responseJson([
                'success' => true,
                'data' => $team
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        }
    }

}
