<?php

use Ava\App\Domain\Controllers\BaseController;
use Swagger\Annotations as SWG;
use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Support\Perfil;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class EscolaDigitalController extends BaseController
{

    public $layout = false;

    /**
     * @SWG\Get(
     *     path="/library/escola-digital",
     *     summary="Retornas dados informativos sobre os livro do SAE Digital",
     *     description="Busca dados informativos dos livros do SAE Digital.",
     *     produces={"application/json"},
     *     tags={"Biblioteca"},
     *     @SWG\Parameter(
     *          name="idSerie",
     *          in="query",
     *          type="integer",
     *          required=true
     *     ),
     *     @SWG\Parameter(
     *          name="ignoreCache",
     *          in="query",
     *          type="boolean",
     *          required=false
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success",
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     */
    public function index()
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::ALUNO]);

            $idSerie = $this->input->get('idSerie');
            $ignoreCache = filter_var($this->input->get('ignoreCache'), FILTER_VALIDATE_BOOLEAN);

            if (!$idSerie) {
                throw new InvalidArgumentException('É obrigatório informar o idSerie');
            }

            $cacheKey = implode([
                'api:escola-digital-controller:index:idSerie-',
                $idSerie
            ]);

            // $cachedData = $this->cache()->get($cacheKey);

            // if ($cachedData && !$ignoreCache) {
            //     return $this->responseJson([
            //         'success' => true,
            //         'data' => $cachedData
            //     ]);
            // }

            $file = file_get_contents(__DIR__ . '/../../../public/escola_digital/data-2021.json');
            $data = \GuzzleHttp\json_decode($file);

            $response = collect($data)->where('idSerie', $idSerie)->values()->toArray();

            if (count($response))
                $this->cache()->put($cacheKey, $response, env('SAE_DEFAULT_CACHE_TTL', 60));

            return $this->responseJson([
                'success' => true,
                'data' => $response
            ]);

        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        } catch (Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
}
