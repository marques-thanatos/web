<?php

use Ava\App\Domain\Controllers\BaseController;
use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\Assuntos\AssuntosPorDisciplinaAssunto;
use Ava\App\Services\Disciplinas\BuscarComponentesCurricularesPorLogin;
use Ava\App\Services\Disciplinas\BuscarComponentesCurricularesNextAva;
use Ava\App\Services\Turma\BuscarTurmasAlunosDisciplinasNextAva;
use Ava\App\Services\Disciplinas\BuscarDadosDisciplinas;
use Ava\App\Services\Disciplinas\BuscarDisciplinasPorSerieVersao;
use Ava\App\Services\Disciplinas\VerificaDisciplinaPorLogin;
use Ava\App\Services\Turma\BuscarDadosTurma;
use Ava\App\Support\Perfil;
use Ava\App\Support\Situacao;
use Swagger\Annotations as SWG;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class CurricularComponentsController extends BaseController
{

    /**
     * @SWG\Get(
     *     path="/curricular-components",
     *     summary="Retornas os componentes curriculares disponíveis para o usuário logado",
     *     description="Busca os componentes curriculares disponíveis para o usuário logado com filtragem de dados com base na série, turma e classificação",
     *     produces={"application/json"},
     *     tags={"Componentes Curriculares"},
     *     @SWG\Parameter(
     *          name="idSerie",
     *          in="query",
     *          type="integer",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="idTurma",
     *          in="query",
     *          type="string",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="idClassificacao",
     *          in="query",
     *          type="integer",
     *          required=false,
     *          default=10
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     *
     * @return string
     */
    public function index()
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $login = $this->session->userdata('login');
            $idProfile = $this->session->userdata('perfil');
            $idContentVersion = $this->session->userdata('versao_conteudo_id');

            $idSerie = $this->input->get('idSerie');
            $idTurma = $this->input->get('idTurma');
            $idClassificacao = $this->input->get('idClassificacao') ?: 10;
            $grades = [];
            if ($idProfile == Perfil::PROFESSOR || $idProfile == Perfil::COORDENADOR) {
                /** @var BuscarComponentesCurricularesPorLogin $service */
                $token = $this->session->userdata('token');


                $service = SaeDigital::make(BuscarTurmasAlunosDisciplinasNextAva::class);
                $teamsStudentsData = $service->handle($token);
                

                $nextAvaData = collect($teamsStudentsData);
                
                if($idSerie)
                    $nextAvaData = collect($teamsStudentsData)->where("serieid", "=", $idSerie);
                
                if($idTurma) {
                    $nextAvaData = collect($teamsStudentsData)->filter(function ($teamItem) use ($idTurma) {
                        return ($teamItem->itemName == $idTurma || $teamItem->team_id == $idTurma);
                    });
                }
       
                if($idClassificacao == 11) {
                    $nextAvaData = array_values($nextAvaData->toArray());

                    for($countDados = 0; $countDados < sizeof($nextAvaData); $countDados++) {
                        $subjectsArray = $nextAvaData[$countDados]->subjects;

                        $subjectsPlataformaLiteraria = array_filter($subjectsArray, function($subject) {
                            return $subject->disciplinaidnextava == 52;
                        });

                        $nextAvaData[$countDados]->subjects = (sizeof($subjectsPlataformaLiteraria) > 0) ? $subjectsPlataformaLiteraria : [];
                    }
                }
                else if($idClassificacao == 10) {
                    $nextAvaData = array_values($nextAvaData->toArray());

                    for($countDados = 0; $countDados < sizeof($nextAvaData); $countDados++) {
                        $subjectsArray = $nextAvaData[$countDados]->subjects;
                        
                        $subjectsPlataformaLiteraria = array_values(collect($subjectsArray)->where('disciplinaidnextava', '!=', 52)->toArray());

                        $nextAvaData[$countDados]->subjects = (sizeof($subjectsPlataformaLiteraria) > 0) ? $subjectsPlataformaLiteraria : [];
                    }
                }

                foreach($nextAvaData as $tsd) {    
                    if ( $tsd->vigenciaturma == 2020 ) {
                        $service = SaeDigital::make(BuscarComponentesCurricularesPorLogin::class);
                        $disciplinaArray = $service->handle($login, $tsd->SerieID, $tsd->itemName, $idClassificacao);
                        if(sizeof($disciplinaArray) > 0) {
                            foreach($disciplinaArray as $disciplina){
                                array_push($grades, $disciplina);
                            }
                        }
                    }
                    else {
                        $serieId = $tsd->serieid;
                        $subjectsNextAva = $tsd->subjects;

                        foreach( $subjectsNextAva as $subject) {
                            $serviceDisciplinas = SaeDigital::make(BuscarDadosDisciplinas::class);
                           
                            $disciplinaID = $subject->disciplinaid;
                        
                            $disciplinaData = $serviceDisciplinas->handle($serieId, $idContentVersion, [$idClassificacao], $disciplinaID);

                            if( $disciplinaData != null ) {
                                $disciplinaArray = array(
                                    'Ancora' => $disciplinaData[0]['Ancora'],
                                    'descricao' => $disciplinaData[0]['Descricao'],
                                    'idClassificacao' => $disciplinaData[0]['ClassificacaoID'],
                                    'componenteNome' => $subject->nomedisciplina,
                                    'SerieID' => $serieId,
                                    'idDisciplina' => $subject->disciplinaid
                                );
                            }
                            else {
                                $disciplinaArray = array(
                                    'Ancora' => $subject->slug,
                                    'descricao' => $subject->nomedisciplina,
                                    'idClassificacao' => 10,
                                    'componenteNome' => $subject->nomedisciplina,
                                    'SerieID' => $serieId,
                                    'idDisciplina' => $subject->disciplinaid
                                );
                            }

                            array_push($grades, $disciplinaArray);
                        }
                    }
                }

            }
            $listaFiltrada = [];
            foreach ( $grades as $item){
                $listaFiltrada[ $item['idDisciplina']] = $item;
            }


            $grades = array_values($listaFiltrada);


            return $this->responseJson($grades, 200);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        }
    }

    /**
     * @SWG\Get(
     *     path="/curricular-components/{idDisciplina}/modules",
     *     summary="Retorna os módulos de estudo de uma disciplina.",
     *     description="Busca os módulos de estudo de uma disciplina ",
     *     produces={"application/json"},
     *     tags={"Componentes Curriculares"},
     *     @SWG\Parameter(
     *          name="idDisciplina",
     *          in="path",
     *          description="Obrigatório, informação utilizada para filtrar os módulos de uma disciplina.",
     *          type="integer",
     *          required=true
     *     ),
     *     @SWG\Parameter(
     *          name="idAssunto",
     *          in="query",
     *          description="Opcional, informação utilizada para filtrar por um assunto em uma disciplina.",
     *          type="integer"
     *     ),
     *     @SWG\Parameter(
     *          name="escolaDigital",
     *          in="query",
     *          description="Opcional, informação utilizada para filtrar por um assunto em uma disciplina.",
     *          type="boolean"
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     *
     * @param $idDisciplina
     * @return string
     */
    public function showModules($idDisciplina) {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $login = $this->session->userdata('login');
            $idPerfil = $this->session->userdata('perfil');

            if ($idPerfil == Perfil::PROFESSOR) {
                /** @var VerificaDisciplinaPorLogin $verificaDisciplinaService */
                $verificaDisciplinaService = SaeDigital::make(VerificaDisciplinaPorLogin::class);
               // $acessoDisciplina = $verificaDisciplinaService->handle($login, $idDisciplina);

               // if (!$acessoDisciplina) {
                //     throw new NotAllowedException('Você não tem permissão de acesso a este componente curricular.');
                //}
            }

            $filterEscolaDigital = filter_var($this->input->get('escolaDigital'), FILTER_VALIDATE_BOOLEAN);
            $idAssunto = $this->input->get('idAssunto');

            /** @var AssuntosPorDisciplinaAssunto $assuntosService */
            $assuntosService = SaeDigital::make(AssuntosPorDisciplinaAssunto::class);
            $subjects = $assuntosService->handle($idDisciplina, $idAssunto, $filterEscolaDigital);

            return $this->responseJson([
                'success' => true,
                'count' => count($subjects),
                'data' => $subjects
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ], 403);
        }
    }
}
