<?php

use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\Turma\BuscarTurmasPorLoginComAlunos;
use Ava\App\Services\Turma\BuscarTurmasNextAva;
use Ava\App\Support\Perfil;
use Swagger\Annotations as SWG;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class TeamsController extends MY_Controller
{

    /** @var bool */
    public $layout = false;

    /**
     * @SWG\Get(
     *     path="/teams",
     *     summary="Retornas as turmas disponíveis para o usuário logado.",
     *     description="Busca as turmas disponíveis relacionadas com o usuário logado.",
     *     produces={"application/json"},
     *     tags={"Turmas"},
     *     @SWG\Parameter(
     *          name="idSerie",
     *          in="query",
     *          type="integer",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="idTurma",
     *          in="query",
     *          type="string",
     *          required=false
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=403,
     *          description="Forbidden"
     *     )
     * )
     *
     * @return string
     */
    public function index()
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $login = $this->session->userdata('login');
            $groupBy = $this->input->get('groupBy');
            $idSerie = $this->input->get('idSerie');
            $idTurma = $this->input->get('idTurma');
            /** @var BuscarTurmasPorLoginComAlunos $teamsService */
            //$teamsService = SaeDigital::make(BuscarTurmasPorLoginComAlunos::class);
            //$teams = $teamsService->handle($login, $groupBy, $idSerie, $idTurma);
            $teamsArray = $this->session->userdata('teams');

            $token = $this->session->userdata('token');
            $teamsArray = array_unique($teamsArray, SORT_REGULAR);
            $teamsIds = [];

            foreach($teamsArray as $team) {
                if(!$idTurma && !$idSerie)
                    array_push($teamsIds, $team->id);
                else if( $idSerie ) {
                    if($team->grade_id == $idSerie) {
                        array_push($teamsIds, $team->id);
                    }
                }
                else if ( $idTurma ) {
                    if($team->itemName == $idTurma || $team->id == $idTurma) {
                        array_push($teamsIds, $team->id);
                    }
                }

            }
        
            $teamsService = SaeDigital::make(BuscarTurmasNextAva::class);
            $teams = $teamsService->handle($token, $teamsIds, $teamsArray);
        


            return $this->responseJson([
                'success' => true,
                'count' => count($teams),
                'data' => $teams
            ]);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        }
    }

}
