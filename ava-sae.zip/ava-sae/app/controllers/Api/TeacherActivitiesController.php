<?php

use Illuminate\Support\Collection;

use Ava\App\Domain\Controllers\BaseController;
use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\Agendamentos\BuscarAgendamentoPorId;
use Ava\App\Services\Agendamentos\BuscarAgendamentosPorDisciplinaTurma;
use Ava\App\Services\Agendamentos\BuscarAgendamentosPorTurma;
use Ava\App\Services\Agendamentos\FiltrarAgendamentosPorTipo;
use Ava\App\Services\Assuntos\AssuntosPorDisciplinaAssunto;
use Ava\App\Services\Aluno\BuscarAluno;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracaoEscolaPorSerie;
use Ava\App\Services\Disciplinas\PegaDisciplinaIDPelaAncora;
use Ava\App\Services\Disciplinas\PegaDisciplinaPeloId;
use Ava\App\Services\Turma\BuscarTurmaPorAluno;
use Ava\App\Services\Turma\BuscarTurmasPorLoginProfessor;
use Ava\App\Services\Video\BuscarPorcentagemVideo;
use Ava\App\Services\Questoes\DadosReforco;
use Ava\App\Support\Perfil;
use Ava\App\Support\TipoAgendamento;

use Ava\App\Services\Bimestres\PegaBimestrePeloId;
use Ava\App\Services\Agendamentos\BuscarAgendamentoPorTurmaAssunto;


if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class TeacherActivitiesController extends MY_Controller
{
	public $layout = false;

	public function __construct()
    {
        parent::__construct();
        $this->load->library('disciplina_lib');
	}

	/**
     * @param str $Ancora
	 *
     * @return view
     */
	public function index($TurmaID, $Ancora){
		$this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);
		try {

			$Login 			= $this->session->userdata('login');
			$ProfessorID 	= $this->session->userdata('pessoaid');

			$DisciplinaID 	= SaeDigital::make(PegaDisciplinaIDPelaAncora::class)->handle($Ancora);
			$disciplina 	= SaeDigital::make(PegaDisciplinaPeloId::class)->handle($DisciplinaID);

			$assuntos 		= SaeDigital::make(AssuntosPorDisciplinaAssunto::class)->handle($DisciplinaID);
			$assuntosED 	= SaeDigital::make(AssuntosPorDisciplinaAssunto::class)->handle($DisciplinaID, null, true);
			$agendamentos	= SaeDigital::make(BuscarAgendamentosPorDisciplinaTurma::class)->handle($DisciplinaID, $TurmaID, false);

			$collectionAgd 	= collect($agendamentos);

			$retorno 	= [
				'disciplina'		=> $disciplina['Descricao'],
				'atividades' 		=> [],
				'reforco' 			=> [],
				'videoaulas' 		=> []
			];
			foreach( $assuntos as $assunto ){
				$itemVazio		= $this->itemVazio( $assunto );
				$nomeCurto 	= SaeDigital::make(FiltrarAgendamentosPorTipo::class)->obterNomeCurtoBimestre( $assunto['DescricaoBimestre'] );

				$agendamentoTrilha 		= $collectionAgd->where('AssuntoID', $assunto['AssuntoID'])->where('tipo_agendamento', TipoAgendamento::TRILHA)->first();
				$agendamentoReforco 	= $collectionAgd->where('AssuntoID', $assunto['AssuntoID'])->where('tipo_agendamento', TipoAgendamento::REFORCO)->first();

				$item = $agendamentoTrilha ? SaeDigital::make(FiltrarAgendamentosPorTipo::class)->formatarAgendamento($agendamentoTrilha) : $itemVazio;
				$item['type'] = 'atividades';
				$retorno['atividades'] = $this->inserirArray($retorno['atividades'], $nomeCurto, $assunto['DescricaoBimestre'], $item);

				$item = $agendamentoReforco ? SaeDigital::make(FiltrarAgendamentosPorTipo::class)->formatarAgendamento($agendamentoReforco) : $itemVazio;
				$item['type'] = 'reforcos';
				$retorno['reforco'] = $this->inserirArray($retorno['reforco'], $nomeCurto, $assunto['DescricaoBimestre'], $item);
			}

			$videoaulas 	= [];
			foreach( $assuntosED as $assunto ){
				$nomeCurto 	= SaeDigital::make(FiltrarAgendamentosPorTipo::class)->obterNomeCurtoBimestre( $assunto['DescricaoBimestre'] );

				$agendamento 			= $collectionAgd->where('AssuntoID', $assunto['AssuntoID'])->first();
				$item 					= is_array($agendamento) ?
					SaeDigital::make(FiltrarAgendamentosPorTipo::class)->formatarAgendamento($agendamento)
					: $this->itemVazio( $assunto );

				$item['type'] = 'videoaulas';
				$retorno['videoaulas'] 	= $this->inserirArray($retorno['videoaulas'], $nomeCurto, $assunto['DescricaoBimestre'], $item);
			}

			return $this->responseJson($retorno, 200);

        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        }
	}

	/**
     * @param int $AgendamentoID
	 *
     * @return array
     */
	function details($Ancora, $AssuntoID){
		try {

			$this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

			$this->load->model('disciplina_model');
			$DisciplinaID 	= SaeDigital::make(PegaDisciplinaIDPelaAncora::class)->handle($Ancora);

			$assuntos 		= SaeDigital::make(AssuntosPorDisciplinaAssunto::class)->handle($DisciplinaID, $AssuntoID);
			$assuntosED 	= SaeDigital::make(AssuntosPorDisciplinaAssunto::class)->handle($DisciplinaID, $AssuntoID, true);

			if ( count($assuntos) + count($assuntosED) == 0 ) {
				return $this->responseJson([], 404);
			}
			$assunto			= count($assuntos)>0 ? $assuntos[0] : $assuntosED[0];

			$dadosAgendamento 	= $this->disciplina_lib->arrayAulas( $DisciplinaID,  $AssuntoID,  $assunto['FrenteID'],  false);

			$aulasCollection 	= collect( $dadosAgendamento['aulas'] );
			$questoes 			= $aulasCollection->where('Tipo', 'Q')->first();
			$revisoes 			= $aulasCollection->where('Tipo', 'R')->first();
			$video 				= $aulasCollection->where('Tipo', 'N')->first();


			$retorno 							= [];
			$retorno['videoDuracao']			= !is_null($video) && is_null($video['Duracao']) ? '00:00:00' : $video['Duracao'];
			$retorno['linkVideo'] 				= 'curso/'. 	$Ancora ."/questao/". $video['itemName'] 	."/1";

			if ( count($assuntos)>0 ){
				$retorno['questoesTotais']			= 4;
				$retorno['revisoesTotais']			= 3;
				$retorno['linkQuestoes'] 			= 'curso/'. 	$Ancora ."/questao/". $questoes['itemName'] ."/1?questao=true";
				$retorno['linkRevisoes'] 			= 'curso/'. 	$Ancora ."/revisao/". $revisoes['itemName'] ."/3?questao=true";
			}

			$param[0]['DisciplinaID'] 			= $AssuntoID;
			$param[0]['Tipo'] = 'Q';
			$param[1]['Tipo'] = 'R';
			$questoesReforco 					= $this->disciplina_model->questoesReforco($param, $DisciplinaID);
			if ( $questoesReforco ) {
				$retorno['reforcosTotais']				= count($questoesReforco);
				$retorno['linkReforco'] 			= 'reforco/'. 	$Ancora ."/reforco/". $questoes['itemName'] ."/3?questao=true";
			}

			return $this->responseJson($retorno, 200);

		} catch (NotAllowedException $e) {
			return $this->responseJson([
				'success' => false,
				'message' => 'Você não tem permissão para acessar este conteúdo'
			], 403);
		}
	}

	function inserirArray($array, $nomeCurto, $bimestre, $item){
		if ( array_key_exists($nomeCurto, $array) ){
			$array[ $nomeCurto ]['agendamentos'][] = $item;
		} else {
			$array[ $nomeCurto ] = [
				"agrupador"		=> $nomeCurto,
				"titulo"		=> $bimestre,
				"agendamentos" 	=> [
					$item
				]
			];
		}
		return $array;
	}

	function itemVazio( $assunto ){
		return [
			"idAgendamento"	=> "",
			"idAssunto"		=> $assunto['AssuntoID'],
			"titulo"		=> $assunto['Descricao'],
			"idFrente"		=> $assunto['FrenteID'],
			"agendado"		=> "",
			"inicio"		=> "",
			"fim"			=> "",
			"expired" 		=> false,
			"detalhes"		=> []
		];
	}

}
