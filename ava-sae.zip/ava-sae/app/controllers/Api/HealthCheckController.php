<?php

use Ava\App\Services\HealthCheck\DBHealth;
use Swagger\Annotations as SWG;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 */
class HealthCheckController extends MY_Controller
{

    /** @var bool */
    public $layout = false;

    /**
     * @SWG\Get(
     *     path="/health-check",
     *     summary="Retorna status da aplicação.",
     *     description="Realiza um consulta no banco de dados para verificação de status de aplicação e serviços.",
     *     produces={"application/json"},
     *     tags={"Health Check"},
     *     @SWG\Response(
     *          response=200,
     *          description="Success",
     *     ),
     *     @SWG\Response(
     *          response=502,
     *          description="Bad Gateway"
     *     )
     * )
     *
     * @return string
     */
    public function index()
    {
        try {
            return $this->responseJson([
                'success' => true,
                'message' => SaeDigital::make(DBHealth::class)->handle()
            ]);
        } catch (Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
