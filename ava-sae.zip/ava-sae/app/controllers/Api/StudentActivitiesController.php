<?php

use Illuminate\Support\Collection;

use Ava\App\Domain\Controllers\BaseController;
use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\Agendamentos\BuscarAgendamentoPorId;
use Ava\App\Services\Agendamentos\BuscarAgendamentosPorDisciplinaTurmaUsuario;
use Ava\App\Services\Agendamentos\BuscarAgendamentosPorTurma;
use Ava\App\Services\Agendamentos\FiltrarAgendamentosPorTipo;
use Ava\App\Services\Aluno\BuscarAlunoReduzido;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracaoEscolaPorSerie;
use Ava\App\Services\Disciplinas\PegaDisciplinaIDPelaAncora;
use Ava\App\Services\Disciplinas\PegaDisciplinaPeloId;
use Ava\App\Services\Turma\BuscarTurmaPorAluno;
use Ava\App\Services\Turma\BuscarTurmasPorLoginProfessor;
use Ava\App\Services\Video\BuscarPorcentagemVideo;
use Ava\App\Services\Questoes\DadosReforco;
use Ava\App\Support\Perfil;
use Ava\App\Support\TipoAgendamento;

use Ava\App\Services\Bimestres\PegaBimestrePeloId;
use Ava\App\Services\Agendamentos\BuscarAgendamentoPorTurmaAssunto;


if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class StudentActivitiesController extends MY_Controller
{
	public $layout = false;

	public function __construct()
    {
        parent::__construct();

        $this->load->model('curso_model', 'curso');
        $this->load->model('cadastro_model', 'cadastro');
        $this->load->library('disciplina_lib');
        $this->load->library('video_lib');
	}

	/**
     * @param str $Ancora
	 *
     * @return view
     */
	public function index($Ancora){
		$this->allowProfile([Perfil::ALUNO]);
		try {

			$AlunoID 	= $this->session->userdata('id');
			$turmas 	= $this->session->userdata('teams');
			$turma 		= $turmas[0];

			$DisciplinaID 		= SaeDigital::make(PegaDisciplinaIDPelaAncora::class)->handle($Ancora);
			if ( $DisciplinaID==0 )
				return [];

			$disciplina 		= SaeDigital::make(PegaDisciplinaPeloId::class)->handle($DisciplinaID);

			$agendamentos 		= SaeDigital::make(BuscarAgendamentosPorDisciplinaTurmaUsuario::class)->handle(
				$DisciplinaID,
				$turma->id,
				$AlunoID
			);

			$agendamentosFiltrados = SaeDigital::make(FiltrarAgendamentosPorTipo::class)->handle($agendamentos);
			$retorno 	= [
				'disciplina'		=> $disciplina['Descricao'],
				'atividades' 		=> $agendamentosFiltrados['atividades'],
				'reforco' 			=> $agendamentosFiltrados['reforco'],
				'videoaulas' 		=> $agendamentosFiltrados['videoaulas']
			];

			return $this->responseJson($retorno, 200);

        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para acessar este conteúdo'
            ], 403);
        }

		$data = ['ancora' => $Ancora];
		$this->load->view('componente_curricular_aluno', $data);
	}

	/**
     * @param int $AgendamentoID
	 *
     * @return array
     */
	function details($AgendamentoID){
		try {
			$this->allowProfile([Perfil::ALUNO]);

			$this->load->model('disciplina_model');
			$UsuarioID 			= $this->session->userdata('pessoaid');
			$escola 			= (array) $this->session->userdata('school');
			$infoTurma			= (array) $this->session->userdata('teams')[0];

			$EscolaID = $escola['itemName'];
			$Serie = $infoTurma['grade_id'];

			$agendamento 		= SaeDigital::make(BuscarAgendamentoPorId::class)->handle($AgendamentoID);
			
			$configEscola 		= SaeDigital::make(BuscarConfiguracaoEscolaPorSerie::class)->handle($EscolaID, $Serie);
			$meta 				= intval( $configEscola['Meta'] );
			$metaVideo 			= intval( $configEscola['Percentual'] );

			$dadosAgendamento 	= $this->disciplina_lib->arrayAulas( $agendamento['DisciplinaID'],  $agendamento['AssuntoID'],  $agendamento['FrenteID'],  false);

			$aulasCollection 	= collect( $dadosAgendamento['aulas'] );
			$questoes 			= $aulasCollection->where('Tipo', 'Q')->first();
			$revisoes 			= $aulasCollection->where('Tipo', 'R')->first();
			$video 				= $aulasCollection->where('Tipo', 'N')->first();

			$duracaoTotalVideo 	= $dadosAgendamento['info']['TempoTotalVideos'];
			$disciplina = SaeDigital::make(PegaDisciplinaPeloId::class)->handle($agendamento['DisciplinaID']);
			$Ancora = $disciplina['Ancora'];

			$retorno 			= [];
			$retorno['meta'] 	= $meta;

			switch( $agendamento['tipo_agendamento'] ){

				case TipoAgendamento::REFORCO:
					$param[0]['DisciplinaID'] 			= $agendamento['AssuntoID'];
					$param[0]['Tipo'] = 'Q';
					$param[1]['Tipo'] = 'R';
					$questoesReforco 					= $this->disciplina_model->questoesReforco($param, $agendamento['DisciplinaID']);

					// dump($questoesReforco); die;
					$retorno['reforcosTotais'] 			= count($questoesReforco);
					$retorno['reforcosAcertos']			= intval(SaeDigital::make(DadosReforco::class)->acertos($UsuarioID, $agendamento['AssuntoID']));
					$retorno['reforcosRespondidas']	= intval(SaeDigital::make(DadosReforco::class)->respostas($UsuarioID, $agendamento['AssuntoID']));
					$retorno['reforcosPorcentagem']	= intval( 100 * $retorno['reforcosAcertos'] / $retorno['reforcosTotais'] );

					$retorno['nota']					= $retorno['reforcosPorcentagem'];

					$retorno['linkReforco'] 			= 'reforco/'. 	$Ancora ."/reforco/". $questoes['itemName'] ."/3?questao=true";
					$retorno['linkAtual'] 				= $retorno['linkReforco'];
					break;

				case TipoAgendamento::PLATAFORMA_LITERARIA:
					if ( $questoes ) {
						$retorno['questoesTotais']			= $questoes['QtdQuestoes'];
						$retorno['questoesAcertos']			= $questoes['QtdRespostaCorretas'];
						$retorno['questoesRespondidas']	= $questoes['QtdQuestoesRespondidas'];
						$retorno['questoesPorcentagem']	= intval( 100 * $questoes['QtdRespostaCorretas'] / $questoes['QtdQuestoes'] );

						$retorno['linkQuestoes'] 			= 'curso/'. 	$Ancora ."/plataforma/". $questoes['itemName'] ."/1?questao=true";
						$retorno['linkAtual'] 				= $retorno['linkQuestoes'];
					}

					if ( $video ) {
						$retorno['videoDuracao']				= $video['Duracao'];
						$retorno['videoPorcentagem']		= SaeDigital::make(BuscarPorcentagemVideo::class)->handle($UsuarioID, $agendamento['AssuntoID']);
						$retorno['videoAssistido']			= $this->formatarVideoAssistido($retorno['videoPorcentagem'], $duracaoTotalVideo);

						$retorno['linkVideo'] 				= 'curso/'. 	$Ancora ."/questao/". $video['itemName'] 	."/1";
						$retorno['linkAtual'] 				= $retorno['linkVideo'];
					}
					break;

				case TipoAgendamento::TRILHA:
				default:

					$retorno['questoesTotais']			= $questoes['QtdQuestoes'];
					$retorno['questoesAcertos']			= $questoes['QtdRespostaCorretas'];
					$retorno['questoesRespondidas']	= $questoes['QtdQuestoesRespondidas'];
					$retorno['questoesPorcentagem']	= (intval($questoes['QtdQuestoes']) == 0 ? 0 : intval( 100 * $questoes['QtdRespostaCorretas'] / $questoes['QtdQuestoes'] ));

					$retorno['videoDuracao']			  = !is_null($video) && is_null( $video['Duracao'] ) ? '00:00:00' : $video['Duracao'];
					$retorno['videoPorcentagem']		= SaeDigital::make(BuscarPorcentagemVideo::class)->handle($UsuarioID, $agendamento['AssuntoID']);
					$retorno['videoAssistido']			= $this->formatarVideoAssistido($retorno['videoPorcentagem'], $duracaoTotalVideo);

					$concluiuQuestoes 	= $questoes['QtdQuestoes'] == $questoes['QtdQuestoesRespondidas'];
					$concluiuRevisoes 	= $revisoes['QtdQuestoes'] == $revisoes['QtdQuestoesRespondidas'];
					$concluiuVideo 		= $retorno['videoPorcentagem'] >= $metaVideo;

					$mostrarRevisoes =
						$concluiuQuestoes
						&& ( $retorno['questoesPorcentagem']==0 || $retorno['questoesPorcentagem']<$meta )
						&& $retorno['videoPorcentagem']>=$metaVideo
					;

					if ( $mostrarRevisoes ){
						$retorno['revisoesTotais']			= $revisoes['QtdQuestoes'];
						$retorno['revisoesAcertos']			= $revisoes['QtdRespostaCorretas'];
						$retorno['revisoesRespondidas']	= $revisoes['QtdQuestoesRespondidas'];
						$retorno['revisoesPorcentagem'] = (intval($revisoes['QtdQuestoes']) == 0 ? 0 : intval( 100 * $revisoes['QtdRespostaCorretas'] / $revisoes['QtdQuestoes'] ));
					}

					$retorno['nota']					= max( $retorno['questoesPorcentagem'], $retorno['revisoesPorcentagem'] );

					$retorno['linkQuestoes'] 			= 'curso/'. 	$Ancora ."/questao/". $questoes['itemName'] ."/1?questao=true";
					$retorno['linkRevisoes'] 			= 'curso/'. 	$Ancora ."/revisao/". $revisoes['itemName'] ."/3?questao=true";
					$retorno['linkVideo'] 				= 'curso/'. 	$Ancora ."/questao/". $video['itemName'] 	."/1";

					$retorno['linkAtual']				= '';
					if ( !$concluiuQuestoes )			$retorno['linkAtual'] = $retorno['linkQuestoes'];
					else if ( !$concluiuVideo )			$retorno['linkAtual'] = $retorno['linkVideo'];
					else if ( $mostrarRevisoes && !$concluiuRevisoes ) 		$retorno['linkAtual'] = $retorno['linkRevisoes'];

					$questoes = $this->curso->studentQuestions($UsuarioID, false, $agendamento['AssuntoID']);
					if ($questoes[0]->questoesGeradas  != 8) {
						$coleta = $this->coletarDadosEstrutura($UsuarioID, $AgendamentoID);
					}
					break;
			}

			return $this->responseJson($retorno, 200);

		} catch (NotAllowedException $e) {
			return $this->responseJson([
				'success' => false,
				'message' => 'Você não tem permissão para acessar este conteúdo'
			], 403);
		}
	}

	/**
     * @param int $percentualAssistido
     * @param int $duracaoVideo
	 *
     * @return array
     */
	function formatarVideoAssistido ( $percentualAssistido, $duracaoTotalVideo ){
		$tempoAssistido = intval( $percentualAssistido * $duracaoTotalVideo / 100 );
		return gmdate('H:i:s', $tempoAssistido);
	}

	/**
	 * PONTO DE ATENÇÃO: CÓDIGO DUPLICADO, COPIADO DA CONTROLLER Curso
	 * Não foi possível reutilizar/importar
	 *
	 * Esses dois métodos foram copiados de forma inalterada, por enquanto
	 */
	public function coletarDadosEstrutura($itemNameAluno, $idAgendamento)
    {
        $this->layout = false;
        try {
			$this->load->library('Dadosrelatorio_lib');

			$agendamento 				= SaeDigital::make(BuscarAgendamentoPorId::class)->handle($idAgendamento);
			$disciplina 				= SaeDigital::make(PegaDisciplinaPeloId::class)->handle($agendamento['DisciplinaID']);
			$itemName = $this->session->userdata('pessoaid');
			$nomeAluno = $this->session->userdata('nome');
			$perfil = $this->session->userdata('perfil');
			$turma = (array) $this->session->userdata('teams')[0];
			$escola = (array) $this->session->userdata('school');

			$turmaId = $turma['id'];
			$escolaId = $escola['itemName'];

			$dadosUsuario 				= [
				'pessoaid'				=> $itemName,
				'perfilid' 				=> $perfil,
				'turmaid' 				=> $turmaId,
				'escolaid' 				=> $escolaId,
				'nomeAluno'				=> $nomeAluno,
				'descricaoPacote' 		=> $disciplina['Descricao'],
				'recalcularPercentual' 	=> null,
				'percentual' 			=> null
			];

			$dadosDisciplina 			= [
				'assuntoId' 			=> $agendamento['AssuntoID'],
				'disciplinaId' 			=> $agendamento['DisciplinaID'],
				'frenteId' 				=> $agendamento['FrenteID'],
				'exibeDisciplina' 		=> '1',
				'liberaQuestao' 		=> '1',
			];

			$result = $this->obterEstruturaQuestoes($dadosUsuario, $dadosDisciplina, false);

            return $result;
        } catch (Exception $e) {
            return $this->responseJson(['message' => $e->getMessage(), 'success' => false], 500);
        }
    }

	    /**
     * obterEstruturaQuestoes
     * Ajusta os dados de aluno e dagendamento para, no final, gerar a estrutura das questões
     * @param array $dadosUsuario
     * @param array $dadosDisciplina
     * @param bool $retornoAva opcional, true para fazer os retornos em html para o ava, false para retornar json para o app
     * @return    void
     */
    function obterEstruturaQuestoes($dadosUsuario, $dadosDisciplina, $retornoAva = true) {
			// Desacoplando os dados do usuário e da disciplina para variáveis locais desse método, a fim de literalmente não encostar na lógica de gerar estruturas das questões
			$pessoaid						= $dadosUsuario['pessoaid'];
			$perfilid 						= $dadosUsuario['perfilid'];
			$turmaid 						= $dadosUsuario['turmaid'];
			$escolaid 						= $dadosUsuario['escolaid'];
			$descricaoPacote 				= $dadosUsuario['descricaoPacote'];
			$recalcularPercentual 			= $dadosUsuario['recalcularPercentual'];
			$percentual 					= $dadosUsuario['percentual'];
			$assuntoId 						= $dadosDisciplina['assuntoId'];
			$disciplinaId 					= $dadosDisciplina['disciplinaId'];
			$frenteId 						= $dadosDisciplina['frenteId'];
			$exibeDisciplina 				= $dadosDisciplina['exibeDisciplina'];
			$liberaQuestao 					= $dadosDisciplina['liberaQuestao'];
			$paramVideo['disciplinaid'] 	= $assuntoId;
			$paramVideo['turmaid'] 			= $turmaid;
			$metaPercentual 				= 0;
			$metaQuestao 					= 0;
			$percentual 					= NULL;
			$recalcularPercentual 			= FALSE;
			$data['perfil'] 				= $perfilid;

			$bimestre = SaeDigital::make(PegaBimestrePeloId::class)->handle($frenteId);

			$configuracoes = $this->curso->getConfiguracoesescola($escolaid);
			//seta valores padrao caso a escola ainda nao tenha cadastrado as configura?oes
			if ($configuracoes && isset($configuracoes[0])) {
				$data['configuracoes'] = $configuracoes[0];
				unset($configuracoes[0]);
			}

			$turma = (array) $this->session->userdata('teams')[0];
			$array = $this->disciplina_lib->arrayAulas($disciplinaId, $assuntoId, $frenteId, false);
			$disciplina = SaeDigital::make(PegaDisciplinaPeloId::class)->handle($disciplinaId);

			$temVideo = false;
			foreach ($array['aulas'] as $keyx => $valuex) {
				if ($valuex['Tipo'] == 'N') {
					if ($valuex['Video'] == '') {
						if ( !$retornoAva ) {
							return ['success' => false, 'error' => 'Vídeo não encontrado'];
						}
					} else {
						$temVideo = true;
					}
				}
			}

			if ($perfilid == PERFIL_ALUNO) {
				$questao = [];
				$revisao = [];
				foreach ($array['aulas'] as $aula) {
					switch ($aula['Tipo']) {
					case 'Q':
						$questao = $this->curso->getQuestoesAula($disciplinaId, $aula['AulaID']);
						break;
					case 'R':
						$revisao = $this->curso->getQuestoesAula($disciplinaId, $aula['AulaID']);
					}

					$questoes = $this->curso->studentQuestions($pessoaid, $aula['Tipo'], $assuntoId);
					if (empty($questoes[0]->questoesGeradas)) {
						$descAssunto = $this->curso->verificaDisciplinas($disciplinaId, $aula['DisciplinaID'], $frenteId);
						switch ($aula['Tipo']) {
							case 'Q':
							case 'R':
								$this->dadosrelatorio_lib->insereQuestao($disciplinaId, $aula['AulaID'], $frenteId, $descricaoPacote, $descAssunto[0]['Descricao'], $aula, $metaQuestao, $dadosUsuario);
								break;
							case 'N':
								$this->dadosrelatorio_lib->insereVideo($disciplinaId, $aula['AulaID'], $frenteId, $descricaoPacote, $descAssunto[0]['Descricao'], $aula, $dadosUsuario);
								break;
						}
					}
        }

				if (!$temVideo && (count($questao) === 0 || count($revisao) === 0)){
					if ( !$retornoAva ) {
						return ['success' => false, 'error' => 'Questoes nao encontradas'];
					}
        }

				foreach ($configuracoes as $v) {
					if (isset($v['Serie']) && $v['Serie'] == $turma['grade_id']) {
						$metaPercentual = isset($v['Percentual']) ? $v['Percentual'] : 0;
						$metaQuestao = isset($v['Meta']) ? $v['Meta'] : 60;
					}
        }

				$array['percentualVideo'] = $this->curso->getTempoVideo($array);
      }

		  // verifica percentual das aulas:
      $param[0]['DisciplinaID'] = $assuntoId;
      $param[0]['Tipo'] = 'Q';
      $param[1]['Tipo'] = 'R';
      $this->load->model('disciplina_model');
      $array['reforco']['TotalReforco'] = count($this->disciplina_model->questoesReforco($param, $disciplinaId));

      $ordemAulas = ['Q', 'N', 'R'];
      usort($array['aulas'], function ($a, $b) use ($ordemAulas) {
        $pos_a = array_search($a['Tipo'], $ordemAulas);
        $pos_b = array_search($b['Tipo'], $ordemAulas);
        return $pos_a - $pos_b;
      });

      if ((int)$perfilid === Perfil::ALUNO) {
        $data['idAssunto'] = $assuntoId;
        $data['idDisciplina'] = $disciplinaId;
        $data['idBimestre'] = $frenteId;
        $data['idAluno'] = $pessoaid;
      }
      $array['disciplina'] = $disciplina;
		  /** @var BuscarAgendamentoPorTurmaAssunto $scheduleService */
      $scheduleService = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class);
      $schedules = $scheduleService->handle($turmaid, $assuntoId, $disciplinaId, $pessoaid, TipoAgendamento::TRILHA);
      $reviews = $scheduleService->handle($turmaid, $assuntoId, $disciplinaId, $pessoaid, TipoAgendamento::REFORCO);
      $metadata = [
        'hasSchedules' => count($schedules) > 0,
        'hasReviews' => count($reviews) > 0,
        'tipoAgendamento' => $tipoAgendamento
      ];

      if ($this->input->get('json') && filter_var($this->input->get('json'), FILTER_VALIDATE_BOOLEAN)) {
        $common = [
          'exibeDisciplina' => $exibeDisciplina,
          'liberaQuestao' => $liberaQuestao,
          'metaPercentual' => $metaPercentual,
          'percentual' => $percentual,
          'metaQuestao' => $metaQuestao,
          'metadata' => $metadata
        ];
        $json = array_merge($array, $common, $data, $bimestre);
        return $this->responseJson($json);
      }
			return ['success' => true, 'error' => ''];
    }
}
