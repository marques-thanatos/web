<?php

use Illuminate\Support\Collection;

use Ava\App\Services\QRCode\FetchQRCodeLink;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class QRCode extends CI_Controller {

	public $layout = false;
		
	/**
	 * 	Retorna o link vinculado a um QRCode
	 */
	public function getQRCodeLink($QRCode){

		$status = 404;
		$data = [ "success"=>false, "link" => "" ];

		$code = SaeDigital::make(FetchQRCodeLink::class)->handle($QRCode);

		if ( $code ){
			$status = 200;
			$data['success'] = true;
			$data['link'] = $code;
		}

		// Para o acesso direto não foi possível herdar da MY_Controller, por isso CI_Controller
		// CI_Controller não tem responseJson, por isso cabeçalhos setados aqui
        header('Content-Type: application/json');
        http_response_code( $status );
        echo json_encode( $data );
	}


}