<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Agendamento extends MY_Controller {

    public $layout = 'default';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    //public $css = array('bootstrap', '_reset', 'css-responsive', 'geral', 'messi', 'home') ;
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'curso.min', 'redactor.min', 'flowplayer-3.2.12.min', 'geral_v5', 'messi.min', 'home_v10.min', 'jquery.cookie');
    public $keywords = array('sae', 'home');

    public function __construct() {

        parent::__construct();

        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'home', 'mensagem');
        $this->css[] = $this->minify->getCSS('home_construct.min', $this->cssMinify, ENVIRONMENT);
        $this->load->model('curso_model', 'curso');

        if ($this->session->userdata('perfil') != 272 && $this->session->userdata('perfil') != 271) {//teste {
            header("Location: " . base_url());
            die('Somente perfil professor e coordenador podem realizar agendamento em massa ' . $this->session->userdata('perfil'));
        }

        //deve ser professor para realizar agendamento
        $configuracoes = $this->curso->getConfiguracoesescola($this->session->userdata('escola'));
        $configuracoes = $configuracoes[0];
        if ($configuracoes['AgendamentoDisciplinasLote'] != 'S') {
            header("Location: " . base_url());
            die('Parametro "AgendamentoDisciplinasLote" nao ativo para escola ');
        }
    }

    /**
     * index - [página principal área logada]
     *
     * Exibe a página inicial do usuário quando logado.
     *
     * @access	public
     * @return	void
     */
    public function index($turma = null) {
        $this->carregaOnLoad();
        $fields['Login'] = $this->session->userdata('login');
        $dados['turma_selecionada'] = $turma;

        $configuracoes = $this->curso->getConfiguracoesescola($this->session->userdata('escola'));
        $dados['configuracoes'] = $configuracoes[0];
        $dados['perfil'] = $this->session->userdata('perfil');

        //carrega turmas que o usuario possui
        $retornoDados = $this->home->verificaDisciplinas($fields, $this->configuracoes[0]['Base'], 'A');
        $categorias = array();

        $d = array();
        $retornoTurmas = array();
        foreach ($retornoDados as $arr => $disciplina) {
            if (isset($disciplina['Categoria'])) {
                $categorias[] = $disciplina['Categoria'];
            }

            if (isset($disciplina['Turma']) && !in_array($disciplina['Turma'], $d)) {
                $d[] = $disciplina['Turma'];
                $retornoTurmas[] = $disciplina;
            }
        }
        if (!empty($categorias) && empty($retornoTurmas)) {
            $retornoTurmas = array();
            $turmasCategoria = $this->home->verificaCategoriaTurmas(implode("','", $categorias));

            if ($turmasCategoria) {
                foreach ($turmasCategoria as $key => $value) {
                    $retornoTurmas[$value['itemName']]['DescricaoTurma'] = $value['Descricao'];
                }
            }
            $dados['turmasArrDiff'] = $retornoTurmas;
        }

        $dados['turmas'] = $retornoTurmas;

        //carrega disciplinas de cada turma
        $disciplinas = array();
        $turmasArr = array();

        if ($turma != '') {
            $disciplinas[] = $this->getDisciplinasDaTurma($turma);
            $turmasArr[] = $turma;
        }
        $dados['disciplinas'] = $disciplinas;
        $dados['turmaID'] = $turma;

        $this->load->view('agendamento', $dados);
    }

    //busca disciplinas de determinada turma
    private function getDisciplinasDaTurma($turma) {
        $serie = $this->home->verificaTurmas($turma);

        $grupoAula = array();
        $arrayGrupoAula = $this->home->verificaDisciplinaVigencia(null, $serie[0]['Vigencia'], $serie[0]['SerieID']);
        if ($arrayGrupoAula) {
            $grupoAula = array_merge($grupoAula, $arrayGrupoAula);
        }

        $disciplinasIDExclusivas = $this->home->getDisciplinasExclusivas($this->session->userdata('escola'), $serie[0]['SerieID']);

        if (!empty($disciplinasIDExclusivas)) {
            for ($i = 0; $i < count($disciplinasIDExclusivas); $i++) {
                $grupoAula2 = $this->home->buscaDisciplinasExclusivas($disciplinasIDExclusivas[$i]['DisciplinaID']);
                if (is_array($grupoAula2)) {
                    $grupoAula = is_array($grupoAula) ? array_merge($grupoAula, $grupoAula2) : $grupoAula2;
                }
            }
        }
//        $grupoAula['TurmaID'] = $turma;
//        var_dump($grupoAula);exit;
        return $grupoAula;
    }

    //carregamento de javascript e css
    private function carregaOnLoad() {
        $this->js[] = 'jquery.countdown.min';
        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'curso';
        $this->cssMinify[] = 'glyphicon';
        $this->cssMinify[] = 'datepicker';
        $this->css[] = $this->minify->getCSS('curso_index.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'bootstrap-datepicker';
        $this->load->helper('form_cursos');
    }

    function search($array, $key, $value) {

        if (!is_array($value)) {
            return;
        }

        $results = array();
        foreach ($value as $key2) {
            $this->search_r($array, $key, $key2, $results);
        }
        return $results;
    }

    function search_r($array, $key, $value, &$results) {
        if (!is_array($array)) {
            return;
        }

        if (isset($array[$key]) && $array[$key] == $value) {
            $results[] = $array;
        }

        foreach ($array as $subarray) {
            $this->search_r($subarray, $key, $value, $results);
        }
    }

    public function getAssuntosDisciplinaAjax($Ancora) {
        $this->load->model('curso_model', 'curso');
        $this->load->library('disciplina_lib');

        $configuracoes = $this->curso->getConfiguracoesescola($this->session->userdata('escola'));

        if ($configuracoes && isset($configuracoes[0])) {
            $data['configuracoes'] = $configuracoes[0];
            unset($configuracoes[0]);
        } else {
            $data['configuracoes']['QuestaoCoordenador'] = 'N';
            $data['configuracoes']['QuestaoProfessor'] = 'N';
            $data['configuracoes']['AgendaCoordenador'] = 'N';
            $data['configuracoes']['AgendaProfessor'] = 'N';
        }

        $data['perfil'] = $this->session->userdata('perfil');
        $data['turma'] = $this->input->post('turma');
        $data['Ancora'] = $Ancora;

        $grupoAula = $Ancora ? $this->home->verificaGrupoAulaAncora($Ancora) : '';

        if (!empty($grupoAula)) {
            $data['cursoNome'] = $grupoAula[0]['Descricao'];
            $data['grupoAulaID'] = $grupoAula[0]['itemName'];
            $data['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];

            $data['meta'] = $this->session->userdata('meta');

            $data['videoaulas'] = $this->disciplina_lib->arrayDisciplinas($data['grupoAulaID'], $data['turma']);

            if ($data['videoaulas']) {
                foreach ($data['videoaulas'] as $grid => $val) {
                    $data['qtdSemanas'] = count($val) - 1;
                }
            }

            $array['Ancora'] = $Ancora;
            $array['grupoAulaID'] = $grupoAula[0]['itemName'];
            $array['DescricaoPacote'] = utf8_encode($grupoAula[0]['Descricao']);
            $array['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];
            $array['TipoPDF'] = isset($grupoAula[0]['TipoPDF']) ? $grupoAula[0]['TipoPDF'] : 'L';
        }
        $this->session->set_userdata($array);

        $this->load->view('agendamento_assuntos', $data);
    }

}

/* End of file home.php */
/* Location: ./application/controllers/home.php */
