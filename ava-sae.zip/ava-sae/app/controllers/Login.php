<?php

use Ava\App\Services\Cadastro\UsuarioPrimeiroIDAtivo;
use Ava\App\Services\LivroDigital\BuscarAcessoLivroDigitalPorLogin;
use Ava\App\Services\Notificacoes\ListarNotificacoes;
use Ava\App\Services\Token\TokenApi;
use Ava\App\Services\Usuario\EnqueueDeletarUsuarioPortal;
use Ava\App\Services\Usuario\AceitarTermosUso;
use Ava\App\Services\Usuario\BuscarUsuarioPorItemName;
use Ava\App\Services\Usuario\ObterUsuarioNextAva;
use Ava\App\Support\Perfil;
use SebastianBergmann\Exporter\Exporter;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * http://example.com/index.php/welcome
     * - or -
     * http://example.com/index.php/welcome/index
     * - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     *
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public $layout = 'new-ava';

    public $title = 'AVA SAE';

    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.cookie');

    public $keywords = array('sae', 'login');

    public $configuracoes;

    public $sdb;

    public $menu_vertical = '';

    public function __construct()
    {
        parent::__construct();

        SaeDigital::make(\Ava\App\Services\Monitoramento\Sentry::class)->handle();

        $this->load->model('login_model', 'login');
        $this->load->model('cadastro_model', 'cadastro');
        $this->load->model('configuracoes_model', 'configuracoes');
        $this->load->model('acesso_model', 'acesso');
        $this->load->model('curso_model', 'curso');
        $this->load->helper('menu_helper');
        $this->load->helper('log_helper');

        $this->configuracoes = $this->configuracoes->configuracoes();

        $url = $this->uri->segment(1);

        if ($url == 'minhaConta') {
            $data['pagina'] = $url;
        } else {
            $data['pagina'] = 'login';
        }

        // configura??es do header
        $data['logo'] = 'logos/' . $this->configuracoes[0]['Logo'];
        $data['topo'] = isset($this->configuracoes[0]['ImagemTopo']) ? $this->configuracoes[0]['ImagemTopo'] : null;
        $data['fone'] = $this->configuracoes[0]['Telefone'];
        $data['site'] = $this->configuracoes[0]['id'];

        $this->header = $this->load->view('view_header', $data, true);
    }

    /**
     * index [?rea de autentifica??o usu?rio]
     *
     * Exibe a p?gina inicial de login.
     *
     * @access public
     * @return void
     */

    public function index()
    {
        if ($this->session->userdata('logado') &&
            $this->session->userdata('redirecionar')) {
                header("Location: /{$this->session->userdata('redirecionar')}");
        }

        $redirectTo = $this->input->get('redirect_to', null);

        if ($redirectTo) {
            $this->session->set_userdata('RedirectTO', $redirectTo);
        }

        $this->cssMinify[] = 'login';
        $this->css[] = $this->minify->getCSS('login_index' . $this->configuracoes[0]['id'] . '.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'login'; // para programar o arquivo voltar para login e quando versionar adicionar vers?o e executar min
        $this->load->view('login');
    }

    public function index_dev() {
        $this->cssMinify[] = 'login';

        $this->css[] = $this->minify->getCSS('login_index' . $this->configuracoes[0]['id'] . '.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'login'; // para programar o arquivo voltar para login e quando versionar adicionar vers?o e executar min

        $this->load->view('login2');
    }

    /**
     * Verifica acesso usu?rio login
     *
     * Verifica se o usu?rio e senha informados na tela incial
     * login s?o v?lidos, se acordo com o par?metro recebido via $_POST
     *
     * @access public
     * @param
     *            integer - Usuário informado.
     * @param
     *            integer - Senha informado.
     * @return int
     */
    public function verificaUsuario() {
        // $t0 -> tN = Variables to track time on external interactions
        $t0 = microtime(true);
        $this->layout = '';
        $resposta = new stdClass();
        $post = $this->input->post(NULL, TRUE);
        extract($post);
        $data = [ 'user' => $usuario, 'pwd' => $_POST['senha'], 'sso' => $_POST['sso'] ];
        $client = new \GuzzleHttp\Client();
        try {
            if ($sso == '') {
                $url = getenv('SAEAPIS_URL')."auth/login";
                $res = $client->post($url, [
                    'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
                    'body' => json_encode($data)
                ]);
            } else {
                $url = getenv('SAEAPIS_URL')."auth/sso-login";
                $res = $client->post($url, [
                    'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
                    'body' => json_encode($data)
                ]);
            }
        } catch( \GuzzleHttp\Exception\ServerException $e ) {
            $resposta->t1 = microtime(true) - $t0;
            $resposta->resposta = 2;
            print_r(json_encode($resposta));
            die;
        }
        $dadosLogin = json_decode($res->getBody());
        $token = $dadosLogin->token;
        $resposta->t1 = microtime(true) - $t0;
        setcookie('userToken',$token,time() + 2*7*24*60*60,'/');
        try {
            $userData = SaeDigital::make(ObterUsuarioNextAva::class)->handle($token);
        } catch( Exception $e ) {
            $resposta->resposta = 5;
            print_r(json_encode($resposta));
            die;
        }

        $resposta->t2 = microtime(true) - $t0;

        // dd($userData);
        $mixPanelData = [
            'login' => $userData->login,
            'name' => $userData->nome,
            'profile' => $userData->perfil,
            'scholl_name' => $userData->nomeEscola,
            'school_id' => $userData->escola,
            'email' => $userData->email,
            'id' => $userData->id
        ];

        $resposta->userData = $mixPanelData;

        if($userData || $this->session->userdata('logado')) {
            if($userData->termo_aceite == false) {
                $arrayDados = (array) $userData;
                $this->session->set_userdata('id', $arrayDados['id']);
                
                $resposta->t3 = microtime(true) - $t0;
                $resposta->resposta = -2;
                $resposta->redirect = 'TermoAceite';
                print_r(json_encode($resposta));
                die;
            } else {
                if($dadosLogin->first_login == true) {
                    $this->session->set_userdata('token', $token);
                    $this->session->set_flashdata('login', $userData->login);

                    $resposta->t3 = microtime(true) - $t0;
                    $resposta->resposta = 11;
                    $resposta->redirect = 'cadastro/cadDadosPrimeiroLogin/';
                    print_r(json_encode($resposta));
                    die;
                } else {
                    $resposta->resposta = 1;
                    $this->session->set_userdata('token', $token);
                    $this->session->set_userdata('login', $userData->login);

                    $resposta->t3 = microtime(true) - $t0;
                    $resposta->redirect = $userData->redirecionar;
                    $redirectTo = $userData->redirecionar;
                    $arrayDados = (array) $userData;
                    if($userData->perfil == Perfil::PROFESSOR || $userData->perfil  == Perfil::COORDENADOR) {
                        setcookie('itemName', $userData->pessoaid,time() + 2*7*24*60*60,'/','sae.digital', false);
                        setcookie('escola', $userData->nomeEscola,time() + 2*7*24*60*60,'/','sae.digital', false);
                        setcookie('escolaid',$arrayDados['school']->itemName,time() + 2*7*24*60*60,'/','sae.digital', false);
                        setcookie('perfil',$userData->perfil,time() + 2*7*24*60*60,'/','sae.digital', false);
                    }
                    $this->session->set_userdata('RedirectTO', $redirectTo);
                    $this->session->set_userdata($arrayDados);
                    $this->session->set_userdata('escola', $arrayDados['school']->itemName);
                    $this->session->set_userdata('Serie', $arrayDados['teams'][0]->grade_id);
                    $this->session->set_userdata('logado', TRUE);

                    $log['loginid'] = $this->session->userdata['pessoaid'];
                    $log['login'] = $this->session->userdata['login'];
                    $log['acao'] = 'Logou no sistema';
                    $log['nomeescola'] = utf8_encode($this->session->userdata['nomeEscola']);
                    $log['escola'] = utf8_encode($this->session->userdata['escola']);
                    $log['codigo'] = '1'; //Login

                    $this->load->model('Log_model', 'logacesso');

                    $this->logacesso->GravaLog($log);
                    
                    print_r(json_encode($resposta));
                    die;
                }
            }
        }




        /*
        $retornoLogin = $this->login->verificaLogin($fields, $this->configuracoes[0]['Base'], $this->configuracoes[0]['id']);

        $redirectTo = $this->input->get('redirect_to', null);

        if ($redirectTo) {
            $this->session->set_userdata('RedirectTO', $redirectTo);
        }

        if (!$retornoLogin) {
            $resposta->resposta = 2;
            print_r(json_encode($resposta));
            die;
        }

        $AnoVigenciaLogin = explode('-', $retornoLogin[0]['DtCad']);
        $anoAtual = date('Y');
        $perfilLogin = $retornoLogin[0]['Perfil'];
        if ($AnoVigenciaLogin[0] < $anoAtual && ($perfilLogin != 268 && $perfilLogin != 269)) {
            $resposta->resposta = 2;
        } else if ($AnoVigenciaLogin[0] == $anoAtual || ($perfilLogin == 268 || $perfilLogin == 269)) {
            if (isset($retornoLogin[0]['UsuarioCad']))
                $criador = $this->login->RetornaCriador($retornoLogin[0]['UsuarioCad']);

            if ($retornoLogin) {
                if (isset($retornoLogin[0]['Escola']) && $retornoLogin[0]['Perfil'] != 268) {

                    $escolaID = $retornoLogin[0]['Escola'];
                    $escola = $this->login->getDadosEscola($escolaID);

                    if ($escola[0]['Situacao'] != 'A') {
                        $resposta->resposta = -1;
                        print_r(json_encode($resposta));
                        die;
                    }
                }


                if (isset($retornoLogin[0]['Senha']) && trim($retornoLogin[0]['Senha']) == trim(md5($senha)) || trim($this->configuracoes[0]['SenhaMaster']) == trim(md5($senha)) || isset($logado)) {

					if ( !$retornoLogin[0]['TermoAceite'] && in_array($retornoLogin[0]['Perfil'], [Perfil::ALUNO, Perfil::RESPONSAVEL]) ) {
						$resposta->resposta = -2;
						$resposta->redirect = 'TermoAceite';
						print_r(json_encode($resposta));
						die;
					}

					if ( isset($retornoLogin[0]['PrimeiroLogin']) && $retornoLogin[0]['PrimeiroLogin'] == 'S') {
						$this->session->set_flashdata('login', $fields['usuario']);
						$resposta->resposta = 11;
						$resposta->redirect = 'cadastro/cadDadosPrimeiroLogin/';
						print_r(json_encode($resposta));
						die;
					}

                    // Verifica se a senha informada corresponde a senhaMaster
                    $senhaMaster = 'N';
                    if (trim($this->configuracoes[0]['SenhaMaster']) == trim(md5($senha))) {
                        if (in_array($retornoLogin[0]['Perfil'], [Perfil::ADMIN, Perfil::CONTEUDO]) && getenv('CI_ENV') !== 'dev') {
                            $resposta->resposta = 3;
                            print_r(json_encode($resposta));
                            die;
                        }

                        $senhaMaster = 'S';
                    }

                    $acessoLD = SaeDigital::make(BuscarAcessoLivroDigitalPorLogin::class)->handle(
                        $retornoLogin[0]['Login'],
                        $retornoLogin[0]['Perfil']
                    );

                    $redirecionar = isset($retornoLogin[0]['Redirecionar']) ? $retornoLogin[0]['Redirecionar'] : '';
                    $escolaid = isset($retornoLogin[0]['Escola']) ? $retornoLogin[0]['Escola'] : '';
                    if (isset($retornoLogin[0]['Perfil']) && $retornoLogin[0]['Perfil'] == Perfil::ESCOLA) {
                        $escolaid = (isset($retornoLogin[0]['itemName'])) ? $retornoLogin[0]['itemName'] : '';
                    }

                    if($retornoLogin[0]['Perfil'] == Perfil::PROFESSOR || $retornoLogin[0]['Perfil'] == Perfil::COORDENADOR) {
                        setcookie('itemName',$retornoLogin[0]['itemName'],time() + 2*7*24*60*60,'/','sae.digital', false);
                        setcookie('escola',$escola[0]['Nome'],time() + 2*7*24*60*60,'/','sae.digital', false);
                        setcookie('escolaid',$escolaid,time() + 2*7*24*60*60,'/','sae.digital', false);
                        setcookie('perfil',$retornoLogin[0]['Perfil'],time() + 2*7*24*60*60,'/','sae.digital', false);
                    }

                    $senhaAluno = 'S';
                    if ($escolaid) {
                        $configEscola = $this->login->verificaConfigEscola($escolaid);
                        $senhaAluno = (!isset($configEscola[0]['SenhaAluno']) || (isset($configEscola[0]['SenhaAluno']) && $configEscola[0]['SenhaAluno'] == '')) ? 'N' : $configEscola[0]['SenhaAluno'];
                    }

                    $notificacoes = SaeDigital::make(ListarNotificacoes::class)->handle(
                        $retornoLogin[0]['Login'], $escolaid
                    );

                    $jwtToken = $this->getJwtToken($retornoLogin[0]['Login'], $retornoLogin[0]['Senha']);

                    $userFirstId = SaeDigital::make(UsuarioPrimeiroIDAtivo::class)->handle($retornoLogin[0]['Login']);
                    $pessoaid = $retornoLogin[0]['itemName'];


                    if (count($userFirstId)) {
                        $pessoaid = $userFirstId['itemName'];
                    }

                    if (isset($criador[0]['Login'])) {
                        $newdata = [
                            'jwtToken' => $jwtToken,
                            'usuario' => isset($retornoLogin[0]['Email']) ? $retornoLogin[0]['Email'] : '',
                            'nome' => isset($retornoLogin[0]['Nome']) ? $retornoLogin[0]['Nome'] : '',
                            'pessoaid' => $pessoaid,
                            'manterconectado' => (isset($conectado) && $conectado == 'true') ? 31536000 : 0,
                            'SM' => $senhaMaster,
                            'redirecionar' => isset($retornoLogin[0]['Redirecionar']) ? $retornoLogin[0]['Redirecionar'] : '',
                            'perfil' => $retornoLogin[0]['Perfil'],
                            'id' => $retornoLogin[0]['id'],
                            'login' => $retornoLogin[0]['Login'],
                            'nomeEscola' => $escola[0]['Nome'],
                            'escola' => $escolaid,
                            'acessoLD' => $acessoLD,
                            'senhaAluno' => $senhaAluno,
                            'ExibeMenuLD' => $acessoLD,
                            'logado' => TRUE,
                            'criador' => $criador[0]['Login'],
                            'id_erp' => $retornoLogin[0]['id_erp'],
                            'versao_conteudo_id' => $this->cadastro->getSchoolContentVersion($escolaid),
                            'notificacoes' => $notificacoes,
                            'termo_aceite' => $retornoLogin[0]['TermoAceite']
                        ];
                    } else {
                        $newdata = array(
                            'jwtToken' => $jwtToken,
                            'usuario' => isset($retornoLogin[0]['Email']) ? $retornoLogin[0]['Email'] : '',
                            'nome' => isset($retornoLogin[0]['Nome']) ? $retornoLogin[0]['Nome'] : '',
                            'pessoaid' => $pessoaid,
                            // 'QtdAcesso' => $retornoLogin[0]['QtdAcesso'],
                            'manterconectado' => (isset($conectado) && $conectado == 'true') ? 31536000 : 0,
                            'SM' => $senhaMaster,
                            'redirecionar' => isset($retornoLogin[0]['Redirecionar']) ? $retornoLogin[0]['Redirecionar'] : '',
                            'perfil' => $retornoLogin[0]['Perfil'],
                            'id' => $retornoLogin[0]['id'],
                            'login' => $retornoLogin[0]['Login'],
                            'nomeEscola' => $escola[0]['Nome'],
                            'escola' => $escolaid,
                            'acessoLD' => $acessoLD,
                            'senhaAluno' => $senhaAluno,
                            'ExibeMenuLD' => $acessoLD,
                            'logado' => TRUE,
                            'id_erp' => $retornoLogin[0]['id_erp'],
                            'versao_conteudo_id' => $this->cadastro->getSchoolContentVersion($escolaid),
                            'notificacoes' => $notificacoes,
                            'termo_aceite' => $retornoLogin[0]['TermoAceite']
                        );
                    }



                    if (isset($escolaid) && ($newdata['redirecionar'] == 'professor' || $newdata['redirecionar'] == 'coordenador')) {
                        $this->load->model('notificacoes_model', 'notificacao');
                        $configuracoes = $this->notificacao->getConfiguracoes($escolaid);
                        $notificacaoresponsavel = isset($configuracoes[0]['NotificacaoResponsavel']) ? $configuracoes[0]['NotificacaoResponsavel'] : 'N';
                        $newdata['notificacaoresponsavel'] = $notificacaoresponsavel;
                    }

                    $this->session->set_userdata($newdata);

                    // Verifica se o usu?rio n?o possui acesso simult?neo com o mesmo login (PessoaPerfilID)
                    if ($this->session->userdata('SM') != 'S')
                        $this->load->library('acesso_lib');

                    if ($retornoLogin[0]['Perfil'] == 290) {
                        $resposta->resposta = 4;
                        $resposta->redirect = $redirecionar;
                        print_r(json_encode($resposta));
                        die;
                    }
                    if ($retornoLogin[0]['Perfil'] == 291) {
                        $resposta->resposta = 500;
                        $resposta->redirect = $redirecionar;
                        print_r(json_encode($resposta));
                        die;
                    }

                    // pcc - pergunta continua conex?o
                    if ($this->session->userdata('pcc') == 'S') {
                        $resposta->resposta = 10;
                    } else {
                        $this->session->set_userdata('situacaoSessao', 'A');

                        //$log['loginid'] = $this->session->userdata['id'];
                        $log['loginid'] = $this->session->userdata['pessoaid'];
                        $log['login'] = $this->session->userdata['login'];
                        $log['acao'] = 'Logou no sistema';
                        $log['nomeescola'] = utf8_encode($this->session->userdata['nomeEscola']);
                        $log['escola'] = utf8_encode($this->session->userdata['escola']);
                        $log['codigo'] = '1'; //Login

                        $this->load->model('Log_model', 'logacesso');

                        $this->logacesso->GravaLog($log);

                        $resposta->resposta = 1;
                        $resposta->redirect = $redirecionar;
                    }

                } else {
                    $resposta->resposta = 3;
                }
            } else {
                $resposta->resposta = 2;
            }
        }


        */
        if (stripos(@$_SERVER['HTTP_REFERER'], 'www.aprovaconcursos.com.br') || stripos(@$_SERVER['HTTP_REFERER'], 'lab.iesde.com.br') || stripos(@$_SERVER['HTTP_REFERER'], 'www.portalava.com.br')
        || stripos(@$_SERVER['HTTP_REFERER'], 'academy.mundopm.com.br')) {

        if ($resposta->resposta == 10) {
            $this->logoutControleAcesso('S');
            $this->session->set_userdata('situacaoSessao', 'A');
        }
        header('Location: http://ava.aprovaconcursos.com.br/');

    } else {
        $redirectToOpenIssue = $this->input->get('redirect_to', null);

        if (isset($avasae)) {
            die('<script>window.location = "/' . $redirecionar . '"</script>');
        } else {
            print_r(json_encode($resposta));
        }
    }
    }

    public function loginNextAva() {
        $user = $this->input->post('user');
        $pass = $this->input->post('pwd');

        $body['user'] = $user;
        $body['pwd'] = $pass;

        $data = array(
            'user' => $user,
            'pwd' => $pass
         );

        $client = new \GuzzleHttp\Client();

        $url = getenv('SAEAPIS_URL')."auth/login";

        $res = $client->post($url, [
            'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
             'body' => json_encode($data)
            ]);

        $token = json_decode($res->getBody())->token;
        print_r($token);
}

    public function retornarUserFromItemName() {
        $itemName = $this->input->get('itemName');
        
        header('Content-Type: application/json');
        http_response_code(200);

        $this->layout = false;
        $login = SaeDigital::make(BuscarUsuarioPorItemName::class)->handle($itemName)['Login'];

        if(!$login){
            $userData = SaeDigital::make(ObterUsuarioNextAva::class)->handle('', $itemName);
            $login = $userData->login;
        }

        echo json_encode(array('user'=> $login));
    }

    /**
     * Verifica acesso usu?rio login externo
     *
     * Verifica se o usu?rio e senha informados na tela incial
     * login s?o v?lidos, se acordo com o par?metro recebido via $_POST
     *
     * @access    public
     * @param integer - Usu?rio informado.
     * @param integer - Senha informado.
     * @return    int
     */
    public function verificaUsuarioexterno() {
        $this->layout = '';

        $post = $this->input->post(null, true);
        extract($post);
        if ((isset($usuario) && $usuario != '') && (isset($senha) && $senha != '')) {
            $fields['usuario'] = trim($usuario);
            $fields['senha'] = md5($senha);

            $resposta = new stdClass();

            $retornoLogin = $this->login->verificaLogin($fields, $this->configuracoes[0]['Base'], $this->configuracoes[0]['id']);

            if ($retornoLogin) {
                $escolaID = (isset($retornoLogin[0]['Escola'])) ? $retornoLogin[0]['Escola'] : null;
                if ($escolaID != null) {
                    $escola = $this->login->getDadosEscola($escolaID);
                }

                if ($escolaID == null || $escola[0]['Situacao'] == 'A') {
                    if (trim(@$retornoLogin[0]['Senha']) == trim(md5($senha)) || trim($this->configuracoes[0]['SenhaMaster']) == trim(md5($senha)) || isset($logado)) {
                        // Verifica se a senha informada corresponde a senhaMaster
                        $senhaMaster = 'N';
                        if (trim($this->configuracoes[0]['SenhaMaster']) == trim(md5($senha)))
                            $senhaMaster = 'S';

                        // Cria sess?o
                        $redirecionar = @$retornoLogin[0]['Redirecionar'];

                        $acessoLD = $this->login->verificaAcessoLD($escolaID);

                        $acessoLD = (!isset($acessoLD[0]['AcessoLD']) || (isset($acessoLD[0]['AcessoLD']) && ($acessoLD[0]['AcessoLD'] == ''))) ? 'N' : $acessoLD[0]['AcessoLD'];

                        $acessoMenuLDSerie = ($acessoLD == 'S') ? 'S' : 'N';

                        $userFirstId = SaeDigital::make(UsuarioPrimeiroIDAtivo::class)->handle($retornoLogin[0]['Login']);
                        $pessoaid = $retornoLogin[0]['itemName'];

                        if (count($userFirstId)) {
                            $pessoaid = $userFirstId[0]['itemName'];
                        }

                        $escolaid = @$retornoLogin[0]['Perfil'] == 269 ? @$retornoLogin[0]['id'] : @$retornoLogin[0]['Escola'];
                        $newdata = array(
                            'usuario' => @$retornoLogin[0]['Email'],
                            'nome' => @$retornoLogin[0]['Nome'],
                            'pessoaid' => $pessoaid,
                            'manterconectado' => (@$conectado == 'true') ? 31536000 : 0,
                            'SM' => $senhaMaster,
                            'redirecionar' => @$retornoLogin[0]['Redirecionar'],
                            'perfil' => $retornoLogin[0]['Perfil'],
                            'id' => $retornoLogin[0]['id'],
                            'login' => $retornoLogin[0]['Login'],
                            'escola' => $escolaid,
                            'logado' => TRUE,
                            'acessoLD' => $acessoLD,
                            'ExibeMenuLD' => $acessoMenuLDSerie,
                            'id_erp' => $retornoLogin[0]['id_erp'],
                            'versao_conteudo_id' => $this->cadastro->getSchoolContentVersion($escolaid)
                        );

                        $this->session->set_userdata($newdata);
                        $this->session->set_userdata('situacaoSessao', 'A');
                        $resposta->resposta = 1;
                        $resposta->redirect = $redirecionar;

                    } else {
                        $data['resposta'] = 3;
                    }
                } else {
                    $data['resposta'] = -1;
                }

            } else {
                $data['resposta'] = 2;
            }
        } else {
            $data['resposta'] = 4;
        }

        if (isset($resposta->resposta) && $resposta->resposta == 1) {
            redirect($redirecionar);
        } else {

            //retorna para o login
            $this->layout = 'default';
            $this->cssMinify[] = 'login';
            $this->css[] = $this->minify->getCSS('login_index' . $this->configuracoes[0]['id'] . '.min', $this->cssMinify, ENVIRONMENT);
            $this->js[] = 'login'; //para programar o arquivo voltar para login e quando versionar adicionar vers?o e executar min

            $this->load->view('login', $data);
        }
	}

	public function verificaPermissaoAcessoUsuario() {

        $this->layout = '';

        $this->session->set_userdata('VPM', 'S'); // Verifica permiss?o Usu?rio
        $resposta = 0;
        // Verifica se o usu?rio n?o possui acesso simult?neo com o mesmo login (PessoaPerfilID)
        if ($this->session->userdata('SM') != 'S')
            $this->load->library('acesso_lib');

        $this->session->set_userdata('VPM', 'N'); // Verifica permiss?o Usu?rio
        // pcc - pergunta continua conex?o
        if ($this->session->userdata('situacaoSessao') == 'I')
            $resposta = 10;

        exit(print_r($resposta));

    }

    /**
     * Sair
     *
     * Destr?i a sess?o do usu?rio
     * retornando para tela de login
     *
     * @access public
     * @return void
     */
    public function sair() {
        unset($_COOKIE['userToken']);
        setcookie('userToken','',time() - 3600);
        setcookie('userToken','',time() - 3600,'/','sae.digital', false);


        if($this->session->userdata('perfil') == Perfil::PROFESSOR || $this->session->userdata('perfil') == Perfil::COORDENADOR) {
            unset($_COOKIE['perfil']);
            setcookie('perfil','',time() - 3600);
            setcookie('perfil','',time() - 3600,'/','sae.digital', false);

            unset($_COOKIE['escola']);
            setcookie('escola','',time() - 3600);
            setcookie('escola','',time() - 3600,'/','sae.digital', false);

            unset($_COOKIE['escolaid']);
            setcookie('escolaid','',time() - 3600);
            setcookie('escolaid','',time() - 3600,'/','sae.digital', false);

            unset($_COOKIE['itemName']);
            setcookie('itemName','',time() - 3600);
            setcookie('itemName','',time() - 3600,'/','sae.digital', false);

            setcookie('logout','do_logout',time() + 2*7*24*60*60,'/','sae.digital', false);
        }

        if (isset($this->session->userdata['login']) && $this->uri->segment(1) == 'sair') {
            $log['loginid'] = $this->session->userdata['pessoaid'];
            $log['login'] = $this->session->userdata['login'];
            $log['acao'] = 'Deslogou do sistema';
            $log['nomeescola'] = utf8_encode($this->session->userdata['nomeEscola']);
            $log['escola'] = utf8_encode($this->session->userdata['escola']);
            $log['codigo'] = '2'; //Deslogar
            $this->load->model('Log_model', 'logacesso');
            $this->logacesso->GravaLog($log);
        }
        $this->session->sess_destroy();
        $this->index();
    }

    /**
     * Definir senha
     *
     * Exibe a tela de altera??o de senha.
     *
     * @access public
     * @return void
     */
    function minhaConta() {

        $token = $this->session->token;

        $userData = SaeDigital::make(ObterUsuarioNextAva::class)->handle($token);

        $data['userData'] = $userData;

        $this->load->view('minhaConta', $data);
    }

    /**
     * Esqueci Senha
     *
     * verifica se o e-mail informado realment existe na base de dados
     *
     * @access public
     * @return int
     */
    function esqueciSenha() {
        $this->layout = '';
        $post = $this->input->post(NULL, TRUE);
        extract($post);
        $fields['usuario'] = (isset($login)) ? trim($login) : '';
        $existeUsuario = $this->login->esqueciSenha($fields);
        // se obter valor atualizaSenha
        if (!empty($existeUsuario)) {
            if ($existeUsuario[0]['Perfil'] == 273) {
                $configEscola = $this->login->verificaConfigEscola($existeUsuario[0]['Escola']);
                if ($configEscola[0]['SenhaAluno'] == 'N') {
                    exit(print(55)); // nao permite alterar senha
                }
            }
            if (!empty($existeUsuario[0]['Email'])) {
                $id = $this->iesdeuuid->getIdRandom();

                $dados = array(
                    'Codigo' => base64_encode($fields['usuario']),
                    'Data_Expira' => date('Y-m-d H:i:s', strtotime('+1 day')),
                    'Situacao' => 'A'
                );
                $this->load->model('cadastro_model', 'cadastro');
                $insert = $this->cadastro->salvaDados('D033_Ava_Sae_RecuperarSenha', $id, $dados, TRUE);

                if ($insert) {
                    if ($this->_enviaConfirmacao($existeUsuario[0]['Email'], $id)) {
                        print(33); // enviado email com link para alterar a senha
                        die();
                    } else {
                        print(44); // erro ao enviar email
                        die();
                    }
                }
            } else {
                print(22); // login nao tem email
                die();
            }
        } else {
            print(11); // Login nao encontrado
            die();
        }
    }

    function markAcceptTerm() {
        $this->layout = '';
        $post = $this->input->post(NULL, TRUE);
        extract($post);
        $fields['usuario'] = (isset($login)) ? trim($login) : '';
        $existeUsuario = $this->login->esqueciSenha($fields);
        // se obter valor atualizaSenha
        if (!empty($existeUsuario)) {
            if ($existeUsuario[0]['Perfil'] == 273) {
                $configEscola = $this->login->verificaConfigEscola($existeUsuario[0]['Escola']);
                if ($configEscola[0]['SenhaAluno'] == 'N') {
                    exit(print(55)); // nao permite alterar senha
                }
            }
            if (!empty($existeUsuario[0]['Email'])) {
                $id = $this->iesdeuuid->getIdRandom();
                $dados = array(
                    'Codigo' => base64_encode($fields['usuario']),
                    'Data_Expira' => date('Y-m-d H:i:s', strtotime('+1 day')),
                    'Situacao' => 'A'
                );
                $this->load->model('cadastro_model', 'cadastro');
                $insert = $this->cadastro->salvaDados('D033_Ava_Sae_RecuperarSenha', $id, $dados, TRUE);

                if ($insert) {
                    if ($this->_enviaConfirmacao($existeUsuario[0]['Email'], $id)) {
                        print(33); // enviado email com link para alterar a senha
                        die();
                    } else {
                        print(44); // erro ao enviar email
                        die();
                    }
                }
            } else {
                print(22); // login nao tem email
                die();
            }
        } else {
            print(11); // Login nao encontrado
            die();
        }
    }

    /**
     * Atualiza senha
     *
     * Atualiza a nova senha do usuario
     *
     * @access public
     * @return int
     */
    public function atualizaSenha()
    {
        $this->layout = '';
        $id = $this->input->post('id');
        $email = $this->input->post('email');
        $senha = $this->_geraSenha();
        $atualiza = $this->login->atualizaSenha($id, md5($senha));
        if (count($atualiza) == 0) {
            print(0);
            die;
        } else {
            if ($this->_enviaConfirmacao($senha, $email)) {
                print(1);
                die;
            } else {
                print(2);
                die;
            }
        }
    }

    /**
     * Atualiza informacoes da conta do usuario
     *
     *
     * @access public
     * @return int
     */
    public function atualizaMinhaConta($codigo = '')
    {
        $this->layout = '';
        $senha = $this->input->post('senha');
        $email = $this->input->post('email');

        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            print(3);
            die;
        }

        if (empty($codigo)) {
            print(0);
            die;
        }

        $result = 0;
        if ($this->session->has_userdata('login')) {
            //$fields['usuario'] = trim($this->session->userdata('login'));
            $login = $this->session->userdata('login'); //$this->login->esqueciSenha($fields);
        } else if (!empty($codigo)) {
            $resultado = $this->login->buscaRecuperaSenha(base64_decode($codigo));

            if (!empty($resultado)) {
                $login = base64_decode($resultado[0]['Codigo']);
            } else {
                die(0);
            }
        }

        $usuario = $this->login->getUsuario($this->session);

        $dados['EmailBounced'] = $usuario['EmailBounced'];

        if (!empty($email) && $usuario['Email'] != $email) {
            $dados['EmailBounced'] = 'N';
            $dados['Email'] = $email;
        }

        $logins = $this->login->verificaTodosLogins($login);
        $dados['Senha'] = md5($senha);

        foreach ($logins as $key => $value) {
            $result = $this->login->atualizaSenha($value['id'], $dados);
        }
        if (!empty($codigo)) {
            $D033['Situacao'] = 'I';
            $result = $this->login->atualizaRecuperarSenha(base64_decode($codigo), $D033);
        }

        SaeDigital::make(EnqueueDeletarUsuarioPortal::class)->handle($login);

        print($result);
        die();
    }
    //$result = $this->login->atualizaDados('D019_Ava_Sae', $value['id'], $dados,$replace=TRUE);
    public function atualizaEmailSenha($codigo = '')
    {
        $this->layout = '';
        $senha = $this->input->post('senha');
        $email = $this->input->post('email');

        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            print(3);
            die;
        }

        if (empty($codigo)) {
            print(0);
            die;
        }

        $result = 0;
        if ($this->session->has_userdata('login')) {
            //$fields['usuario'] = trim($this->session->userdata('login'));
            $login = $this->session->userdata('login'); //$this->login->esqueciSenha($fields);
        } else if (!empty($codigo)) {
            $resultado = $this->login->buscaRecuperaSenha(base64_decode($codigo));

            if (!empty($resultado)) {
                $login = base64_decode($resultado[0]['Codigo']);
            } else {
                die(0);
            }
        }

        $usuario = $this->login->getUsuario($this->session);

        $logins = $this->login->verificaTodosLogins($login);
        $dados['Senha'] = md5($senha);
        $dados['Email'] = $email;

        foreach ($logins as $key => $value) {
            $result = $this->login->atualizaDados('D019_Ava_Sae', $value['id'], $dados,$replace=TRUE);
        }
        if (!empty($codigo)) {
            $D033['Situacao'] = 'I';
            $result = $this->login->atualizaRecuperarSenha(base64_decode($codigo), $D033);
        }

        SaeDigital::make(EnqueueDeletarUsuarioPortal::class)->handle($login);

        print($result);
        die();
    }
    /**
     * Atualiza o email do usuário
     *
     *
     * @access public
     * @return int
     */
    public function atualizaEmail()
    {
        $this->layout = "";
        header('Content-Type: application/json');

        $emailToTest = $this->input->post('email');

        $login = $this->session->userdata("login");

        $email = $this->login->verifyEmailExists($login, $emailToTest);

        if ($email) {

            $response = [
                "success" => FALSE,
                "email" => $email,
                "Message" => "Este e-mail já esta sendo usado por outra pessoa",
                "icon" => "error"
            ];

        } else {

            $this->login->updateEmail($login, $emailToTest);

            $response = [
                "success" => TRUE,
                "email" => $email,
                "Message" => "O email foi alterado",
                "icon" => "success"
            ];

        }

        exit(json_encode($response));
    }

    /**
     * Gera senha
     *
     * Gera a nova senha temporaria
     *
     * @access public
     * @return int
     */
    public function _geraSenha()
    {
        $novo_valor = "";
        $valor = "abcdefghijklmnopqrstuvwxyz0123456789";
        srand((double)microtime() * 1000000);

        for ($i = 0; $i < 6; $i++) {
            $novo_valor .= $valor[rand() % strlen($valor)];
        }

        return $novo_valor;
    }

    /**
     * Envia confirma??o
     *
     * Envia e-mail confirmando a nova altera??o de senha
     *
     * @param
     *            int #senha Nova senha do usu?rio
     * @param string $email
     *            E-mail do usu?rio
     * @access public
     * @return int
     */
    public function _enviaConfirmacao($email, $codigo)
    {
        $this->layout = "";

        $mensagem = "Para alterar a senha acesse o link " . base_url() . "minhaConta/" . base64_encode($codigo);

        $this->load->library('email');

        $config['mailtype'] = 'html';
        $config["protocol"] = "smtp";
        $config["smtp_host"] = "email-smtp.us-east-1.amazonaws.com";
        $config["smtp_user"] = "AKIAJNXZILPPXXEHLEOQ";
        $config["smtp_pass"] = "AuSMfzWOmEwDOqqXPWve841xEkdTSsEPChwuuNnqNZQJ";
        $config['smtp_crypto'] = 'ssl';
        $config["charset"] = "UTF-8";
        $config["smtp_port"] = "465";
        $config["priority"] = "1";
        $config['validate'] = TRUE;
        $config['wordwrap'] = TRUE;

        $this->email->initialize($config);
        $this->email->from("naoresponda@saedigital.com.br");

        if (ENVIRONMENT == 'development') {
            $this->email->to("contato@saedigital.com.br");
        } else {
            $this->email->to($email);
        }

        $this->email->subject("Senha do site http://ava.sae.digital");
        $this->email->message($mensagem);
        $this->email->set_newline("\r\n");

        if ($this->email->send())
            return true;
        else
            return false;
    }

    /**
     * Logout Controle Acesso
     *
     * Verifica se o usu?rio quer continuar conectado ou cancelar conex?o, quando h? acessos m?ltiplos
     *
     * @param string $resposta
     *            tipo de instru??o que o usu?rio deseja realizar
     * @access public
     * @return int
     */
    public function logoutControleAcesso()
    {
        header('Content-Type: application/json');
        $this->layout = '';
        $this->load->model('login_model');
        $mySessionId = session_id();
        $opcao = $this->input->post('resposta');

        try {

            // We delete all the other sessions, and login the user
            if ($opcao == "S") {
                // In this case $_SESSION["id"] is id on table D019
                $this->login_model->deleteSessions(
                    $_SESSION["id"],
                    $mySessionId
                );

            } else {
                // Or delete the user current session and login him
                $this->login_model->deleteMySession($mySessionId);

            }

            $response = [
                "success" => TRUE,
                "redirecionar" => $_SESSION["redirecionar"]
            ];

        } catch (Exception $e) {
            $response = [
                "message" => $e->getMessage(),
                "success" => FALSE
            ];
        }

        exit(json_encode($response));
    }

    public function QtdAcesso()
    {
        $atualiza = $this->input->post('atualiza');
        $this->session->set_userdata('QtdAcesso', '3');

        if ($atualiza) {
            $arrayAcesso = array(
                'QtdAcesso' => 3
            );
            $this->login->atualizaDados('D019_Ava_Sae', $retornoLogin[0]['id'], $arrayAcesso);
        }
    }

    public function cadDadosPrimeiroLogin($login = null) {

        $this->load->model('cadastro_model', 'cadastro');
        $this->js[] = 'primeiroLogin';
        $this->css[] = $this->minify->getCSS('cadastro_login.min', $this->cssMinify, ENVIRONMENT);

        $login = base64url_decode($login);

        $data['dados'] = $this->cadastro->getDados(null, null, 'A', null, $login);
        $data['edit'] = 1;
        $this->load->view('primeiroLogin', $data);
    }

    public function cleanSessions()
    {
        $this->layout = FALSE;

        $token = $this->input->post('token');

        if ($token !== CLEAN_SESSION_TOKEN) {
            $this->echoWithDate("O token inserido é inválido");
            exit();
        }

        $inactiveSessions = $this->acesso->countInactiveSessions();

        if ($inactiveSessions) {

            $this->echoWithDate("$inactiveSessions sessões inativas");
            $this->echoWithDate("Apagando sessões inativas");
            $inactiveSessionsDeleted = $this->acesso->deleteInactiveSessions();

            if ($inactiveSessionsDeleted) {

                $this->echoWithDate("As sessões inativas foram apagadas");

            } else {

                $this->echoWithDate("Ocorreu um erro ao apagar as sessões");

            }

        } else {

            $this->echoWithDate("Nenhuma sessão inativa para ser apagada");

        }

    }

    private function echoWithDate($message)
    {
        echo "[" . date("Y-m-d H:i:s") . "]" . " - ";
        echo $message;
        echo "<br>";
        log_system_action($message);
    }

    private function getJwtToken($usuario, $senha)
    {
        try {
            return SaeDigital::make(TokenApi::class)->getCredentials($usuario, $senha);
        } catch (Exception $e) {
            return;
        }
    }
}

/* End of file login.php */
/* Location: ./application/controllers/login.php */
