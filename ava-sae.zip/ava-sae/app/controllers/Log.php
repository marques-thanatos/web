<?php
 
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Log extends MY_Controller 
{
    public $layout = 'default';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $css = array('bootstrap', '_reset', 'css-responsive','geral', 'messi', 'dtjquery-ui', 'morris', 'dtstyle');
    
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.maskedinput.min', 'mensagem', 'jquery.cookie', 'jquery.dataTables', 'cadastro', 'listarResponsavel', 'rellog', 'jquery_ui', 'morris.min', 'raphael-min');
    public $keywords = array('sae', 'curso');

    public function __construct() 
    {
        parent::__construct();

        $this->load->model('log_model', 'logmodel');
    }

    public function index() 
    {
        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'home', 'mensagem');

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);
    }   
    
    public function RelatorioLog()
    {        
        if($this->session->userdata['escola'])
        {
            $escola = $this->session->userdata['escola'];
        }
        else
        {
            $escola = null;
        }
        
        
        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);    
        
        $datamensal = date("Y-m");
                        
        $data['log']['Y'] = $this->logmodel->RetornaEixoYMensal($escola, $datamensal);        
        
        foreach($data['log']['Y'] as $eixoy)
        {
            $date = new DateTime($eixoy['DtLog']);
            $dataalt = $date->format('Y-m-d');
            
            $qtd_mes = $this->logmodel->RetornaEixoXPorValor($dataalt, $escola);
            $dataX['log']['X'][$dataalt] = count($qtd_mes);
        }
                
        $this->load->view('relatoriolog', $dataX);
    }
    
    public function Reconsulta()
    {
        $escola = null;
        if($this->session->userdata['escola'])
        {
            $escola = $this->session->userdata['escola'];
        }
        
        $dataini = $_POST['dataini'];
        $datafim = $_POST['datafim'];

        $dados = $this->logmodel->RetornaDadosGrafico($escola, $dataini, $datafim);
        $dataX = [];
        foreach($dados as $dado){
            $dataX['log']['X'][$dado['Dtlog']] = $dado['numero_acessos'];
        }

        print_r(json_encode($dataX));
        die();
    }
}

/* End of file curso.php */
/* Location: ./application/controllers/curso.php */