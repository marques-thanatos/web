<?php

use Ava\App\Services\Enqueue\Enqueue;
use Ava\App\Services\Turma\BuscarTurmasAtivas;
use Ava\App\Services\Relatorios\RelatorioDesempenhoHome;

if (!defined('BASEPATH')) {
    die("No direct Script Access allowed");
}

/**
 * Class ConsumerConsolidateTeamsData
 */
class ConsumerConsolidateTeamsData extends CI_Controller
{
    /** @var bool */
    public $layout = false;

    /** @var string */
    private $teamsQueueName;

    /**
     * ConsumerConsolidateTeamsData constructor.
     */
    public function __construct()
    {
        parent::__construct();

        $this->teamsQueueName = getenv('CI_ENV') . '_platform_consolidate_teams_data';

		$this->load->helper('log_helper');
	}

    /**
     * @return void
     */
    public function handle()
    {
        try {
            /*
             * Example message:
             *
             * {
             *   "team_id": "{itemName}",
             *   "school_id": "{itemName}"
             * }
             */
            SaeDigital::make(Ava\App\Services\Enqueue\Enqueue::class)->consume($this->teamsQueueName, function ($msg) {
				$message = SaeDigital::Make(RelatorioDesempenhoHome::class)->handle($msg);
				$messageJson = json_encode($message, true);
				echo $messageJson;
				log_system_action($messageJson);
				return true;
            });

        } catch (\Exception $e) {
            echo $e->getMessage() . PHP_EOL;
        }
    }

    /**
     * Consulta turmas ativas e envia cada uma delas para a fila de processamento para consolidação.
     *
     * @return void
     */
    public function pushTeamsToQueue()
    {
		$teams = SaeDigital::Make(BuscarTurmasAtivas::class)->handle();

        foreach ($teams as $team) {
            SaeDigital::make(Enqueue::class)->sendMessage([
                'team_id' => $team['itemName'],
                'school_id' => $team['EscolaID']
            ], $this->teamsQueueName);
        }
    }

}
