<?php

if (!defined('BASEPATH')) {
    die("No direct Script Access allowed");
}

/**
 * Class ConsumerJarvis
 */
class ConsumerContentVersion extends CI_Controller
{
    /**
     * consumer moduleSync
     */
    public function migrateContentVersion()
    {
        $this->layout = false;
        try {
            SaeDigital::make(Ava\App\Services\Enqueue\Enqueue::class)->consume(getenv('CI_ENV') . '_platform_migrate_content_version',
                function ($msg) {
                    return SaeDigital::make(\Ava\App\Services\ContentVersion\SyncContentVersion::class)->handle($msg);
                });

        } catch (\Exception $e) {
            echo $e->getMessage() . PHP_EOL;
        }
    }
}
