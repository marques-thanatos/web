<?php

use Ava\App\Services\JWT\CreateEducatJWT;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Coordenador extends MY_Controller {

    public $layout = 'new-ava';
    public $title = 'AVA SAE - Página Inicial';
    public $description = 'Ambiente Virtual de Aprendizagem - SAE';
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'flowplayer-3.2.12.min', 'geral_v5', 'messi.min', 'home_v10.min', 'mensagem');   
    public $keywords = array('sae', 'home');

    public function __construct()
    {
        parent::__construct();

        $this->load->model('curso_model', 'curso');

        // define os arquivos para juntar e comprimir
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'home', 'mensagem');
        // $this->css[] =  $this->minify->getCSS('home_construct.min', $this->cssMinify, ENVIRONMENT);
    }

    /**
     * index - [página principal área logada]
     *
     * Exibe a página inicial do usuário quando logado.
     *
     * @access	public
     * @return	void
     */
    public function index($id = null) {
        $this->js[] = 'jquery.countdown.min';

        $this->load->helper('form_cursos');
	    $mValorPago[] = 0;
        $fields['id'] = $id;
        $fields['Login'] = $this->session->userdata('login');

        if($id){
        	$retornoDadosCoordenador = $this->home->verificaPacotes($fields, $this->configuracoes[0]['Base'],$this->configuracoes[0]['id']);
        }else{
        	$retornoDadosCoordenador = $this->home->verificaDisciplinas($fields, $this->configuracoes[0]['Base'],'A');
        }
        $formAssinatura='';
		$formCursos='';
        $valorMaiorPacote = 0;
        $data['comboAno'] = '';
        $vigencia = 0;

		if (!empty($retornoDadosCoordenador))
		{
		    foreach($retornoDadosCoordenador as $key => $value) {

		    	if(isset($value['Categoria'])){

		    		$listaTurmas = $this->home->verificaTurmas($value['Categoria']);
		    		if($listaTurmas){

		    			$data['comboAno'] .= '<option value="'.$value['id'].'" '.$selected.'>'.$value['DescricaoSerie'].'</option>';

			    		foreach($listaTurmas as $k => $val) {
			    			$selected = date('Y') ==  $value['VigenciaTurma'] ? 'selected' : '';
			    			$data['comboAno'] .= '<option value="'.$value['id'].'" '.$selected.'>'.$value['DescricaoSerie'].'</option>';
			    		}
		    		}
		    	}

		    	$selected = date('Y') ==  $value['VigenciaTurma'] ? 'selected' : '';
		    	$data['comboAno'] .= '<option value="'.$value['id'].'" '.$selected.'>'.$value['DescricaoSerie'].'</option>';

		    	if($vigencia < $value['VigenciaTurma']){
		    		$vigencia = $value['VigenciaTurma'];
		    	}
			}

			$vigencia = $vigencia < date('Y') ? $vigencia : date('Y');

			foreach($retornoDadosCoordenador as $key => $value) {

				if($value['VigenciaTurma'] == $vigencia){
					$grupoAula = $this->home->verificaGrupoAula($value['Serie'],$vigencia);

					if (!empty($grupoAula)) {

						$dadosGrupoAula = $this->curso->verificaVideoAulasDisciplina($grupoAula[0]['id']);

						$value['Controller'] = $grupoAula[0]['Controller'];
						$value['QtdPacotesSimultaneos'] = @$grupoAula[0]['QtdAcessosSimultaneos'];
						$value['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];
						$value['Ancora'] = $grupoAula[0]['Ancora'];
						$value['Duracao'] = $grupoAula[0]['Duracao'];
						//retira 1 da contagem pois a primeira possicao do array e o nome da disciplina
						$value['QtdAssuntos'] = count(reset($dadosGrupoAula))-1;

						$value['DescricaoPacote'] = $grupoAula[0]['Descricao'];

						// Antiga lógica da view
						$DiasRestantesPacote = '';
						$DiasRestantesBoleto = '';
						$dtInicioPacote = '';
						$dtFimPacote = '';
						$value['linkCurso'] =  '';
						$value['btnIniciar'] = 2;
						$value['imprimeBoleto'] = 0;
						$value['bloqueado'] = '';

						if (isset($value['Ancora']) && !empty($value['Ancora']) /*&& $value['Rec'] != 'N'*/) {

							$value['linkCurso'] = base_url() . $value['Controller'] .'/' . trim($value['Ancora']);

							if ($this->session->userdata('situacaoSessao') == 'I') {

								$value['linkCurso'] = 'javascript:void(0)';
								$value['btnIniciar'] = 3;
							}

						}

						$formCursos .= form_home(2, $key, $value,$this);

					}
				}
			}

		}

		//salva o cookie dos pacotes para ser usado nas mensagens
		$cookie = array(
		    'name'   => 'pacotes'.$this->session->userdata('id'),
		    'value'  => json_encode($pacotes),
		    'expire' => 14400,
		    'domain' => '',
		    'secure' => FALSE
		);
		$this->input->set_cookie($cookie);


		$data['formCursos'] = $formCursos;

		$data['formAssinatura'] = $formAssinatura;

        //widgets class esquerda
        //$data['boxMeusCursos'] = $retornoVerificaPacotesAluno;
        $data['boxNoticias'] = $this->home->verificaNoticias();


        //widgets class direita
        //$data['boxVideo'] = $this->home->verificaProgramadaSemana();
        $this->session->set_userdata('siteID', $data['boxVideo'][0]['id']);

        $data['likebox'] = verificaURL(URL_lIKEBOX);
        $data['banner'] = verificaURL(LINK_TABLET_MULTILASER);

        $data['educatSignedUrl'] = SaeDigital::make(CreateEducatJWT::class)->generateUrl($this->session->userdata('pessoaid'));

        $this->load->view('coordenador_home', $data);
    }

    function search($array, $key, $value) {

        if (!is_array($value)) {
            return;
        }

        $results = array();
        foreach ($value as $key2) {
            $this->search_r($array, $key, $key2, $results);
        }
        return $results;
    }

    function search_r($array, $key, $value, &$results) {
        if (!is_array($array)) {
            return;
        }

        if (isset($array[$key]) && $array[$key] == $value) {
            $results[] = $array;
        }

        foreach ($array as $subarray) {
            $this->search_r($subarray, $key, $value, $results);
        }
    }
}

/* End of file home.php */
/* Location: ./application/controllers/home.php */
