<?php

use Ava\App\Exceptions\MissingArgumentException;
use Ava\App\Exceptions\NotFoundException;
use Ava\App\Services\Escola\BuscarDadosEscola;
use Ava\App\Services\Token\TokenApi;
use Ava\App\Support\Perfil;

class ApiAuthToken extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->allowProfile(Perfil::ESCOLA);
        $this->layout = false;
    }

    public function listTokens()
    {
        try {
            $escola = SaeDigital::make(BuscarDadosEscola::class)->handle($this->session->userdata('escola'));

            if (!is_array($escola)) {
                throw new NotFoundException('Escola não encontrada!');
            }

            if (!$this->session->userdata('apiAuthToken')) {
                $token = SaeDigital::make(TokenApi::class)->getCredentials($escola['Login'], $escola['Senha']);
                $this->session->set_userdata('apiAuthToken', $token);
            }

            $tokens = SaeDigital::make(TokenApi::class)->getTokens($this->session->userdata('apiAuthToken'));

            return $this->responseJson(['items' => $tokens], 200);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        }
    }

    public function createToken()
    {
        try {
            $escola = SaeDigital::make(BuscarDadosEscola::class)->handle($this->session->userdata('escola'));

            $tokenName = $this->input->post('tokenName');
            if (!$tokenName) {
                throw new MissingArgumentException('Nome do token é obrigatório');
            }

            if (!is_array($escola)) {
                throw new NotFoundException('Escola não encontrada!');
            }

            if (!$this->session->userdata('apiAuthToken')) {
                $token = SaeDigital::make(TokenApi::class)->getCredentials($escola['Login'], $escola['Senha']);
                $this->session->set_userdata('apiAuthToken', $token);
            }

            $token = SaeDigital::make(TokenApi::class)->getCredentials(
                $escola['Login'], $escola['Senha'], true, $tokenName
            );

            return $this->responseJson(['token' => $token], 200);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        } catch (MissingArgumentException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 400);
        }
    }

    public function deleteToken($id)
    {
        try {
            $escola = SaeDigital::make(BuscarDadosEscola::class)->handle($this->session->userdata('escola'));

            if (!$id) {
                throw new MissingArgumentException('Token não informado!');
            }

            if (!is_array($escola)) {
                throw new NotFoundException('Escola não encontrada!');
            }

            if (!$this->session->userdata('apiAuthToken')) {
                $token = SaeDigital::make(TokenApi::class)->getCredentials($escola['Login'], $escola['Senha']);
                $this->session->set_userdata('apiAuthToken', $token);
            }

            $code = SaeDigital::make(TokenApi::class)->deleteToken($this->session->userdata('apiAuthToken'), $id);

            if ($code === 204) {
                return $this->responseJson(['message' => 'Token deletado'], 204);
            }

            return $this->responseJson(['message' => 'Não foi possível deletar o token, tente novamente'], 400);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        } catch (MissingArgumentException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 400);
        }
    }
}