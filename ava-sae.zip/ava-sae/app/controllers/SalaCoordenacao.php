<?php
use Ava\App\Services\NextAVA\ProjetoDeVidaNextAVA;
use Ava\App\Services\JWT\CreateEducatJWT;
use Ava\App\Support\Perfil;

class SalaCoordenacao extends MY_Controller
{
    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    /**
     * @return string
     */
    public function index()
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR]);

            $haveAccess = SaeDigital::make(ProjetoDeVidaNextAVA::class)->HaveAccess($this->session->userData('token'));
            
            $data['haveAccess'] = $haveAccess;

            $data['educatSignedUrl'] = SaeDigital::make(CreateEducatJWT::class)->generateUrl($this->session->userdata('pessoaid'));
            return $this->load->view('sala-coordenacao', $data);
        } catch (\Ava\App\Exceptions\NotAllowedException $e) {
            log_error($e->getMessage());
        }
    }
}
