<?php

use Ava\App\Support\Perfil;
use Ava\App\Services\NextAVA\ProjetoDeVidaNextAVA;

class PastaDoProfessor extends MY_Controller
{
    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    /**
     * @return string
     */
    public function index()
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $haveAccess = SaeDigital::make(ProjetoDeVidaNextAVA::class)->HaveAccess($this->session->userData('token'));
            
            $data['haveAccess'] = $haveAccess;

            $this->load->view('pasta-do-professor', $data);

        } catch (\Ava\App\Exceptions\NotAllowedException $e) {

            log_error($e->getMessage());
        }
    }
}
