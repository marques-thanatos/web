<?php

use Ava\App\Services\Assuntos\PegaAssuntoPeloId;
use Ava\App\Services\Notificacoes\MarcarNotificacoesComoLida;
use Ava\App\Support\Perfil;

class AulaAoVivo extends MY_Controller
{
    public $layout = 'new-ava';
    public $title = 'Aulas ao Vivo | AVA';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $keywords = array('sae', 'aula', 'ao vivo');
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'flowplayer-3.2.12.min', 'geral_v5', 'messi.min', 'home_v10.min', 'mensagem', 'arrase.no.enem');
    public function __construct()
    {
        parent::__construct();
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'home', 'mensagem');
        $this->css[] = $this->minify->getCSS('home_construct.min', $this->cssMinify, ENVIRONMENT);
    }
    public function index()
    {
        try {

            $userData = $this->session->userdata();

            if (Perfil::PROFESSOR) {
                $userData['meetMail'] = 'p.'.$this->session->userdata['id'].'@prof.saedigital.io';
            }
            // else if (Perfil::ALUNO) {
            //     $userData['meetMail'] = 'a.'.$this->session->userdata['id'].'@aluno.saedigital.io';
            // };

            $data = [
                'jwtToken' => $userData['jwtToken'],
                'sessionData' => $userData,
                'saeMsMeetUrl' => env('SAE_MS_MEET_URL')
            ];

            return $this->load->view('aula-ao-vivo', $data);
        } catch (\Exception $e) {

            if (Perfil::ALUNO) {
                $this->redirect('/aluno');
            }

            log_error($e->getMessage());
        }
    }
}
