<?php
//header("Content-Type: text/html; charset=ISO-8859-1",true);
//header ('Content-type: text/html; charset=UTF-8');
header("Content-Type: text/html; charset=UTF-8",true);

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Mensagemsae extends MY_Controller {
    public $layout = 'default';
    public $title = 'Mural de Recados';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.maskedinput.min', 'mensagem', 'jquery.cookie', 'jquery.dataTables', 'cadastro', 'chosen.jquery.min');
    public $keywords = array('sae', 'curso');

    public function __construct()
    {
        parent::__construct();              
      
        $this->load->model('mensagemsae_model', 'mensagem');
        $this->load->model('curso_model','curso');
        $this->load->helper('url');
        $this->load->helper('cookie');
        $this->load->helper('menu_helper');            
        $this->load->model('ticket_model', 'tickets');
        $this->load->library("pagination");
        
        $this->cssMinify = array('bootstrap-new.min', 'bootstrap', '_reset', 'geral', 'messi', 'mensagem', 'chosen');        
    }   
    
    public function ExportacaoGeral()        
    {
        $this->layout = '';
 
        $idEscola = null;
        $NomeEscola = null;
        $antigos = null;
        $categoria = null;
        $id = null;
        $login = null;
        $finalizado = null;
        $indeferido = null;
        
        if(isset($_POST['escola']))
        {
            $idEscola = $this->input->post('escola', TRUE);
            
            if($idEscola == 'todos')
            {
                $idEscola = null;
            }
        }
        
        if(isset($_POST['escolaNome']))
        {
            $NomeEscola = utf8_decode($_POST['escolaNome']);
        }
        
        if(isset($_POST['antigos']))
        {
            $antigos = $_POST['antigos'];
        }
        
        if(isset($_POST['categoria']))
        {
            $categoria = $_POST['categoria'];
            
            if($categoria == 'todos')
            {
                $categoria = null;
            }            
        }                  
        
        if(isset($_POST['id']))
        {
            $id = $_POST['id'];
        }
        
        if(isset($_POST['login']))
        {
            $login = $_POST['login'];
        }
        
        if(isset($_POST['finalizado']) && $_POST['finalizado'] == "sim") {
            $finalizado = $_POST['finalizado'];
        }
        
        if(isset($_POST['indeferido']) && $_POST['indeferido'] == "sim" ) {
            $indeferido = $_POST['indeferido'];
        }

        $dados['erros'] = $this->mensagem->ListaErrosExport($idEscola, null, $categoria, null, $id, null, $finalizado, $indeferido);                                        
        
        if(isset($dados['erros']))
        {
            foreach($dados['erros'] as $key => $value)
            {
                if(!isset($value['TurmaDesc']))
                {
                    if(isset($value['TurmaID']))
                    {
                        $array_turma = $this->mensagem->CarregaDescricaoTurma($value['TurmaID']);
                        if($array_turma)
                            $dados['erros'][$key]['TurmaDesc'] = $array_turma[0]['Descricao'];
                    }
                }
                
            }
        }
        
        $dados['dadosEscola'] = $this->mensagem->CarregaEscolas();
        
        if(isset($NomeEscola))
        {
            $dados['NomeEscola'] = $NomeEscola;
        }
        
        $this->load->view('erros_exportar', $dados);
    }
    
    public function Exportacao()
    {        
        $this->layout = 'default_exp';
                
        if(isset($_POST['escola']))
        {
            $idEscola = $this->input->post('escola', TRUE);
        }
        
        if(isset($_POST['escolaNome']))
        {
            $NomeEscola = utf8_decode($_POST['escolaNome']);
        }                
        
        if(isset($_POST['categoria']))
        {
            $categoria = $_POST['categoria'];
        }
        
        if(isset($_POST['id']))
        {
            $id = $_POST['id'];
        }
        
        if(isset($_POST['login']))
        {
            $login = $_POST['login'];
        }
        
        
        
        $filtroTriagem = "";
        
        if(isset($_POST['filtroTriagem']))
        {
            if($_POST['filtroTriagem'] == 'conteudo')
            {
                $filtroTriagem  .= 'S|';
            }
            else
            {
                $filtroTriagem  .= 'N|';
            }
                        
            if($_POST['filtroTriagem'] == 'cadastro')
            {
                $filtroTriagem  .= 'S|';
            }
            else
            {
                $filtroTriagem  .= 'N|';
            }
            
            if($_POST['filtroTriagem'] == 'tecnico')
            {
                $filtroTriagem  .= 'S';
            }
            else
            {
                $filtroTriagem  .= 'N';
            }
        }
        else
        {
            $filtroTriagem = 'N|N|N';
        }        
        
        //print_pre($idEscola ."|". $antigos ."|". $categoria);die();
        //'6b32cb21-b81a-492c-a8af-f04de16595eb|N|todos'               
        
//        if($filtroTriagem != 'N|N|N')
//        {
        
        
        
        if(!isset($idEscola))
        {
            $idEscola = null;
        }
                
        if(!isset($categoria))
        {
            $categoria = null;
        }
        
        if(!isset($id))
        {
            $id = null;
        }
        
        if(!isset($login))
        {
            $login = null;
        }
        
        $dados['erros'] = $this->mensagem->ListaErrosExport($idEscola, null, $categoria, null, $id, $login);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
//            if(isset($idEscola))
//            {     
//                if($idEscola != 'todos')
//                {
//                    if(isset($categoria) && $categoria != 'Todas')
//                    {
//                        $dados['erros'] = $this->mensagem->ListaErrosExport($idEscola, null, $categoria, $filtroTriagem);
//                    }
//                    else
//                    {
//                        $dados['erros'] = $this->mensagem->ListaErrosExport($idEscola, null, null, $filtroTriagem);
//                    }                
//                }
//                else
//                {
//                    if(isset($categoria) && $categoria != 'Todas')
//                    {
//                        $dados['erros'] = $this->mensagem->ListaErrosExport(null, null, $categoria, $filtroTriagem);
//                    }
//                    else
//                    {
//                        $dados['erros'] = $this->mensagem->ListaErrosExport(null, null, null, $filtroTriagem);
//                    }                
//                }
//            }
//            else
//            {
//                if(isset($categoria) && $categoria != 'Todas')
//                {
//                    $dados['erros'] = $this->mensagem->ListaErrosExport(null, null, $categoria, $filtroTriagem);
//                }
//                else
//                {               
//                    $dados['erros'] = $this->mensagem->ListaErrosExport(null, null, null, $filtroTriagem);
//                }
//            }
//        }
        
        //print_pre($dados);die();
        
        if(isset($dados['erros']) && $dados['erros'] != null)
        {
            foreach($dados['erros'] as $key => $value)
            {            
                if(!isset($value['TurmaDesc']))
                {
                    if(isset($value['TurmaID']))
                    {
                        $array_turma = $this->mensagem->CarregaDescricaoTurma($value['TurmaID']);
                        if($array_turma)
                            $dados['erros'][$key]['TurmaDesc'] = $array_turma[0]['Descricao'];
                    }
                }

//                if(!isset($value['Escolaid']))
//                {
//                    $array_escola = $this->mensagem->CarregaEscolaIDByLogin($value['UsuarioLogin']);
//                    $dados['erros'][$key]['Escolaid'] = $array_escola[0]['id'];
//                }
            }    
        }
        
        $dados['dadosEscola'] = $this->mensagem->CarregaEscolas();
        
        if(isset($NomeEscola))
        {
            $dados['NomeEscola'] = $NomeEscola;
        }                
       
        
        if(isset($filtroTriagem))
        {
            if($filtroTriagem == 'S|N|N')
            {
                $responsavel = "Conteúdo";
            }
            else if($filtroTriagem == 'N|S|N')
            {
                $responsavel = "Cadastro";
            }
            else if($filtroTriagem == 'N|N|S')
            {
                $responsavel = "Técnico";
            }
                
            if(isset($responsavel))
            {
                $dados['Responsabilidade'] = $responsavel;
            }
        }             
                
        if(isset($categoria))
        {
            $dados['Categoria_filtro'] = $categoria;
        }     
        
        $this->load->view('erros_exportar', $dados);
    }      
    
    public function MuralRecados($idPop = null)       
    {               
        $post = $this->input->post(NULL, TRUE);
        extract($post);
                    
        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        
        $dados['dados'] = montaMenu($this->session->userdata('perfil'));        
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);     
       
        $id = $this->session->userdata("pessoaid");
        
        $dados['lista'] = $this->mensagem->CarregaListaRecados($id);        
        //$dados['geral'] = $this->mensagem->CarregaListaRecadosGeral();   
        
        if(isset($api_url))
        {
            $dados['erropop'] = $api_url;
        }        
                        
        $this->load->view('mensagens_sae_view', $dados);        
    }
    
    public function LendoMensagem()
    {
        $post = $this->input->post(NULL, TRUE);
        extract($post);
        
        $this->MarcaComoLido($id);
        
        $info['url'] = PATH_IMG_SITE;
        $info['mensagem'] = $this->mensagem->CarregaMensagem($id);
        $info['retorno'] = $this->mensagem->CarregaRetornoTecnico($info['mensagem'][0]['Erro']);
        $info['MsgNaoLida'] = $this->session->userdata('MsgNaoLidas');
                
        print(json_encode($info));
        die();
    }
    
    public function MarcaComoLido($id)   
    {
        $dados['Lido'] = 'S';
        
        $qtdmsg = $this->session->userdata('MsgNaoLidas');        
        $this->session->set_userdata('MsgNaoLidas', $qtdmsg-1);
        
        $this->mensagem->MensagemLida($id, $dados);
    }


    /**
     * Verifica se existe chamados do zendesk em nosso banco de dados, se não existir busca na API do zendesk
     *
     * @return void
     */
    public function BuscaRecados()
    {
        try {
            $agora = new DateTime();
            $ultimaAtualizacaoZD = $this->session->userdata("ultimaAtualizacaoZD");
            $mensagens = $this->session->userdata("mensagens");
            $mensagensNaoLidas = $this->mensagem->buscarMensagensNaoLidas($this->session->userdata('pessoaid'));
            $dados['requestApi'] = false;
            $countRequest = 0;


            if ($this->session->userdata("countRequest") === null) {
                $this->session->set_userdata("countRequest", $countRequest);
            }

            $dados['countRequest'] = $countRequest = (int) $this->session->userdata("countRequest");

            if (count($mensagensNaoLidas) > 0 && count($mensagensNaoLidas) > count($mensagens)) {
                $mensagens = null;
            }

            if (!isset($ultimaAtualizacaoZD)){
                $this->session->set_userdata("ultimaAtualizacaoZD", $agora);
                $ultimaAtualizacaoZD = $this->session->userdata("ultimaAtualizacaoZD");
            }

            $timeDiff = intval(($agora->getTimestamp() - $ultimaAtualizacaoZD->getTimestamp()) / 60);

            $dados['url'] = PATH_IMG_SITE;

            $dados["fonte"] = "zendesk";


            if (($timeDiff > getenv('ZENDESK_UPDATE_RATE') || !isset($mensagens)) && $countRequest%15 == 0) {
                $dados['requestApi'] = true;
                $ultimaAtualizacaoZD = $this->session->set_userdata("ultimaAtualizacaoZD", $agora);
                $client = $this->tickets->getClient();
                $search = $client->users()->search(['query' => 'email:' . $this->tickets->getRequesterEmail()]);
                $dados['mensagens'] = null;
                if (!empty($search->users)) {

                    $user = $search->users[0];

                    $client->users()->update($user->id, [
                        'user_fields' => [
                            'login' => $this->session->userdata('login')
                        ]

                    ]);

                    $tickets = $client->search()->find(
                        'requester:' . $this->tickets->getRequesterEmail(). " -tags:lido",
                        array( 'sort_by' => 'created_at', 'sort_order' => 'desc')
                    );
                    $dados['mensagens'] = $tickets->results;
                    $this->session->set_userdata("mensagens", $tickets->results);
                    $dados['cached'] = FALSE;
                }

            } else {
                $dados['mensagens'] = $this->session->userdata("mensagens");
                $dados['cached'] = TRUE;
            }

            $this->session->set_userdata("countRequest", $countRequest + 1);

            return $this->responseJson($dados);
        } catch (\Zendesk\API\Exceptions\ApiResponseException $e) {
            log_error($e->getMessage());
            return $this->responseJson(['message' => $e->getMessage()], $e->getCode());
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson(['message' => $e->getMessage()], 400);
        }
    }
    
    public function iso_utf(&$a){
        if (is_array($a)){
            foreach ($a as $k => $v) {
                if (!is_array($v)){
                    $a[$k] = utf8_encode($a[$k]);
                } else {
                    $this->iso_utf($a[$k]);
                }
            }
        } else {
            $a = utf8_encode($a);
        }
        return $a;
    }		
        
        
    public function utf_iso(&$a){
        if (is_array($a)){
            foreach ($a as $k => $v) {
                if (!is_array($v)){
                    $a[$k] = utf8_decode($a[$k]);
                } else {
                    utf_iso($a[$k]);
                }
            }
        } else {
            $a = utf8_decode($a);
        }
        return $a;
    }        
    
    public function ListaErros( $indice = 0, $idEscola = null ){
        $this->title = 'Central de Erros';
        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        
        $this->ajustarRequest();
        $this->configuracaoPaginacao( $_REQUEST, false );

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $dados["erros"] = $this->mensagem->getQueryPagination(30, $page, $_REQUEST);
        $dados['dadosEscola'] = $this->mensagem->CarregaEscolas();
        $dados = $this->mensagem->CarregaTurmas($dados);
        $dados["links"] = $this->pagination->create_links();
        $this->load->view('listaErros', $dados);
    }
    
    public function ListaErros_old ($idEscola = null)
    {                                                                       
        header('Content-Type: text/html; charset=utf-8');
        $this->title = 'Central de Erros';              
        
        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        //$this->css[] = $this->minify->getCSS('cadastro_escola_lista.min', $this->cssMinify, ENVIRONMENT);                                                   
                        
        if(isset($_POST['escola']))
        {
            $idEscola = $this->input->post('escola', TRUE);
        }
        
        if(isset($_POST['escolaNome']))
        {
            $NomeEscola = utf8_decode($_POST['escolaNome']);
        }
        
        if(isset($_POST['antigos']))
        {
            $antigos = $_POST['antigos'];
        }
        
        if(isset($_POST['categoria']))
        {
            $categoria = $_POST['categoria'];
        }
        
        if(isset($_POST['idErro']))
        {
            $id = $_POST['idErro'];
        }
        
        if(isset($_POST['loginPesq']))
        {
            $loginPesq = $_POST['loginPesq'];            
        }                
                
        if(isset($_POST['filtroAssessoria']))
        {
            $filtroAssessoria = $_POST['filtroAssessoria'];
        }
        else
        {
            $filtroAssessoria = 'N';
        }
        if(isset($_POST['filtroIsabel']))
        {
            $filtroIsabel = $_POST['filtroIsabel'];
        }
        else
        {
            $filtroIsabel = 'N';
        }
        if(isset($_POST['filtroTi']))
        {
            $filtroTi = $_POST['filtroTi'];
        }
        else
        {
            $filtroTi = 'N';
        }
        
        $filtroResponsavel = $filtroAssessoria ."|". $filtroIsabel ."|". $filtroTi;                                
        
        if(isset($id))
        {            
            $ifcontrol['fluxo'][] = 1;
            if($id)
            {
                $ifcontrol['fluxo'][] = 2;
                if($idEscola)
                {             
                    $ifcontrol['fluxo'][] = 3;
                    if($idEscola != 'todos') //quero uma escola específica
                    {
                        $ifcontrol['fluxo'][] = 4;
                        if(isset($categoria) && $categoria != 'todos') //quero uma categoria específica
                        {             
                            $ifcontrol['fluxo'][] = 5;
                            $dados['erros'] = $this->mensagem->ListaErros($idEscola, null, $categoria, $filtroResponsavel, $id, $loginPesq);
                        }
                        else //sem categoria
                        {
                            $ifcontrol['fluxo'][] = 6;
                            $dados['erros'] = $this->mensagem->ListaErros($idEscola, null, null, $filtroResponsavel, $id, $loginPesq);
                        }
                    }
                    else //todas as escolas
                    {                     
                        $ifcontrol['fluxo'][] = 7;
                        if(isset($categoria) && $categoria != 'todos')//porem quero uma categoria específica
                        {
                            $ifcontrol['fluxo'][] = 8;
                            $dados['erros'] = $this->mensagem->ListaErros(null, null, $categoria, $filtroResponsavel, $id, $loginPesq);
                        }
                        else //tanto faz a categoria e a escola
                        {
                            $ifcontrol['fluxo'][] = 9;
                            $dados['erros'] = $this->mensagem->ListaErros(null, null, null, null, $id, $loginPesq);
                        }
                    }
                }
                else //todas as escolas
                {
                    $ifcontrol['fluxo'][] = 10;
                    if(isset($categoria) && $categoria != 'todos') //porem quero uma categoria específica
                    {
                        $ifcontrol['fluxo'][] = 11;
                        $dados['erros'] = $this->mensagem->ListaErros(null, null, $categoria, $filtroResponsavel, $id, $loginPesq);
                    }
                    else //tanto faz a categoria e a escola
                    {
                        $ifcontrol['fluxo'][] = 12;
                        $dados['erros'] = $this->mensagem->ListaErros(null, null, null, null, $id, $loginPesq);
                    }
                }    
            }
            else
            {
                $ifcontrol['fluxo'][] = 13;
                if($idEscola)
                {     
                    $ifcontrol['fluxo'][] = 14;
                    if($idEscola != 'todos') //quero uma escola específica
                    {
                        $ifcontrol['fluxo'][] = 15;
                        if(isset($categoria) && $categoria != 'todos') //quero uma categoria específica
                        {              
                            $ifcontrol['fluxo'][] = 16;
                            $dados['erros'] = $this->mensagem->ListaErros($idEscola, null, $categoria, $filtroResponsavel, null, $loginPesq);
                        }
                        else //sem categoria
                        {
                            $ifcontrol['fluxo'][] = 17;
                            $dados['erros'] = $this->mensagem->ListaErros($idEscola, null, null, $filtroResponsavel, null, $loginPesq);
                        }
                    }
                    else //todas as escolas
                    {
                        $ifcontrol['fluxo'][] = 18;
                        if(isset($categoria) && $categoria != 'todos')//porem quero uma categoria específica
                        {
                            $ifcontrol['fluxo'][] = 19;
                            $dados['erros'] = $this->mensagem->ListaErros(null, null, $categoria, $filtroResponsavel, null, $loginPesq);
                        }
                        else //tanto faz a categoria e a escola
                        {
                            $ifcontrol['fluxo'][] = 20;
                            //$dados['erros'] = $this->mensagem->ListaErros();
                            $dados['erros'] = $this->mensagem->ListaErros(null, null, null, null, null, $loginPesq);
                            //print_pre($loginPesq);die();
                        }
                    }
                }
                else //todas as escolas
                {
                    $ifcontrol['fluxo'][] = 21;
                    if(isset($categoria) && $categoria != 'todos') //porem quero uma categoria específica
                    {
                        $ifcontrol['fluxo'][] = 22;
                        $dados['erros'] = $this->mensagem->ListaErros(null, null, $categoria, $filtroResponsavel, null, $loginPesq);
                    }
                    else //tanto faz a categoria e a escola
                    {
                        $ifcontrol['fluxo'][] = 23;
                        $dados['erros'] = $this->mensagem->ListaErros(null, null, null, null, null, $loginPesq);
                    }
                }
            }
        }
        else
        {
            $ifcontrol['fluxo'][] = 24;
            if($idEscola)
            {     
                $ifcontrol['fluxo'][] = 25;
                if($idEscola != 'todos') //quero uma escola específica
                {
                    $ifcontrol['fluxo'][] = 26;
                    if(isset($categoria) && $categoria != 'todos') //quero uma categoria específica
                    {              
                        $ifcontrol['fluxo'][] = 27;
                        $dados['erros'] = $this->mensagem->ListaErros($idEscola, null, $categoria, $filtroResponsavel, null, $loginPesq);
                    }
                    else //sem categoria
                    {
                        $ifcontrol['fluxo'][] = 28;
                        $dados['erros'] = $this->mensagem->ListaErros($idEscola, null, null, $filtroResponsavel, null, $loginPesq);
                    }
                }
                else //todas as escolas
                {
                    $ifcontrol['fluxo'][] = 29;
                    if(isset($categoria) && $categoria != 'todos')//porem quero uma categoria específica
                    {
                        $ifcontrol['fluxo'][] = 30;
                        $dados['erros'] = $this->mensagem->ListaErros(null, null, $categoria, $filtroResponsavel, null, $loginPesq);
                    }
                    else //tanto faz a categoria e a escola
                    {
                        $ifcontrol['fluxo'][] = 31;
                        $dados['erros'] = $this->mensagem->ListaErros(null, null, null, null, null, $loginPesq);
                    }
                }
            }
            else //todas as escolas
            {
                $ifcontrol['fluxo'][] = 32;
                if(isset($categoria) && $categoria != 'todos') //porem quero uma categoria específica
                {
                    $ifcontrol['fluxo'][] = 33;
                    $dados['erros'] = $this->mensagem->ListaErros(null, null, $categoria, $filtroResponsavel, null, $loginPesq);
                }
                else //tanto faz a categoria e a escola
                {
                    $ifcontrol['fluxo'][] = 34;
                    if(isset($loginPesq))
                    {
                        $ifcontrol['fluxo'][] = 35;
                        $dados['erros'] = $this->mensagem->ListaErros(null, null, null, null, null, $loginPesq);
                    }
                    else
                    {
                        $ifcontrol['fluxo'][] = 36;
                        $dados['erros'] = $this->mensagem->ListaErros(null, null, null, null, null);
                    }
                }
            } 
        }        
        
        
        //FIM FILTRO PESQUISA
        if(isset($dados['erros']))
        {
            if($dados['erros'])
            {
                foreach($dados['erros'] as $key => $value)
                {
                    if(!isset($value['TurmaDesc']))
                    {
                        if(isset($value['TurmaID']))
                        {
                            $array_turma = $this->mensagem->CarregaDescricaoTurma($value['TurmaID']);
                            if($array_turma)
                                $dados['erros'][$key]['TurmaDesc'] = $array_turma[0]['Descricao'];
                        }
                    }

                }
            }
        }
        
        $dados['dadosEscola'] = $this->mensagem->CarregaEscolas();
        
        if(isset($NomeEscola))
        {
            $dados['NomeEscola'] = $NomeEscola;
        }
        $this->load->view('listaErros', $dados); 
    }
    
    public function FiltraErrosAJAX()
    {
        $post = $this->input->post(NULL, TRUE);
        extract($post);
            $dados['erros'] = $this->mensagem->ListaErros($escola);            
        //$a = $this->iso_utf($dados);                  
        
        print($dados);
        die();
    }
    
    public function CarregaConteudoErros()
    {
        $post = $this->input->post(NULL, TRUE);
        extract($post);

        $info['erros'] = $this->mensagem->GetConteudoErros($id);
        
        print(json_encode($info));
        die();
    }
    
    public function FinalizaErros()
    {
        $post = $this->input->post(NULL, TRUE);
        extract($post);        

        $dados['RetornoTecnico'] = $retorno;
        $dados['DtFinalizado'] = date("Y-m-d");
        $dados['Categoria'] = $categoria;

        if($msgid)
        {
            $dadosmsg['MensagemID'] = $msgid;
            $this->mensagem->FinalizaErro($id, $dados, $dadosmsg);  
        }
        else
        {
            $this->mensagem->FinalizaErro($id, $dados);  
        }                                           
        
        echo "ok";
        die();
    }
    
    public function EncaminhaErros()
    {
        $post = $this->input->post(NULL, TRUE);
        extract($post);
        
        // Sempre encaminha para o setor técnico
        if ( $responsavel == "" ){
            $responsavel = "N|N|S";
        }

        $dados['GrupoResponsavel'] = $responsavel;
        $dados['ObservacaoEncaminhar'] = $obs;
        $dados['Indeferido'] = $indeferido;
        
        $this->mensagem->EncaminhaErro($id, $dados);        
        
        echo "ok|". $responsavel;
        die();
    }
    
    public function TriagemErros(){
        $this->title = 'Central de Erros';
        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'erro';
        
        unset($_SESSION['finalizado'], $_SESSION['indeferido']);
        $_SESSION['filtroTriagem'] = isset($_SESSION['filtroTriagem'])? $_SESSION['filtroTriagem']:"";
        
        if ( isset($_REQUEST['filtroTriagem']) ){
            $_SESSION['filtroTriagem'] = $_REQUEST['filtroTriagem'];
        }else{
            $_REQUEST['filtroTriagem'] = $_SESSION['filtroTriagem'];
        }
        $_REQUEST['filtroTriagem'] = $_SESSION['filtroTriagem'];
        $_REQUEST['finalizado'] = 'sim';
        
        $this->configuracaoPaginacao( $_REQUEST );

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $dados["erros"] = $this->mensagem->getQueryPagination(30, $page, $_REQUEST);
        $dados['dadosEscola'] = $this->mensagem->CarregaEscolas();
        $dados = $this->mensagem->CarregaTurmas($dados);
        $dados["links"] = $this->pagination->create_links();
        
        if( $this->uri->segment(2) == "triagem" && $_SESSION['filtroTriagem'] == ""){
            unset($dados["erros"]);
        }
        
        $this->load->view('listaTriagem', $dados);
    }
    
    public function TriagemErros_old()
    {        
        header('Content-Type: text/html; charset=utf-8');
        $this->title = 'Central de Erros';              
        
        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        //$this->css[] = $this->minify->getCSS('cadastro_escola_lista.min', $this->cssMinify, ENVIRONMENT);   
        
        $this->js[] = 'erro';
                
        if(isset($_POST['escola']))
        {
            $idEscola = $this->input->post('escola', TRUE);
        }
        
        if(isset($_POST['escolaNome']))
        {
            $NomeEscola = utf8_decode($_POST['escolaNome']);
        }                
        
        if(isset($_POST['categoria']))
        {
            $categoria = $_POST['categoria'];
        }
        
        $filtroTriagem = "";
        
        if(isset($_POST['filtroTriagem']))
        {
            if($_POST['filtroTriagem'] == 'conteudo')
            {
                $filtroTriagem  .= 'S|';
            }
            else
            {
                $filtroTriagem  .= 'N|';
            }
                        
            if($_POST['filtroTriagem'] == 'cadastro')
            {
                $filtroTriagem  .= 'S|';
            }
            else
            {
                $filtroTriagem  .= 'N|';
            }
            
            if($_POST['filtroTriagem'] == 'tecnico')
            {
                $filtroTriagem  .= 'S';
            }
            else
            {
                $filtroTriagem  .= 'N';
            }
        }
        else
        {
            $filtroTriagem = 'N|N|N';
        }        
        
        //print_pre($idEscola ."|". $antigos ."|". $categoria);die();
        //'6b32cb21-b81a-492c-a8af-f04de16595eb|N|todos'               
        
        if($filtroTriagem != 'N|N|N')
        {
            if(isset($idEscola))
            {     
                if($idEscola != 'todos')
                {
                    if(isset($categoria) && $categoria != 'Todas')
                    {
                        $dados['erros'] = $this->mensagem->ListaErrosTriagem($idEscola, null, $categoria, $filtroTriagem);
                    }
                    else
                    {
                        $dados['erros'] = $this->mensagem->ListaErrosTriagem($idEscola, null, null, $filtroTriagem);
                    }                
                }
                else
                {
                    if(isset($categoria) && $categoria != 'Todas')
                    {
                        $dados['erros'] = $this->mensagem->ListaErrosTriagem(null, null, $categoria, $filtroTriagem);
                    }
                    else
                    {
                        $dados['erros'] = $this->mensagem->ListaErrosTriagem(null, null, null, $filtroTriagem);
                    }                
                }
            }
            else
            {
                if(isset($categoria) && $categoria != 'Todas')
                {
                    $dados['erros'] = $this->mensagem->ListaErrosTriagem(null, null, $categoria, $filtroTriagem);
                }
                else
                {               
                    $dados['erros'] = $this->mensagem->ListaErrosTriagem(null, null, null, $filtroTriagem);
                }
            }
        }        
        
        if(isset($dados['erros']) && $dados['erros'] != null)
        {
            foreach($dados['erros'] as $key => $value)
            {            
                if(!isset($value['TurmaDesc']))
                {
                    if(isset($value['TurmaID']))
                    {
                        $array_turma = $this->mensagem->CarregaDescricaoTurma($value['TurmaID']);
                        if($array_turma)
                            $dados['erros'][$key]['TurmaDesc'] = $array_turma[0]['Descricao'];
                    }
                }

//                if(!isset($value['Escolaid']))
//                {
//                    $array_escola = $this->mensagem->CarregaEscolaIDByLogin($value['UsuarioLogin']);
//                    $dados['erros'][$key]['Escolaid'] = $array_escola[0]['id'];
//                }
            }    
        }
        
        $dados['dadosEscola'] = $this->mensagem->CarregaEscolas();
        
        if(isset($NomeEscola))
        {
            $dados['NomeEscola'] = $NomeEscola;
        }                
       
        
        if(isset($filtroTriagem))
        {
            if($filtroTriagem == 'S|N|N')
            {
                $responsavel = "Conteúdo";
            }
            else if($filtroTriagem == 'N|S|N')
            {
                $responsavel = "Cadastro";
            }
            else if($filtroTriagem == 'N|N|S')
            {
                $responsavel = "Técnico";
            }
                
            if(isset($responsavel))
            {
                $dados['Responsabilidade'] = $responsavel;
            }
        }             
                
        if(isset($categoria))
        {
            $dados['Categoria_filtro'] = $categoria;
        }        
        
        
        $this->load->view('listaTriagem', $dados); 
    }
    
    public function ErrosConcluidos()
    {
        header('Content-Type: text/html; charset=utf-8');
        $this->title = 'Central de Erros';              
        
        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        //$this->css[] = $this->minify->getCSS('cadastro_escola_lista.min', $this->cssMinify, ENVIRONMENT);   
        
        $this->js[] = 'erro';
                
        if(isset($_POST['escola']))
        {
            $idEscola = $this->input->post('escola', TRUE);
        }
        
        if(isset($_POST['escolaNome']))
        {
            $NomeEscola = utf8_decode($_POST['escolaNome']);
        }                
        
        if(isset($_POST['categoria']))
        {
            $categoria = $_POST['categoria'];
        }
        
        $filtroTriagem = "";
        
        if(isset($_POST['filtroTriagem']))
        {
            if($_POST['filtroTriagem'] == 'conteudo')
            {
                $filtroTriagem  .= 'S|';
            }
            else
            {
                $filtroTriagem  .= 'N|';
            }
                        
            if($_POST['filtroTriagem'] == 'cadastro')
            {
                $filtroTriagem  .= 'S|';
            }
            else
            {
                $filtroTriagem  .= 'N|';
            }
            
            if($_POST['filtroTriagem'] == 'tecnico')
            {
                $filtroTriagem  .= 'S';
            }
            else
            {
                $filtroTriagem  .= 'N';
            }
        }
        else
        {
            $filtroTriagem = 'N|N|N';
        }        
        
        //print_pre($idEscola ."|". $antigos ."|". $categoria);die();
        //'6b32cb21-b81a-492c-a8af-f04de16595eb|N|todos'       
        
        if(isset($idEscola))
        {     
            if($idEscola)
            {
                if($idEscola != 'todos')
                {
                    if(isset($categoria) && $categoria != 'Todas')
                    {
                        $dados['erros'] = $this->mensagem->ListaErrosConcluidos($idEscola, null, $categoria, $filtroTriagem);
                    }
                    else
                    {
                        $dados['erros'] = $this->mensagem->ListaErrosConcluidos($idEscola, null, null, $filtroTriagem);
                    }                
                }
                else
                {
                    if(isset($categoria) && $categoria != 'Todas')
                    {
                        $dados['erros'] = $this->mensagem->ListaErrosConcluidos(null, null, $categoria, $filtroTriagem);
                    }
                    else
                    {
                        $dados['erros'] = $this->mensagem->ListaErrosConcluidos(null, null, null, $filtroTriagem);
                    }                
                }
            }
        }
        else
        {
            if(isset($categoria) && $categoria != 'Todas')
            {
                $dados['erros'] = $this->mensagem->ListaErrosConcluidos(null, null, $categoria, $filtroTriagem);
            }
            else
            {
                $dados['erros'] = $this->mensagem->ListaErrosConcluidos(null, null, null, $filtroTriagem);
            }
        }
        
        //print_pre($dados);die();
        
        if(isset($dados['erros']) && $dados['erros'] != null)
        {
            //print_pre($dados);die();
            foreach($dados['erros'] as $key => $value)
            {            
                if(isset($value['TurmaDesc']))
                {
                    if(isset($value['TurmaID']))
                    {
                        $array_turma = $this->mensagem->CarregaDescricaoTurma($value['TurmaID']);
                        $dados['erros'][$key]['TurmaDesc'] = $array_turma[0]['Descricao'];
                    }
                }

//                if(!isset($value['Escolaid']))
//                {
//                    $array_escola = $this->mensagem->CarregaEscolaIDByLogin($value['UsuarioLogin']);
//                    $dados['erros'][$key]['Escolaid'] = $array_escola[0]['id'];
//                }
            }    
        }
        
        $dados['dadosEscola'] = $this->mensagem->CarregaEscolas();
        
        if(isset($NomeEscola))
        {
            $dados['NomeEscola'] = $NomeEscola;
        }                
       
        
        if(isset($filtroTriagem))
        {
            if($filtroTriagem == 'S|N|N')
            {
                $responsavel = "Conteúdo";
            }
            else if($filtroTriagem == 'N|S|N')
            {
                $responsavel = "Cadastro";
            }
            else if($filtroTriagem == 'N|N|S')
            {
                $responsavel = "Técnico";
            }
                
            if(isset($responsavel))
            {
                $dados['Responsabilidade'] = $responsavel;
            }
        }             
                
        if(isset($categoria))
        {
            $dados['Categoria_filtro'] = $categoria;
        }        
        
        //$this->load->view('listaTriagem', $dados); 
//        print_pre($dados);die();
        $this->load->view('listaErrosConcluidos', $dados); 
    }
    
    public function ExcluirErros()
    {
        $post = $this->input->post(NULL, TRUE);
        extract($post);                

        $dados['Situacao'] = 'I';
        
        $this->mensagem->ExcluirErros($id, $dados);
        $this->mensagem->ExcluirMensagemErros($id, $dados);
        
        echo "ok";
        die();
    }        
    
    public function CriaErro()
    {
        $dados['login'] = $this->input->post('login', TRUE);
        $dados['email'] = $this->input->post('email', TRUE);
        $dados['escola'] = $this->input->post('escola', TRUE);
        $dados['turma'] = $this->input->post('turma', TRUE);
        $dados['disciplina'] = $this->input->post('disciplina', TRUE);
        $dados['questao'] = $this->input->post('questao', TRUE);
        $dados['assunto'] = $this->input->post('assunto', TRUE);
        $dados['responsabilidadeCnt'] = $this->input->post('responsabilidadeCnt', TRUE);
        $dados['responsabilidadeTi'] = $this->input->post('responsabilidadeTi', TRUE);
        $dados['obs'] = $this->input->post('obs', TRUE);
        $dados['erro'] = $this->input->post('erro', TRUE);
        
        if($dados['responsabilidadeCnt']) {
            $dados['responsavel'] = 'S|N|N';
        } else if($dados['responsabilidadeTi']) {
            $dados['responsavel'] = 'N|N|S';
        }
         
        $dados2['emailreclamante'] = $dados['email'];
        $dados2['assunto'] = '-'; //categoria
        $dados2['descricaoerro'] = $dados['erro'];
        $dados2['usuario'] = $dados['login'];
        $dados2['escola'] = $dados['escola'];
        $dados2['turma'] = $dados['turma'];
        $dados2['txt_error_desc'] = $dados['erro'];
        $dados2['responsavel'] = $dados['responsavel'];
        $dados2['obs'] = $dados['obs'];
        $dados2['conteudo'] = $dados['assunto'];
        
        $array_turma = $this->mensagem->CarregaDescricaoTurmaByLogin($dados['login']);
        $array_escola = $this->mensagem->CarregaEscolaIDByLogin($dados['login']);
        
        $dados2['turmaDesc'] = $array_turma[0]['DescricaoTurma'];
        $dados2['turmaID'] = $array_turma[0]['itemName'];
        
        $dados2['EscolaItemName'] = $array_escola[0]['Escola'];
                
        $dados2['questao'] = $dados['questao'];
        $dados2['disciplina'] = $dados['disciplina'];
        $dados2['assunto'] = $dados['assunto'];                
        
        $a = $this->mensagem->GravaErroManual($dados2);        
    }
    
    public function VerificaLoginExiste()
    {
        $login = $this->input->post('login', TRUE);        
        echo $this->mensagem->VerificaLoginExiste($login);
        die();
    }
    
    public function Dashboard()
    {
        header('Content-Type: text/html; charset=utf-8');
        $this->title = 'Central de Erros - Dashboard';              
        
        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        
        //$dados['qtdconteudo'] = $this->mensagem->QuantidadeErrosConteudo();
        //$dados['qtdtecnico']  = $this->mensagem->QuantidadeErrosTecnico();
        
        $dados['conteudoG'] = $this->mensagem->ErrosConteudo();
        $dados['tecnicoG'] = $this->mensagem->ErrosTecnico();
                        
        $c = 0;
        
        //conta conteudo total
        $info['conteudo']['total'] = count($dados['conteudoG']);
        $info['tecnico']['total'] = count($dados['tecnicoG']);
        
        //conteudo - concluidos
        foreach($dados['conteudoG'] as $key => $value)
        {
            if(isset($value['DtFinalizado']))
            {
                $c+=1;
            }
        }
        $info['conteudo']['concluidos'] = $c;
        
        $c = 0;
        
        //conteudo - abertos
        foreach($dados['conteudoG'] as $key => $value)
        {
            if(!isset($value['DtFinalizado']))
            {
                $c+=1;
            }
        }
        $info['conteudo']['abertos'] = $c;
        
        $c = 0;
        
        //tecnico - concluidos
        foreach($dados['tecnicoG'] as $key => $value)
        {
            if(isset($value['DtFinalizado']))
            {
                $c+=1;
            }
        }
        $info['tecnico']['concluidos'] = $c;
        
        $c = 0;
        
        //conteudo - abertos
        foreach($dados['tecnicoG'] as $key => $value)
        {
            if(!isset($value['DtFinalizado']))
            {
                $c+=1;
            }
        }        
        $info['tecnico']['abertos'] = $c;
        
        
        //erros por tipo - tecnico
        $info['tecnico']['tipos']['t1'] = 0;
        $info['tecnico']['tipos']['t2'] = 0;
        $info['tecnico']['tipos']['t3'] = 0;
        $info['tecnico']['tipos']['t4'] = 0;
        $info['tecnico']['tipos']['t5'] = 0;
        $info['tecnico']['tipos']['t6'] = 0;
        $info['tecnico']['tipos']['t7'] = 0;
        $info['tecnico']['tipos']['t8'] = 0;
        $info['tecnico']['tipos']['t9'] = 0;
        $info['tecnico']['tipos']['t10'] = 0;                
        foreach($dados['tecnicoG'] as $key => $value)
        {
            if($value['Assunto'])
            {
                if(strpos($value['Assunto'], "|"))
                {
                    $ass = explode("|", $value['Assunto']);
                    //print_pre($ass[1]);
                    if($ass[1] == 'Vídeo está travando.')
                    {
                        $info['tecnico']['tipos']['t1'] += 1;
                    }
                    else if($ass[1] == 'Vídeo não está contabilizando percentual(%).')
                    {
                        $info['tecnico']['tipos']['t2'] += 1;
                    }
                    else if($ass[1] == 'Meu relatório está divergente.')
                    {
                        $info['tecnico']['tipos']['t3'] += 1;
                    }
                    else if($ass[1] == "O botão 'Responder' não está funcionando.")
                    {
                        $info['tecnico']['tipos']['t4'] += 1;
                    }
                    else if($ass[1] == 'A questão não carrega.')
                    {
                        $info['tecnico']['tipos']['t5'] += 1;
                    }
                    else if($ass[1] == 'Plataforma está lenta.')
                    {
                        $info['tecnico']['tipos']['t6'] += 1;
                    }
                    else if($ass[1] == 'Questão já está respondida.')
                    {
                        $info['tecnico']['tipos']['t7'] += 1;
                    }
                    else if($ass[1] == 'Atividade no prazo, porém está dando prazo expirado.')
                    {                        
                        $info['tecnico']['tipos']['t8'] += 1;
                    }
                    else if($ass[1] == 'Questão ou vídeo com serviço indisponível.')
                    {
                        $info['tecnico']['tipos']['t9'] += 1;
                    }
                    else if($ass[1] == 'Outro.')
                    {
                        $info['tecnico']['tipos']['t10'] += 1;
                    }
                }
            }
        }
        
        //erros por tipo - tecnico
        $info['conteudo']['tipos']['t1'] = 0;
        $info['conteudo']['tipos']['t2'] = 0;
        $info['conteudo']['tipos']['t3'] = 0;
        $info['conteudo']['tipos']['t4'] = 0;
        $info['conteudo']['tipos']['t5'] = 0;      
        foreach($dados['conteudoG'] as $key => $value)
        {
            if($value['Assunto'])
            {
                if(strpos($value['Assunto'], "|"))
                {
                    $ass = explode("|", $value['Assunto']);
                    
                    if($ass[1] == 'Vídeo está com o conteúdo divergente.')
                    {
                        $info['conteudo']['tipos']['t1'] += 1;
                    }
                    else if($ass[1] == 'Questão com gabarito errado.')
                    {
                        $info['conteudo']['tipos']['t2'] += 1;
                    }
                    else if($ass[1] == 'Questão repetida.')
                    {
                        $info['conteudo']['tipos']['t3'] += 1;
                    }
                    else if($ass[1] == "Questão está com erros ortográficos.")
                    {
                        $info['conteudo']['tipos']['t4'] += 1;
                    }
                    else if($ass[1] == 'Outro.')
                    {
                        $info['conteudo']['tipos']['t5'] += 1;
                    }
                }
            }
        }
                        
        $this->load->view('erros_dashboard', $info); 
    }
    
    protected function configuracaoPaginacao( $triagem = false, $filtro_triagem = true ){
        $config = array();
        $config["base_url"] = base_url() . 'mural/erros/';
        
        if ( $filtro_triagem ){
            $config["base_url"] = base_url() . 'mural/triagem/';
        }
        
        $config["total_rows"] = $this->mensagem->record_count( $triagem );
        $config["per_page"] = 30;
        $config["uri_segment"] = 3;
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tagl_close'] = '</a></li>';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tagl_close'] = '</li>';
        $config['first_tag_open'] = '<li class="page-item disabled">';
        $config['first_tagl_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tagl_close'] = '</a></li>';
        $config['attributes'] = array('class' => 'page-link');

        $this->pagination->initialize($config);
    }
    
    
    protected function ajustarRequest(){
        unset($_SESSION['filtroTriagem']);
        $_SESSION['finalizado'] = isset($_SESSION['finalizado'])? $_SESSION['finalizado']:"";
        $_SESSION['indeferido'] = isset($_SESSION['indeferido'])? $_SESSION['indeferido']:"";
        
        if ( isset($_REQUEST['finalizado']) ){
            if ( $_REQUEST['finalizado'] == "sim" ){
                $_SESSION['finalizado'] = $_REQUEST['finalizado'];
            }else{
                unset($_REQUEST['finalizado'], $_SESSION['finalizado']);
            }
        } else {
            $_REQUEST['finalizado'] = $_SESSION['finalizado'];
        }
        
        if ( isset($_REQUEST['indeferido']) ){
            if ( $_REQUEST['indeferido'] == "sim" ){
                $_SESSION['indeferido'] = $_REQUEST['indeferido'];
            }else{
                unset($_REQUEST['indeferido'], $_SESSION['indeferido']);
            }
        } else {
            $_REQUEST['indeferido'] = $_SESSION['indeferido'];
        }
    }
    
}
