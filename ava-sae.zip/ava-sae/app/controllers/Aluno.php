<?php

use Ava\App\Collections\StudentCalendarCollection;
use Ava\App\Collections\StudentCalendarEvent;
use Ava\App\Services\Agendamentos\BuscarAgendamentosPorTurma;
use Ava\App\Services\Agendamentos\BuscarCalendarioPorTurma;
use Ava\App\Services\Agendamentos\ParseDisciplineFromTitle;
use Ava\App\Services\Aluno\BuscarLoginsAlunosResponsaveisPorTurmaNextAva;
use Ava\App\Services\Escola\BuscarDadosEscola;
use Ava\App\Services\Escola\BuscarDadosEscolaNextAva;
use Ava\App\Services\JWT\CreateEducatJWT;
use Ava\App\Services\Relatorios\Helper\Csv2Xls;
use Ava\App\Services\Relatorios\RelatorioAlunosResponsaveisPorEscolaTurma;
use Illuminate\Support\Collection;
use League\Csv\Writer;
use League\Flysystem\Adapter\Local;
use League\Flysystem\Filesystem;
use Ava\App\Services\NextAVA\ProjetoDeVidaNextAVA;

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Aluno extends MY_Controller {

    public $layout = 'new-ava';
    public $title = 'Aluno | AVA';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $keywords = array('sae', 'home');
    public $planoAssinatura;
    /**
    * @var ParseDisciplineFromTitle
    */
    private $parseDisciplineService;
    public function __construct() {
        parent::__construct();
        $this->load->model('curso_model', 'curso');
        $this->load->library('PHPExcel');
        $this->parseDisciplineService = new ParseDisciplineFromTitle();
    }
    /**
     * @param null $id
     * @throws Exception
     */
    public function index($id = null) {
        try {
            $this->allowProfile(PERFIL_ALUNO);
            $redirectTo = $this->session->userdata('RedirectTO', null);
            if ($redirectTo) {
                $this->session->set_userdata('RedirectTO', null);
                header('Location: ' . $redirectTo);
            }
            $this->load->helper('form_cursos');
            
            $dados['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->load->view('view_menu', $dados, true);
            $fields['Login'] = $this->session->userdata('login');
            $dadosUsuario = $this->home->verificaDisciplinas($fields, $this->configuracoes[0]['Base'], 'A');
            foreach ($dadosUsuario as $usuario) {
                $serie = date('Y') == $usuario['VigenciaTurma'] ? $usuario['itemName'] : '';
                $formSerie[$usuario['id']] = $usuario['DescricaoSerie'];
                $data['qrcode_string'] = $usuario['AppQrcode'];
                $data['itemName'] = $usuario['itemName'];
            }
            $extra = array(
                'id' => 'inputSerie',
                'onChange' => 'alteraSerie();',
                'class' => 'form-control',
                'style' => 'margin-left:20px;'
            );
            $data['comboAno'] = form_dropdown('inputSerie', $formSerie, $serie, $extra);

            $turma = $this->session->userdata('teams')[0];
            $agendas = $turma ? SaeDigital::make(BuscarAgendamentosPorTurma::class)->handle($turma->id) : []; 
            $vencidas = array();
            $disponiveis = array();
            if (!empty($agendas)) {
                foreach ($agendas as $disc) {
                    $dataInicio = DateTime::createFromFormat('Y-m-d', $disc['DtInicio']);
                    $dataFim = DateTime::createFromFormat('Y-m-d', $disc['DtFim']);
                    $dataAtual = new DateTime();
                    if ($dataInicio > $dataAtual) {
                        continue;
                    }
                    if ($dataFim < $dataAtual) {
                        $vencidas[] = $disc;
                    } else {
                        $disponiveis[] = $disc;
                    }
                }
                foreach ($disponiveis as $disp) {
                    array_unshift($vencidas, $disp);
                }
                $agendas = $vencidas;
                foreach ($agendas as $agenda) {
                    if (!isset($forms[$agenda['DisciplinaID']]['DescricaoDisciplina'])) {
                        $dadosDisciplina = $this->home->getDescricaoDisciplina($agenda['DisciplinaID']);
                        if (is_array($dadosDisciplina)) {
                            $forms[$agenda['DisciplinaID']]['DescricaoDisciplina'] = $dadosDisciplina[0]['Descricao'];
                            $forms[$agenda['DisciplinaID']]['Ancora'] = $dadosDisciplina[0]['Ancora'];
                            $forms[$agenda['DisciplinaID']]['Classificacao'] = $dadosDisciplina[0]['ClassificacaoID'];
                            $forms[$agenda['DisciplinaID']]['Controller'] = $dadosDisciplina[0]['Controller'];
                        }
                    }
                    $forms[$agenda['DisciplinaID']]['Assuntos'][$agenda['AssuntoID']]['DtFim'] = $agenda['DtFim'];
                }
            }
            //arsort($forms);
            /* AS DISCIPLINAS QUE NÃO PRECISA DE AGENDAMENTO! */
            $disciplinasSemAgendamento = $turma ? $this->home->getDisciplinasPermanentes($turma->grade_id) : [];
            $disciplinasPermanentes = [];
            $arraseNoEnem = [];
            /*
             * Vamos separar as disciplinas do arrase no enem, elas precisam ser exibidas agrupadas.
             */
            foreach ($disciplinasSemAgendamento as $disciplinaItem) {
                if (strpos(mb_strtolower($disciplinaItem['Descricao']), 'arrase no enem') !== false) {
                    $arraseNoEnem[$disciplinaItem['id']] = [
                        'DescricaoDisciplina' => $disciplinaItem['Descricao'],
                        'Ancora' => $disciplinaItem['Ancora'],
                        'DataInicio' => $disciplinaItem['DtInicio'],
                        'DataFim' => $disciplinaItem['DtFim'],
                        'Classificacao' => $disciplinaItem['ClassificacaoID'],
                        'Controller' => $disciplinaItem['Controller'],
                    ];
                } else {
                    $disciplinasPermanentes[] = $disciplinaItem;
                }
            }
            if (!empty($disciplinasPermanentes)) {
                foreach ($disciplinasPermanentes as $permanente) {
                    if (strpos($permanente['Descricao'], 'Acesso')) {
                        if (($this->session->userdata('school')->itemName == 'fd1d73cdc6d0fff603dd59e3a43cb8c1')) {
                            $forms[$permanente['id']]['DescricaoDisciplina'] = $permanente['Descricao'];
                            $forms[$permanente['id']]['Ancora'] = $permanente['Ancora'];
                            $forms[$permanente['id']]['DataInicio'] = $permanente['DtInicio'];
                            $forms[$permanente['id']]['DataFim'] = $permanente['DtFim'];
                            $forms[$permanente['id']]['Classificacao'] = $permanente['ClassificacaoID'];
                            $forms[$permanente['id']]['Controller'] = $permanente['Controller'];
                        }
                    } else {
                        $forms[$permanente['id']]['DescricaoDisciplina'] = $permanente['Descricao'];
                        $forms[$permanente['id']]['Ancora'] = $permanente['Ancora'];
                        $forms[$permanente['id']]['DataInicio'] = $permanente['DtInicio'];
                        $forms[$permanente['id']]['DataFim'] = $permanente['DtFim'];
                        $forms[$permanente['id']]['Classificacao'] = $permanente['ClassificacaoID'];
                        $forms[$permanente['id']]['Controller'] = $permanente['Controller'];
                    }
                }
            }
            krsort($arraseNoEnem);
            $data['formCursos'] = newFormCurso($forms, $turma->id);
            $data['arraseNoEnem'] = newFormCurso($arraseNoEnem, $turma->id);
            //$data['boxVideo'] = $this->home->verificaProgramadaSemana();
            $this->session->set_userdata('siteID', $data['boxVideo'][0]['id']);
            //FIXME: Simulado 2017
            $mostraSimulado = false;
            $serieAluno = intval($turma->grade_id);
            if ($serieAluno >= 10) {
                $mostraSimulado = true;
            }
            $perfilid = $this->session->userdata('perfil');
            $data["perfil"] = $perfilid;
            $data["mostraSimulado"] = $mostraSimulado;


            /**
             * Start calendar events
             *
             * 1 - Get data from D024_Ava_Sae_agenda.
             * 2 - Make objects from return data.
             * 3 - Serialize to json to parse in JS.
             */
            $data["events"] = [];

            $agendamentos = SaeDigital::make(BuscarCalendarioPorTurma::class)->handle($turma->id);

            $events = new StudentCalendarCollection();

            array_walk($agendamentos, function ($agendamento) use ($events) {
                $startDate = new DateTime($agendamento['DtInicio']);
                $endDate = new DateTime($agendamento['DtFim']);
                $events->push(new StudentCalendarEvent(
                    // $this->parseDisciplineService->handle($agendamento['DisciplinaDescricao']),
                    $agendamento['DisciplinaDescricao'],
                    true,
                    $endDate,
                    $endDate,
                    $agendamento['AgendaID'],
                    [
                        'StartDate' => $startDate->format('d/m/Y'),
                        'EndDate' => $endDate->format('d/m/Y'),
                        'AssuntoDescricao' => $agendamento['AssuntoDescricao'],
                        'TurmaDescricao' => $agendamento['TurmaDescricao']
                    ]
                ));
            });

            $data['events'] = $events->toJson();
            $notificacoes = $this->session->userdata('notificacoes');
            $data['notificacoes'] = collect($notificacoes)
                ->groupBy('tipo_notificacao_id')->map(function (Collection $notificacao) {
                    return [
                        'descricao' => $notificacao->first()['descricao'],
                        'login' => $notificacao->first()['login'],
                        'notificacoes' => $notificacao->toArray()
                    ];
                })->toArray();

            # EDUCAT
            # Not allowed series
            if (in_array($serieAluno, [1, 2, 3, 14, 15, 16, 17, 18, 19])) {
                $showBanner = false;
            } else {
                $showBanner = boolval(getenv('EDUCAT_SHOW_BANNER', false));
            }

            $data['educatShowBanner'] = $showBanner;
            $data['educatSignedUrl'] = SaeDigital::make(CreateEducatJWT::class)->generateUrl($this->session->userdata('pessoaid'));

            # AULAO ESPECIAL

            if (in_array($serieAluno, [1, 2, 3, 4, 5, 6, 7, 8, 9, 14, 15, 16, 17, 18, 19])) {
                $data['aulaoShowBanner'] = false;
            }

            $aulaoDateLimit = \Carbon\Carbon::create(2020, 06, 19, 16, 00);
            $datetimeNow = \Carbon\Carbon::now();

            if ($datetimeNow->lessThan($aulaoDateLimit) && in_array($serieAluno, [10, 11, 12, 13, 20])) {
                $data['aulaoShowBanner'] = true;
            }

            $haveAccess = SaeDigital::make(ProjetoDeVidaNextAVA::class)->HaveAccess($this->session->userData('token'));
            
            $data['haveAccess'] = $haveAccess;

            $this->load->view('mochila-do-aluno', $data);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function exportarAlunos()
    {
        $this->layout = '';
        try {
            $idEscola = $this->input->get('idEscola');
            $turmas = $this->input->get('turmas');

            // $escola = SaeDigital::make(BuscarDadosEscola::class)->handle($idEscola);
            $escola = SaeDigital::make(BuscarDadosEscolaNextAva::class)->get($idEscola);

            $nomeArquivo = $escola->name . ' - ' . date('d-m-Y');
            // $relatorio = SaeDigital::make(RelatorioAlunosResponsaveisPorEscolaTurma::class)->handle($idEscola, $turmas);
            $relatorio = SaeDigital::make(BuscarLoginsAlunosResponsaveisPorTurmaNextAva::class)->handle($turmas);

            $objPHPExcel = $this->phpexcel;

            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'Nome Aluno');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B1', 'Login Aluno');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', 'Email Aluno');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D1', 'Nome Responsável');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E1', 'Login Responsável');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F1', 'Email Responsável');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G1', 'Turma');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H1', 'Serie');

            $count_foreach = 2;

            foreach($relatorio as $aluno){
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$count_foreach, ($aluno->student_name));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$count_foreach, ($aluno->student_login));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$count_foreach, ($aluno->student_email));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$count_foreach, ($aluno->responsible_name));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.$count_foreach, ($aluno->responsible_login));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$count_foreach, ($aluno->responsible_email));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$count_foreach, ($aluno->team_name));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$count_foreach, ($aluno->grade_name));

                $count_foreach ++;
            }

            // Miscellaneous glyphs, UTF-8
            // Renomeia a worksheet
            $objPHPExcel->getActiveSheet()->setTitle('Exportação');
            // Define qual a worksheet estará ativa ao abrir o arquivo
            $objPHPExcel->setActiveSheetIndex(0);
            // Salva o arquivo no formato do Excel 2007 (.xlsx)
            // We'll be outputting an excel file
            header('Content-type: application/vnd.ms-excel');
            header('Content-Disposition: attachment; filename="'.$nomeArquivo.'.xls"');
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
            $objWriter->save('php://output');
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function search($array, $key, $value)
    {

        if (!is_array($value)) {
            return;
        }

        $results = array();
        foreach ($value as $key2) {
            $this->search_r($array, $key, $key2, $results);
        }
        return $results;
    }

    function search_r($array, $key, $value, &$results)
    {
        if (!is_array($array)) {
            return;
        }

        if (isset($array[$key]) && $array[$key] == $value) {
            $results[] = $array;
        }

        foreach ($array as $subarray) {
            $this->search_r($subarray, $key, $value, $results);
        }
    }
}

/* End of file home.php */
/* Location: ./application/controllers/home.php */
