<?php

use Ava\App\Support\Perfil;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Importacao extends MY_Controller {

    public $layout = 'default';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    //public $css = array('bootstrap', '_reset', 'css-responsive','geral', 'messi');

    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.maskedinput.min', /* 'mensagem', */ 'jquery.cookie', 'jquery.dataTables', 'cadastro');
    public $keywords = array('sae', 'curso');

    public function __construct()
    {
        try {
            parent::__construct();
            $this->allowProfile([Perfil::ADMIN]);

            $this->ava = $this->load->database('ava', TRUE);

            $this->cssMinify = array('bootstrap-new.min', 'bootstrap', '_reset', 'geral', 'messi', 'mensagem');
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function index() 
    {
        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';

        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        $this->css[] = $this->minify->getCSS('cadastro_escola_lista.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $this->load->view('importacao_home', $dados);
    }
    
    public function ProcessaImportacao()
    {
        $pacote = $this->input->post("pacote", true);
        
        $this->ApagaRegistrosSimpleDB($pacote);                
        $this->InativaQuestoes($pacote);
        $this->ReconstroiEstrutura($pacote);
    }
    
    public function ApagaRegistrosSimpleDB($grupoID)
    {
    }
    
    public function InativaQuestoes($grupoID)
    {
        $query = "select EstruturaAulaID from E358_EstruturaAulasQuestoes where GrupoAulaiD = '". $grupoID ."'";
        
        $questoes = $this->ava->query($query)->result();
        
        if($questoes)
        {
            for ($i = 0; $i < count($questoes) ; $i++) 
            {
                $this->ava->set('Situacao', 'I');
                $this->ava->where('EstruturaAulaID', $questoes[$i]->EstruturaAulaID);
                $this->ava->update('E359_AulaQuestoes');
            }
        }
    }
    
    public function ReconstroiEstrutura($grupoID)
    {
        //$url = "http://integracaoavasdb.aprovaconcursos.com.br/grupoaulas/insereEstruturasSae/". $grupoID;
        $url = "http://integracao_ava_aprovaconcursos.programador04.dev.iesde.com.br/grupoaulas/insereEstruturasSae/". $grupoID;
        
        $curl = curl_init();    
        curl_setopt($curl, CURLOPT_URL, $url); 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($curl, CURLOPT_HEADER, 0); 
        curl_setopt($curl, CURLOPT_HTTPGET, 1); 
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        
        $output = curl_exec($curl);       
    }
}