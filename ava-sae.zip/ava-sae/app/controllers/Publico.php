<?php 
if (! defined('BASEPATH'))
    exit('No direct script access allowed');

class Publico extends My_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * http://example.com/index.php/welcome
     * - or -
     * http://example.com/index.php/welcome/index
     * - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * 
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public $layout = 'default';

    public $title = 'AVA SAE';

    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    public $cssMinify = array('bootstrap', '_reset', 'geral', 'messi');

    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.cookie');

    public $keywords = array('sae', 'videoaulas');

    public $configuracoes;

    public $sdb;

    public $menu_vertical = '';

    public function __construct()
    {
    	parent::__construct();        
    }
    
    /**
     * Vídeo
     *
     * Exibe a página inicial de vídeo da disciplina.
     *
     * @param string $Ancora determinanda qual é a identificador da disciplina
     * @access	public
     * @return	void
     */
    public function video($Ancora = null) {
    
    	$this->layout = '';
    	$linkVideoaula = 'sae_digital_questoes_enem/' . $Ancora . '.mp4';
    	
    	$this->session->set_userdata('link_video_aula', $linkVideoaula);
    
   		if ($this->agent->is_mobile() ||  ($this->agent->browser() == 'Firefox' && $this->agent->version() >= 11) || ($this->agent->browser() == 'Chrome' && $this->agent->version() >= 25) || ($this->agent->browser() == 'Safari' && $this->agent->version() >= 6)  ) { // true
   			$data['tipo'] = 'playerHTML5';
   		} else {
   			$data['tipo'] = 'player';
   		}
		$this->load->view('video_publico', $data);
    }

    public function health()
    {
        try {
            $start = microtime(true);

            /** @var PDO $pdo */
            $pdo = SaeDigital::make(PDO::class);
            $stmt = $pdo->prepare('SELECT NOW() now;');
            $stmt->execute();
            $now = $stmt->fetch(PDO::FETCH_ASSOC);

            $end = microtime(true);

            return $this->responseJson([
                'status' => 'success',
                'data' => [
                    'now' => $now['now'],
                    'transaction_start' => $start,
                    'transaction_end' => $end,
                    'execution_time' => $end - $start
                ]
            ], 200);
        } catch (Exception $e) {
            return $this->responseJson([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 500);
        }
    }
    
}