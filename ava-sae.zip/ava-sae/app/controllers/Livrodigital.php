<?php

use Ava\App\Services\LivroDigital\ListarLinksLivroDigital;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Livrodigital extends MY_Controller {

    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $cssMinify = array('style_avasae_bootstrap3', 'mensagem');
    public $css = array('mensagem');
    public $js = array('jquery/dist/jquery.min', 'bootstrap/dist/js/bootstrap.min', 'livrodigital', 'jquery.cookie', 'mensagem');
    public $keywords = array('avasae', 'curso');
    public $metaAcertos = 0;
    public $teste;

    public function __construct() {

        parent::__construct();

        $this->load->model('livrodigital_model', 'livrodigital');

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $dados['menu_com_legenda'] = false;

        $this->menu_vertical = $this->load->view('view_menurelatorio', $dados, true);

        $this->teste = new ArrayObject();
    }

    function index()
    {
        $this->css[] = $this->minify->getCSS('relatorio_desempenhogeral.min', $this->cssMinify, ENVIRONMENT);

        $this->load->view('livrodigital', []);
    }

    private function validaOS($userOs, $linkOs)
    {
        return $userOs == $linkOs;
    }

    private function validaArquitetura($userArq, $linkArq)
    {
        return $userArq == $linkArq;
    }

    public function buscarLinksLivroDigital()
    {
        try {
            $this->layout = false;

            $os = strtolower($this->input->get('os'));
            $arq = $this->input->get('arquitetura');

            $links = SaeDigital::make(ListarLinksLivroDigital::class)->handle();

            foreach ($links as $key => $link) {
                $sistema = $this->validaOS($os, $link['sistema_operacional']);
                $arquitetura = $this->validaArquitetura($arq, $link['arquitetura']);

                if (($sistema && $arquitetura) || ($sistema && $os === 'os x')) {
                    $links[$key]['destaque'] = true;
                }
            }

            $data['links'] = $links;

            return $this->responseJson($data, 200);
        } catch (Exception $e) {
            return $this->responseJson([
                'message' => 'Ocorreu um erro ao listar links, por favor tente novamente'
            ], 500);
        }
    }

    /**
     * index - [página principal área logada]
     *
     * Exibe a página inicial do usuário quando logado. 
     *
     * @access	public
     * @return	void
     */
    function dispositivos() {
        $this->css[] = $this->minify->getCSS('relatorio_desempenhogeral.min', $this->cssMinify, ENVIRONMENT);


        $usuario = $this->session->userdata('pessoaid');

        $dados['dispositivos'] = $this->livrodigital->buscaDispositivos($usuario);

        //print_pre($dados);die;

        $this->load->view('dispositivos', $dados);
    }

    function excluiDispositivo($id = '') {
        extract($_POST);
        
        $dados['DtAlt'] = date('Y-m-d H:i:s');
        $dados['Situacao'] = 'I';

        $result = $this->livrodigital->excluiDispositivo($dados, $itemName);

        if ($result) {
            print(1);
        } else {
            print(0);
        }
        die();
    }

}

/* End of file home.php */
/* Location: ./application/controllers/home.php */
