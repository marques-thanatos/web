<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Acesso extends MY_Controller {

    public $layout = 'default';
    public $title = 'AVA SAE - Controle de Acesso';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.maskedinput.min', /* 'mensagem', */ 'jquery.cookie', 'jquery.dataTables', 'cadastro');
    public $keywords = array('sae', 'curso');

    public function __construct() {

        parent::__construct(); 
        
        $this->load->model('Log_model', 'log');
        
        $this->ava = $this->load->database('ava', TRUE);

        $this->cssMinify = array('bootstrap-new.min', 'bootstrap', '_reset', 'geral', 'messi', 'mensagem');
    }

    public function index() 
    {
        $this->cssMinify[] = 'jquery-ui';        
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        
        
        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        $this->css[] = $this->minify->getCSS('cadastro_escola_lista.min', $this->cssMinify, ENVIRONMENT);
        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);          
       
        $this->load->view('importacao_home', $dados);
    }        
}