<?php

use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Services\ArraseNoEnem\BuscarDisciplinaArraseNoEnemPorTurma;
use Ava\App\Services\AudioLinguaEstrangeira\BuscarDisciplinaAudioPorTurma;
use Ava\App\Services\PlataformaLiteraria\BuscarDisciplinaLiterariaPorTurma;
use Ava\App\Services\Turma\BuscarTurmaPorAluno;
use Ava\App\Support\Perfil;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class RedirectController extends MY_Controller
{

    /** @var bool */
    public $layout = false;

    /**
     * Redireciona o usuário para plataforma-literaria
     * @return string
     */
    public function plataformaLiteraria()
    {
        try {
            $this->allowProfile([Perfil::ALUNO]);

            $userId = $this->session->userdata('pessoaid');
            $userSerie = $this->session->userdata('Serie');
            $contentVersion = $this->session->userdata('versao_conteudo_id');

            if ($userSerie > 9)
                throw new NotAllowedException();

            /** @var BuscarTurmaPorAluno $teamService */
            $teamService = SaeDigital::make(BuscarTurmaPorAluno::class);
            $team = $teamService->handle($userId);

            /** @var BuscarDisciplinaLiterariaPorTurma $componentsService */
            $componentsService = SaeDigital::make(BuscarDisciplinaLiterariaPorTurma::class);
            $component = $componentsService->handle($team['itemName'], $contentVersion);

            $url = "/curso-plataforma-literaria/{$component['Ancora']}?turmaID={$team['itemName']}";

            $this->redirect($url);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão de acesso a este conteúdo.'
            ]);
        }
    }

    /**
     * Redireciona o usuário para plataforma-literaria
     * @return string
     */
    public function arraseNoEnem()
    {
        try {
            $this->allowProfile([Perfil::ALUNO]);

            $userId = $this->session->userdata('pessoaid');
            $userSerie = $this->session->userdata('Serie');
            $contentVersion = $this->session->userdata('versao_conteudo_id');

            if (!in_array($userSerie, [10, 11, 12, 13, 20, 21]))
                throw new NotAllowedException();

            /** @var BuscarTurmaPorAluno $teamService */
            $teamService = SaeDigital::make(BuscarTurmaPorAluno::class);
            $team = $teamService->handle($userId);

            /** @var BuscarDisciplinaArraseNoEnemPorTurma $componentsService */
            $componentsService = SaeDigital::make(BuscarDisciplinaArraseNoEnemPorTurma::class);
            $component = $componentsService->handle($team['itemName'], $contentVersion);

            $url = "/preparatorio/{$component['Ancora']}?turmaID={$team['itemName']}";

            $this->redirect($url);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão de acesso a este conteúdo.'
            ]);
        }
    }

    /**
     * Redireciona o usuário para plataforma-literaria
     * @return string
     */
    public function audiosLinguaEstrangeira()
    {
        try {
            $this->allowProfile([Perfil::ALUNO]);

            $userId = $this->session->userdata('pessoaid');
            $contentVersion = $this->session->userdata('versao_conteudo_id');

            /** @var BuscarTurmaPorAluno $teamService */
            $teamService = SaeDigital::make(BuscarTurmaPorAluno::class);
            $team = $teamService->handle($userId);

            /** @var BuscarDisciplinaAudioPorTurma $componentsService */
            $componentsService = SaeDigital::make(BuscarDisciplinaAudioPorTurma::class);
            $component = $componentsService->handle($team['itemName'], $contentVersion);

            $url = "/preparatorio/{$component['Ancora']}?turmaID={$team['itemName']}";

            $this->redirect($url);
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão de acesso a este conteúdo.'
            ]);
        }
    }
}
