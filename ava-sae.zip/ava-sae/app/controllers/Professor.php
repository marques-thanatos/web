<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Professor extends MY_Controller {

    public $layout = 'new-ava';
    public $title = 'Pasta do professor | AVA';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    //public $css = array('bootstrap', '_reset', 'css-responsive', 'geral', 'messi', 'home');                               
    //public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'flowplayer-3.2.12.min', 'geral_v5', 'messi.min', 'home_v10.min', 'mensagem');
    public $keywords = array('sae', 'home');

    public function __construct() {

        parent::__construct();

        $this->load->model('curso_model', 'curso');

        // define os arquivos para juntar e comprimir
        // $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'home', 'mensagem');
        // $this->css[] =  $this->minify->getCSS('home_construct.min', $this->cssMinify, ENVIRONMENT);
    }

    /**
     * index - [página principal área logada]
     * Exibe a página inicial do usuário quando logado.
     *
     * @access	public
     * @return	void
     */
    public function index($id = null) {

        $this->js[] = 'jquery.countdown.min';

        $this->load->helper('form_cursos');

        $mValorPago[] = 0;
        $fields['id'] = $id;
        $fields['Login'] = $this->session->userdata('login');

        $retornoVerificaPacotes = $this->home->verificaDisciplinas($fields, $this->configuracoes[0]['Base'],$this->configuracoes[0]['id']);
        $pacotes = array();
        $formAssinatura='';
        $formCursos='';
        $valorMaiorPacote = 0;
        $data['comboAno'] = '';
        $vigencia = 0;
        if (!empty($retornoVerificaPacotes)) {
            foreach($retornoVerificaPacotes as $key => $value) {
                $grupoAula = $this->home->verificaGrupoAulaProf($value['Disciplina']);

                if (!empty($grupoAula)) {
                    $dadosGrupoAula = $this->curso->verificaVideoAulasDisciplina($grupoAula[0]['id']);

                    $value['Controller'] = $grupoAula[0]['Controller'];
                    $value['QtdPacotesSimultaneos'] = isset($grupoAula[0]['QtdAcessosSimultaneos']) ? $grupoAula[0]['QtdAcessosSimultaneos'] : '';
                    $value['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];
                    $value['Ancora'] = $grupoAula[0]['Ancora'];
                    $value['Duracao'] = $grupoAula[0]['Duracao'];
                    //retira 1 da contagem pois a primeira possicao do array e o nome da disciplina
                    $value['QtdAssuntos'] = count(reset($dadosGrupoAula))-1;

                    $value['DescricaoPacote'] = $grupoAula[0]['Descricao'];

                    // Antiga lógica da view
                    $DiasRestantesPacote = '';
                    $DiasRestantesBoleto = '';
                    $dtInicioPacote = '';
                    $dtFimPacote = '';
                    $value['linkCurso'] =  '';
                    $value['btnIniciar'] = 2;
                    $value['imprimeBoleto'] = 0;
                    $value['bloqueado'] = '';

                    if (isset($value['Ancora']) && !empty($value['Ancora']) /*&& $value['Rec'] != 'N'*/) {
                        $value['linkCurso'] = base_url() . $value['Controller'] .'/' . trim($value['Ancora']);
                        if ($this->session->userdata('situacaoSessao') == 'I') {
                            $value['linkCurso'] = 'javascript:void(0)';
                            $value['btnIniciar'] = 3;
                        }
                    }

                    $formCursos .= form_home(2, $key, $value,$this);
                }
            }
        }

        //salva o cookie dos pacotes para ser usado nas mensagens
        $cookie = array(
            'name'   => 'pacotes'.$this->session->userdata('id'),
            'value'  => json_encode($pacotes),
            'expire' => 14400,
            'domain' => '',
            'secure' => FALSE
        );
        $this->input->set_cookie($cookie);

        $data['formCursos'] = $formCursos;
        $data['formAssinatura'] = $formAssinatura;
        $data['boxNoticias'] = $this->home->verificaNoticias();
        //$data['boxVideo'] = $this->home->verificaProgramadaSemana();
        $this->session->set_userdata('siteID', $data['boxVideo'][0]['id']);
        $this->load->view('pasta-do-professor', $data);
    }

    function search($array, $key, $value) {

        if (!is_array($value)) {
            return;
        }

        $results = array();
        foreach ($value as $key2) {
            $this->search_r($array, $key, $key2, $results);
        }
        return $results;
    }

    function search_r($array, $key, $value, &$results) {
        if (!is_array($array)) {
            return;
        }

        if (isset($array[$key]) && $array[$key] == $value) {
            $results[] = $array;
        }

        foreach ($array as $subarray) {
            $this->search_r($subarray, $key, $value, $results);
        }
    }
}

/* End of file home.php */
/* Location: ./application/controllers/home.php */
