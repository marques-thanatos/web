<?php

use Ava\App\Services\Cadastro\UsuarioPrimeiroIDAtivo;
use Ava\App\Services\LivroDigital\BuscarAcessoLivroDigitalPorLogin;
use Ava\App\Services\Notificacoes\ListarNotificacoes;
use Ava\App\Services\Token\TokenApi;
use Ava\App\Services\Usuario\EnqueueDeletarUsuarioPortal;
use Ava\App\Services\Usuario\AceitarTermosUso;
use Ava\App\Services\Usuario\BuscarUsuarioPorItemName;
use Ava\App\Services\Usuario\ObterUsuarioNextAva;
use Ava\App\Support\Perfil;
use SebastianBergmann\Exporter\Exporter;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

    
class loginSso extends CI_Controller
{
    public $layout = 'new-ava';

    public $title = 'AVA SAE';

    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.cookie');

    public $keywords = array('sae', 'login');

    public $configuracoes;

    public $sdb;

    public $menu_vertical = '';
    
    public function __construct()
    {
        parent::__construct();

        SaeDigital::make(\Ava\App\Services\Monitoramento\Sentry::class)->handle();
    }

    /**
     * Verifica acesso usu?rio login
     *
     * Verifica se o usu?rio e senha informados na tela incial
     * login s?o v?lidos, se acordo com o par?metro recebido via $_POST
     *
     * @access public
     * @param
     *            integer - Usuário informado.
     * @param
     *            integer - Senha informado.
     * @return int
     */
    public function verifica($token) {

        // $t0 -> tN = Variables to track time on external interactions
        $t0 = microtime(true);
        $this->layout = '';
        $resposta = new stdClass();
        $post = $this->input->post(NULL, TRUE);
        extract($post);
        $data = [ 'sso' => $token, 'user' => $usuario, 'pwd' => $_POST['senha'] ];
        $client = new \GuzzleHttp\Client();
        try {
            $url = getenv('SAEAPIS_URL')."auth/sso-login";
            $res = $client->post($url, [
                'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
                'body' => json_encode($data)
            ]);
        } catch( \GuzzleHttp\Exception\ServerException $e ) {
            $resposta->t1 = microtime(true) - $t0;
            $resposta->resposta = 2;
            print_r(json_encode($resposta));
            die;
        }
        $dadosLogin = json_decode($res->getBody());
        $token = $dadosLogin->token;
        $resposta->t1 = microtime(true) - $t0;
        setcookie('userToken',$token,time() + 2*7*24*60*60,'/');
        try {
            $userData = SaeDigital::make(ObterUsuarioNextAva::class)->handle($token);
        } catch( Exception $e ) {
            $resposta->resposta = 5;
            print_r(json_encode($resposta));
            die;
        }

        $resposta->t2 = microtime(true) - $t0;

        // dd($userData);
        $mixPanelData = [
            'login' => $userData->login,
            'name' => $userData->nome,
            'profile' => $userData->perfil,
            'scholl_name' => $userData->nomeEscola,
            'school_id' => $userData->escola,
            'email' => $userData->email,
            'id' => $userData->id
        ];

        $resposta->userData = $mixPanelData;

        if($userData || $this->session->userdata('logado')) {
            if($userData->termo_aceite == false) {
                $arrayDados = (array) $userData;
                $this->session->set_userdata('id', $arrayDados['id']);
                
                $resposta->t3 = microtime(true) - $t0;
                $resposta->resposta = -2;
                $resposta->redirect = 'TermoAceite';
                print_r(json_encode($resposta));
                die;
            } else {
                if($dadosLogin->first_login == true) {
                    $this->session->set_userdata('token', $token);
                    $this->session->set_flashdata('login', $usuario);

                    $resposta->t3 = microtime(true) - $t0;
                    $resposta->resposta = 11;
                    $resposta->redirect = 'cadastro/cadDadosPrimeiroLogin/';
                    print_r(json_encode($resposta));
                    die;
                } else {
                    $resposta->resposta = 1;
                    $this->session->set_userdata('token', $token);
                    $this->session->set_userdata('login', $usuario);

                    $resposta->t3 = microtime(true) - $t0;
                    $resposta->redirect = $userData->redirecionar;
                    $redirectTo = $userData->redirecionar;
                    $arrayDados = (array) $userData;
                    if($userData->perfil == Perfil::PROFESSOR || $userData->perfil  == Perfil::COORDENADOR) {
                        setcookie('itemName', $userData->pessoaid,time() + 2*7*24*60*60,'/','sae.digital', false);
                        setcookie('escola', $userData->nomeEscola,time() + 2*7*24*60*60,'/','sae.digital', false);
                        setcookie('escolaid',$arrayDados['school']->itemName,time() + 2*7*24*60*60,'/','sae.digital', false);
                        setcookie('perfil',$userData->perfil,time() + 2*7*24*60*60,'/','sae.digital', false);
                    }
                    $this->session->set_userdata('RedirectTO', $redirectTo);
                    $this->session->set_userdata($arrayDados);
                    $this->session->set_userdata('escola', $arrayDados['school']->itemName);
                    $this->session->set_userdata('Serie', $arrayDados['teams'][0]->grade_id);
                    $this->session->set_userdata('logado', TRUE);

                    $log['loginid'] = $this->session->userdata['pessoaid'];
                    $log['login'] = $this->session->userdata['login'];
                    $log['acao'] = 'Logou no sistema';
                    $log['nomeescola'] = utf8_encode($this->session->userdata['nomeEscola']);
                    $log['escola'] = utf8_encode($this->session->userdata['escola']);
                    $log['codigo'] = '1'; //Login

                    $this->load->model('Log_model', 'logacesso');

                    $this->logacesso->GravaLog($log);
                    
                    print_r(json_encode($resposta));
                    die;
                }
            }
        }

        if (stripos(@$_SERVER['HTTP_REFERER'], 'www.aprovaconcursos.com.br') || 
            stripos(@$_SERVER['HTTP_REFERER'], 'lab.iesde.com.br') || 
            stripos(@$_SERVER['HTTP_REFERER'], 'www.portalava.com.br') || 
            stripos(@$_SERVER['HTTP_REFERER'], 'academy.mundopm.com.br')
        ) {

            if ($resposta->resposta == 10) {
                $this->logoutControleAcesso('S');
                $this->session->set_userdata('situacaoSessao', 'A');
            }
            header('Location: http://ava.aprovaconcursos.com.br/');

        } else {
            $redirectToOpenIssue = $this->input->get('redirect_to', null);

            if (isset($avasae)) {
                die('<script>window.location = "/' . $redirecionar . '"</script>');
            } else {
                print_r(json_encode($resposta));
            }
        }
    }

    public function loginNextAva() {
        $user = $this->input->post('user');
        $pass = $this->input->post('pwd');

        $body['user'] = $user;
        $body['pwd'] = $pass;

        $data = array(
            'user' => $user,
            'pwd' => $pass
         );

        $client = new \GuzzleHttp\Client();

        $url = getenv('SAEAPIS_URL')."auth/login";

        $res = $client->post($url, [
            'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
             'body' => json_encode($data)
            ]);

        $token = json_decode($res->getBody())->token;
        print_r($token);
    }

    public function retornarUserFromItemName() {
        $itemName = $this->input->get('itemName');

        header('Content-Type: application/json');
        http_response_code(200);

        $this->layout = false;
        $login = SaeDigital::make(BuscarUsuarioPorItemName::class)->handle($itemName)['Login'];

        echo json_encode(array('user'=> $login));
    }
}