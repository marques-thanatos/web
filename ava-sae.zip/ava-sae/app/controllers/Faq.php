<?php

use Ava\App\Exceptions\DuplicatedEntryException;
use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Exceptions\NotFoundException;
use Ava\App\Services\Faq\AdicionaFaqNaCategoria;
use Ava\App\Services\Faq\AdicionarFaq;
use Ava\App\Services\Faq\ListarCategorias;
use Ava\App\Services\Faq\ListarFaqs;
use Ava\App\Services\Faq\PegarCategoriasPorFaqId;
use Ava\App\Services\Faq\PegarFaqPorPergunta;
use Ava\App\Services\Faq\RemoveFaqDaCategoria;
use Ava\App\Services\Faq\SalvarFaq;
use Ava\App\Support\Perfil;

class Faq extends MY_Controller
{
    /** @var Twig_Environment $twig */
    private $twig;

    public function __construct()
    {
        parent::__construct();
        $this->layout = false;

        $this->twig = SaeDigital::make('twig');
    }

    public function index()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            echo $this->twig->render('plataforma/faq/index.html.twig', [
                'name' => $this->security->get_csrf_token_name(),
                'hash' => $this->security->get_csrf_hash()
            ]);
        } catch (NotAllowedException $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function getCategories()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $categories = SaeDigital::make(ListarCategorias::class)->handle();

            if (empty($categories)) {
                throw new NotFoundException('Nenhuma categoria encontrada');
            }

            return $this->responseJson($categories, 200);
        } catch (NotAllowedException $e) {
            return $this->responseJson(['message' => 'Acesso não permitido'], 401);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        }
    }

    public function getFaqList()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $faq = SaeDigital::make(ListarFaqs::class)->handle();

            if (empty($faq)) {
                throw new NotFoundException('Nenhum FAQ encontrado');
            }

            return $this->responseJson($faq, 200);
        } catch (NotAllowedException $e) {
            return $this->responseJson(['message' => 'Acesso não permitido'], 401);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        }
    }

    public function changeFaqStatus()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            SaeDigital::make(SalvarFaq::class)->handle(
                ['ativo' => $this->input->post('ativo') === 'true'],
                ['id' => (int)$this->input->post('id')]
            );

            return $this->responseJson(['message' => 'Status do faq atualizado'], 200);
        } catch (NotAllowedException $e) {
            return $this->responseJson(['message' => 'Acesso não permitido'], 401);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        }
    }

    public function saveFaq()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            SaeDigital::make(PDO::class)->beginTransaction();

            $faq = [
                'pergunta' => html_entity_decode(trim($_POST['pergunta'])),
                'resposta' => html_entity_decode(trim($_POST['resposta'])),
                'ativo' => $this->input->post('faq_ativo') === 'true'
            ];

            $validarDuplicidade = SaeDigital::make(PegarFaqPorPergunta::class)->handle($faq['pergunta']);

            if (!empty($validarDuplicidade) && $validarDuplicidade[0]['id'] !== $this->input->post('id')) {
                throw new DuplicatedEntryException('Essa pergunta já esta cadastrada!');
            }

            $categoriesToUpdate = explode(',', trim($this->input->post('categoria')));

            SaeDigital::make(RemoveFaqDaCategoria::class)->handle($this->input->post('id'), $categoriesToUpdate);
            SaeDigital::make(AdicionaFaqNaCategoria::class)->handle($this->input->post('id'), $categoriesToUpdate);
            SaeDigital::make(SalvarFaq::class)->handle($faq, ['id' => (int)$this->input->post('id')]);

            SaeDigital::make(PDO::class)->commit();

            return $this->responseJson(['message' => 'FAQ atualizado'], 200);
        } catch (NotAllowedException $e) {
            return $this->responseJson(['message' => 'Acesso não permitido'], 401);
        } catch (DuplicatedEntryException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 400);
        } catch (PDOException $e) {
            SaeDigital::make(PDO::class)->rollBack();
            return $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }

    public function createFaq()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            SaeDigital::make(PDO::class)->beginTransaction();

            $faq = [
                'pergunta' => html_entity_decode(trim($_POST['pergunta'])),
                'resposta' => html_entity_decode(trim($_POST['resposta'])),
                'ativo' => $this->input->post('faq_ativo') === 'true',
                'criado_em' => (new DateTime())->format('Y-m-d H:i:s'),
                'responsavel_id' => $this->session->userdata('id'),

            ];

            $validarDuplicidade = SaeDigital::make(PegarFaqPorPergunta::class)->handle($faq['pergunta']);

            if (!empty($validarDuplicidade)) {
                throw new DuplicatedEntryException('Essa pergunta já esta cadastrada!');
            }

            $categories = explode(',', trim($this->input->post('categoria')));

            $faqId = SaeDigital::make(AdicionarFaq::class)->handle($faq);

            SaeDigital::make(AdicionaFaqNaCategoria::class)->handle($faqId, $categories);

            SaeDigital::make(PDO::class)->commit();

            return $this->responseJson(['message' => 'FAQ criado'], 200);
        } catch (NotAllowedException $e) {
            return $this->responseJson(['message' => 'Acesso não permitido'], 401);
        } catch (DuplicatedEntryException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 400);
        } catch (PDOException $e) {
            SaeDigital::make(PDO::class)->rollBack();
            return $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }
}