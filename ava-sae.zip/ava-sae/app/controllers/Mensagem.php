<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Mensagem (ISO-8859-1)
 * Created: 18/11/2013
 * 
 * @author Maria C. Dadalt
 */
class Mensagem extends CI_Controller {

    public $layout = 'default';
    public $title = 'Mural de Recados';
    public $description = '';
    //public $css = array('bootstrap', '_reset', 'css-responsive', 'geral', 'messi');
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.maskedinput.min', 'curso.min', 'mensagem','jquery.cookie');
    public $keywords = array('sae', 'mensagem');
    public $menu_vertical = '';
    public $configuracoes;
    public $css;

    //put your code here
    public function __construct() {
        parent::__construct();

      
        $this->load->model('configuracoes_model', 'configuracoes');
        $this->configuracoes = $this->configuracoes->configuracoes();

        $this->load->model('home_model', 'home');
        //$this->load->model('curso_model', 'curso');
        $this->load->model('mensagem_model', 'mensagem');

        //$this->load->helper('url');
        //$this->load->helper('cookie');
        // define os arquivos para juntar e comprimir
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'mensagem');
        $this->header = $this->load->view('view_header', '', true);
        $this->menu_vertical = $this->load->view('view_menu', '', true);
    }

    public function getMensagens() {
	
        session_start();
		
        $this->layout = '';

        $user = $this->session->userdata('pessoaid');
        $fields['matriculaID'] = $user;

        $packages = array();
        
        $packages = @get_object_vars(json_decode($this->input->cookie('pacotes'.$this->session->userdata('matriculaid'),FALSE)));

        if( empty($packages)){
	        $response = $this->home->verificaPacotesAluno($fields, $this->configuracoes[0]['Base']);

	        //seta o cookie caso ele nao existir
			if ($response) {
				foreach ($response as $value) {
					$date = date_create($value["DtInicio"]);
					$packages[$value["GrupoAulaID"]] = date_format($date,"Y-m-d H:i:s");
				}
			}			
        }
    
        
		//caso nao existir o tempo na sessao, seta tempo maior que 10min para fazer a busca        
        $dadosSessao = $this->session->userdata('intervalomsg');
        if(!empty($dadosSessao)){
        	$difTempo = $this->difTempo($dadosSessao);
        }else{
        	$difTempo = '23:59';
        }
		
        $tempo = strtotime($difTempo);
		$limite = strtotime('23:59');  
		
		//$dadosMsg = $this->input->cookie('dadosmsg'.$this->session->userdata('matriculaid'),FALSE);
		$dadosMsg = @$_SESSION['dadosmsg'.$this->session->userdata('matriculaid')];
	
        if($limite >= $tempo && !empty($dadosMsg)){
		
			$msgCookie = get_object_vars(json_decode(base64_decode($dadosMsg)));
			//$msgCookie['busca'] = 'Cookie';
			$msgCookie['busca'] = 'Session';
			$dados = $msgCookie;

        }else{
			//pega os ids das disciplinas retornadas do memcache
			$disciplinas = array();
			$cont4 = array();
			if ($packages) {
				foreach ($packages as $item => $value) {
					//pegando todas as disciplinas de todos os pacotes do aluno
					$infoDisciplinas = $this->curso->verificaDisciplinasMensagem($item);
					foreach($infoDisciplinas as $disc) {
						$disciplinas[$item][] = $disc['DisciplinaID'];
					}
				}
			}
			
	        $dados['unread'] = $this->mensagem->getUnreadNumber($user, $packages,$disciplinas);
	        $dados['url'] = PATH_IMG_SITE;
	        $dados['mensagens'] = array();
			$dados['mensagens'] = $this->mensagem->getMessages($user, $packages,$disciplinas, 5);
			$dados['busca'] = 'SB';
			
			$array = array('intervalomsg'=>date('Y-m-d H:i:s'));
			//grava na sessao a data e hora da ultima pesquisa feita
			$this->session->set_userdata($array);
			
			$_SESSION['dadosmsg'.$this->session->userdata('matriculaid')] = base64_encode(json_encode($dados));			
        }

        print(json_encode($dados));
    }
    
    public function difTempo ($data1){

    	$data2 = date('Y-m-d H:i:s');
	
		$unix_data1 = strtotime($data1);
		$unix_data2 = strtotime($data2);
		
		$nHoras   = ($unix_data2 - $unix_data1) / 3600;
		$nMinutos = (($unix_data2 - $unix_data1) % 3600) / 60;
    	
    	return(sprintf('%02d:%02d', $nHoras , $nMinutos));
    	
    }

    public function read($mensagem) {
        $lido = $this->mensagem->isMessageRead($mensagem, $this->session->userdata('pessoaid'));

        if (!$lido) {
            $this->mensagem->markAsRead($mensagem, $this->session->userdata('pessoaid'));
        }

        $this->css[] = $this->minify->getCSS('mensagem.min', $this->cssMinify, ENVIRONMENT);
        $this->css[] = $this->minify->getCSS('bootstrap.min', $this->cssMinify, ENVIRONMENT);
        $dados = $this->mensagem->readMessage($mensagem);
        $dados['MensagemID'] = $mensagem;
		session_start();
		unset($_SESSION['dadosmsg'.$this->session->userdata('matriculaid')]);
		
        $this->load->view('mensagem_view', $dados);
    }

    public function markRead($mensagem) {
        $lido = $this->mensagem->isMessageRead($mensagem, $this->session->userdata('pessoaid'));

        if (!$lido) {
            $this->mensagem->markAsRead($mensagem, $this->session->userdata('pessoaid'));
        }
        
        return true;
    }

    public function mural() 
    {
        $this->css[] = $this->minify->getCSS('mensagem.min', $this->cssMinify, ENVIRONMENT);
        $day =  date('w');
        $date = date('Y-m-d H:i:s', strtotime("-{$day} day"));
        $user = $this->session->userdata('pessoaid');
        $fields['matriculaID'] = $user;
		
        $packages = array();
        $disciplinas = array();
		
        $packages = @get_object_vars(json_decode($this->input->cookie('pacotes'.$this->session->userdata('matriculaid'),FALSE)));

        if(empty($packages))
        {
            
            $response = $this->home->verificaPacotesAluno($fields, $this->configuracoes[0]['Base']);

            //seta o cookie caso ele nao existir
            if ($response) 
            {
                foreach ($response as $value) 
                {
                    $datePack = date_create($value["DtInicio"]);
                    $packages[$value["GrupoAulaID"]] = date_format($datePack,"Y-m-d H:i:s");
                }
            }

        }
		
        //pega os ids das disciplinas retornadas do memcache
        $cont4 = array();
        if ($packages) 
        {
            foreach ($packages as $item => $value) 
            {
                //pegando todas as disciplinas de todos os pacotes do aluno
                $infoDisciplinas = $this->curso->verificaDisciplinasMensagem($item);
                foreach($infoDisciplinas as $disc)
                {
                    $disciplinas[$item][] = $disc['DisciplinaID'];
                }
            }
        }
		
        $dados['essasemana'] = $this->mensagem->getMessages($user, $packages, $disciplinas, 0, '*', $date);
        $dados['antigas'] = $this->mensagem->getMessages($user, $packages, $disciplinas, 0, '*', $date, '<');

        $this->load->view('mural_view', $dados);
    }
    
    public function anexoMsg($mensagemId){

		$this->layout = '';

    	$dados = $this->mensagem->readMessage($mensagemId);

    	$anexo = 'http://docs.aprovaconcursos.com.br/'.$dados['PathAnexo'];

    	$nomeAnexo = end(explode('/', $dados['PathAnexo']));

		header('Content-Description: File Transfer');
		header('Content-Disposition: attachment; filename="'.$nomeAnexo.'"');
		header('Content-Type: application/octet-stream');
		header('Content-Transfer-Encoding: binary');
		//header('Content-Length: ' . filesize($nomeAnexo));
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');
		header('Expires: 0');
		readfile($anexo);
    	exit();
    }          
}

/* End of file Mensagem.php */
/* Location: ./caminho/Mensagem.php */
