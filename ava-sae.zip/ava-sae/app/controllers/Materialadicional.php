<?php

use Ava\App\Exceptions\FileNotFoundException;
use Ava\App\Services\MaterialAdicional\ListarMateriaisAdicionaisPorTurma;
use Ava\App\Services\Usuario\ObterUsuarioNextAva;
use League\Flysystem\AwsS3v3\AwsS3Adapter;
use WSW\SimpleUpload\Services\SimpleUpload;
use WSW\SimpleUpload\Services\Translator;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property Materialadicional_Model materialAdicional
 */
class Materialadicional extends MY_Controller
{
    public $js = array('jquery.min', 'materialAdicional', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'curso.min', 'redactor.min', 'pt_pt', 'redactor_special_character', 'redactor.fontcolor', 'redactor.fontsize', 'jquery.cookie'); //'curso.min','chosen'
    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    public function __construct()
    {
        parent::__construct();
        define("UPLOAD_TMP", __DIR__ . "/../../public/tmp/");
        $this->load->model('materialadicional_model', 'materialAdicional');
        // define os arquivos para juntar e comprimir
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'mensagem');

        $this->load->model('curso_model', 'curso');
        $this->load->model('cadastro_model', 'cadastro');
    }


    public function index($msg = null)
    {
        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'curso';
        $this->cssMinify[] = 'glyphicon';
        $this->cssMinify[] = 'datepicker';
        $this->js[] = 'bootstrap-datepicker';
        $this->js[] = 'vue';
        $this->css[] = $this->minify->getCSS('curso_index.min', $this->cssMinify, ENVIRONMENT);
        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        if ($this->session->userdata('perfil') == PERFIL_PROFESSOR or $this->session->userdata('perfil') == PERFIL_COORDENADOR) {
            $idDisciplina = $this->input->get('idDisciplina');
            if ($idDisciplina)
                $this->session->set_userdata('grupoAulaID', $idDisciplina);

            $idTurma = $this->input->get('idTurma');
            if ($idTurma)
                $this->session->set_userdata('TurmaID', $idTurma);

            $escolaID = $this->session->userdata('escola');
            $disciplinaID = $this->session->userdata('grupoAulaID');
            $turmaID = $this->session->userdata('TurmaID');

            $aula['csrf'] = ['name' => $this->security->get_csrf_token_name(), 'hash' => $this->security->get_csrf_hash()];

            $aula['msg'] = $msg;
            $disciplinas = $this->materialAdicional->buscaMaterialAdicional($disciplinaID, $escolaID, $turmaID);
            $aula['arquivos'] = $disciplinas;
            $aula['turma'] = $turmaID;
            $aula['disciplina'] = $disciplinaID;
            $aula['aula'] = $this->home->getDescricaoDisciplina($this->session->userdata('grupoAulaID'));

            if ($this->input->get('jsonResponse')) {
                return $this->responseJson(['response' => $aula], 200);
            } else {
                $this->load->view('material-adicional/professor', $aula);
            }
        } else {
            if (!empty($this->session->userdata('teams'))) {
                $turmaId = $this->session->userdata('teams')[0]->id;
            } else {
                $token = $this->session->token;
                $user = SaeDigital::make(ObterUsuarioNextAva::class)->handle($token);
                $turmaId = $user->teams[0]->id;
            }

            $this->load->view('material-adicional/aluno', ['turmaId' => $turmaId]);
        }
    }

    public function download($idMaterialAdicional)
    {
        try {
            $this->layout = false;

            $material = $this->materialAdicional->findById($idMaterialAdicional);

            if (!$material) {
                throw new FileNotFoundException("{$idMaterialAdicional}", 404);
            }

            /** @var AwsS3Adapter $adapter */
            $adapter = SaeDigital::make(AwsS3Adapter::class);

            $filePath = "avasae/materialadicional/{$material['NomeGerado']}.{$material['Extensao']}";

            if (!$adapter->has($filePath)) {
                show_404();
            }

            $cmd = $adapter->getClient()->getCommand(
                'GetObject',
                [
                    'Bucket' => env('AWS_DEFAULT_BUCKET', 'avasae-teste'),
                    'Key' => $filePath
                ]
            );

            $request = $adapter->getClient()->createPresignedRequest($cmd, '+2 hours');

            $url = (string)$request->getUri();

            header("Location: " . $url);
        } catch (FileNotFoundException $e) {
            show_404();
        } catch (\Exception $e) {
            show_404();
        }
    }

    public function listar($turmaId)
    {
        try {
            $materiais = SaeDigital::make(ListarMateriaisAdicionaisPorTurma::class)->handle($turmaId);

            return $this->responseJson(['lista' => $materiais], 200);
        } catch (Exception $e) {
            return $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }

    /**
     * @param $arquivo
     *
     * @return bool
     * @throws \Exception
     */
    private function validarTamanhoArquivo($file_size)
    {
        if ($file_size > 50010000) {
            throw new \Exception('Falha no upload, favor enviar arquivo com no máximo 50mb.');
        }

        return true;
    }

    public function uploadMaterialAdicional()
    {
        try {
            $all_files_sent = 0;
            $files_fields = [];
            $count = count($_FILES['files']['name']);

            for ($i = 0; $i < $count; $i++) {
                $this->validarTamanhoArquivo($_FILES['files']['size'][$i]);

                $fields = [];
                $fields['TurmaID'] = $this->session->userdata('TurmaID');
                $fields['EscolaID'] = $this->session->userdata('escola');
                $fields['NomeGerado'] = $this->materialAdicional->gerarNomeDeArquivo();
                $fields['Situacao'] = 'A';
                $fields['NomeOriginal'] = pathinfo($_FILES['files']['name'][$i], PATHINFO_FILENAME);
                $fields['Extensao'] = pathinfo($_FILES['files']['name'][$i], PATHINFO_EXTENSION);
                $fields['DtCad'] = date('Y-m-d H:i:s');
                $fields['Path'] = UPLOAD_TMP;
                $fields['DisciplinaID'] = $this->session->userdata('grupoAulaID');

                $tmp_file = [];
                $tmp_file['name'] = $_FILES['files']['name'][$i];
                $tmp_file['type'] = $_FILES['files']['type'][$i];
                $tmp_file['tmp_name'] = $_FILES['files']['tmp_name'][$i];
                $tmp_file['error'] = $_FILES['files']['error'][$i];
                $tmp_file['size'] = $_FILES['files']['size'][$i];

                $file = SimpleUpload::create($tmp_file, SaeDigital::make(AwsS3Adapter::class), Translator::locate('pt-BR'));
                /**
                 * Como essa lib não suporta MIME Types, ultilizar esses links para referencias de extensões 
                 * https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types
                 * https://www.sitepoint.com/mime-types-complete-list/
                 * 
                 * audio -> 'aac', 'aif', 'aifc', 'aiff', 'au', 'funk', 'gsd', 'gsm', 'it', 'jam', 'kar',
                 *      'la', 'lam', 'lma', 'm2a', 'm3u', 'mid', 'midi', 'mjf', 'mod', 'mp2', 'mp3', 'mpa',
                 *      'mpg', 'mpga', 'my', 'pfunk', 'qcp', 'ra', 'ram', 'rm', 'rmi', 'rmm', 'rmp', 'rpm',
                 *      's3m', 'sid', 'snd', 'tsi', 'tsp', 'voc', 'vox', 'vqe', 'vqf', 'vql', 'wav', 'weba',
                 *      'xm', '3gp', '3g2',
                 * video -> 'afl', 'asf', 'asx', 'avi', 'avs', 'dif', 'dl', 'dv', 'fli', 'fmf', 'gl', 'isu',
                 *      'm1v', 'm2v', 'mjpg', 'moov', 'mov', 'movie', 'mp2', 'mp3', 'mp4', 'mpa', 'mpe', 'mpeg', 'mpg',
                 *      'mv', 'ogv', 'qt', 'qtc', 'rv', 'scm', 'vdo', 'viv', 'vivo', 'vos', 'webm', 'xdr', 'xsr',
                 * image -> 'art', 'bm', 'bmp', 'dwg', 'dxf', 'fif', 'flo', 'fpx', 'g3', 'gif', 'ico', 'ief',
                 *      'iefs', 'jfif', 'jfif-tbnl', 'jpe', 'jpeg', 'jpg', 'jps', 'jut', 'mcf', 'nap', 'naplps',
                 *      'nif', 'niff', 'pbm', 'pct', 'pcx', 'pgm', 'pic', 'pict', 'pm', 'png', 'pnm', 'ppm',
                 *      'qif', 'qti', 'qtif', 'ras', 'rast', 'rf', 'rgb', 'rp', 'svf', 'svg', 'tif', 'tiff',
                 *      'turbot', 'webp', 'wbmp', 'xbm', 'xif', 'xpm', 'x-png', 'xwd',
                 */

                $file->setAllowedExtensions([
                    'aac', 'aif', 'aifc', 'aiff', 'au', 'funk', 'gsd', 'gsm', 'it', 'jam', 'kar',
                    'la', 'lam', 'lma', 'm2a', 'm3u', 'mid', 'midi', 'mjf', 'mod', 'mp2', 'mp3', 'mpa',
                    'mpg', 'mpga', 'my', 'pfunk', 'qcp', 'ra', 'ram', 'rm', 'rmi', 'rmm', 'rmp', 'rpm',
                    's3m', 'sid', 'snd', 'tsi', 'tsp', 'voc', 'vox', 'vqe', 'vqf', 'vql', 'wav', 'weba',
                    'xm', '3gp', '3g2',
                    'afl', 'asf', 'asx', 'avi', 'avs', 'dif', 'dl', 'dv', 'fli', 'fmf', 'gl', 'isu',
                    'm1v', 'm2v', 'mjpg', 'moov', 'mov', 'movie', 'mp2', 'mp3', 'mp4', 'mpa', 'mpe', 'mpeg', 'mpg',
                    'mv', 'ogv', 'qt', 'qtc', 'rv', 'scm', 'vdo', 'viv', 'vivo', 'vos', 'webm', 'xdr', 'xsr',
                    'art', 'bm', 'bmp', 'dwg', 'dxf', 'fif', 'flo', 'fpx', 'g3', 'gif', 'ico', 'ief',
                    'iefs', 'jfif', 'jfif-tbnl', 'jpe', 'jpeg', 'jpg', 'jps', 'jut', 'mcf', 'nap', 'naplps',
                    'nif', 'niff', 'pbm', 'pct', 'pcx', 'pgm', 'pic', 'pict', 'pm', 'png', 'pnm', 'ppm',
                    'qif', 'qti', 'qtif', 'ras', 'rast', 'rf', 'rgb', 'rp', 'svf', 'svg', 'tif', 'tiff',
                    'turbot', 'webp', 'wbmp', 'xbm', 'xif', 'xpm', 'x-png', 'xwd',
                    'xls', 'xlsx', 'doc', 'docx', 'ppt', 'pptx', 'pdf'
                ]);
                $file->setPath('avasae/materialadicional');
                $file->setName($fields['NomeGerado'] . '.' . $fields['Extensao']);

                if ($file->send()) {
                    $all_files_sent ++;

                    $files_fields[] = $fields;
                }
            }

            if ($all_files_sent == $count) {
                for ($i = 0; $i < $count; $i++) {
                    $id = $this->materialAdicional->geraId();
                    $this->cadastro->salvaDados('D038_Materiais_Adicionais_Upload', $id, $files_fields[$i], TRUE);
                }

                return $this->responseJson(['msg' => 'Upload realizado com sucesso.'], 200);
            } else {
                return $this->responseJson(['msg' => 'Ocorreu um problema com o upload.'], 500);
            }
        } catch (\Exception $e) {
            $this->layout = false;

            return $this->responseJson(['msg' => $e->getMessage()], 500);
        }
    }

    /**
     * Método vai ficar comentado até passar pelos testes
     */
    // public function incluirmaterial()
    // {
    //     $files = $_FILES['file'];
    //     $allowed =  array('xls','xlsx' ,'doc','docx','ppt','pptx','pdf');
    //     $filename = $_FILES['file']['name'];
    //     $ext = pathinfo($filename, PATHINFO_EXTENSION);
    //
    //     if(!in_array($ext,$allowed) ) {
    //         redirect('/materialadicional');
    //     }
    //
    //     $fields = array();
    //     $originalName = explode(".",$_FILES['file']['name']);
    //     $fields['TurmaID'] = $this->session->userdata('TurmaID');
    //     $fields['EscolaID'] = $this->session->userdata('escola');
    //     $fields['NomeGerado'] = $this->materialAdicional->gerarNomeDeArquivo();
    //     $fields['Situacao'] = 'A';
    //     $fields['NomeOriginal'] = $originalName[0];
    //     $fields['Extensao'] = $originalName[1];
    //     $fields['Path'] = UPLOAD_TMP;
    //     $fields['DisciplinaID'] = $this->session->userdata('grupoAulaID');
    //     $id = $this->materialAdicional->geraId();
    //
    //
    //     if (!move_uploaded_file($files['tmp_name'], UPLOAD_TMP.$fields['NomeGerado'].'.'.$fields['Extensao'])){
    //         $error = array('error' => 'Erro durante o Upload');
    //         $this->index($error);
    //     }
    //         $this->cadastro->salvaDados('D038_Materiais_Adicionais_Upload', $id, $fields, TRUE);
    //         $arrayImg = array(
    //             'Bucket' => env('AWS_DEFAULT_BUCKET', 'avasae-teste'),
    //             'Key' => 'avasae/materialadicional/'.$fields['NomeGerado'].'.'.$fields['Extensao'],
    //             'Body' => fopen(UPLOAD_TMP.$fields['NomeGerado'].'.'.$fields['Extensao'], 'rb'),
    //             'ACL' => 'public-read'
    //         );
    //
    //         $this->servicos3_lib->upload_s3(null, $data['file_name'], null , $arrayImg);
    //         unlink(UPLOAD_TMP.$fields['NomeGerado'].'.'.$fields['Extensao']);
    //
    //     if (isset($error))
    //         redirect('/materialadicional');
    //     else {
    //        redirect('/materialadicional');
    //     }
    // }

    public function excluirMaterial($id)
    {
        $this->cadastro->excluirArquivo($id);
        redirect('/materialadicional');
    }
}
