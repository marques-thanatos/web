<?php

use Ava\App\Services\Enqueue\Enqueue;
use Ava\App\Services\Usuario\DeletarUsuarioPortal;

class ConsumerDeletarUsuarioPortal extends CI_Controller
{
    public function userSync()
    {
        $this->layout = false;
        try {
            SaeDigital::make(Enqueue::class)->consume(getenv('CI_ENV') . '_portal_user_sync',
                function ($msg) {
                    return SaeDigital::make(DeletarUsuarioPortal::class)->handle($msg['user_login']);
                });

        } catch (\Exception $e) {
            echo $e->getMessage() . PHP_EOL;
        }
    }
}
