<?php

use Ava\App\Services\NextAVA\ProjetoDeVidaNextAVA;

class MochilaDoAluno extends MY_Controller {
    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    public function __construct() {
    
        parent::__construct();
    
    }
    
    public function index() {
        
        try {
            
            $haveAccess = SaeDigital::make(ProjetoDeVidaNextAVA::class)->HaveAccess($this->session->userData('token'));
            
            $data['haveAccess'] = $haveAccess;

            return $this->load->view('mochila-do-aluno', $data);

        } catch (\Exception $e) {

            log_error($e -> getMessage());
        }

    }
}
