<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class RelatorioPlataformaLiteraria extends MY_Controller {

    public $layout = 'relatorio';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $cssMinify = array('style_avasae_bootstrap3', 'botao_imprimir', 'mensagem');
    public $css = array();
    public $js = array('jquery/dist/jquery.min','bootstrap/dist/js/bootstrap.min','jquery.cookie',
        'mensagem', 'relatorio-plataforma', 'exportar-relatorio');
    public $keywords = array('avasae', 'relatorio');
    public $perfil = null;
    public $nome = null;
    public $usuarioid = null;
    public $login = null;
    public $turma = null;
    public $serieid = null;
    public $grupoaulaid = null;
    public $assuntos = null;

    public function __construct() {
        parent::__construct();

        //FIXED: ATRIBUTOS GLOBAIS
        $this->perfil = $this->session->userdata('perfil');
        $this->usuarioid = $this->session->userdata('pessoaid');
        $this->login = $this->session->userdata('login');
        $this->nome = $this->session->userdata('nome');
        $this->css[] = $this->minify->getCSS('relatorio_desempenhogeral.min', $this->cssMinify, ENVIRONMENT);
        //FIXED: LOAD MODEL CLASS
        $this->load->model('plataformaliteraria_model', 'literaria');
        $this->load->model('curso_model', 'curso');
        $this->load->model('cadastro_model', 'cadastro');
        $this->load->library('PHPExcel');

        $dados['dados'] = montaMenu($this->perfil);
        $this->menu_vertical = $this->load->view('view_menurelatorio', $dados, true);
    }

    public function relatorioAluno(){
        try{
            $this->css[] = $this->minify->getCSS('relatorio_professor.min', $this->cssMinify, ENVIRONMENT);
            $dados = array();
            $alunoid = $this->session->userdata('login');
            $infoUsuario = $this->literaria->getSerieTurmaPorLogin($alunoid, null);
            if ($infoUsuario)
            {
                $serieid = $infoUsuario[0]->SerieID;
                $turmaid = $infoUsuario[0]->Turma;
                $usuarioid = $infoUsuario[0]->itemName;

                $assuntos = $this->literaria->getAssuntosPlataformaLiterariaPorLoginSerie($usuarioid, $serieid);
                $assuntosAgendados = array();
                foreach ($assuntos as $key => $assunto){
                    $disciplinaid = $assunto->GrupoAulaID;
                    $frenteid = $assunto->CategoriaAulaID;
                    $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $disciplinaid, $frenteid, null);
                    if($agendamento){
                        $assunto->TurmaID =  $turmaid;
                        $assunto->SerieID =  $serieid;
                        array_push($assuntosAgendados, $assunto);
                    }
                }
                $dados["perfil"] = intval($this->perfil);
                $dados["assuntos"] = $assuntosAgendados;
            }
            $dados["turma_selecionada"] = $turmaid;

            $this->load->view('relatorios/relatorioPlataformaLiterariaAluno',$dados);
        }catch (Exception $exception){
            //TODO: salvar log de relatorio em caso de erro
            $message = $exception->getMessage();
        }
    }

    public function relatorioProfessor(){
        try{
            $this->css[] = $this->minify->getCSS('relatorio_professor.min', $this->cssMinify, ENVIRONMENT);
            $this->js[] = 'chosen.jquery.min';
            $this->cssMinify[] = 'chosen';

            $turmaid = $this->input->post('turma') ? $this->input->post('turma', true) : null;
            $usuariologin = $this->session->userdata('login');

            $turmas = $this->literaria->getTurmasProfessorPorLogin($usuariologin, null, true);
            $cboTurmas = array(NULL => 'Selecione uma Turma');
            foreach ($turmas as $key => $turma) {
                if (!in_array($turma->Turma, $cboTurmas)) {
                    $cboTurmas[$turma->Turma] = $turma->DescricaoTurma;
                }
            }
            $extraTurma = array('id' => 'turma', 'class' => 'form-control', 'placehold' => 'Selecione uma turma');
            $data = array();
            $data['comboTurma'] = form_dropdown('turma', $cboTurmas, $turmaid, $extraTurma);

            if (isset($turmaid, $usuariologin)){
                $infoUsuario = $this->literaria->getSerieTurmaPorLogin($usuariologin, $turmaid);

                if ($infoUsuario){
                    $serieid = $infoUsuario[0]->SerieID;
                    $assuntos = $this->literaria->getAssuntosPlataformaLiterariaPorSerie($serieid);
                    $assuntosAgendados = array();
                    foreach ($assuntos as $key => $assunto){
                        $disciplinaid = $assunto->GrupoAulaID;
                        $frenteid = $assunto->CategoriaAulaID;
                        $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $disciplinaid, $frenteid, null);
                        if($agendamento){
                            $assunto->TurmaID =  $turmaid;
                            $assunto->SerieID =  $serieid;
                            array_push($assuntosAgendados, $assunto);
                        }
                    }
                    $data["assuntos"] = $assuntosAgendados;
                }
            }
            $data["turma_selecionada"] = $turmaid;
            $data["perfil"] = intval($this->perfil);
            $data['postRelatorio'] = base_url().'relatorioPlataformaLiteraria/relatorioProfessor';
            $this->load->view('relatorios/relatorioPlataformaLiterariaProfessor',$data);
        }catch (Exception $exception){
            //TODO: salvar log de relatorio em caso de erro
            $message = $exception->getMessage();
        }
    }

    public function exportarRelatorio($turmaid, $formato) {
        $usuariologin = $this->session->userdata('login');
        $usuarioid = $this->session->userdata('pessoaid');
        $infoUsuario = $this->literaria->getSerieTurmaPorLogin($usuariologin, $turmaid);

        if ($infoUsuario){
            $serieid = $infoUsuario[0]->SerieID;
            $assuntos = $this->literaria->getAssuntosPlataformaLiterariaPorSerie($serieid);
            $assuntosAgendados = array();
            foreach ($assuntos as $key => $assunto){
                $disciplinaid = $assunto->GrupoAulaID;
                $frenteid = $assunto->CategoriaAulaID;
                $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $disciplinaid, $frenteid, null);
                if($agendamento){
                    $assunto->TurmaID =  $turmaid;
                    $assunto->SerieID =  $serieid;
                    array_push($assuntosAgendados, $assunto);
                }
            }
        }
        foreach ($assuntosAgendados as $key => $assunto) {
            $alunosTurma = $this->buscaRelatorioPorAssunto(
                $turmaid, $assunto->CategoriaAulaID, $assunto->GrupoAulaID, $usuarioid
            );
            $assunto->alunos = $alunosTurma["alunosTurma"];
        }
        return $this->gerarRelatorioProfessor($assuntosAgendados, $formato);
    }

    public function exportarRelatorioAluno($turmaid, $formato) {
        $usuariologin = $this->session->userdata('login');
        $pessoaid = $this->session->userdata('pessoaid');
        $infoUsuario = $this->literaria->getSerieTurmaPorLogin($usuariologin, $turmaid);
        if ($infoUsuario){
            $serieid = $infoUsuario[0]->SerieID;
            $assuntos = $this->literaria->getAssuntosPlataformaLiterariaPorSerie($serieid);
            $assuntosAgendados = array();
            foreach ($assuntos as $key => $assunto){
                $disciplinaid = $assunto->GrupoAulaID;
                $frenteid = $assunto->CategoriaAulaID;
                $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $disciplinaid, $frenteid, null);
                if($agendamento){
                    $assunto->TurmaID =  $turmaid;
                    $assunto->SerieID =  $serieid;
                    array_push($assuntosAgendados, $assunto);
                }
            }
        }
        foreach ($assuntosAgendados as $key => $assunto) {
            $assunto->desempenho = $this->buscaRelatorioPorAluno(
                $assunto->CategoriaAulaID, $assunto->GrupoAulaID,
                $pessoaid, $turmaid
            );
        }
        return $this->gerarRelatorioAluno($assuntosAgendados, $formato);
    }

    private function buscaRelatorioPorAluno($categoriaaulaid,$grupoaulaid,$usuarioid, $turmaid) {
        if (isset($categoriaaulaid,$grupoaulaid,$usuarioid, $turmaid)) {
            $aulaAssunto = $this->literaria->getAulaAssuntoPlataformaLiteraria($grupoaulaid, $categoriaaulaid);
            $respostasAluno = $this->literaria->getRespostaAlunoQuestoes($usuarioid, $grupoaulaid, $categoriaaulaid);
            $dtHoje = date("d-m-Y");
            $mediaaluno = 0;
            $qtdeAulaValida = 0;
            $dadosTurma = $this->cadastro->dadosTurma($turmaid);
            $metaSerie = $this->cadastro->verificaMeta(
                $dadosTurma->SerieID, 
                $dadosTurma->EscolaID
            )[0];

            foreach ($aulaAssunto as $indexAula => $aula) {
                $aulaTemp = new stdClass();
                $aulaTemp->Respondido = false;
                $aulaTemp->TurmaID = $turmaid;
                $aulaTemp->UsuarioID = $usuarioid;
                $aulaTemp->Meta = 0;
                $aulaTemp->PercentualAcertos = 0;
                $aulaTemp->PercentualVideo = 0;
                $aulaTemp->QtdeAcertos = 0;
                $aulaTemp->QtdeErradas = 0;
                $aulaTemp->TotalQuestoes = 0;
                $aulaTemp->TotalRespondido = 0;
                $aulaTemp->DataInicioAgendamento = null;
                $aulaTemp->DataFimAgendamento = null;

                if ($aula->Tipo == "D") {
                    $aulaTemp->TotalQuestoes = intval($this->literaria->getTotalQuestoesDiscursivas($aula->AulaID, $grupoaulaid, $aula->SubCategoriaID));
                    $aulaTemp->TotalRespondido = intval($this->literaria->getTotalRespondidoQuestaoDiscursiva($turmaid, $usuarioid, $grupoaulaid, $aula->SubCategoriaID));


                    $aulaTemp->Meta = $metaSerie['Meta'];
                    if ($aulaTemp->TotalRespondido > $aulaTemp->TotalQuestoes)
                    {
                        // $aula->SubCategoriaID will be AssuntoID on 
                        // SAE_Questoes_Discursivas and
                        // SAE_Respostas_Questoes_Discursivas
                        $this->literaria->removeDuplicadasPl(
                            $aula->SubCategoriaID,
                            $aula->AulaID,
                            $aula->GrupoAulaID,
                            $usuarioid
                        );

                        // We need to recalculate de total of answers because we deleted some duplicated responses
                        $aulaTemp->TotalQuestoes = intval($this->literaria->getTotalQuestoesDiscursivas($aula->AulaID, $grupoaulaid, $aula->SubCategoriaID));
                        $aulaTemp->TotalRespondido = intval($this->literaria->getTotalRespondidoQuestaoDiscursiva($turmaid, $usuarioid, $grupoaulaid, $aula->SubCategoriaID));
                    }

                    $aulaTemp->NotaTotal = intval($this->literaria->getNotaTotalQuestaoDiscursiva($turmaid, $usuarioid, $grupoaulaid, $aula->SubCategoriaID));;

                    $aulaTemp->QtdeAcertos = $aulaTemp->TotalRespondido;
                    $aulaTemp->Respondido = true;
                    $percentualacerto = ($aulaTemp->NotaTotal / $aulaTemp->TotalQuestoes);
                    $aulaTemp->PercentualAcertos = number_format($percentualacerto, 0);

                }else{
                    foreach ($respostasAluno as $indexResposta => $resposta) {
                        if ($resposta->AulaID == $aula->AulaID) {
                            $aulaTemp->Respondido = true;
                            $aulaTemp->QtdeAcertos = intval($resposta->QtdeAcertos);
                            $aulaTemp->QtdeErradas = intval($resposta->QtdeErradas);
                            $aulaTemp->TotalQuestoes = intval($resposta->TotalQuestoesAula); //tem que ser o msm
                            $aulaTemp->TotalRespondido = intval($resposta->TotalRespondido);
                            $aulaTemp->Meta = floatval(isset($metaSerie["Meta"]) ? $metaSerie["Meta"] : 100);
                            $aulaTemp->PercentualVideo = floatval(isset($resposta->PercentualVideo) ? $resposta->PercentualVideo : 0);
                            $aulaTemp->DataInicioAgendamento = $resposta->DtAgendaInicio;
                            $aulaTemp->DataFimAgendamento = $resposta->DtAgendaFim;
                            break;
                        }
                    }
                }

                //CASO NAO TENHA RESPONDIDO
                if ($aulaTemp->DataInicioAgendamento == null || $aulaTemp->DataFimAgendamento == null){
                    $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $aula->GrupoAulaID, $aula->CategoriaAulaID, $aula->SubCategoriaID);
                    if ($agendamento) {
                        $aulaTemp->DataInicioAgendamento = $agendamento[0]->DtInicio;
                        $aulaTemp->DataFimAgendamento = $agendamento[0]->DtFim;
                    }
                }

                if($aulaTemp->TotalQuestoes == null){
                    $aulaTemp->TotalQuestoes = intval($this->literaria->getTotalQuestoes($grupoaulaid, $aula->SubCategoriaID));
                }

                //CALCULAR A MEDIA DE ACERTO DA ATIVIDADE
                if ($aula->Tipo == "N")
                {
                    $aulaTemp->PercentualAcertos = number_format($aulaTemp->PercentualVideo, 0);
                }
                elseif ($aula->Tipo != "D")
                {
                    $percentual = (intval($aulaTemp->QtdeAcertos) / intval($aulaTemp->TotalQuestoes)) * 100;
                    $aulaTemp->PercentualAcertos = number_format($percentual, 0);
                }

                //formatar datas
                $inicio = strtotime($aulaTemp->DataInicioAgendamento);
                $fim = strtotime($aulaTemp->DataFimAgendamento);
                $aulaTemp->DataInicioAgendamento = date('d-m-Y',$inicio);
                $aulaTemp->DataFimAgendamento = date('d-m-Y',$fim);
                $aulaAssunto[$indexAula]->Aluno = $aulaTemp;

                //media aluno
                if(strtotime($dtHoje) > strtotime($aula->Aluno->DataFimAgendamento))
                {
                    $qtdeAulaValida +=1;
                    $mediaaluno += $aula->Aluno->PercentualAcertos;
                }
                elseif(strtotime($dtHoje) <= strtotime($aula->Aluno->DataFimAgendamento) && $aula->Aluno->Respondido)
                {
                    $qtdeAulaValida += 1;
                    $mediaaluno += $aula->Aluno->PercentualAcertos;
                }
            }

            if ($qtdeAulaValida > 0){
                $media= $mediaaluno / $qtdeAulaValida;
                $mediaaluno = number_format($media,0);
            }
            return array("aulaAssunto" => $aulaAssunto, "mediaAluno" => $mediaaluno );
        }
    }

    private function gerarRelatorioAluno($assuntosAgendados, $formato) {
        $this->layout = "";
        $objPHPExcel = $this->phpexcel;
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setLastModifiedBy("SAE Digital");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setTitle("Relatóri Geral");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setSubject("Relatório geral");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setDescription("Relatório geral");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setKeywords("Relatório geral");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setCategory("Relatório");

        $count_lines = 1;
        if($assuntosAgendados){
            foreach($assuntosAgendados as $assunto){
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$count_lines, $assunto->Descricao);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.($count_lines+1), "Nome do aluno");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.($count_lines+1), "Vídeo 1");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($count_lines+1), "Quiz 1");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($count_lines+1), "Questões discursivas");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($count_lines+1), "Quiz 2");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.($count_lines+1), "Quiz 3");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.($count_lines+1), "Produção de texto");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.($count_lines+2), $this->session->userdata("nome"));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.($count_lines+2), $assunto->desempenho["aulaAssunto"][0]->Aluno->PercentualAcertos."%");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($count_lines+2), $assunto->desempenho["aulaAssunto"][1]->Aluno->PercentualAcertos."%");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($count_lines+2), $assunto->desempenho["aulaAssunto"][2]->Aluno->PercentualAcertos."%");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($count_lines+2), $assunto->desempenho["aulaAssunto"][3]->Aluno->PercentualAcertos."%");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.($count_lines+2), $assunto->desempenho["aulaAssunto"][4]->Aluno->PercentualAcertos."%");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.($count_lines+2), $assunto->desempenho["aulaAssunto"][5]->Aluno->PercentualAcertos."%");
                $count_lines += 4;
            }
        }
        $data_geracao_relatorio = date("d-m-Y-H-i");
        $objPHPExcel->getActiveSheet()->setTitle('Relatório Plataforma Literária');
        $objPHPExcel->setActiveSheetIndex(0);
        $filename = $data_geracao_relatorio."_relatorio_pl.".$formato;
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        if ($formato === "csv") {
            header('Content-type: text/csv');
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV');
        } else {
            header('Content-type: application/vnd.ms-excel');
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        }
        $objWriter->save('php://output');
    }

    private function gerarRelatorioProfessor($assuntosAgendados, $formato) {
        $this->layout = "";
        $objPHPExcel = $this->phpexcel;
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setLastModifiedBy("SAE Digital");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setTitle("Relatóri Geral");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setSubject("Relatório geral");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setDescription("Relatório geral");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setKeywords("Relatório geral");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setCategory("Relatório");

        $count_lines = 1;
        if($assuntosAgendados){
            foreach($assuntosAgendados as $assunto){
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$count_lines, $assunto->Descricao);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.($count_lines+1), "Nome do aluno");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.($count_lines+1), "Vídeo 1");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($count_lines+1), "Quiz 1");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($count_lines+1), "Questões discursivas");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($count_lines+1), "Quiz 2");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.($count_lines+1), "Quiz 3");
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.($count_lines+1), "Produção de texto");
                foreach($assunto->alunos as $aluno) {
                    $count_lines += 1;
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.($count_lines+1),  $aluno->Nome);
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.($count_lines+1), $aluno->Aulas[0]->RespostaAluno->PercentualAcertos."%");
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($count_lines+1), $aluno->Aulas[1]->RespostaAluno->PercentualAcertos."%");
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($count_lines+1), $aluno->Aulas[2]->RespostaAluno->PercentualAcertos."%");
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($count_lines+1), $aluno->Aulas[3]->RespostaAluno->PercentualAcertos."%");
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.($count_lines+1), $aluno->Aulas[4]->RespostaAluno->PercentualAcertos."%");
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.($count_lines+1), $aluno->Aulas[5]->RespostaAluno->PercentualAcertos."%");
                }
                $count_lines += 3;

            }
        }
        $data_geracao_relatorio = date("d-m-Y-H-i");
        $objPHPExcel->getActiveSheet()->setTitle('Relatório Plataforma Literária');
        $objPHPExcel->setActiveSheetIndex(0);
        $filename = $data_geracao_relatorio."_relatorio_pl.".$formato;
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        if ($formato === "csv") {
            header('Content-type: text/csv');
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV');
        } else {
            header('Content-type: application/vnd.ms-excel');
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        }
        $objWriter->save('php://output');
    }


    public function buscaRelatorioPorAssunto($turmaid, $categoriaaulaid, $grupoaulaid, $usuarioid) {
//        $alunosTurma = $this->literaria->getAlunosAtivosPorTurma($turmaid, $grupoaulaid);
        $alunosTurma = $this->literaria->getAlunosPorTurma($turmaid);
        $mediaturma = 0;
        $dtHoje = date("d-m-Y");
        $dadosTurma = $this->cadastro->dadosTurma($turmaid);
        $metaSerie = $this->cadastro->verificaMeta(
            $dadosTurma->SerieID, 
            $dadosTurma->EscolaID
        )[0];

        foreach ($alunosTurma as $indexaluno => $aluno)
        {
            //TODO: assuntos, copiar por valor nao por referencia
            $aulaAssunto = $this->literaria->getAulaAssuntoPlataformaLiteraria($grupoaulaid, $categoriaaulaid);
            $respostasAluno = $this->literaria->getRespostaAlunoQuestoes($aluno->itemName, $grupoaulaid, $categoriaaulaid);
            $mediaaluno = 0;
            $qtdeAulaValida = 0;
            $alunosTurma[$indexaluno]->MediaAluno = $mediaaluno;
            $alunosTurma[$indexaluno]->Aulas = null;

            foreach ($aulaAssunto as $indexaula => $aula)
            {
                $respondido = false;
                $aula->RespostaAluno = null;
                $alunoaula = new stdClass();
                $alunoaula->AulaID = $aula->AulaID;
                $alunoaula->UsuarioID = $aluno->itemName;
                $alunoaula->TotalQuestoes = 0;
                $alunoaula->TotalRespondido = 0;
                $alunoaula->PercentualAcertos = 0;
                $alunoaula->Meta = 0;
                $alunoaula->PercentualVideo = 0;
                $alunoaula->QtdeAcertos = 0;
                $alunoaula->QtdeErradas = 0;
                $alunoaula->DataInicioAgendamento = null;
                $alunoaula->DataFimAgendamento = null;

                //FIXME: Buscar as respostas do aluno (Questoes/Videos ou Discursivas)
                if($aula->Tipo == 'D')
                {

                    $totalDiscursivas = $this->literaria->getTotalQuestoesDiscursivas($aula->AulaID, $grupoaulaid, $aula->SubCategoriaID);
                    $totalRespondido = $this->literaria->getTotalRespondidoQuestaoDiscursiva($turmaid, $aluno->itemName, $grupoaulaid, $aula->SubCategoriaID);
                    if ($totalRespondido > $totalDiscursivas)
                    {
                        // $aula->SubCategoriaID will be AssuntoID on 
                        // SAE_Questoes_Discursivas and
                        // SAE_Respostas_Questoes_Discursivas
                        $this->literaria->removeDuplicadasPl(
                            $aula->SubCategoriaID,
                            $aula->AulaID,
                            $aula->GrupoAulaID,
                            $aluno->itemName
                        );

                        // We need to recalculate de total of answers because we deleted some duplicated responses
                        $totalDiscursivas = $this->literaria->getTotalQuestoesDiscursivas($aula->AulaID, $grupoaulaid, $aula->SubCategoriaID);
                        $totalRespondido = $this->literaria->getTotalRespondidoQuestaoDiscursiva($turmaid, $aluno->itemName, $grupoaulaid, $aula->SubCategoriaID);
                    }
                    
                    $alunoaula->TotalQuestoes = intval(isset($totalDiscursivas)? $totalDiscursivas : 0);
                    $alunoaula->TotalRespondido = intval(isset($totalRespondido)? $totalRespondido : 0);
                    $alunoaula->QtdeAcertos = intval(isset($totalRespondido)? $totalRespondido : 0);
                    $alunoaula->NotaTotal = intval($this->literaria->getNotaTotalQuestaoDiscursiva($turmaid, $aluno->itemName, $grupoaulaid, $aula->SubCategoriaID));;
                    $alunoaula->Meta = $metaSerie['Meta'];

                    if ($alunoaula->TotalRespondido > 0 && $alunoaula->TotalQuestoes > 0)
                    {
                        $respondido = true;
                        $percentualacerto = ($alunoaula->NotaTotal / $alunoaula->TotalQuestoes);
                        $alunoaula->PercentualAcertos = number_format($percentualacerto, 0);
                    }
                }
                else
                {
                    foreach ($respostasAluno as $indexresposta => $resposta)
                    {
                        if($aula->AulaID == $resposta->AulaID)
                        {
                            $respondido = true;
                            $alunoaula->QtdeAcertos =  intval($resposta->QtdeAcertos);
                            $alunoaula->QtdeErradas =  intval($resposta->QtdeErradas);
                            $alunoaula->TotalQuestoes =  intval($resposta->TotalQuestoesAula);
                            $alunoaula->TotalRespondido =  intval($resposta->TotalRespondido);
                            $alunoaula->Meta =  floatval(isset($metaSerie["Meta"]) ? $resposta->Meta : 0);
                            $alunoaula->PercentualVideo =  floatval($resposta->PercentualVideo);
                            $alunoaula->DataInicioAgendamento =  $resposta->DtAgendaInicio;
                            $alunoaula->DataFimAgendamento =  $resposta->DtAgendaFim;
                            break;
                        }
                    }

                    if($alunoaula->TotalQuestoes == 0){
                        $questoes = $this->literaria->getTotalQuestoes($grupoaulaid, $aula->SubCategoriaID);
                        $alunoaula->TotalQuestoes = intval($questoes[0]->TotalQuestoes);
                    }

                    //CALCULAR A MEDIA DE ACERTO DA ATIVIDADE
                    if ($aula->Tipo == "N")
                    {
                        $alunoaula->PercentualAcertos = number_format($alunoaula->PercentualVideo, 0);
                    }
                    else
                    {
                        $percentual = (intval($alunoaula->QtdeAcertos) / intval($alunoaula->TotalQuestoes)) * 100;
                        $alunoaula->PercentualAcertos = number_format($percentual, 0);
                    }
                }

                if($alunoaula->DataInicioAgendamento == null || $alunoaula->DataFimAgendamento == null)
                {
                    $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $aula->GrupoAulaID, $aula->CategoriaAulaID, $aula->SubCategoriaID);
                    if ($agendamento) {
                        $alunoaula->DataInicioAgendamento = $agendamento[0]->DtInicio;
                        $alunoaula->DataFimAgendamento = $agendamento[0]->DtFim;
                    }
                }

                //formatar da$html .= $htmllabel;tas
                $inicio = strtotime($alunoaula->DataInicioAgendamento);
                $fim = strtotime($alunoaula->DataFimAgendamento);
                $alunoaula->DataInicioAgendamento = date('d-m-Y',$inicio);
                $alunoaula->DataFimAgendamento = date('d-m-Y',$fim);

                $alunoaula->Respondido = $respondido;
                //media aluno
                if(strtotime($dtHoje) > strtotime($alunoaula->DataFimAgendamento)) //ja passou do prazo
                {
                    $qtdeAulaValida +=1;
                    $mediaaluno += $alunoaula->PercentualAcertos;
                }
                elseif($alunoaula->Respondido) //dentro do prazo,mas realizou
                {
                    $qtdeAulaValida += 1;
                    $mediaaluno += $alunoaula->PercentualAcertos;
                }

                $aulaAssunto[$indexaula]->RespostaAluno = $alunoaula;
            }

            //media do aluno
            if ($qtdeAulaValida > 0)
            {
                $mediaaluno = ($mediaaluno / $qtdeAulaValida);
                $mediaaluno = number_format($mediaaluno,0);
                $mediaturma += $mediaaluno;
                $alunosTurma[$indexaluno]->MediaAluno = $mediaaluno;
            }
            $alunosTurma[$indexaluno]->Aulas = $aulaAssunto;
        }

        $qtdeAlunos = count($alunosTurma);
        if ($qtdeAlunos > 0){
            $mediaturma = $mediaturma / $qtdeAlunos;
            $mediaturma = number_format($mediaturma, 0);
        }
        return array("alunosTurma" => $alunosTurma, "mediaTurma" => $mediaturma );
    }

    public function relatorioCoordenador(){
        try{
            $this->css[] = $this->minify->getCSS('relatorio_professor.min', $this->cssMinify, ENVIRONMENT);
            $this->js[] = 'chosen.jquery.min';
            $this->cssMinify[] = 'chosen';

            $turmaid = $this->input->post('turma') ? $this->input->post('turma', true) : null;
            $usuariologin = $this->session->userdata('login');
            $turmas = $this->literaria->getTurmasProfessorPorLogin($usuariologin);
            $cboTurmas = array(NULL => 'Selecione uma Turma');
            foreach ($turmas as $key => $turma) {
                if (!in_array($turma->Turma, $cboTurmas)) {
                    $cboTurmas[$turma->Turma] = $turma->DescricaoTurma;
                }
            }
            $extraTurma = array('id' => 'turma', 'class' => 'form-control', 'placehold' => 'Selecione uma turma');
            $data = array();
            $data['comboTurma'] = form_dropdown('turma', $cboTurmas, $turmaid, $extraTurma);

            if (isset($turmaid, $usuariologin)){
                $infoUsuario = $this->literaria->getSerieTurmaPorLogin($usuariologin, $turmaid);

                if ($infoUsuario){
                    $serieid = $infoUsuario[0]->SerieID;
                    $assuntos = $this->literaria->getAssuntosPlataformaLiterariaPorSerie($serieid);
                    $assuntosAgendados = array();
                    foreach ($assuntos as $key => $assunto){
                        $disciplinaid = $assunto->GrupoAulaID;
                        $frenteid = $assunto->CategoriaAulaID;
                        $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $disciplinaid, $frenteid, null);
                        if($agendamento){
                            $assunto->TurmaID =  $turmaid;
                            $assunto->SerieID =  $serieid;
                            array_push($assuntosAgendados, $assunto);
                        }
                    }
                    $data["assuntos"] = $assuntosAgendados;
                }
            }
            $data["turma_selecionada"] = $turmaid;
            $data["perfil"] = intval($this->perfil);
            $data['postRelatorio'] = base_url().'relatorioPlataformaLiteraria/relatorioCoordenador';
            $this->load->view('relatorios/relatorioPlataformaLiterariaCoordenador',$data);
        }catch (Exception $exception){
            //TODO: salvar log de relatorio em caso de erro
            $message = $exception->getMessage();
        }
    }

    public function relatorioDiretor(){

    }

    public function buscarAssuntoPorTurma()
    {
        try {
            $categoriaaulaid = $this->input->post('categoriaaulaid');
            $grupoaulaid = $this->input->post('grupoaulaid');
            $turmaid = $this->input->post('turmaid');
            $usuarioid = $this->session->userdata('pessoaid');

            if (isset($turmaid, $categoriaaulaid, $grupoaulaid, $usuarioid)) {
                $this->corrigeAgendamentoPL($turmaid, $categoriaaulaid, $grupoaulaid);
                $dadosRelatorio = $this->buscaRelatorioPorAssunto($turmaid, $categoriaaulaid, $grupoaulaid, $usuarioid);
                $html = $this->getHtmlTBodyAulaProfesssor(
                    $dadosRelatorio["alunosTurma"], $dadosRelatorio["mediaTurma"]
                );
                print $html;
                exit();
            }else{
                throw new Exception("Arguments is missing");
            }

        }catch (Exception $exception) {
            //TODO: salvar log de relatorio em caso de erro
            exit($exception->getMessage());
        }
    }

    public function corrigeAgendamentoPL($turmaid, $categoriaaulaid, $grupoaulaid)
    {
        // On R001 categoriaaulaid is frenteid
        $dadosAssunto = $this->curso->dadosAssuntoPlataformaLiteraria(
            $turmaid, $categoriaaulaid
        );

        foreach ($dadosAssunto as $exercicio) 
        {
            $this->curso->corrigeAgendamentosPlataformaLiteraria(
                $turmaid, 
                $exercicio['AssuntoID'], 
                $exercicio['DisciplinaID'] 
            );
        }

    }

    public function buscarAssuntoPorAluno(){
        try{
            $categoriaaulaid = $this->input->post('categoriaaulaid');
            $grupoaulaid = $this->input->post('grupoaulaid');
            $usuarioid = $this->session->userdata('pessoaid');
            $turmaid = $this->input->post('turmaid');

            if (isset($categoriaaulaid,$grupoaulaid,$usuarioid, $turmaid)) {
                $this->corrigeAgendamentoPL($turmaid, $categoriaaulaid, $grupoaulaid);
                $dadosRelatorio = $this->buscaRelatorioPorAluno($categoriaaulaid,$grupoaulaid,$usuarioid, $turmaid);
                $html = $this->getHtmlTBodyAulaAluno(
                    $dadosRelatorio["aulaAssunto"], $dadosRelatorio["mediaAluno"]);
                print $html;die;
            }

        }catch (Exception $exception){
            //TODO: salvar log de relatorio em caso de erro
        }
        exit();
    }

    function getHtmlTarefaNaoRealizadaDentroPrazo($title){
        $html = '
            <th>
                <a href="javascript: void(0)" data-toggle="tooltip" title="'.$title.'" data-original-title="'.$title.'">
                    <span>-</span>
                </a>
            </th>';
        return $html;
    }

    function getHtmlVideoAssistido($title){
        $html = '<th>
                    <a href="javascript: void(0)" data-toggle="tooltip" title="'.$title.'" data-original-title="'.$title.'">
                        <span class="glyphicon glyphicon-facetime-video" aria-hidden="true"></span>
                    </a>
                </th>';
        return $html;
    }

    function getHtmlTarefaNaoRealizadaExpirada($title){
        $html = '
            <th>
                <a href="javascript: void(0)" data-toggle="tooltip" title="'.$title.'" data-original-title="'.$title.'">
                    <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                </a>
            </th>';
        return $html;
    }

    function getHtmlTarefaRealizada($title){
        $html = '
            <th>
                <a href="javascript: void(0)" data-toggle="tooltip" title="'.$title.'" data-original-title="'.$title.'">
                    <span class="glyphicon glyphicon-ok" aria-hidden="true"></span>
                </a>
            </th>';
        return $html;
    }

    function getHtmlObjetivoAlcancado($title){
        $html = '
            <th>
                <a href="javascript: void(0)" data-toggle="tooltip" title="'.$title.'" data-original-title="'.$title.'">
                    <span class="glyphicon glyphicon-ok success" aria-hidden="true"></span>
                </a>
            </th>';
        return $html;
    }

    function getHtmlTituloAtividades($aulas){
        $html = '
                <tr>
                 <th></th>         
                 <th><a href="javascript: void(0)" data-toggle="tooltip" title="'.$aulas[0]->Tema.'" data-original-title="Vídeo de apresentação">V¹</a></th>
                 <th><a href="javascript: void(0)" data-toggle="tooltip" title="'.$aulas[1]->Tema.'" data-original-title="Quiz 1">Q¹</a></th>
                 <th><a href="javascript: void(0)" data-toggle="tooltip" title="'.$aulas[2]->Tema.'" data-original-title="Questões Discursivas">QDs</a></th>
                 <th><a href="javascript: void(0)" data-toggle="tooltip" title="'.$aulas[3]->Tema.'" data-original-title="Quiz 2">Q²</a></th>
                 <th><a href="javascript: void(0)" data-toggle="tooltip" title="'.$aulas[4]->Tema.'" data-original-title="Quiz 3">Q³</a></th>
                 <th><a href="javascript: void(0)" data-toggle="tooltip" title="'.$aulas[5]->Tema.'" data-original-title="Vídeo">V²</a></th>
                </tr>';
        return $html;
    }

    function getProgressoDesempenho($mediaaluno, $mediaturma=null){
        $html = '<th>
                        <div class="progress">
                            <div class="progress-bar progress-bar-insuficiente" style="width:'.$mediaaluno.'%">
                                <span data-toggle="tooltip" data-container="body" 
                                      title="Média do aluno '.$mediaaluno.'%">'.$mediaaluno.'%</span>
                            </div>
                            <span class="class-median" data-toggle="tooltip" data-container="body"
                                    title="Média da turma '.$mediaturma.'%" data-placement="top"                                   
                                    style="left: '.$mediaturma.'%;">
                                   |
                            </span>
                        </div>
                    </th>';
        return $html;
    }

    function getProgressoDesempenhoAluno($mediaaluno){
        $html = '
            <th>
                <div class="progress">
                      <div class="progress-bar progress-bar-insuficiente" style="width: '.$mediaaluno.'%">
                            <span data-toggle="tooltip" data-container="body" 
                                  title="Média do aluno '.$mediaaluno.'%">'.$mediaaluno.'% </span>
                      </div>
                </div>
            </th>';
        return $html;
    }

    function getStatusVideo($aula, $mediaaluno){
        $percentual = $aula->PercentualVideo;
        $label = "Atividade de ".$aula->DataInicioAgendamento." a ".$aula->DataFimAgendamento;
        if ($percentual){
            $html = $this->getHtmlVideoAssistido($label);
        }elseif ($this->getStatusAtividadeExpirada($aula->DataFimAgendamento)){
            $html = $this->getHtmlTarefaNaoRealizadaExpirada($label);
        }else {
            $html = $this->getHtmlTarefaNaoRealizadaDentroPrazo($label);
        }
        return $html;
    }

    function getStatusQuestoes($aula, $mediaaluno){
        $label = "Atividade de ".$aula->DataInicioAgendamento." a ".$aula->DataFimAgendamento;
        $total = intval($aula->TotalQuestoes);
        $respondido = intval($aula->TotalRespondido);
        $expirou = $this->getStatusAtividadeExpirada($aula->DataFimAgendamento);
        
        if ($aula->PercentualAcertos >= $aula->Meta && $respondido > 0 && $aula->TotalQuestoes == $aula->TotalRespondido){
            $html = $this->getHtmlObjetivoAlcancado($label);
        }elseif($aula->PercentualAcertos < $aula->Meta && $respondido > 0 && $aula->TotalQuestoes == $aula->TotalRespondido){
            $html = $this->getHtmlTarefaRealizada($label);
        }elseif(!$expirou && $respondido == 0){
            $html = $this->getHtmlTarefaNaoRealizadaDentroPrazo($label);
        }elseif (($respondido <= 0 && $expirou) || $aula->TotalQuestoes != $aula->TotalRespondido) {
            $html = $this->getHtmlTarefaNaoRealizadaExpirada($label);
        }
        return $html;
    }

    function getStatusQuestoesDiscursivas($aula, $mediaaluno){
        $label = "Atividade de ".$aula->DataInicioAgendamento." a ".$aula->DataFimAgendamento;
        $total = intval($aula->TotalQuestoes);
        $respondido = intval($aula->TotalRespondido);
        $expirou = $this->getStatusAtividadeExpirada($aula->DataFimAgendamento);

        if ($aula->PercentualAcertos >= $aula->Meta && $respondido > 0 && $aula->TotalQuestoes == $aula->TotalRespondido){
            $html = $this->getHtmlObjetivoAlcancado($label);
        }elseif($aula->PercentualAcertos < $aula->Meta && $respondido > 0 && $aula->TotalQuestoes == $aula->TotalRespondido){
            $html = $this->getHtmlTarefaRealizada($label);
        }elseif(!$expirou && $respondido == 0 && $aula->TotalQuestoes == $aula->TotalRespondido){
            $html = $this->getHtmlTarefaNaoRealizadaDentroPrazo($label);
        }elseif ($respondido <= 0 && $expirou || $aula->TotalQuestoes != $aula->TotalRespondido) {
            $html = $this->getHtmlTarefaNaoRealizadaExpirada($label);
        }
        return $html;
    }

    function getLabelQuestao($aula, $mediaaluno){
        $percentual = $aula->PercentualAcertos;
        $label = "Acertou ".$aula->QtdeAcertos." de ".$aula->TotalQuestoes. " | Respondidas: ".$aula->TotalRespondido;
        $html = '<td><span><a href="javascript:void(0)" data-toggle="tooltip" title="'.$label.'"> '.$percentual.'%</a></span></td>';
        return $html;
    }

    function getLabelVideo($aula, $mediaaluno){
        $percentual = $aula->PercentualAcertos;
        $label = "Assistiu ".$aula->PercentualVideo. " %";
        $html = '<td><span><a href="javascript:void(0)" data-toggle="tooltip" title="'.$label.'"> '.$percentual.'%</a></span></td>';
        return $html;
    }

    function getLabelDiscursiva($aula, $mediaaluno){
        $percentual = $aula->PercentualAcertos;
        $label = "Respondeu ".$aula->QtdeAcertos." de ".$aula->TotalQuestoes;
        $html = '<td><span><a href="javascript:void(0)" data-toggle="tooltip" title="'.$label.'"> '.$percentual.'%</a></span></td>';
        return $html;
    }

    function getHtmlTBodyTrLabelAluno($assunto, $mediaaluno){
        $htmlTD = '';
        foreach ($assunto as $key => $aula){
            $tipo = $aula->Tipo;
            if ($tipo == "N"){
                $htmlTD .= $this->getLabelVideo($aula->Aluno, $mediaaluno);
            }elseif($tipo == "D"){
                $htmlTD .= $this->getLabelDiscursiva($aula->Aluno, $mediaaluno);
            }elseif ($tipo == "Q"){
                $htmlTD .= $this->getLabelQuestao($aula->Aluno, $mediaaluno);
            }
        }
        $html = '<tr>';
        $html .= '<td>Desempenho</td>';
        $html .= $htmlTD;
        $html .= "</tr>";
        return $html;
    }

    function getHtmlTBodyTrIconeAluno($assunto, $mediaaluno){
        $htmlTD = '';
        foreach ($assunto as $key => $aula){
            $tipo = $aula->Tipo;
            if(!$aula->Aluno->Respondido && $this->getStatusAtividadeExpirada($aula->Aluno->DataFimAgendamento)){
                $label = "Atividade de ".$aula->Aluno->DataInicioAgendamento." a ".$aula->Aluno->DataFimAgendamento;
                $htmlTD .= $this->getHtmlTarefaNaoRealizadaExpirada($label);
                continue;
            }
            if ($tipo == "N"){
                $htmlTD .= $this->getStatusVideo($aula->Aluno, $mediaaluno);
            }elseif($tipo == "D"){
                $htmlTD .= $this->getStatusQuestoesDiscursivas($aula->Aluno, $mediaaluno);
            }elseif ($tipo == "Q"){
                $htmlTD .= $this->getStatusQuestoes($aula->Aluno, $mediaaluno);
            }
        }
        $html = '<tr>';
        $html .= $this->getProgressoDesempenhoAluno($mediaaluno);
        $html .= $htmlTD;
        $html .= "</tr>";
        return $html;
    }

    function getHtmlTBodyAulaAluno($assunto, $mediaaluno){
        $html = '';
        $html .= $this->getHtmlTBodyTrLabelAluno($assunto, $mediaaluno);
        $html .= $this->getHtmlTBodyTrIconeAluno($assunto, $mediaaluno);
        return $html;
    }

    //TODO: Professor Relatorio
    function getHtmlTBodyAulaProfesssor($alunosturma, $mediaturma){
        $sorted = sort($alunosturma);

        $html = '';
        foreach ($alunosturma as $iTurma => $aluno)
        {
            $html .= $this->getHtmlTBodyTrLabelProfessor($aluno, $mediaturma);
            $html .= $this->getHtmlTbodyTrIconeProfessor($aluno, $mediaturma);
        }
        return $html;
    }

    function getHtmlTBodyTrLabelProfessor($aluno, $mediaturma){
        $html = '<tr>';
        $html .= '<td>'.$aluno->Nome.'</td>';

        foreach ($aluno->Aulas as $iA => $aula)
        {
            $tipo = $aula->Tipo;
            if ($tipo == "N"){
                $html .= $this->getLabelVideo($aula->RespostaAluno, $aluno->MediaAluno);
            }elseif($tipo == "D"){
                $html .= $this->getLabelDiscursiva($aula->RespostaAluno, $aluno->MediaAluno);
            }elseif ($tipo == "Q"){
                $html .= $this->getLabelQuestao($aula->RespostaAluno, $aluno->MediaAluno);
            }
        }
        $html .= '</tr>';
        return $html;
    }

    function getHtmlTbodyTrIconeProfessor($aluno, $mediaturma){

        $mediaaluno = $aluno->MediaAluno;

        $html = '<tr>';
        $html .= $this->getProgressoDesempenho($aluno->MediaAluno, $mediaturma);

        foreach ($aluno->Aulas as $iA => $aula)
        {
            $tipo = $aula->Tipo;
            if(!$aula->RespostaAluno->Respondido && $this->getStatusAtividadeExpirada($aula->RespostaAluno->DataFimAgendamento)){
                $label = "Atividade de ".$aula->RespostaAluno->DataInicioAgendamento." a ".$aula->RespostaAluno->DataFimAgendamento;
                $html .= $this->getHtmlTarefaNaoRealizadaExpirada($label);
                continue;
            }
            if ($tipo == "N"){
                $html .= $this->getStatusVideo($aula->RespostaAluno, $mediaaluno);
            }elseif($tipo == "D"){
                $html .= $this->getStatusQuestoesDiscursivas($aula->RespostaAluno, $mediaaluno);
            }elseif ($tipo == "Q"){
                $html .= $this->getStatusQuestoes($aula->RespostaAluno, $mediaaluno);
            }
        }
        $html .= '</tr>';

        return $html;
    }

    //TODO: Funcoes Uteis
    function getStatusAtividadeExpirada($dtFimAgendamento){
        $dtHoje = date("d-m-Y");
        if(strtotime($dtHoje) > strtotime($dtFimAgendamento)){
            //passou do prazo - deve ser considerado no calculo
            return true;
        }
        return false;
    }

    function organizarAulasAssuntos($assuntos, $turma){
        foreach ($assuntos as $key => $assunto){
            $aulasAssunto = $this->literaria->getAulaAssuntoPlataformaLiteraria($assunto->GrupoAulaID, $assunto->CategoriaAulaID);
            $assuntos[$key]->TurmaID =  $turma;
            $assuntos[$key]->Aulas = $aulasAssunto;
        }
        return $assuntos;
    }

}
