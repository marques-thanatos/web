<?php

class Management extends MY_Controller
{
    /** @var int $profile */
    private $profile = 0;

    public function __construct()
    {
        parent::__construct();
        $this->layout = false;

        $this->profile = (int)$this->session->userdata('perfil');
    }


    public function getMenuList()
    {
        return $this->responseJson(montaMenu($this->profile), 200);
    }

    public function getToolbarMenuList()
    {
        $menu = [
            [
                'desc' => 'Minha Conta',
                'url' => '/minhaConta'
            ],
            [
                'desc' => 'Sair',
                'url' => '/sair'
            ]
        ];

        $user = $this->session->userdata('nome');

        return $this->responseJson([
            'menu' =>$menu,
            'user' => $user
        ], 200);
    }
}