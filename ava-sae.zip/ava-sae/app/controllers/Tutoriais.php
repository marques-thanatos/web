<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tutoriais extends MY_Controller {

    public $layout = 'default';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $cssMinify = array('style_avasae_bootstrap3');
    public $css = array();
    public $js = array('jquery/dist/jquery.min', 'bootstrap/dist/js/bootstrap.min', 'jquery.cookie');
    public $keywords = array('avasae', 'curso');
    public $metaAcertos = 0;
    public $teste;

    public function __construct() {

        parent::__construct();

        $this->load->model('tutoriais_model');
    }

    public function index() {
        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        
        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'curso';
        $this->cssMinify[] = 'glyphicon';
        $this->cssMinify[] = 'datepicker';
        $this->css[] = $this->minify->getCSS('curso_index.min', $this->cssMinify, ENVIRONMENT);

        $this->js[] = 'bootstrap-datepicker';
        /* PRECISA CARREGAR ESSE MODEL PARA MONTAR O MENU VERTICAL */
        $this->load->model('curso_model', 'curso');

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $data['perfil'] = $this->session->userdata('perfil');
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['videoaulas'] = $this->tutoriais_model->getTutoriais($data['perfil']);

        $this->load->view('tutoriais', $data);
    }

    
    public function video($tutorialid) {
        
        $this->cssMinify[] = 'video';
        $this->cssMinify[] = 'style';
        $this->cssMinify[] = 'redactor/redactor';
        $this->cssMinify[] = 'glyphicon';
        $this->cssMinify[] = 'css-responsive';

        $this->css[] = $this->minify->getCSS('video_curso.min', $this->cssMinify, ENVIRONMENT);

        $this->js[] = 'flowplayer-3.2.12.min';
        $this->js[] = 'jquery.oembed.min';
        $this->js[] = 'jquery.paginate.min';
        $this->js[] = 'video';
        $this->js[] = 'bootstrap-tooltip';

        $video = $this->tutoriais_model->getVideo($tutorialid);

        if (!empty($video)) {
              $data['cursoNome'] = $video[0]['Descricao'];
              $data['perfil'] = $this->session->userdata('perfil');
           
            $linkVideoaula = $video[0]['PathVideo'];

            $data['videoNome'] = $video[0]['Descricao'];

            $data['videoPlayer'] = $linkVideoaula; //player($linkVideoaula);
            $idUsuario = $this->session->userdata('id');

            $this->session->set_userdata('link_video_aula', $linkVideoaula);
            $this->session->set_userdata('tema', $data['videoNome']);
            $data['videoPlayer'] = '<iframe width="100%" height="100%" scrolling="no" style="min-height: 420px;" src="' . base_url() . 'api-video" mozallowfullscreen webkitallowfullscreen allowfullscreen></iframe>';

            $data['tipo'] = 'player';
            if ($this->agent->is_mobile() || ($this->agent->browser() == 'Firefox' && $this->agent->version() >= 11) || ($this->agent->browser() == 'Chrome' && $this->agent->version() >= 25) || ($this->agent->browser() == 'Safari' && $this->agent->version() >= 6)) { // true
                $data['tipo'] = 'playerHTML5';
            }

            $this->load->view('video_tutorial', $data);
        } else {
            show_404('page');
        }
    }

}

/* End of file home.php */
/* Location: ./application/controllers/home.php */
