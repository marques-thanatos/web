<?php

use Ava\App\Exceptions\NotFoundException;
use Ava\App\Services\Aluno\BuscarAluno;
use Ava\App\Services\Aluno\ObterAlunoPorIdNextAva;
use Ava\App\Services\Aluno\BuscarAlunosPorResponsavel;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracaoGeralEscola;
use Ava\App\Services\Disciplinas\BuscarDisciplinasPorSerieVersao;
use Ava\App\Services\Disciplinas\BuscarDisciplinasPorTurma;
use Ava\App\Services\Disciplinas\BuscarDisciplinasPorTurmaLoginNextAva;
use Ava\App\Services\Disciplinas\BuscarDisciplinasPorTurmaLogin;
use Ava\App\Services\Disciplinas\BuscarDisciplinasPorTurmaNextAva;
use Ava\App\Services\Disciplinas\PegaDisciplinaPeloId;
use Ava\App\Services\JWT\CreateMetabaseJWT;
use Ava\App\Services\PlataformaLiteraria\BuscarDisciplinaLiterariaPorTurma;
use Ava\App\Services\Professor\BuscarProfessorPorEscola;
use Ava\App\Services\Professor\BuscarProfessoresPorCoordenador;
use Ava\App\Services\NextAVA\DisciplinasPorProfessorEAno;

use Ava\App\Services\Relatorios\Calculos\CalcularCoeficienteDesempenhoAcademico;
use Ava\App\Services\Relatorios\Exportar\ExportarRelatorioDesempenho;
use Ava\App\Services\Relatorios\Exportar\ExportarRelatorioDesempenhoSerie;
use Ava\App\Services\Relatorios\Exportar\ExportarRelatorioIndividualDiario;
use Ava\App\Services\Relatorios\Exportar\ExportarRelatorioPlataformaLiteraria;
use Ava\App\Services\Relatorios\Exportar\ExportarRelatorioPlataformaLiterariaAluno;
use Ava\App\Services\Relatorios\Exportar\ExportarRelatorioReforco;
use Ava\App\Services\Relatorios\Exportar\ExportarRelatorioTurma;
use Ava\App\Services\Relatorios\Helper\Csv2Xls;
use Ava\App\Services\Relatorios\RelatorioConsolidado;
use Ava\App\Services\Relatorios\RelatorioDesempenhoIndividual;
use Ava\App\Services\Relatorios\RelatorioDesempenhoIndividualDiario;
use Ava\App\Services\Relatorios\RelatorioDesempenhoSerie;
use Ava\App\Services\Relatorios\RelatorioDesempenhoSerieSAE;
use Ava\App\Services\Relatorios\RelatorioDesempenhoTurma;
use Ava\App\Services\Relatorios\RelatorioPlataformaLiteraria;
use Ava\App\Services\Relatorios\RelatorioPlataformaLiterariaAluno;
use Ava\App\Services\Relatorios\RelatorioReforco;
use Ava\App\Services\Series\ListarSeriesPorVersaoConteudoEscola;
use Ava\App\Services\Turma\BuscarDadosTurma;
use Ava\App\Services\Turma\BuscaDadosTurmaNextAva;
use Ava\App\Services\Relatorios\VerificaPlataformaLit;
use Ava\App\Services\Turma\BuscarTurmasPorEscolaAgrupadasPorSerie;
use Ava\App\Services\Turma\BuscarTurmasPorLoginAgrupadasPorSerie;
use Ava\App\Services\Turma\BuscarTurmasRelatorioNextAva;
use Ava\App\Services\Professor\BuscarProfessoresPorTurma;
use Ava\App\Services\Professor\BuscarAgendasPorDisciplinasTurmas;
use Ava\App\Services\Professor\BuscarAssuntoPorDisciplinasLivro;
use Ava\App\Services\Usuario\BuscarUsuarioPorLogin;
use Ava\App\Services\Usuario\ObterUsuarioNextAva;
use Ava\App\Services\Disciplinas\BuscarDisciplinaPorDescricaoAluno;
use Ava\App\Support\ClassificacaoConteudo;
use Ava\App\Support\Perfil;
use Knp\Snappy\Pdf;
use League\Csv\Writer;
use League\Flysystem\Adapter\Local;
use League\Flysystem\Filesystem;
use Swagger\Annotations as SWG;

use Ava\App\Services\Metabase\StudentReportService;
use Ava\App\Services\NextAVA\AlunosResponsavelNextAva;
use Ava\App\Services\NextAVA\ObterDisciplinasTurmasNextAVA;

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Relatorio extends MY_Controller
{
    public $css = [];
    public $title = 'AVA SAE';
    public $layout = 'relatorio';
    public $keywords = ['avasae', 'curso'];
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $cssMinify = ['style_avasae_bootstrap3', 'botao_imprimir', 'mensagem'];
    public $js = ['jquery/dist/jquery.min', 'bootstrap/dist/js/bootstrap.min', 'mensagem'];
    private $relatorioDisciplinaService;

    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logado')) {
            $dados['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menurelatorio', $dados, true);
        }

        $this->css[] = $this->minify->getCSS('relatorio_index.min', $this->cssMinify, ENVIRONMENT);
        $this->relatorioDisciplinaService = new BuscarDisciplinaPorDescricaoAluno();
    }

    public function index()
    {
        if (intval($this->session->userdata('perfil')) === intval(Perfil::RESPONSAVEL)) {
            redirect('/responsavel');
        }
        if (in_array((int)$this->session->userdata('perfil'), [Perfil::ALUNO, Perfil::RESPONSAVEL])) {
            $this->layout = 'new-ava';
            $this->title = 'AVA SAE';
            $this->description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
            $this->load->view('relatorios/aluno', [
                'perfil' => (int)$this->session->userdata('perfil'),
                'plataforma' => SaeDigital::make(VerificaPlataformaLit::class)->handle(
                    $this->session->userdata('id'))
            ]);
        } elseif (intval($this->session->userdata('perfil')) === Perfil::COORDENADOR) {
            $this->load->view('relatorios/index', [
                'perfil' => (int)$this->session->userdata('perfil')
            ]);
        } else {
            $this->load->view('relatorios/index', [
                'perfil' => (int)$this->session->userdata('perfil'),
                'plataforma' => SaeDigital::make(VerificaPlataformaLit::class)->handle(
                    $this->session->userdata('id'))
            ]);
        }
    }

    public function informativo()
    {
        $this->layout = false;
        $template = '';
        $perfil = (int)$this->session->userdata('perfil');
        if (in_array($perfil, [Perfil::ALUNO, Perfil::RESPONSAVEL])) {
            $template = $this->load->view('relatorios/informativoAluno', [], true);
        } elseif (in_array($perfil, [Perfil::PROFESSOR, Perfil::COORDENADOR])) {
            $template = $this->load->view('relatorios/informativoTurma', [
                "perfil" => $perfil
            ], true);
        } elseif ($perfil === Perfil::DIRETOR) {
            $template = $this->load->view('relatorios/informativoDiretor', [], true);
        }

        return $this->responseJson(['template' => $template], 200);
    }

    /**
     *  Index da tela de relatórios da turma.
     */
    public function relatorioTurma()
    {
        try {
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $template = $this->load->view('relatorios/relatorioTurma', [], true);

            return $this->responseJson(['template' => $template], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function relatorioConsolidado()
    {
        try {
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR]);

            $template = $this->load->view('relatorios/relatorioConsolidado', [], true);

            return $this->responseJson(['template' => $template], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    /**
     *  Index da tela de relatório geral da escola, acessada pelo diretor
     */
    public function relatorioGeralEscola()
    {
        try {
            $this->allowProfile([Perfil::DIRETOR]);

            $this->load->view('relatorios/relatorioGeralEscola', []);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function relatorioReforco()
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $template = $this->load->view('relatorios/relatorioReforco', [], true);

            return $this->responseJson(['template' => $template], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function relatorioVideoaulas()
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $template = $this->load->view('relatorios/relatorioVideoaulas', [], true);

            return $this->responseJson(['template' => $template], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function metabaseVideoaulasReportUrl()
    {
        try {
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $idTurma = $this->input->get('idTurma');
            $idDisciplina = $this->input->get('idDisciplina');
            $idEscola = $this->session->userdata('escola');

            /** @var CreateMetabaseJWT $metabaseService */
            $metabaseService = SaeDigital::make(CreateMetabaseJWT::class);

            $params = [
                'escola' => $idEscola,
                'turma' => $idTurma,
                'componente_curricular' => $idDisciplina
            ];

            $metabaseToken = $metabaseService->getDashboard(5, $params);
            $metabaseUrl = $metabaseService->generateUrl($metabaseToken);

            $data = [
                'success' => true,
                'metabaseUrl' => $metabaseUrl,
                'params' => $params
            ];

            return $this->responseJson($data, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    /**
     *  Index da tela de relatório diário do aluno, acessado por aluno e responsável
     */
    public function relatorioAlunoDiario()
    {
        try {
            $this->allowProfile([Perfil::ALUNO, Perfil::RESPONSAVEL]);

            $data['perfil'] = (int)$this->session->userdata('perfil');
            if ($data['perfil'] === Perfil::ALUNO) {
                $data['idAluno'] = $this->session->userdata('pessoaid');
            }

            $template = $this->load->view('relatorios/relatorioAlunoDiario', $data, true);

            return $this->responseJson(['template' => $template], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    /**
     *  Index da tela de relatório de desempenho do aluno.
     */
    public function relatorioAlunoDesempenho($idAluno = null)
    {
        try {
            $this->allowProfile([
                Perfil::ALUNO,
                Perfil::RESPONSAVEL,
                Perfil::PROFESSOR,
                Perfil::COORDENADOR,
                Perfil::DIRETOR
            ]);

            $data['idAluno'] = $idAluno;
            $data['perfil'] = (int)$this->session->userdata('perfil');
            if ($data['perfil'] === Perfil::ALUNO) {
                $data['idAluno'] = $this->session->userdata('pessoaid');
            }

            if (is_null($idAluno)) {
                $template = $this->load->view('relatorios/relatorioAlunoDesempenho', $data, true);

                return $this->responseJson(['template' => $template], 200);
            }


            $this->load->view('relatorios/relatorioAlunoDesempenhoDocente', $data);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function relatorioPlataformaLiteraria()
    {
        try {
            $perfil = (int)$this->session->userdata('perfil');

            if (in_array($perfil, [Perfil::DIRETOR, Perfil::COORDENADOR, Perfil::PROFESSOR])) {
                $template = $this->load->view('relatorios/plataformaLiteraria/turma', [], true);
            } else {
                $data['perfil'] = $perfil;
                if ($data['perfil'] === Perfil::ALUNO) {
                    $data['idAluno'] = $this->session->userdata('pessoaid');
                }
                $template = $this->load->view('relatorios/plataformaLiteraria/aluno', $data, true);
            }
            return $this->responseJson(['template' => $template], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function relatorioAcompanhamentoAtividade()
    {
        try {
            $this->allowProfile([
                Perfil::COORDENADOR,
                Perfil::DIRETOR
            ]);

            $template = $this->load->view('relatorios/relatorioAcompanhamentoAtividade', [$this->session->userdata('pessoaid')], true);

            return $this->responseJson(['template' => $template], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    /**
     *  Busca as informações necessárias para exibição do relatório de turmas que pode ser acessado pelo
     *  diretor, coordenador e professor
     */
    public function buscarDadosRelatorioTurma()
    {
        try {
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR, Perfil::PROFESSOR]);
           
            $idTurma = $this->input->get('idTurma');
            $idDisciplina = $this->input->get('idDisciplina');
			$idEscola = $this->session->userdata('escola');
            //$turma = SaeDigital::make(BuscarDadosTurma::class)->handle($idTurma, ['A'], Date('Y'));
            $turma = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($idTurma)[0];
  
            $data['relatorio'] = SaeDigital::make(RelatorioDesempenhoTurma::class)->handle(
                $idTurma,
                $turma->schoolId,
                $turma->gradeId,
                $idDisciplina
            );
			$configEscola = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle($idEscola);

            if ($configEscola['MediaTurmaRelatorio'] === 'S') {
                if (in_array((int)$this->session->userdata('perfil'), [Perfil::PROFESSOR, Perfil::COORDENADOR])) {

                    
                    $data['medias'] = SaeDigital::make(RelatorioDesempenhoSerie::class)->handle(
                        $turma->gradeId, $idDisciplina, $idEscola, false, true
                    );
                    
                } else {
                    $data['medias'] = SaeDigital::make(RelatorioDesempenhoSerieSAE::class)->handle(
                        $turma->gradeId, $idDisciplina, $idEscola
                    );
                }
			}
			
			return $this->responseJson($data, 200);
			
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao pesquisar os dados do relatório, por favor tente novamente!',
                'error' => $e->getMessage()
            ], 400);
        }
    }

    /**
     *  Busca as informações necessárias para exibição do relatório diário do aluno que pode ser acessado pelo aluno
     *  e seus responsáveis.
     *
     *  O relatório diário traz informações das atividades agendadas pela data escolhida pelo usuário
     */
    public function buscarDadosRelatorioDiario()
    {
        try {
            $this->allowProfile([Perfil::ALUNO, Perfil::RESPONSAVEL]);

            $idAluno = $this->input->get('idAluno') ?: $this->session->userdata('pessoaid');
            $dataInicial = DateTime::createFromFormat('d-m-Y', $this->input->get('dataInicial'))->setTime(0, 0, 0);
            $dataFinal = DateTime::createFromFormat('d-m-Y', $this->input->get('dataFinal'))->setTime(0, 0, 0);

            $aluno = (array) SaeDigital::make(ObterAlunoPorIdNextAva::class)->handle($idAluno);
            
            if (!$aluno) {
                throw new NotFoundException('Aluno informado não foi encontrado!');
            }
            $data['nome'] = $aluno['nome'];
            
            $data['relatorio'] = SaeDigital::make(RelatorioDesempenhoIndividualDiario::class)->handle(
                $aluno['itemName'], $aluno['Turma'], $aluno['EscolaID'], $dataInicial, $dataFinal
            );
            
            return $this->responseJson($data, 200);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao pesquisar os dados do relatório, por favor tente novamente',
                'error' => $e->getMessage()
            ], 400);
        }
    }

    /**
     *  Busca as informações necessárias para exibição do relatório de desempenho geral do aluno que pode
     *  ser acessado pelo aluno e seus responsáveis.
     *
     *  O relatório de desempenho traz informações de todos os agendamentos feitos para a turma do aluno
     */
    public function buscarDadosRelatorioDesempenho()
    {
        try {
            $this->allowProfile([
                Perfil::ALUNO,
                Perfil::RESPONSAVEL,
                Perfil::PROFESSOR,
                Perfil::COORDENADOR,
                Perfil::DIRETOR
            ]);

            $idAluno = $this->input->get('idAluno') ?: $this->session->userdata('pessoaid');

            //$aluno = SaeDigital::make(BuscarAluno::class)->handle($idAluno);
            $aluno = (array) SaeDigital::make(ObterAlunoPorIdNextAva::class)->handle($idAluno);

            if (!$aluno) {
                throw new NotFoundException('Aluno informado não foi encontrado!');
            }

            $data['nome'] = ucwords(strtolower($aluno['nome']));
            $data['serie'] = $aluno['gradeName'];     
                  

            $data['relatorio'] = SaeDigital::make(RelatorioDesempenhoIndividual::class)->handle(
                $aluno['itemName'],
                $aluno['Turma'],
                $aluno['Escola']
			);

            $data['coeficiente'] = SaeDigital::make(CalcularCoeficienteDesempenhoAcademico::class)->handle(
                $data['relatorio']
            );

			// JAGUATIRICA
			$configEscola = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle($aluno['Escola']);
			if ( $configEscola['MediaTurmaRelatorio'] === 'S' ) {
                $turma = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($aluno['Turma'])[0];
				$data['medias'] = SaeDigital::make(RelatorioDesempenhoTurma::class)->handle(
				    $turma->id,
				    $turma->schoolId,
				    $turma->gradeId
                );
                $desempenhos = array_column($data['medias'], 'desempenho');

                $data['medias']['media_turma'] = count($desempenhos) > 0 ? array_sum($desempenhos) / count($desempenhos) : 0;
            }
            
            $data['status'] = 'OK';

            return $this->responseJson($data, 200);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao pesquisar os dados do relatório, por favor tente novamente',
                'error' => $e->getMessage()
            ], 400);
        }
	}
	
	// FUNÇÃO EXCLUSIVA PARA A JAGUATIRICA
	private function obterIdEscolaLevel($itemNameEscola) {
		$escolas = [
			'7159697ec35b996c30bbc853cc7637f8'	=> 1,		// integracao.dombosco
			'd07e0a07387e91cde8c81768443f235b'	=> 1,		// new_integracao.dombosco
			'6a05926dc211749512f0eb22f2266f18'	=> 2,		// santo.anjo
			'c37583ada557da3fae05eda1f39895cc'	=> 2,		// new_santo.anjo
			'dae1e5d16ceecbbc14586bb1b8a9b418'	=> 4,		// dombosco.balsas
			'9618df4005ddc7d05a384b22553fd393'	=> 4,		// new_dombosco.balsas
		];

		return isset($escolas[$itemNameEscola]) ? $escolas[$itemNameEscola] : 0;
	}

    /**
     *  Busca as informações necessárias para exibição do relatório de desempenho geral da série e disciplina da escola
     *
     *  Pode ser acessado pelo diretor
     */
    public function buscarDadosRelatorioGeralEscola()
    {
        try {
            $idSerie = $this->input->get('idSerie');
            $idDisciplina = $this->input->get('idDisciplina');
            $idEscola = $this->session->userdata('escola');

            $configEscola = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle($idEscola);

            $data['relatorio'] = SaeDigital::make(RelatorioDesempenhoSerie::class)->handle(
                $idSerie,
                $idDisciplina,
                $idEscola,
                true
            );

            if ($configEscola['MediaTurmaRelatorio'] === 'S') {
                $data['medias'] = SaeDigital::make(RelatorioDesempenhoSerieSAE::class)->handle(
                    $idSerie, $idDisciplina, $idEscola, false
                );
            }

            return $this->responseJson($data, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao buscar dados do relatório, por favor tente novamente'
            ], 400);
        }
    }

    public function buscarDadosRelatorioConsolidado()
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::DIRETOR]);

            $idTurma = $this->input->get('idTurma');
            $bimestre = $this->input->get('bimestre');
            $idEscola = $this->session->userdata('escola');

			$relatorio = SaeDigital::make(RelatorioConsolidado::class)->handle($idEscola, $idTurma, $bimestre);
			
            return $this->responseJson(['relatorio' => $relatorio], 200);
        } catch (Exception $e) {
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao buscar dados do relatório, por favor tente novamente',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function buscarDadosRelatorioPlataformaLiteraria()
    {
        $this->layout = false;
        try {
            $data = [];

            $idTurma = $this->input->get('idTurma');
            $idAluno = $this->input->get('idAluno');
            $versao = (int)$this->session->userdata('versao_conteudo_id');

            if ($idTurma) {
                $turma = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($idTurma)[0];
                if (count($turma) === 0) {
                    throw new NotFoundException('Turma informada não foi encontrada');
                }

                $getTurmas = SaeDigital::make(ObterDisciplinasTurmasNextAVA::class)->handle($idTurma);                            

                $getGrade = $getTurmas[0]->grade_id;

                $disciplinas = SaeDigital::make(BuscarDisciplinasPorTurmaNextAva::class)->handle($idTurma, $getGrade);

                foreach ($disciplinas as $disciplina) {
                if ((int)$disciplina['idClassificacao'] === ClassificacaoConteudo::PLATAFORMA_LITERARIA) {
                        $idDisciplina = $disciplina;
                    }
                }

                $data['relatorio'] = SaeDigital::make(RelatorioPlataformaLiteraria::class)->handle(
                    $idTurma, $turma->schoolId, $idDisciplina['idDisciplina']
                );

            } else {
                $aluno = SaeDigital::make(BuscarAluno::class)->handle($idAluno);
                if (count($aluno) === 0) {
                    throw new NotFoundException('Aluno não encontrado');
                }

                $idDisciplina = SaeDigital::make(BuscarDisciplinaLiterariaPorTurma::class)->handle(
                    $aluno['Turma'], $versao
                );

                $data['relatorio'] = SaeDigital::make(RelatorioPlataformaLiterariaAluno::class)->handle(
                    $idAluno, $aluno['Turma'], $aluno['Escola'], $idDisciplina['idDisciplina']
                );
            }

            return $this->responseJson($data, 200);
        } catch (Exception $e) {
            return $this->responseJson([
                'message' => 'Ocorreu um erro ao buscar dados do relatório, por favor tente novamente!',
                'error' => $e->getMessage()
            ], 200);
        }
    }

    /**
     * Busca as séries cadastradas pela versão de conteudo da escola
     */
    public function buscarSeries()
    {
        try {
            $idVersao = $this->session->userdata('versao_conteudo_id');
            $idEscola = $this->session->userdata('escola');

            $series = SaeDigital::make(ListarSeriesPorVersaoConteudoEscola::class)->handle($idVersao, $idEscola);

            /**
             * Essas séries não devem aparecer nos relatórios
             */
            $seriesParaRemover = [1, 2, 3, 14, 15, 16, 17, 18, 19];


            $data['series'] = [];
            foreach ($series as $serie) {
                if (in_array($serie['idSerie'], $seriesParaRemover)) {
                    continue;
                }

                $data['series'][] = $serie;
            }

            return $this->responseJson($data, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema na busca das séries, por favor tente novamente'
            ], 400);
        }
    }

    /**
     * Faz a pesquisa das turmas por login caso seja professor ou coordenador, caso seja diretor busca as turmas da
     * escola
     *
     * @SWG\Get(
     *      path="/reports/teams",
     *      summary="Retorna lista de turmas de professor, coordenador e diretor",
     *      description="Busca as turmas vinculadas ao usuarios utilizando o login",
     *      produces={"application/json"},
     *      tags={"Relatórios"},
     *      @SWG\Parameter(
     *          name="plataformaLiteraria",
     *          in="query",
     *          description="Filtra dados por turma que possuem plataforma literária",
     *          type="boolean",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="arraseNoEnem",
     *          in="query",
     *          description="Filtra dados por turma que possuem arrase no enem",
     *          type="boolean",
     *          required=false
     *     ),
     *     @SWG\Parameter(
     *          name="allGrades",
     *          in="query",
     *          description="Retorna todas as turmas",
     *          type="boolean",
     *          required=false
     *     ),
     *      @SWG\Response(
     *          response=200,
     *          description="Success"
     *      ),
     *     @SWG\Response(
     *          response=400,
     *          description="Bad Request"
     *     )
     * )
     * @return string
     */
    public function buscarTurmas()
    {
        try {
            $login = $this->session->userdata('login');
			$plataformaLiteraria = $this->input->get('plataformaLiteraria') === "true";

            if ((int)$this->session->userdata('perfil') === Perfil::DIRETOR) {
                $series = SaeDigital::make(BuscarTurmasPorEscolaAgrupadasPorSerie::class)->handle(
                    $this->session->userdata('escola')
                );
            } else {
                
                $teamsArray = $this->session->userdata('teams');
                $series = SaeDigital::make(BuscarTurmasRelatorioNextAva::class)->handle($teamsArray);
            }

            $response = [];
            // Remove as turmas infantis e fundamental I, II, III
            $seriesParaRemover = [14, 15, 16, 17, 18, 19];

            $allGrades = $this->input->get('allGrades');
            if ($allGrades && filter_var($allGrades, FILTER_VALIDATE_BOOLEAN)){
                $seriesParaRemover = [];
            }

            $arraseNoEnem = $this->input->get('arraseNoEnem');
            if ($arraseNoEnem && filter_var($arraseNoEnem, FILTER_VALIDATE_BOOLEAN)){
                $seriesParaRemover = [1, 2, 3, 4, 5, 6, 7, 8, 9, 14, 15, 16, 17, 18, 19];
            }

            if ($plataformaLiteraria) {
                // Remove as turmas infantis e ensino médio
                $seriesParaRemover = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
            }

            // Zera as filtragem de turma
            $showAll = (bool)$this->input->get('showAll');
            if ($showAll) {
                $seriesParaRemover = [];
            }

            foreach ($series as $serie => $turmas) {
                foreach ($turmas as $turma) {
                    if (in_array($turma->idSerie, $seriesParaRemover)) {
                        continue;
                    }

                    $response[$serie][] = $turma;
                }
            }

            return $this->responseJson($response, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'success' => false,
                'message' => 'Ocorreu um problema ao pesquisar as turmas, por favor tente novamente!'
            ], 400);
        }
    }

    /**
     * Faz a pesquisa de disciplinas pela turma e login caso seja professor, se não, busca disciplinas por turma
     *
     * @SWG\Get(
     *     path="/reports/teams/{idTurma}/curricular-components",
     *     summary="Retorna lista de componentes curriculares de uma turma",
     *     description="Busca lista de componentes curriculares disponíveis em uma turma consideranda vinculo com usuário.",
     *     produces={"application/json"},
     *     tags={"Relatórios"},
     *     @SWG\Parameter(
     *          name="idTurma",
     *          in="path",
     *          required=true,
     *          description="Identificaçao unica da turma."
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=400,
     *          description="Bad Request"
     *     )
     * )
     *
     * @param null|string $idTurma
     * @return string
     */
    public function buscarDisciplinasPorTurma($idTurma = null)
    {
        try {
            $login = $this->session->userdata('login');
            $idTurma = $this->input->get('idTurma') ?: $idTurma;

            if ((int)$this->session->userdata('perfil') === Perfil::PROFESSOR) {
                $token = $this->session->userdata('token');
                $disciplinas = SaeDigital::make(BuscarDisciplinasPorTurmaLoginNextAva::class)->handle($idTurma, $login, $token);
            } else {
                $disciplinas = SaeDigital::make(BuscarDisciplinasPorTurmaNextAva::class)->handle($idTurma);
            }

            $response = [];
            foreach ($disciplinas as $disciplina) {
                if ((int)$disciplina['idClassificacao'] === ClassificacaoConteudo::CONTEUDO_GERAL) {
                    $response[] = $disciplina;
                }
			}

            if (empty($response)) {
                throw new NotFoundException('Não há agendamentos para esta turma.');
            }

            return $this->responseJson($response, 200);
        } catch (NotFoundException $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => $e->getMessage()
            ], 404);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao buscar disciplinas, por favor tente novamente'
            ], 400);
        }
    }

    /**
     * Faz a pesquisa de disciplinas por serie das turmas da escola
     *
     * @SWG\Get(
     *     path="/reports/grades/{idSerie}/curricular-components",
     *     summary="Retorna lista de componentes curriculares de uma série",
     *     description="Busca lista de componentes curriculares disponíveis em uma série.",
     *     produces={"application/json"},
     *     tags={"Relatórios"},
     *     @SWG\Parameter(
     *          name="idSerie",
     *          in="path",
     *          required=true,
     *          description="Identificaçao unica da série."
     *     ),
     *     @SWG\Response(
     *          response=200,
     *          description="Success"
     *     ),
     *     @SWG\Response(
     *          response=400,
     *          description="Bad Request"
     *     )
     * )
     *
     * @param int|null $idSerie
     * @return void
     */
    public function buscarDisciplinasPorSerie($idSerie = null)
    {
        try {
            $idSerie = $this->input->get('idSerie') ?: $idSerie;
            $idVersao = $this->session->userdata('versao_conteudo_id');

            $disciplinas = SaeDigital::make(BuscarDisciplinasPorSerieVersao::class)->handle(
                Date('Y'), $idSerie, $idVersao, [ClassificacaoConteudo::CONTEUDO_GERAL]
            );

            $data['disciplinas'] = [];
            foreach ($disciplinas as $disciplina) {
                if ((int)$disciplina['ClassificacaoID'] === ClassificacaoConteudo::CONTEUDO_GERAL) {
                    $data['disciplinas'][] = [
                        'idDisciplina' => (int)$disciplina['itemName'],
                        'descricao' => $disciplina['Descricao']
                    ];
                }

            }

            return $this->responseJson($data, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao buscar disciplinas, por favor tente novamente'
            ], 400);
        }
    }

    /**
     *  Método para busca de alunos através do login de responsável
     */
    public function buscarAlunosPorResponsavel()
    {
        try {
            $this->allowProfile([Perfil::RESPONSAVEL]);

            $alunos = SaeDigital::make(AlunosResponsavelNextAva::class)->handle($this->session->userdata('pessoaid'));
            //$alunos = SaeDigital::make(BuscarAlunosPorResponsavel::class)->handle($this->session->userdata('login'));

            return $this->responseJson($alunos, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema na pesquisa de alunos, por favor tente novamente!'
            ], 400);
        }
    }

    /**
     * Faz a pesquisa das professores por login de coordenador
     *
     * @return array
     */
    public function buscarProfessoresPorCoord()
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::DIRETOR]);

            $login      = $this->session->userdata('login');
            $person_id  = $this->session->userdata('id');  
            $profs      = [];
 
            if ((int)$this->session->userdata('perfil') === Perfil::COORDENADOR) { 
                $profs = SaeDigital::make(BuscarProfessoresPorCoordenador::class)->handle($this->session->userdata('id'));
                
            } else {                
                $profs = SaeDigital::make(BuscarProfessorPorEscola::class)->handle($this->session->userdata('escola'));
            } 
            return $this->responseJson($profs, 200);
        } catch (Exception $e) { 
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao pesquisar as turmas, por favor tente novamente!'
            ], 400);
        }
    }

    /**
     *  Busca as informações necessárias para exibição do relatório de acompanhamento de atividades que pode ser acessado pelo
     *  diretor, coordenador
     */
    public function buscarDadosAcompanhamentoAtividades()
    { 
        try {
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR]);

            $dadosProfessor = $this->input->get('professor');
            $bimestre       = $this->input->get('bimestre');
            $tmpProfessor   = explode(';', $dadosProfessor);
            $idProfessor    = $tmpProfessor[0]; 
            $data = [];
 
            $fullDataFromTeacher  = SaeDigital::make(ObterUsuarioNextAva::class)->handle("", $idProfessor);

            if(empty($fullDataFromTeacher) || empty($fullDataFromTeacher->teams) || empty($fullDataFromTeacher->subjects)){
                throw new Exception("Não foram encontrados dados suficientes para filtro das informações.");
            }
            
            //(na base existe indexacao se estiver no formato texto)
            $apenasDisciplinas  = implode(",", array_unique(array_map(function($e){return "'". $e ."'";}, $fullDataFromTeacher->subjects)));
            $apenasTurmas = [];

            foreach($fullDataFromTeacher->teams as $turma){
                //(na base existe indexacao se estiver no formato texto)
                $apenasTurmas[]   = "'" . $turma->id . "'";
                $data[$turma->id] = [
                    "name"        => $turma->name,
                    "scheduled"   => 0,
                    "total"       => 0,
                    "progress"    => 0,
                    "listaAberta" => false,
                    "items"       => []
                ];
            }

            $t0 = microtime(TRUE);
            $assuntosDisciplinas = SaeDigital::make(BuscarAssuntoPorDisciplinasLivro::class)->handle($bimestre, $apenasDisciplinas); 
            $agendas = collect(SaeDigital::make(BuscarAgendasPorDisciplinasTurmas::class)->handle($apenasDisciplinas, implode(",", array_unique($apenasTurmas))));
               
            $t1 = microtime(TRUE);
            foreach($assuntosDisciplinas as $assuntoDisciplina){
                foreach($fullDataFromTeacher->teams as $turma){ 
                    if($turma->grade_id != $assuntoDisciplina['serie_id'] || !empty($data[$turma->id]['items'][$assuntoDisciplina['disciplina_id']][$assuntoDisciplina['assunto_id']])){
                        continue;
                    }
                    $dta_inicio = $dta_fim = $existe = null; 
                    $dataInicioFormatada = $dataFimFormatada = "";
                    $existe = $agendas->where('assunto_id',    $assuntoDisciplina['assunto_id'])
                                        ->where('disciplina_id', $assuntoDisciplina['disciplina_id'])
                                        ->where('turma_id',      $turma->id)
                                        ->first();
                    $flagExiste = !empty($existe) && !empty($existe['agenda_id']);
                    if($flagExiste){
                        $dta_inicio          = DateTime::createFromFormat('Y-m-d', $existe['dta_inicio']);
                        $dta_fim             = DateTime::createFromFormat('Y-m-d', $existe['dta_fim']);
                        $dataInicioFormatada = ($dta_inicio ? $dta_inicio->format('d/m/Y')  : '');
                        $dataFimFormatada    = ($dta_fim    ? $dta_fim->format('d/m/Y')     : ''); 
                    }
                    $data[$turma->id]['items'][$assuntoDisciplina['disciplina_id']][$assuntoDisciplina['assunto_id']] = 
                    [ 
                        "name"       => $assuntoDisciplina['assunto_descricao'],
                        "disciplina" => $assuntoDisciplina['disciplina_descricao'],
                        "agenda"     => $flagExiste,
                        "dta_inicio" => $dataInicioFormatada,
                        "dta_fim"    => $dataFimFormatada
                    ];
                    if($flagExiste){
                        $data[$turma->id]["scheduled"]++;
                    }
                    $data[$turma->id]["total"]++;
                    $data[$turma->id]["progress"] = round(($data[$turma->id]["scheduled"] / $data[$turma->id]["total"]) * 100, 1);                    
                }
            }
            return $this->responseJson([
                "relatorio" => array_values($data), 
                't0' => $t1 - $t0, 
                't1' => microtime(TRUE) - $t1
            ], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao pesquisar os dados do relatório, por favor tente novamente!'
            ], 400);
        }
    }

    public function exportarRelatorioTurma()
    {
        try {
            $this->layout = false;
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR, Perfil::PROFESSOR]);
            $data = [];

            $idTurma = $this->input->get('idTurma');
            $idDisciplina = $this->input->get('idDisciplina');
            $tipoArquivo = $this->input->get('tipoArquivo');
            $data['listaAssuntos'] = $this->input->get('listaAssuntos');
            $data['listaBimestres'] = $this->input->get('listaBimestres');

            $turma = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($idTurma)[0];
            if (count($turma) === 0) {
                throw new NotFoundException('Turma informada não existe!');
            }
          

            if ($tipoArquivo === 'pdf') {
                $data['turma'] = $turma->name;
                $data['serie'] = $turma->grade;
                $data['escola'] = $turma->schoolName;

                $data['relatorio'] = SaeDigital::make(RelatorioDesempenhoTurma::class)->handle(
                    $idTurma,
                    $turma->schoolId,
                    $turma->gradeId,
                    $idDisciplina
                );
            } else {
                $relatorio = SaeDigital::make(ExportarRelatorioTurma::class)->handle(
                    $idTurma,
                    $turma->schoolId,
                    $turma->gradeId,
                    $idDisciplina
                );

                $csv = Writer::createFromFileObject(new SplTempFileObject());
                $csv->insertOne($relatorio['headers']);
                $csv->insertAll($relatorio['data']);
            }

            $nomeArquivo = 'Relatório Turma - ' . $turma->name . ' - ' . Date('d-m-Y');
            if ($tipoArquivo === 'csv') {
                $csv->output($nomeArquivo . '.csv');
            } elseif ($tipoArquivo === 'xlsx') {
                $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xlsx');
            } else {
                $html = $this->twig()->render('relatorios/relatorio-turma.twig', $data);
                $this->exportarPdf($html);
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function exportarRelatorioAcompanhamento()
    { 
        try {
            $this->layout = false;
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR]);

            $data               = [];
            $items              = [];
            $turmasDisponiveis  = [];
            $dataCsv            = [];
            $dadosProfessor     = $this->input->get('professor');
            $tmpProfessor       = explode(';', $dadosProfessor);
            $idProfessor        = $tmpProfessor[0];
            $nomeProfessor      = $tmpProfessor[1];
            $nomeEscola         = $this->session->userdata('school')->Nome;
            $bimestre           = $this->input->get('bimestre');
            $tipoArquivo        = $this->input->get('tipoArquivo');
            $nomeArquivo        = 'Relatório Acompanhamento - ' . $nomeProfessor . ' - ' . date('d-m-Y');
  
            $fullDataFromTeacher  = SaeDigital::make(ObterUsuarioNextAva::class)->handle("", $idProfessor);

            if(empty($fullDataFromTeacher) || empty($fullDataFromTeacher->teams) || empty($fullDataFromTeacher->subjects)){
                throw new Exception("Não foram encontrados dados suficientes para filtro das informações.");
            }
            
            //(na base existe indexacao se estiver no formato texto)
            $apenasDisciplinas  = implode(",", array_unique(array_map(function($e){return "'". $e ."'";}, $fullDataFromTeacher->subjects)));
            $apenasTurmas = [];

            foreach($fullDataFromTeacher->teams as $turma){
                //(na base existe indexacao se estiver no formato texto)
                $apenasTurmas[]   = "'" . $turma->id . "'";
                $data[$turma->id] = [
                    "name"        => $turma->name,
                    "scheduled"   => 0,
                    "total"       => 0,
                    "progress"    => 0,
                    "listaAberta" => false,
                    "items"       => []
                ];
            }
 
            $assuntosDisciplinas = SaeDigital::make(BuscarAssuntoPorDisciplinasLivro::class)->handle($bimestre, $apenasDisciplinas); 
            $agendas = collect(SaeDigital::make(BuscarAgendasPorDisciplinasTurmas::class)->handle($apenasDisciplinas, implode(",", array_unique($apenasTurmas))));
                
            foreach($assuntosDisciplinas as $assuntoDisciplina){
                foreach($fullDataFromTeacher->teams as $turma){ 
                    if($turma->grade_id != $assuntoDisciplina['serie_id'] || !empty($data[$turma->id]['items'][$assuntoDisciplina['disciplina_id']][$assuntoDisciplina['assunto_id']])){
                        continue;
                    }
                    $dta_inicio = $dta_fim = $existe = null; 
                    $dataInicioFormatada = $dataFimFormatada = "";
                    $existe = $agendas->where('assunto_id',    $assuntoDisciplina['assunto_id'])
                                      ->where('disciplina_id', $assuntoDisciplina['disciplina_id'])
                                      ->where('turma_id',      $turma->id)
                                      ->first();
                    $flagExiste = !empty($existe) && !empty($existe['agenda_id']);
                    if($flagExiste){
                        $dta_inicio          = DateTime::createFromFormat('Y-m-d', $existe['dta_inicio']);
                        $dta_fim             = DateTime::createFromFormat('Y-m-d', $existe['dta_fim']);
                        $dataInicioFormatada = ($dta_inicio ? $dta_inicio->format('d/m/Y')  : '');
                        $dataFimFormatada    = ($dta_fim    ? $dta_fim->format('d/m/Y')     : ''); 
                    }

                    $data[$turma->id]['items'][$assuntoDisciplina['disciplina_id']][$assuntoDisciplina['assunto_id']] = [
                        "name"       => $assuntoDisciplina['assunto_descricao'],
                        "disciplina" => $assuntoDisciplina['disciplina_descricao'],
                        "agenda"     => $flagExiste,
                        "dta_inicio" => $dataInicioFormatada,
                        "dta_fim"    => $dataFimFormatada,
                    ];

                    if ($tipoArquivo == 'csv') {
                        array_push($dataCsv,[
                                iconv("UTF-8", "ISO-8859-1", $turma->name),
                                iconv("UTF-8", "ISO-8859-1", $bimestre),
                                iconv("UTF-8", "ISO-8859-1", $assuntoDisciplina['disciplina_descricao']), 
                                iconv("UTF-8", "ISO-8859-1", $assuntoDisciplina['assunto_descricao']),
                                "dta_inicio" => $dataInicioFormatada,
                                "dta_fim"    => $dataFimFormatada,
                                "agenda"     => ($flagExiste ? "S" : "N"),
                            ]); 
                    }elseif ($tipoArquivo == 'pdf') {                        
                        if($flagExiste){
                            $data[$turma->id]["scheduled"]++;
                        }
                        $data[$turma->id]["total"]++;
                        $data[$turma->id]["progress"] = round(($data[$turma->id]["scheduled"] / $data[$turma->id]["total"]) * 100, 1);  
                    }else{
                        array_push($dataCsv,[                                    
                                $turma->name,
                                $bimestre,
                                $assuntoDisciplina['disciplina_descricao'],
                                $assuntoDisciplina['assunto_descricao'],
                                "dta_inicio" => $dataInicioFormatada,
                                "dta_fim"    => $dataFimFormatada,
                                "agenda"     => ($flagExiste ? "S" : "N"),
                            ]); 
                    }
                }
            } 
            
            
            if ($tipoArquivo === 'pdf') {
                $data = [
                    'professor' => $nomeProfessor,
                    'bimestre'  => $bimestre,
                    'escola'    => $nomeEscola,
                    'relatorio' => $data
                ];

                $html = $this->twig()->render('relatorios/relatorio-acompanhamento.twig', $data); 
                return $this->exportarPdf($html);
            }

            $csv = Writer::createFromFileObject(new SplTempFileObject());
            $csv->insertOne([
                    "Turma",
                    "Livro",
                    "Disciplina",
                    "Assunto",
                    ($tipoArquivo == 'csv' ? iconv("UTF-8", "ISO-8859-1", "Início") : "Início"),
                    "Fim",
                    "Agendamento"]
            );

            $csv->insertAll($dataCsv);
            if ($tipoArquivo === 'csv') {
                return $csv->output($nomeArquivo . '.csv');
            }

            $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xls');

        } catch (Exception $e) { 
            log_error($e->getMessage());
            return show_404();
        }
    }

    public function exportarRelatorioConsolidado()
    {
        try {
            $this->layout = false;
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $idTurma = $this->input->get('idTurma');
            $bimestre = $this->input->get('bimestre');
            $tipoArquivo = $this->input->get('tipoArquivo');

            $turma = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($idTurma)[0];
            if (count($turma) === 0) {
                throw new NotFoundException('Turma informada não existe!');
            }
            
            $relatorio = SaeDigital::make(RelatorioConsolidado::class)->handle(
                $turma->schoolId,
                $idTurma,
                $bimestre
            );

            $csv = Writer::createFromFileObject(new SplTempFileObject());
            $csv->setOutputBOM(Writer::BOM_UTF8);
            $csv->insertOne($relatorio['header']);
            $csv->insertAll($relatorio['data']);

            $descTurma = $turma->name;
            $nomeArquivo = 'Relatório Consolidado - ' . $descTurma . ' - ' . Date('d-m-Y');
            if ($tipoArquivo === 'csv') {
                $csv->output($nomeArquivo . '.csv');
            } else {
                $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xlsx');
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function exportarRelatorioPlataformaLiteraria()
    {
        try {
            $this->layout = false;
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR, Perfil::PROFESSOR]);
            $data = [];

            $idTurma = $this->input->get('idTurma');
            $tipoArquivo = $this->input->get('tipoArquivo');
            $data['listaLivros'] = $this->input->get('listaLivros');

            $turma = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($idTurma)[0];
            if (count($turma) === 0) {
                throw new NotFoundException('Turma informada não foi encontrada');
            }

            $versao = (int)$this->session->userdata('versao_conteudo_id');
            $idDisciplina = SaeDigital::make(BuscarDisciplinaLiterariaPorTurma::class)->handle($idTurma, $versao);

            if ($tipoArquivo === 'pdf') {
                $data['turma'] = $turma->name;
                $data['serie'] = $turma->name;
                $data['escola'] = $turma->schoolName;

                $data['relatorio'] = SaeDigital::make(RelatorioPlataformaLiteraria::class)->handle(
                    $idTurma, $turma->schoolId, $idDisciplina['idDisciplina']
                );
            } else {
                $relatorio = SaeDigital::make(RelatorioPlataformaLiteraria::class)->handle(
                    $idTurma, $turma->schoolId, $idDisciplina['idDisciplina']
                );

                $relatorio = SaeDigital::make(ExportarRelatorioPlataformaLiteraria::class)->handle($relatorio);

                $csv = Writer::createFromFileObject(new SplTempFileObject());
                $csv->setOutputBOM(Writer::BOM_UTF8);
                $csv->insertOne($relatorio['headers']);
                $csv->insertAll($relatorio['data']);
            }

            $nomeArquivo = 'Relatório Plataforma Literária Turma - ' . $turma->name . ' - ' . Date('d-m-Y');
            if ($tipoArquivo === 'csv') {
                $csv->output($nomeArquivo . '.csv');
            } elseif ($tipoArquivo === 'xlsx') {
                $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xlsx');
            } else {
                $html = $this->twig()->render('relatorios/relatorio-literaria-turma.twig', $data);
                $this->exportarPdf($html);
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            echo $e->getMessage();
        }
    }

    public function exportarRelatorioPlataformaLiterariaAluno()
    {
        try {
            $this->layout = false;
            $this->allowProfile([Perfil::ALUNO, Perfil::RESPONSAVEL]);
            $data = [];

            $idAluno = $this->input->get('idAluno');
            $tipoArquivo = $this->input->get('tipoArquivo');
            $data['listaLivros'] = $this->input->get('listaLivros');

            $aluno = SaeDigital::make(BuscarAluno::class)->handle($idAluno);
            if (empty($aluno)) {
                throw new NotFoundException('Aluno informado não existe!');
            }

            $versao = (int)$this->session->userdata('versao_conteudo_id');
            $idDisciplina = SaeDigital::make(BuscarDisciplinaLiterariaPorTurma::class)->handle(
                $aluno['Turma'],
                $versao
            );
            $turma = SaeDigital::make(BuscarDadosTurma::class)->handle($aluno['Turma'], ['A'], Date('Y'));

            $data['relatorio'] = SaeDigital::make(RelatorioPlataformaLiterariaAluno::class)->handle(
                $idAluno, $turma['itemName'], $turma['EscolaID'], $idDisciplina['idDisciplina']
            );

            $data['turma'] = $turma['Descricao'];
            $data['serie'] = $turma['DescricaoSerie'];
            $data['escola'] = $turma['NomeEscola'];
            $data['idAluno'] = $idAluno;

            $relatorio = SaeDigital::make(ExportarRelatorioPlataformaLiterariaAluno::class)->handle($data['relatorio']);

            $csv = Writer::createFromFileObject(new SplTempFileObject());
            $csv->insertOne($relatorio['headers']);
            $csv->insertAll($relatorio['data']);

            $nomeArquivo = 'Relatório Plataforma Literária Turma - ' . $turma['Descricao'] . ' - ' . Date('d-m-Y');
            if ($tipoArquivo === 'csv') {
                $csv->output($nomeArquivo . '.csv');
            } elseif ($tipoArquivo === 'xlsx') {
                $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xlsx');
            } else {
                $html = $this->twig()->render('relatorios/relatorio-literaria-aluno.twig', $data);
                $this->exportarPdf($html);
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            echo $e->getMessage();
        }
    }

    public function exportarRelatorioPlataformaAluno()
    {
        try {
            $this->layout = false;
            $data = [];

            $idAluno = $this->input->get('idAluno');
            $tipoArquivo = $this->input->get('tipoArquivo');
            $data['listaLivros'] = $this->input->get('listaLivros');

            $aluno = SaeDigital::make(BuscarAluno::class)->handle($idAluno);
            if (count($aluno) === 0) {
                throw new NotFoundException('Aluno não encontrado!');
            }

            $versao = (int)$this->session->userdata('versao_conteudo_id');
            $idDisciplina = SaeDigital::make(BuscarDisciplinaLiterariaPorTurma::class)->handle($aluno['Turma'],
                $versao);

            if ($tipoArquivo === 'pdf') {
                $data['turma'] = $aluno['Descricao'];
                $data['serie'] = $aluno['DescricaoSerie'];
                $data['escola'] = $aluno['NomeEscola'];
                $data['idAluno'] = $idAluno;

                $data['relatorio'] = SaeDigital::make(RelatorioPlataformaLiterariaAluno::class)->handle(
                    $idAluno, $aluno['Turma'], $aluno['Escola'], $idDisciplina['idDisciplina']
                );
            } else {
                $relatorio = SaeDigital::make(RelatorioPlataformaLiterariaAluno::class)->handle(
                    $idAluno, $aluno['Turma'], $aluno['Escola'], $idDisciplina['idDisciplina']
                );

                $relatorio = SaeDigital::make(ExportarRelatorioPlataformaLiterariaAluno::class)->handle($relatorio);

                $csv = Writer::createFromFileObject(new SplTempFileObject());
                $csv->insertOne($relatorio['headers']);
                $csv->insertAll($relatorio['data']);
            }

            $nomeArquivo = 'Relatório Plataforma Literária - ' . Date('d-m-Y');
            if ($tipoArquivo === 'csv') {
                $csv->output($nomeArquivo . '.csv');
            } elseif ($tipoArquivo === 'xlsx') {
                $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xlsx');
            } else {
                $html = $this->twig()->render('relatorios/relatorio-literaria-aluno.twig', $data);
                $this->exportarPdf($html);
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            echo $e->getMessage();
        }
    }

    /**
     * Exportação relatório desempenho aluno
     */
    public function exportarRelatorioAlunoDesempenho()
    {
        try {
            try {
                $this->layout = false;

                $idAluno = $this->input->get('idAluno') ?: $this->session->userdata('pessoaid');
                $tipoArquivo = $this->input->get('tipoArquivo');
                $data['listaDisciplinas'] = $this->input->get('listaDisciplinas');
                $data['listaBimestres'] = $this->input->get('listaBimestres');

                $aluno = (array) SaeDigital::make(ObterAlunoPorIdNextAva::class)->handle($idAluno);
             
                if (!$aluno) {
                    throw new NotFoundException('Aluno informado não foi encontrado!');
                }
                $data['aluno'] = $aluno;
                
                if ($tipoArquivo === 'pdf') {
                    $data['relatorio'] = SaeDigital::make(RelatorioDesempenhoIndividual::class)->handle(
                        $aluno['itemName'],
                        $aluno['Turma'],
                        $aluno['Escola']
                    );

                    $data['coeficiente'] = SaeDigital::make(CalcularCoeficienteDesempenhoAcademico::class)->handle(
                        $data['relatorio']
                    );

                } else {
                    $relatorio = SaeDigital::make(ExportarRelatorioDesempenho::class)->handle(
                        $aluno['itemName'],
                        $aluno['Turma'],
                        $aluno['Escola']
                    );

                    $csv = Writer::createFromFileObject(new SplTempFileObject());

                    $csv->setOutputBOM(Writer::BOM_UTF8);
                    $csv->insertOne($relatorio['headers']);
                    $csv->insertAll($relatorio['data']);
                }

                $nomeArquivo = 'Relatório Desempenho - ' . $aluno['nome'] . ' - ' . Date('d-m-Y');
              
                if ($tipoArquivo === 'csv') {
                    $csv->output($nomeArquivo . '.csv');
                } elseif ($tipoArquivo === 'xlsx') {
                    $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xlsx');
                } else {
                    $html = $this->twig()->render('relatorios/relatorio-desempenho.twig', $data);
                    $this->exportarPdf($html);
                }
            } catch (Exception $e) {
                log_error($e->getMessage());
                return $this->responseJson([
                    'detail' => $e->getMessage(),
                    'message' => 'Ocorreu um problema ao pesquisar os dados do relatório, por favor tente novamente'
                ], 400);
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    /**
     * Exportação relatório diário do aluno
     */
    public function exportarRelatorioAlunoDiario()
    {
        try {
            $this->layout = false;

            $idAluno = $this->input->get('idAluno');
            $tipoArquivo = $this->input->get('tipoArquivo');
            $dataInicial = DateTime::createFromFormat('d-m-Y', $this->input->get('dataInicial'))->setTime(0, 0, 0);
            $dataFinal = DateTime::createFromFormat('d-m-Y', $this->input->get('dataFinal'))->setTime(0, 0, 0);
            $periodoPesquisa = $dataInicial->format('d-m-Y') . ' até ' . $dataFinal->format('d-m-Y');

            $aluno = (array) SaeDigital::make(ObterAlunoPorIdNextAva::class)->handle($idAluno);
            if (!$aluno) {
                throw new NotFoundException('Aluno informado não foi encontrado!');
            }

            if ($tipoArquivo === 'pdf') {
                $data['dadosRelatorio'] = SaeDigital::make(RelatorioDesempenhoIndividualDiario::class)->handle(
                    $aluno['itemName'], $aluno['Turma'], $aluno['EscolaID'], $dataInicial, $dataFinal
                );

                $data['aluno'] = $aluno;
                $data['idAluno'] = $idAluno;
            } else {
                $relatorio = SaeDigital::make(ExportarRelatorioIndividualDiario::class)->handle(
                    $aluno['itemName'], $aluno['Turma'], $aluno['EscolaID'], $dataInicial, $dataFinal
                );

                $csv = Writer::createFromFileObject(new SplTempFileObject());
                $csv->insertOne($relatorio['headers']);
                $csv->insertAll($relatorio['data']);
            }

            $nomeArquivo = $aluno['nome'] . ' - Relatório Diário - ' . $periodoPesquisa . '.csv';
            if ($tipoArquivo === 'csv') {
                $csv->output($nomeArquivo . '.csv');
            } elseif ($tipoArquivo === 'xlsx') {
                $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xlsx');
            } else {
                $html = $this->twig()->render('relatorios/relatorio-diario.twig', $data);
                $this->exportarPdf($html);
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    /**
     * Exportação relatório geral da escola
     *
     * @param int $idSerie
     * @param int $idDisciplina
     * @param string $tipoArquivo
     */
    public function exportarRelatorioGeralEscola($idSerie, $idDisciplina, $tipoArquivo = 'csv')
    {
        try {
            $this->allowProfile([Perfil::DIRETOR]);

            $this->layout = false;
            $idEscola = $this->session->userdata('escola');

            $relatorio = SaeDigital::make(ExportarRelatorioDesempenhoSerie::class)->handle(
                $idSerie,
                $idDisciplina,
                $idEscola
            );

            $disciplina = SaeDigital::make(PegaDisciplinaPeloId::class)->handle($idDisciplina);

            $csv = Writer::createFromFileObject(new SplTempFileObject());
            $csv->insertOne($relatorio['headers']);
            $csv->insertAll($relatorio['data']);

            $nomeArquivo = 'Relatório Série - ' . $disciplina['Descricao'] . ' - ' . Date('d-m-Y');
            if ($tipoArquivo === 'csv') {
                $csv->output($nomeArquivo . '.csv');
            } elseif ($tipoArquivo === 'xlsx') {
                $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xlsx');
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    /**
     * Faz o download do arquivo xlsx convertido do csv
     *
     * @param string $arquivo
     * @param string $nomeArquivo
     */
    private function exportarXlsx($arquivo, $nomeArquivo)
    {
        header('Content-Disposition: attachment; filename=' . $nomeArquivo);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        readfile($arquivo);
        unlink($arquivo);
        exit;
    }

    /**
     * Salva o csv temporariamente para converter em xlsx
     *
     * @param string $csv
     * @param string $nomeArquivo
     */
    private function converterXlsx($csv, $nomeArquivo)
    {
        $adapter = new Local(APPPATH . 'tmp');
        $filesystem = new Filesystem($adapter);

        $hash = md5(time()) . '.csv';
        $filesystem->put($hash, $csv);

        $filePath = SaeDigital::make(Csv2Xls::class)->handle($adapter->getPathPrefix(), $hash);

        $this->exportarXlsx($filePath, $nomeArquivo);
    }

    /**
     * @param string $html
     */
    public function exportarPdf($html)
    {
        $this->layout = false;

        $snappy = new Pdf(FCPATH . 'vendor/h4cc/wkhtmltopdf-amd64/bin/wkhtmltopdf-amd64');
        $snappy->setOption('toc', false);

        header('Content-Type: application/pdf');
        echo $snappy->getOutputFromHtml($html, ['encoding' => 'UTF8']);
    }

    public function relatorioNotifica()
    {
        try {
            $disciplinaId = $this->relatorioDisciplinaService->handle(
                $this->input->get('id'),
                $this->input->get('disciplina')
            );
            $aluno = SaeDigital::make(BuscarAluno::class)->handle($this->input->get('id'));

            $relatorio = SaeDigital::make(RelatorioDesempenhoIndividual::class)->handle(
                $aluno['itemName'],
                $aluno['Turma'],
                $aluno['Escola'],
                $disciplinaId
            );

            return $this->responseJson(['status' => 'success', 'data' => $relatorio], 200);
        } catch (Exception $exception) {
            return $this->responseJson([
                'status' => 'error',
                'message' => 'Erro ao buscar relatório: ' . $exception->getMessage()
            ], 500);
        }
    }

    public function buscarDadosRelatorioReforco()
    {
        try {
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR, Perfil::PROFESSOR]);

            $idTurma = $this->input->get('idTurma');
            $idDisciplina = $this->input->get('idDisciplina');

            $dados = SaeDigital::make(RelatorioDesempenhoTurma::class)->handleReforco($idTurma, $idDisciplina);
            $data['relatorio'] = SaeDigital::make(RelatorioReforco::class)->handle($idTurma, $idDisciplina, $dados);

            return $this->responseJson($data, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao pesquisar os dados do relatório, por favor tente novamente!',
                'error' => $e->getMessage()
            ], 400);
        }
    }

    public function exportarRelatorioReforco()
    {
        try {
            $this->layout = false;
            $this->allowProfile([Perfil::DIRETOR, Perfil::COORDENADOR, Perfil::PROFESSOR]);
            $data = [];

            $idTurma = $this->input->get('idTurma');
            $idDisciplina = $this->input->get('idDisciplina');
            $tipoArquivo = $this->input->get('tipoArquivo');
            $data['listaAssuntos'] = $this->input->get('listaAssuntos');
            $data['listaBimestres'] = $this->input->get('listaBimestres');

            $turma = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($idTurma)[0];
            if (count($turma) === 0) {
                throw new NotFoundException('Turma informada não existe!');
            }

            if ($tipoArquivo === 'pdf') {
                $data['turma'] = $turma->name;
                $data['serie'] = $turma->grade;
                $data['escola'] = $turma->schoolName;

                $dados = SaeDigital::make(RelatorioDesempenhoTurma::class)->handleReforco($idTurma, $idDisciplina);
                $data['relatorio'] = SaeDigital::make(RelatorioReforco::class)->handle($idTurma, $idDisciplina, $dados);
            } else {

                $dados = SaeDigital::make(RelatorioDesempenhoTurma::class)->handleReforco($idTurma, $idDisciplina);
                $relatorio = SaeDigital::make(ExportarRelatorioReforco::class)->handle(
                    $dados
                );

                $csv = Writer::createFromFileObject(new SplTempFileObject());
                $csv->insertOne($relatorio['headers']);
                $csv->insertAll($relatorio['data']);
            }

            $nomeArquivo = 'Relatório Reforço Turma - ' . $turma->name . ' - ' . Date('d-m-Y');
            if ($tipoArquivo === 'csv') {
                $csv->output($nomeArquivo . '.csv');
            } elseif ($tipoArquivo === 'xlsx') {
                $this->converterXlsx($csv->__toString(), $nomeArquivo . '.xlsx');
            } else {
                $html = $this->twig()->render('relatorios/relatorio-reforco.twig', $data);
                $this->exportarPdf($html);
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }
}
