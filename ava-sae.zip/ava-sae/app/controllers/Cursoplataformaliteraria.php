<?php

use Ava\App\Exceptions\MissingArgumentException;
use Ava\App\Services\PlataformaLiteraria\BuscarQuestaoDiscursiva;
use Ava\App\Services\PlataformaLiteraria\SalvarRespostasQuestoesDiscursivas;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cursoplataformaliteraria extends MY_Controller {

    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'disciplina', 'redactor.min', 'pt_pt', 'redactor_special_character', 'redactor.fontcolor', 'redactor.fontsize', 'jquery.cookie', 'plataforma'); //'curso.min','chosen'
    public $keywords = array('sae', 'curso');

    public function __construct() {
        parent::__construct();

        $this->load->model('curso_model', 'curso');
        $this->load->model('disciplina_model', 'disciplina');
        $this->load->model('plataformaliteraria_model', 'literaria');
        $this->load->library('disciplina_lib');

        // define os arquivos para juntar e comprimir
        // $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'mensagem');
    }

    /**
     * Index
     *
     * Exibe a página inicial de curso.
     *
     * @param string $Ancora determinanda qual ? a identificador da disciplina
     * @access	public
     * @return	void
     */
    public function index($Ancora = null) {

        // $this->cssMinify[] = 'buscar';
        // $this->cssMinify[] = 'curso';
        // $this->cssMinify[] = 'glyphicon';
        // $this->cssMinify[] = 'datepicker';
        // $this->css[] = $this->minify->getCSS('curso_index.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'bootstrap-datepicker';

        $grupoAula = $Ancora ? $this->home->verificaGrupoAulaAncora($Ancora) : '';
        $this->session->set_userdata('grupoAulaID', $grupoAula[0]['itemName']);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['perfil'] = $this->session->userdata('perfil');

        $configuracoes = $this->curso->getConfiguracoesescola($this->session->userdata('escola'));

        $this->session->set_userdata('escola', $configuracoes[0]['EscolaID']);
        if ($this->input->get('turmaID')) :
            $this->session->set_userdata('TurmaID', $this->input->get('turmaID'));
        endif;

        //seta valores padrao caso a escola ainda nao tenha cadastrado as configurações
        if ($configuracoes && isset($configuracoes[0])) {
            $data['configuracoes'] = $configuracoes[0];
            unset($configuracoes[0]);
        } else {
            $data['configuracoes']['QuestaoCoordenador'] = 'N';
            $data['configuracoes']['QuestaoProfessor'] = 'N';
            $data['configuracoes']['AgendaCoordenador'] = 'N';
            $data['configuracoes']['AgendaProfessor'] = 'N';
        }

        $turmaid = $this->input->get('turmaID') != '' ? $this->input->get('turmaID') : $this->session->userdata('TurmaID');

        $turma = $this->home->verificaTurmas($turmaid, $this->session->userdata('escola'));

        $metaPercentual = 0;
        $percentual = NULL;
        $recalcularPercentual = FALSE;

        if ($data['perfil'] == PERFIL_ALUNO) {
            $percentual = $this->session->userdata('percentual_' . $turmaid);
            $recalcularPercentual = $this->session->userdata('recalcularPercentual_' . $turmaid);

            $metaPercentual = 0;
            foreach ($configuracoes as $v) {
                if (isset($v['Serie']) && $v['Serie'] == $turma[0]['SerieID'])
                    $metaPercentual = isset($v['Percentual']) ? $v['Percentual'] : 0;
            }
        }

        unset($configuracoes[0]);

        $acessa = FALSE;

        if (!empty($grupoAula)) {

        	//dados para gravar na sessao
        	$array['Ancora'] = $Ancora;
        	$array['grupoAulaID'] = $grupoAula[0]['itemName'];
        	$array['DescricaoPacote'] = ($grupoAula[0]['Descricao']);
        	$array['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];
        	$array['TipoPDF'] = isset($grupoAula[0]['TipoPDF']) ? $grupoAula[0]['TipoPDF'] : 'L';
        	$array['TurmaID'] = $turmaid;

            $data['cursoNome'] = $grupoAula[0]['Descricao'];
            $data['grupoAulaID'] = $grupoAula[0]['itemName'];
            $data['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];
            $data['meta'] = $this->session->userdata('meta');

            $data['videoaulas'] = $this->disciplina_lib->arrayDisciplinas($data['grupoAulaID']);

        }

        $this->session->set_userdata($array);

        $this->load->view('disciplina_plataforma_literaria', $data);
    }

    function buscaAulasDisciplinas(){

        $jsonData = $this->getJsonRequestData();

    	$disciplinaid = $this->input->post('disciplinaid') ?: $jsonData['disciplinaid'];
        $grupoaulaid = $this->input->post('grupoaulaid') ?: $jsonData['grupoaulaid'];
        $categoriaid = $this->input->post('categoriaid') ?: $jsonData['categoriaid'];
        $escolaid = $this->session->userdata('escola');
        $turmaid = $this->session->userdata('TurmaID');

        $ancora = $this->input->post('ancora', true) ?: $jsonData['ancora'];
        $this->session->set_userdata('Ancora', $ancora);

        $this->curso->corrigeAgendamentosPlataformaLiteraria($turmaid, $disciplinaid, $grupoaulaid);
    	$array = $this->disciplina_lib->arrayAulas($grupoaulaid,$disciplinaid,$categoriaid);

    	$array['TurmaID'] = $turmaid;
    	$array['GrupoAulaID'] = $grupoaulaid;
    	$array['CategoriaID'] = $categoriaid;
    	$array['DisciplinaID'] = $disciplinaid;
    	$array['UsuarioID'] = $this->session->userdata('pessoaid');

        $aula = $this->literaria->getInfoAulaPlataformaLiteraria($array);
        $html = $this->literaria->getHtmlDetalhesAula($aula);
        //TODO: PASSAR para uma view detalhes do resultado.
        print($html);
        die;
    }

    function questoesDiscursivasAluno() {
        // $this->css[] = $this->minify->getCSS('questoes_discursivas_editar.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'avasae';

        //FIXME: padronizar as variaveis
        $aulaid = $this->uri->segment(3);
        $grupoaulaid = $this->uri->segment(4);
        $assuntoid = $this->uri->segment(5);
        $perfilid = $this->session->userdata('perfil');
        $alunoid = $this->session->userdata('pessoaid');
        $turmaid = $this->session->userdata('TurmaID');
        $escolaid = $this->session->userdata('escola');
        $linkVoltar = $_SERVER['HTTP_REFERER'];

        $discursivas = array();
        $aula = $this->literaria->getInfoAula($aulaid);
        $descricaoAssunto = null;
        if($aula){
            $descricaoAssunto = $aula[0]->Tema;
        }

        $questoes = $this->literaria->getQuestoesDiscursivas($grupoaulaid, null, $assuntoid);
        $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $grupoaulaid, null, $assuntoid);
        $assuntoFinalizado = false;
        $frenteid = null;
        if($agendamento){
            $frenteid = $agendamento[0]->FrenteID;
            $inicio = strtotime($agendamento[0]->DtInicio);
            $fim = strtotime($agendamento[0]->DtFim);
            $now = strtotime(date('d-m-Y'));
            if(isset($fim, $now, $inicio) && $now > $fim) {
                $assuntoFinalizado = true;
            }
            $dados['DataInicioAgendamento'] = date('d-m-Y',$inicio);
            $dados['DataFimAgendamento'] = date('d-m-Y',$fim);
        }
        foreach ($questoes as $index => $questao){
            $respTemp = new stdClass();
            $resposta = $this->literaria->getRespostasDiscursivasPorAssunto($turmaid, $alunoid, $grupoaulaid,
                                    $assuntoid, $questao->QuestaoDiscursivaID);
            $respTemp->QuestaoDiscursivaID = $questao->QuestaoDiscursivaID;
            $respTemp->GrupoAulaID = $questao->GrupoAulaID;
            $respTemp->AssuntoID = $questao->AssuntoID;
            $respTemp->AulaID = $questao->AulaID;
            $respTemp->Enunciado = $this->removeTags( $questao->Enunciado);
            $respTemp->TurmaID = $turmaid;
            $respTemp->RespostaID = null;
            $respTemp->Resposta = null;
            $respTemp->Nota = null;
            $respTemp->FrenteID = $frenteid;
            if ($resposta){
                $respTemp->Resposta = isset($resposta[0]->Resposta)? trim($resposta[0]->Resposta) : null;
                $respTemp->RespostaID = $resposta[0]->RespostaID;
                $respTemp->Nota = isset($resposta[0]->Nota)? $resposta[0]->Nota: null;
                $respTemp->FrenteID = isset($resposta[0]->FrenteID)? $resposta[0]->FrenteID: null;
            }
            array_push($discursivas, $respTemp);
        }
    	$dados['discursivas'] = $discursivas;
    	$dados['descricaoAssunto'] = isset($descricaoAssunto) ? $descricaoAssunto : $this->session->userdata('DescricaoPacote');
    	$dados['turmaid'] = $turmaid;
    	$dados['linkVoltar'] = $linkVoltar;
        $dados['assuntofinalizado'] = $assuntoFinalizado;
        $dados['dados'] = montaMenu($perfilid);

        $this->menu_vertical = $this->load->view('view_menu', $dados, true);
    	$this->load->view('questoes_discursivas_aluno', $dados);
    }

    private function removeTags($string)
    {
        $string = str_replace(['<p>', '</p>'], '', $string);

        return $string;
    }

    public function salvarRespostaDiscursivasAluno()
    {
        try {
            $respostas = $this->input->post('respostas');
            $idAluno = $this->session->userdata('pessoaid');
            $idEscola = $this->session->userdata('escola');
            $idTurma = $this->input->post('turmaid');

            $respostasSalvar = [];
            if(isset($respostas, $idAluno, $idEscola, $idTurma)){
                foreach ($respostas as $key => $resposta) {
                    $respostasSalvar[$key] = [
                        'Situacao' => 'A',
                        'DtAlt' => Date('Y-m-d H:i:s'),
                        'AlunoID' => $idAluno,
                        'Resposta' => trim($resposta['resposta']),
                        'TurmaID' => $idTurma,
                        'UsuarioAlt' => $this->session->userdata('pessoaid'),
                        'GrupoAulaID' => $resposta['grupoaulaid'],
                        'EscolaID' => $idEscola,
                        'AssuntoID' => $resposta['assuntoid'],
                        'QuestaoDiscursivaID' => $resposta['questaoid'],
                        'FrenteID' => $resposta['frenteid'],
                        'DescricaoEscola' => $this->session->userdata('nomeEscola'),
                        'NomeAluno' => $this->session->userdata('nome')
                    ];

                    $questaoDiscursiva = SaeDigital::make(BuscarQuestaoDiscursiva::class)->handle(
                        $resposta['questaoid']
                    );

                    $respostasSalvar[$key]['Enunciado'] = $questaoDiscursiva['Enunciado'];

                    if (!is_null($resposta['respostaid']) && $resposta['respostaid'] !== '') {
                        $respostasSalvar[$key]['RespostaID'] = $resposta['respostaid'];
                    } else {
                        $respostasSalvar[$key]['DtCad'] = Date('Y-m-d H:i:s');
                    }
                }

                $response = SaeDigital::make(SalvarRespostasQuestoesDiscursivas::class)->handle($respostasSalvar);

                return $this->responseJson(['message' => $response], 200);
            }

            throw new MissingArgumentException("Estão faltando parâmetros na requisição, por favor tente novamente!");
        } catch (MissingArgumentException $e) {
            log_error($e->getMessage());

            return $this->responseJson(['message' => $e->getMessage()], 400);
        } catch (Exception $e) {
            log_error($e->getMessage());

            return $this->responseJson([
                'message' => 'Ocorreu um problema durante a requisição, por favor tente novamente!'
            ], 500);
        }

    }

    function salvaQuestoesDiscursivas() {
        $respostas = $this->input->post('respostas');

    	$dados['disciplinaid'] = (int) $this->input->post('grupoaulaid');

    	$dadosCategoria = $this->disciplina->verificaCategoria($dados['disciplinaid']);
    	$dados['descricaofrente'] = ($dadosCategoria[0]['Descricao']);
    	$dados['frenteid'] = (int) $dadosCategoria[0]['CategoriaID'];

    	$dados['assuntoid'] = (int) $this->input->post('disciplinaid');
    	$dadosDisciplina = $this->disciplina->getDisciplinas($dados['disciplinaid'],$dados['assuntoid']);
    	$dados['descricaoassunto'] = ($dadosDisciplina[0]['Descricao']);

    	$dados['alunoid'] = $this->session->userdata('pessoaid');
    	$dados['nomealuno'] = $this->session->userdata('nome');

    	$dadosUsuario = $this->curso->buscaDadosUsuario($dados['alunoid']);
    	$dados['escolaid'] = $this->session->userdata('escola');
    	$dados['descricaoescola'] = ($dadosUsuario[0]['NomeEscola']);
    	$dados['turmaid'] = $this->session->userdata('TurmaID');
    	$dados['descricaoturma'] = ($dadosUsuario[0]['DescricaoTurma']);
        
    	$dados['nomealuno'] = ($dadosUsuario[0]['Nome']);

    	if ($respostas) {
            for ($i = 0; count($respostas) > $i; $i++) {
                if (isset($dados['respostaquestaodiscursiva'])) {
                    unset($dados['respostaquestaodiscursiva']);
                }
                $resp = explode('/', $respostas[$i]);

                $dados['RespostaID'] = !empty($resp[0]) ? $resp[0] : $this->iesdeuuid->getIdRandom();
                $dados['questaodiscursivaid'] = $resp[1];
                $dados['enunciadoquestaodiscursiva'] = (base64url_decode(trim($resp[2])));
                if (!empty(trim($resp[3]))) {
                    $dados['respostaquestaodiscursiva'] = trim(($resp[3]));
                }

                $result = $this->literaria->salvaQuestoesDiscursivasDisciplina($dados);
            }
    	}
    	print($result);die;
    }

}
