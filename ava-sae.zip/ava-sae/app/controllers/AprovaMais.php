<?php

class AprovaMais extends MY_Controller {
    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        try {
            return $this->load->view('aprova-mais/index', $data);
        } catch (\Exception $e) {
            log_error($e->getMessage());
        }
    }

    public function trilha($slug) {
        try {
            $data = ['slug' => $slug];
            return $this->load->view('aprova-mais/trilha', $data);
        } catch (\Exception $e) {
            log_error($e->getMessage());
        }
    }

    public function modulo($materia, $modulo) {
        try {
            $data = [
                'materia' => $materia,
                'modulo' => $modulo,
            ];
            return $this->load->view('aprova-mais/modulo', $data);
        } catch (\Exception $e) {
            log_error($e->getMessage());
        }
    }

    public function questoes($materia, $modulo, $card) {
        try {
            $data = [
                'materia' => $materia,
                'modulo' => $modulo,
                'card' => $card,
            ];
            return $this->load->view('aprova-mais/questoes', $data);
        } catch (\Exception $e) {
            log_error($e->getMessage());
        }
    }
}
