<?php

use Ava\App\Services\Faq\ListarCategorias;
use Ava\App\Services\Faq\ListarFaqs;
use Ava\App\Services\Faq\PegaOsFaqsPorCategoria;
use Ava\App\Services\Faq\PegarCategoriaPorNome;
use Ava\App\Services\Faq\SalvarCategoria;
use Ava\App\Support\Perfil;

use Illuminate\Support\Str;

class Ajuda extends MY_Controller
{

    public $layout = 'default';
    public $title = 'AVA SAE - Ajuda';
    public $description = 'Ambiente Virtual de Aprendizagem - SAE';
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.maskedinput.min', 'curso.min', 'mensagem');
    public $keywords = array('sae', 'ajuda');
    public $menu_vertical = '';
    public $configuracoes;

    public function __construct() {

        parent::__construct();

        $this->load->model('configuracoes_model', 'configuracoes');

        $this->load->helper('menu_helper');

        $this->load->model('home_model', 'home');
        $this->load->model('curso_model', 'curso');

        $this->load->model('ajuda_model', 'ajuda');

        // define os arquivos para juntar e comprimir
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'mensagem');

        $this->configuracoes = $this->configuracoes->configuracoes();
        //configurações do header

        // $logo = $this->home->buscaLogo($this->session->userdata('escola'));
        $data['logo'] = 'logos/'.$this->configuracoes[0]['Logo'];
        if(isset($logo['Logo']) && $logo['Logo'] != ''){
            $data['logo'] = $logo['Logo'];
        }
        $data['topo'] = isset($this->configuracoes[0]['ImagemTopo']) ? $this->configuracoes[0]['ImagemTopo'] : '';
        $data['fone'] = $this->configuracoes[0]['Telefone'];
        $data['site'] = $this->configuracoes[0]['id'];
        $data['pagina'] = 'ajuda';

        if ($this->session->userdata('logado') === true) {
            unset($data['pagina']);
        }

       $this->header = $this->load->view('view_header', $data, true);

        $this->menu_vertical = $this->load->view('view_menu', '', true);

    }

    public function index()
    {
        $this->js[] = 'ajuda.min';
        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'ajuda';
        $this->css[] =  $this->minify->getCSS('ajuda_index_v1.min', $this->cssMinify, ENVIRONMENT);

        $code = $this->input->get('code', null);
        if ($this->session->userdata('logado') === null) {
            $code = 'GfQCZ';
        }

        $this->load->view('ajuda', [
            'logado' => $this->session->userdata('logado') === true ? 'S' : 'N',
            'code' => $code,
            'faqs' => SaeDigital::make(PegaOsFaqsPorCategoria::class)->handle($code),
            'ref' => $_SERVER['HTTP_REFERER']
        ]);
    }

    public function problemasAvaAprovaConcursos() {

        $ipExterno = "";
        $ipInterno = "";

        if ($this->input->server('HTTP_CLIENT_IP')) {
            $ipExterno = $this->input->server('HTTP_CLIENT_IP');
        }

        if ($this->input->server('HTTP_X_FORWARDED_FOR')) {
            $ipInterno = $this->input->server('HTTP_X_FORWARDED_FOR');
        } else {
            $ipInterno = $this->input->server('REMOTE_ADDR');
        }

        //verifica se tem dois ips(interno e externo)
        if (ENVIRONMENT != 'development') 
        {
            $verificaIps = stripos($ipInterno, ",");

            if ($verificaIps !== false) {
                $ip = explode(",", $ipInterno);
                $ipInterno = $ip[0];
                $ipExterno = $ip[1];
            } else {
                $ipExterno = $ipInterno;
                $ipInterno = "";
            }
        }

        $dados['nome'] = $this->input->post('nome');
        $dados['email'] = $this->input->post('email');
        $dados['telefone'] = $this->input->post('telefone');
        $dados['curso'] = $this->input->post('curso');
        $dados['mensagem'] = $this->input->post('mensagem');
        $dados['versaoBrowser'] = $this->input->post('versaoBrowser');
        $dados['versaoFlash'] = $this->input->post('versaoFlash');

        $dados['ipExterno'] = $ipExterno;
        $dados['ipInterno'] = $ipInterno;

        $dados['versaoSO'] = $this->input->post('versaoSO');
        $dados['tipoConexao'] = $this->input->post('tipoConexao');
        $dados['velocidadeConexao'] = $this->input->post('velocidadeConexao');
        $dados['operadora'] = $this->input->post('operadora');

        $dados['formaConexao'] = $this->input->post('formaConexao');
        $dados['localidade'] = $this->input->post('localidade');
        $dados['dispositivos'] = $this->input->post('dispositivos');
        $dados['limite'] = $this->input->post('limite');
        $dados['dificuldade'] = $this->input->post('dificuldade');
        $dados['conjuntodevideos'] = $this->input->post('conjuntodevideos');
        $dados['duracaodificuldade'] = $this->input->post('duracaodificuldade');
        $dados['outrocomputador'] = $this->input->post('outrocomputador');
        $dados['outraconexao'] = $this->input->post('outraconexao');
        $dados['conectarcabo'] = $this->input->post('conectarcabo');
        $dados['requisitosminimos'] = $this->input->post('requisitosminimos');

        $mensagem = "
            Reclamação via AVA SAE!

            1- Qual o tipo de conexão utilizada para acesso à internet
            R: " . utf8_decode($dados['tipoConexao']) . "

            2- Qual é a forma que o computador utilizado para fazer o acesso  está conectado à internet?
            R: " . utf8_decode($dados['formaConexao']) . "

            3- Qual é a velocidade do plano que você contratou de seu provedor de acesso à internet?
            R: " . utf8_decode($dados['velocidadeConexao']) . "

            4- Operadora
            R: " . utf8_decode($dados['operadora']) . "

            5- Qual dos itens a seguir melhor descreve a localidade de onde onde você fez o acesso?
            R: " . utf8_decode($dados['localidade']) . "

            6- Aproximadamente, quantos computadores ou outros dispositivos (smartphones, tablets, Smart TVs) 
            estão compartilhando a mesma conexão que vocÊ usou?
            R: " . utf8_decode($dados['dispositivos']) . "

            7- O plano de acesso a internet que você contratou de seu provedor possui franquia ou limite mensal de tráfego?
            R: " . utf8_decode($dados['limite']) . "

            8- A dificuldade que você enfretou para assistir os vídeos:
            R: " . utf8_decode($dados['dificuldade']) . "

            9- Se você identificou que a dficuldade ocorre em um vídeo específico ou em um conjunto de vídeos, 
            nos diga o título do(s) vídeo(s) para que possamos investigá-los.
            R: " . utf8_decode($dados['conjuntodevideos']) . "

            10- Quanto a duração das dficuldades que você está relatando aqui:
            R: " . utf8_decode($dados['duracaodificuldade']) . "

            11- Ao utilizar outro computador mas sob a mesma conexão com a internet, as dificuldades persistem igualmente?
            R: " . utf8_decode($dados['outrocomputador']) . "

            12- Ao utilizar outro computador mas sob OUTRA conexão com a internet, as dficuldades persistem igualmente?
            R: " . utf8_decode($dados['outraconexao']) . "

            13- Façamos um teste: ao acessar a internet conectando seu computador por cabo diretamente ao roteador 
            em vez do sinal wireless (se certifique de desligar o wireless), as dificuldades persistem igualmente?
            R: " . utf8_decode($dados['conectarcabo']) . "

            14- Existem requisitos mínimos de software e hardware para que você possa assistir os vídeos. 
            Você já checou se seu computador está adequado para estes requisitos?
            R: " . utf8_decode($dados['requisitosminimos']) . "

            Versão Browser: " . utf8_decode($dados['versaoBrowser']) . "

            Versão Flash: " . utf8_decode($dados['versaoFlash']) . "

            IP Interno: " . utf8_decode($dados['ipInterno']) . "

            Ip Externo: " . utf8_decode($dados['ipExterno']) . "

            Versão Sistema Operacional: " . utf8_decode($dados['versaoSO']) . "

            Nome: " . utf8_decode($dados['nome']) . "

            E-mail: " . utf8_decode($dados['email']) . "

            Telefone: " . utf8_decode($dados['telefone']) . "

            Curso: " . utf8_decode($dados['curso']) . "

            Mensagem: " . utf8_decode($dados['mensagem']) . "";

        $this->load->library('email');

        $config["protocol"] = "smtp";
        $config["smtp_host"] = "relay.iesde.com.br";
        $config["charset"] = "ISO 8859-1";
        $config["smtp_port"] = "25";
        $config["crlf"] = "\r\n";
        $config["newline"] = "\r\n";

        $this->email->initialize($config);
        $this->email->from("contato@portalava.com.br");
        
        if (ENVIRONMENT === 'development') {
            $this->email->to("desenvolvimento.ti@iesde.com.br");
        } else {
             $this->email->to("faleconosco@aprovaconcursos.com.br");
        }
        
        $this->email->subject("Reclamação via AVA SAE!");
        $this->email->message($mensagem);

        $assinaturaMatriculaID = $this->session->userdata('assinaturaMatriculaID');
        $result = $this->ajuda->gravaReclamacao($dados, $assinaturaMatriculaID);

        if ($result == 1) {
            print($this->email->send());
            exit;
        } else {
            print(2);
            exit;
        }
    }
    
    function tutorialPortalava() {
         
         $this->js[] = 'ajuda.min';
        
        $this->cssMinify[] = 'ajuda';
        $this->css[] =  $this->minify->getCSS('ajuda_index_v1.min', $this->cssMinify, ENVIRONMENT);
        
        $this->menu_vertical = '';

        $data['videoApresentacao'] = player('/videos/demonstrativos/tutorial-portal-ava.mp4');
        
        $this->load->view('view_apresentacao', $data);
    }

    public function informativoAtividades($etapa)
    {
        $this->layout = false;
        $this->load->view('informativos/agendamento-atividades-'.$etapa, []);
    }

    public function getFaq()
    {
        $code = $this->input->get('code', null);

        return $this->responseJson(['faqs' => SaeDigital::make(PegaOsFaqsPorCategoria::class)->handle($code)]);
    }

    public function listarFaq()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            return $this->responseJson(SaeDigital::make(ListarFaqs::class)->handle(), 200);
        } catch (Exception $e) {

        }
    }

    public function listarCategorias()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            return $this->responseJson(SaeDigital::make(ListarCategorias::class)->handle());
        } catch (Exception $e) {
            return $this->responseJson(['message' => 'Ocorreu um problema ao carregar lista de categorias'], 500);
        }
    }

    public function cadastrarCategoria()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $data = [
                'nome' => trim($this->input->post('nomeCategoria')),
                'codigo' => Str::random(5),
                'criado_em' => (new \DateTime())->format('Y-m-d H:i:s'),
                'responsavel_id' => (int)$this->session->userdata('id'),
                'ativo' => 1
            ];

            SaeDigital::make(SalvarCategoria::class)->handle($data);
            $categoria = SaeDigital::make(PegarCategoriaPorNome::class)->handle($data['nome']);

            return $this->responseJson($categoria, 200);
        } catch (Exception $e) {
            return $this->responseJson(['message' => 'Ocorreu um problema ao salvar categoria'], 500);
        }
    }
}