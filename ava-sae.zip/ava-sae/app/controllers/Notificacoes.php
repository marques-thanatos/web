﻿<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * gera lista para envio de email ou sms para os responsáveis
 * 
 * @author telma.neu
 * 18/08/2015
 */
class Notificacoes extends CI_Controller {
    
    public $layout = '';
    public $configuracoes;
    
    public function __construct() 
    {
        parent::__construct();       
        
        $this->load->model('notificacoes_model','notificacao');
        $this->load->library('dadosrelatorio_lib');
    }
    
    public function index()
    {
        echo "<h1>Portal SAE</h1>";
        echo "<h3>Envio de notificacao de agendamento</h3>";
        echo '<p><a href="' . base_url() . 'agendamento_iniciado"> Agendamento Iniciado</p>';
        echo '<p><a href="' . base_url() . 'agendamento_concluido"> Agendamento Concluido</p>';
    }
    
/*
Step 1 - Verifica agendamentos concluidos dtfim < getdate()
Step 2 - Verifica alunos da turma agendada;
Step 3 - Verifica se aluno tem agendamento especifico 
    Cond - tem agendamento especifico dtfim < getdate()?
		Step 4 - Verifica se tem dados no relatório do aluno
		Cond - tem dados?
			Step 5 verifica se conclui as atividades
				Cond Não concluiu 
					Step 6 - Envia email e sms para o responsével cadastrado.
						Obs - Só enviar se tiver os dados cadastrais corretos. Email válido e um telefone celular.
		Cond - Não tem dados
			Step 7 - Insere os dados na estrutura de relatório, mesma coisa que faz quando cadastra um aluno novo.
			Automaticamente se esse aluno não concluiu a atividade então executar mesma função do Step 6
	Cond - Não tem agendamento
		- Vai para o Step 4 direto.
*/
    public function agendamento_concluido()
    {
        echo '<h3>Notificações de agendamentos de turmas</h3>
              <p>-------------------------------------------</p>
              <p>Iniciando...</p>';
        
        $enviarNotificacao = array();
        
        $agendamentos = $this->notificacao->getAgendamentosConcluidos();
        
        if (empty($agendamentos)){
            echo '<p>Não há agendamentos concluídos.</p>';
            echo '<p>----- FIM do processamento ------</p>';
        }
        else {
            $escolaid = '';
            foreach ($agendamentos as $key => $val)
            {
                if (!isset($val['TurmaID'])) continue;
        
                                
                $escolaid = $val['EscolaID'];
                $turmaid = $val['TurmaID'];
                $disciplina = $val['DisciplinaID'];
                $frente = $val['FrenteID'];
                $assunto = $val['AssuntoID'];
                
                $configuracoes = $this->notificacao->getConfiguracoes($escolaid);
                    

                $permiteNotificacao = 'N';
                if (isset($configuracoes['0']['NotificacaoResponsavel'])) {
                    if ($configuracoes['0']['NotificacaoResponsavel'] == 'S') {
                        $permiteNotificacao = 'S';
                    }
                }
                
                // agendamento específico de aluno:
                $alunoid = null;
                if (isset($val['Aluno']))
                    $alunoid = $val['AlunoID'];
                
                if ($permiteNotificacao == 'S') {        
                
                // alunos:
                $alunos = $this->notificacao->getAlunos($escolaid, $turmaid, $alunoid);    
         
                if (!empty($alunos))
                {
					
                    // verifica relatório:
                    $relatorio = $this->notificacao->getRelatorioAlunos($escolaid, $turmaid, $disciplina, $assunto, $frente, $alunoid,$dtnotificacaoresponsavel);
	
                    if (!empty($relatorio))
                    { 
                        // verifica o relatório do aluno
                        foreach ($relatorio as $rel) 
                        {

                            // caso não tenha concluido, insere no array
                            $concluido = ($rel->Concluido > 0) ? 'S' : 'N';
                            $enviarNotificacao[$rel->UsuarioID] = array('Concluido' => $concluido, 'TemPrazo' => $rel->TemPrazo, 'Email' => '', 'Telefone' => '', 'Aluno' => null, 'DisciplinaID' => $disciplina, 'UsuarioID' => $rel->UsuarioID);
                        }
                    
                        foreach ($alunos as $aluno)
                        {                        
                            // verifica se está no relatório:
                            if (isset($enviarNotificacao[$aluno['id']]))
                            {
                                if ($enviarNotificacao[$aluno['id']]['TemPrazo'] == 'N' && $enviarNotificacao[$aluno['id']]['Concluido'] == 'N')                               
                                    $enviarNotificacao[$aluno['id']]['Aluno'] = $aluno;
                                else
                                    unset($enviarNotificacao[$aluno['id']]); // não enviar: ainda tem prazo ou já concluiu
                            }
                            else {                     
                                if ($alunoid == null) 
                                {
                                    //verificar agendamento individual:
                                    $agendaAluno = $this->notificacao->getAgendaAluno($escolaid, $turmaid, $aluno['id']);

                                    if ($agendaAluno && $agendaAluno[0]['DtFim'] != '' && $agendaAluno[0]['DtFim'] != '-')
                                    {
                                        list($ano, $mes, $dia) = explode('-', $agendaAluno[0]['DtFim']);
                                        $dtfim = mktime(0, 0, 0, $mes, $dia, $ano);
                                        $hoje = mktime(0,0,0,date('m'), date('d'), date('Y'));

                                        if ($dtfim < $hoje) {
                                            // enviar: tem agendamento individual mas não chegou a iniciar a tarefa
                                            $enviarNotificacao[$aluno['id']] = array('Email' => '', 'Telefone' => '', 'Aluno' => $aluno, 'DisciplinaID' => $disciplina, 'UsuarioID' => $enviarNotificacao[$aluno['id']]['UsuarioID']);
                                        }
                                    }
                                    else { 
                                        //enviar: agendamento padrão, tarefa não iniciada
                                        $enviarNotificacao[$aluno['id']] = array('Email' => '', 'Telefone' => '', 'Aluno' => $aluno, 'DisciplinaID' => $disciplina, 'UsuarioID' => $enviarNotificacao[$aluno['id']]['UsuarioID']);
                                    }
                                }
                                else { 
                                    // enviar: agendamento individual e tarefa não iniciada
                                    $enviarNotificacao[$aluno['id']] = array('Email' => '', 'Telefone' => '', 'Aluno' => $aluno, 'DisciplinaID' => $disciplina, 'UsuarioID' => $enviarNotificacao[$aluno['id']]['UsuarioID']);
                                }

                                // se aluno não tem os dados do relatório, cadastrar:
                                $verificaAluno = $this->notificacao->existeRelatorioAluno($aluno['id'], $escolaid, $turmaid);                            
                                if ($verificaAluno->Existe == 0)
                                {
                                    // cadastra os dados para relatorio
                                    $fields['PessoaID'] = $aluno['id'];
                                    $fields['Nome'] = $aluno['Nome'];
                                    $fields['Turma'] = $aluno['Turma'];
                                    $fields['DescricaoTurma'] = $aluno['DescricaoTurma'];
                                    $fields['Escola'] = $aluno['Escola'];
                                    $fields['NomeEscola'] = $aluno['NomeEscola'];
                                    $fields['Serie'] = $aluno['Serie'];
                                    $fields['DescricaoSerie'] = $aluno['DescricaoSerie'];
                                    $fields['VigenciaTurma'] = $aluno['VigenciaTurma'];

                                    $this->dadosrelatorio_lib->insereDados($fields);
                                }
                            }
                        }
                    }
                  
                    if (empty($enviarNotificacao))
                    {
                        echo '<p>Não há notificaões a enviar.</p>';    
                    }
                echo '<br><br>';
                    
                } else {
                    echo '<p>Não há alunos para a turma [' . $turmaid . '] da escola [' . $escolaid . ']</p>';
                }
                
            } else
                echo '<p>Não permite notificação</p>';
            }    
            }
            
            echo '<p>----- FIM do processamento ------</p>';
        }
    
    
    /**
     * notifica os alunos que há tarefas agendadas
     */
    function agendamento_iniciado()
    {
        echo '<h3>Notificações de agendamentos de turmas</h3>
              <p>-------------------------------------------</p>
              <p>Iniciando...</p>';
        
        $enviarNotificacao = array();
        
        $agendamentos = $this->notificacao->getAgendamentosIniciados();
        
        if (empty($agendamentos))
        {
            echo '<p>Não há agendamentos iniciados.</p>';
            echo '<p>----- FIM do processamento ------</p>';
        }
        else {
            foreach ($agendamentos as $key => $val)
            {
                if (!isset($val['TurmaID'])) continue;
                
                $escolaid = $val['EscolaID'];
                $turmaid = $val['TurmaID'];
                
                // agendamento específico de aluno:
                $alunoid = null;
                if (isset($val['Aluno']))
                    $alunoid = $val['AlunoID'];
                
                // alunos:
                $alunos = $this->notificacao->getAlunos($escolaid, $turmaid, $alunoid);
                if (!empty($alunos))
                {
                    foreach ($alunos as $aluno)
                    {
                        //TODO: chamar api para envio de notificação
                        echo '<p>' . $aluno['Nome'] . ' - ' . $aluno['Email'] . '</p>';
                    }
                }
                else {
                    echo '<p>Não há alunos cadastrados na turma ['. $turmaid . '] da escola [' . $escolaid . ']</p>';
                }
            }
            echo '<p>------ FIM do processamento ------</p>';
        }
    }
    
}