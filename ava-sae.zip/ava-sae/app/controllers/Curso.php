<?php

use Ava\App\Exceptions\DuplicatedEntryException;
use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Exceptions\NotFoundException;
use Ava\App\Exceptions\StudentAnswerUpdateException;
use Ava\App\Exceptions\TooManyQuestionFoundException;
use Ava\App\Collections\StudentCalendarCollection;
use Ava\App\Collections\StudentCalendarEvent;
use Ava\App\Services\Agendamentos\BuscarCalendarioPorTurma;
use Ava\App\Services\Agendamentos\ParseDisciplineFromTitle;
use Ava\App\Services\Agendamentos\BuscarAgendamentoPorId;
use Ava\App\Services\Agendamentos\BuscarAgendamentoPorTurmaAssunto;
use Ava\App\Services\Agendamentos\BuscarAgendamentoPorTurmaAssuntoLivro;
use Ava\App\Services\Agendamentos\BuscarAgendamentoReforco;
use Ava\App\Services\Aluno\BuscarAluno;
use Ava\App\Services\Assuntos\AssuntosPorDisciplinaAssunto;
use Ava\App\Services\Assuntos\CalcularDesempenhoAlunoPorAssunto;
use Ava\App\Services\Bimestres\PegaBimestrePeloId;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracaoEscolaPorSerie;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracaoGeralEscola;
use Ava\App\Services\Disciplinas\PegaDisciplinaPeloId;
use Ava\App\Services\Questoes\CorrigirEstruturaQuestoes;

use Ava\App\Services\Monitoramento\Sentry;
use Ava\App\Services\Relatorios\RelatorioDesempenhoIndividual;
use Ava\App\Services\Respostas\GravarRespostasAluno;
use Ava\App\Services\Questoes\BuscaEstatisticasQuestao;
use Ava\App\Support\ClassificacaoConteudo;
use Ava\App\Support\DataAgendamento;
use Ava\App\Support\Perfil;
use Ava\App\Support\Situacao;
use Ava\App\Support\TipoAgendamento;
use Carbon\Carbon;
use Ava\App\Services\Aluno\AnswerStructure;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * @property Disciplina_lib  disciplina_lib
 */
class Curso extends MY_Controller {

    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'curso.min', 'redactor.min', 'pt_pt', 'redactor_special_character', 'redactor.fontcolor', 'redactor.fontsize', 'jquery.cookie', 'mensagem'); //'curso.min','chosen'
    public $keywords = array('sae', 'curso');

    public $escolas_gabarito_liberado = array(
        "fd1d73cdc6d0fff603dd59e3a43cb8c1",
    );

    public function __construct()
    {
        parent::__construct();

        $this->load->model('curso_model', 'curso');
        $this->load->model('cadastro_model', 'cadastro');
        $this->load->library('disciplina_lib');
        $this->load->library('video_lib');

        // define os arquivos para juntar e comprimir
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'mensagem');
    }

    /**
     * Index
     *
     * Exibe a p?gina inicial de curso.
     *
     * @param string $Ancora determinanda qual ? a identificador da disciplina
     * @access    public
     * @return    void
     */
    public function index($Ancora = null) {
      ////     ------------
      $perfil = $this->session->userdata('perfil');

      if ($this->input->get('turmaID')) {
        $this->session->set_userdata('TurmaID', $this->input->get('turmaID'));
      }

      if ($perfil == Perfil::ALUNO && !(strpos($Ancora, 'plataforma-literaria') !== false)) {
        $data = ['ancora' => $Ancora];
        $this->js = [];
        $this->load->view('componente_curricular_aluno', $data);
        return;
      }

      $this->cssMinify[] = 'buscar';
      $this->cssMinify[] = 'curso';
      $this->cssMinify[] = 'glyphicon';
      $this->cssMinify[] = 'datepicker';
      $this->css[] = $this->minify->getCSS('curso_index.min', $this->cssMinify, ENVIRONMENT);

      $this->js[] = 'bootstrap-datepicker';

      $isPlataformaLiteraria = $Ancora === 'plataforma-literaria';
      $isComponenteCurricular = $Ancora === 'componente-curricular';
      /** @var int|false $filterTipoAgendamento */
      $filterTipoAgendamento = filter_var($this->input->get('tipoAgendamento', true), FILTER_VALIDATE_INT);

      if ($isPlataformaLiteraria) {
          $this->session->unset_userdata('grupoAulaID');
          $Ancora = null;
          $data['isPlataformaLiteraria'] = true;
          $data['ClassificacaoID'] = ClassificacaoConteudo::PLATAFORMA_LITERARIA;
      }

      if (!(strpos($Ancora, 'plataforma-literaria') !== false) && !$isPlataformaLiteraria) {
          $this->session->unset_userdata('grupoAulaID');
          $Ancora = null;
          $data['turmaId'] = $this->input->get('turmaID');
          $data['isComponenteCurricular'] = true;
          $data['ClassificacaoID'] = ClassificacaoConteudo::CONTEUDO_GERAL;

          if (in_array($perfil, [Perfil::COORDENADOR, Perfil::PROFESSOR])) {
            $this->load->view('componente_curricular_professor', $data);
            return;
          }
      }

      $grupoAula = $Ancora ? $this->home->verificaGrupoAulaAncora($Ancora) : '';

      if (count($grupoAula) == 0) {
          $grupoAula = $this->home->verificaGrupoAulaAncora(str_replace("a-ano", "-ordm-ano", $Ancora));
          if (count($grupoAula) == 0 && $this->session->userdata('Ancora')) {
              $grupoAula = $this->home->verificaGrupoAulaAncora(str_replace("a-ano", "-ordm-ano", $this->session->userdata('Ancora')));
          }
      }
      if (isset($grupoAula[0]['itemName'])) {
          $this->session->set_userdata('grupoAulaID', $grupoAula[0]['itemName']);
      }

      $dados['dados'] = montaMenu($this->session->userdata('perfil'));
      $this->menu_vertical = $this->load->view('view_menu', $dados, true);

      $data['perfil'] = intval($this->session->userdata('perfil'));

      $configuracoes = $this->curso->getConfiguracoesescola($this->session->userdata('school')->id);

      //seta valores padrao caso a escola ainda nao tenha cadastrado as configura?oes
      if ($configuracoes && isset($configuracoes[0])) {
          $data['configuracoes'] = $configuracoes[0];
          unset($configuracoes[0]);
      } else {
          $data['configuracoes']['QuestaoCoordenador'] = 'N';
          $data['configuracoes']['QuestaoProfessor'] = 'N';
          $data['configuracoes']['AgendaCoordenador'] = 'N';
          $data['configuracoes']['AgendaProfessor'] = 'N';
      }

      if (!empty($grupoAula)) {
          $agendamentosAtivos = $this->curso->agendamentosAtivos($this->input->get('turmaID'), $grupoAula[0]['itemName'], $filterTipoAgendamento);
          $agendamentosAtivos = $agendamentosAtivos[0]['qtdAgendamentosAtivos'] > 0;

          $data['agendamentosAtivos'] = null;
          if (!$agendamentosAtivos && $this->session->userdata('perfil') == PERFIL_ALUNO) {
              $data['agendamentosAtivos'] = 'style="background-color: #aad5e8 !important;"';
          }

          $data['cursoNome'] = $grupoAula[0]['Descricao'];
          $data['grupoAulaID'] = $grupoAula[0]['itemName'];
          $data['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];

          $data['meta'] = $this->session->userdata('meta');

          $data['videoaulas'] = $this->disciplina_lib->arrayDisciplinas($data['grupoAulaID'], null, $filterTipoAgendamento);

          if (empty($data['videoaulas'])) {
              redirect('/materialadicional');
          }

          if ($data['videoaulas']) {
              foreach ($data['videoaulas'] as $grid => $val) {
                  $data['qtdSemanas'] = count($val) - 1;
              }
          }

          //dados para gravar na sessao
          $array['Ancora'] = $Ancora;
          $array['grupoAulaID'] = $grupoAula[0]['itemName'];
          $array['DescricaoPacote'] = ($grupoAula[0]['Descricao']);
          $array['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];
          $array['TipoPDF'] = isset($grupoAula[0]['TipoPDF']) ? $grupoAula[0]['TipoPDF'] : 'L';
      }

      $data['turmaId'] = $this->input->get('turmaID');
      $this->session->set_userdata($array);

      $data['filterClassificaoId'] = $this->input->get('classificacaoId');
      $data['filterClassificaoId'] = '';

      if ($this->input->get('json') && filter_var($this->input->get('json'), FILTER_VALIDATE_BOOLEAN)) {
        return $this->responseJson($data);
      }
      $this->load->view('curso', $data);
    }

    /**
     * buscaAulasDisciplinas
     * Ajusta os dados de aluno e dagendamento para, no final, gerar a estrutura das questões
     * @return    void
     */
	function buscaAulasDisciplinas() {
		$dadosUsuario 				= [
			'pessoaid'				=> $this->session->userdata('pessoaid'),
			'perfilid' 				=> $this->session->userdata('perfil'),
			'turmaid' 				=> $this->session->userdata('TurmaID'),
			'escolaid' 				=> $this->session->userdata('escola'),
			'nomeAluno'				=> $this->session->userdata('nome'),
			'descricaoPacote' 		=> $this->session->userdata('DescricaoPacote'),
			'recalcularPercentual' 	=> $this->session->userdata('recalcularPercentual_' . $this->session->userdata('TurmaID')),
			'percentual' 			=> $this->session->userdata('percentual_' . $this->session->userdata('TurmaID'))
		];
		$jsonData 				= $this->getJsonRequestData();
		$dadosDisciplina 			= [
			'assuntoId' 			  => $this->input->post('disciplinaid', true) ?: $jsonData['disciplinaid'],
			'disciplinaId' 			=> $this->input->post('grupoaulaid', true) ?: $jsonData['grupoaulaid'],
			'frenteId' 				  => $this->input->post('categoriaid', true) ?: $jsonData['categoriaid'],
			'exibeDisciplina' 	=> $this->input->post('exibeDisciplina', true) ?: $jsonData['exibeDisciplina'],
			'liberaQuestao' 		=> $this->input->post('liberaQuestao', true) ?: $jsonData['liberaQuestao'],
		];
		$getAncora 					  = $this->input->post('ancora', true) ?: $jsonData['ancora'];
		$this->session->set_userdata('Ancora', $getAncora);		
    $this->load->library('Dadosrelatorio_lib');
    $finalData = $this->obterEstruturaQuestoes($dadosUsuario, $dadosDisciplina);
    d($finalData);
	}

    /**
     * obterEstruturaQuestoes
     * Ajusta os dados de aluno e dagendamento para, no final, gerar a estrutura das questões
     * @param array $dadosUsuario
     * @param array $dadosDisciplina
     * @param bool $retornoAva opcional, true para fazer os retornos em html para o ava, false para retornar json para o app
     * @return    void
     */
    function obterEstruturaQuestoes($dadosUsuario, $dadosDisciplina, $retornoAva = true) {
      // Desacoplando os dados do usuário e da disciplina para variáveis locais desse método, a fim de literalmente não encostar na lógica de gerar estruturas das questões
      $pessoaid						= $dadosUsuario['pessoaid'];
      $perfilid 						= $dadosUsuario['perfilid'];
      $turmaid 						= $dadosUsuario['turmaid'];
      $escolaid 						= $dadosUsuario['escolaid'];
      $descricaoPacote 				= $dadosUsuario['descricaoPacote'];
      $recalcularPercentual 			= $dadosUsuario['recalcularPercentual'];
      $percentual 					= $dadosUsuario['percentual'];
      $assuntoId 						= $dadosDisciplina['assuntoId'];
      $disciplinaId 					= $dadosDisciplina['disciplinaId'];
      $frenteId 						= $dadosDisciplina['frenteId'];
      $exibeDisciplina 				= $dadosDisciplina['exibeDisciplina'];
      $liberaQuestao 					= $dadosDisciplina['liberaQuestao'];
      $paramVideo['disciplinaid'] 	= $assuntoId;
      $paramVideo['turmaid'] 			= $turmaid;
      $metaPercentual 				= 0;
      $metaQuestao 					= 0;
      $percentual 					= NULL;
      $recalcularPercentual 			= FALSE;
      $data['perfil'] 				= $perfilid;
		  $this->curso->corrigeAgendamentos($escolaid, $assuntoId, $turmaid, $disciplinaId, $frenteId);
      $bimestre = SaeDigital::make(PegaBimestrePeloId::class)->handle($frenteId);

      $configuracoes = $this->curso->getConfiguracoesescola($escolaid);
      //seta valores padrao caso a escola ainda nao tenha cadastrado as configura?oes
      if ($configuracoes && isset($configuracoes[0])) {
        $data['configuracoes'] = $configuracoes[0];
        unset($configuracoes[0]);
      }

      $turma = $this->home->verificaTurmas($turmaid, $escolaid);
      $array = $this->disciplina_lib->arrayAulas($disciplinaId, $assuntoId, $frenteId, false);
      $disciplina = SaeDigital::make(PegaDisciplinaPeloId::class)->handle($disciplinaId);

        $temVideo = false;
        foreach ($array['aulas'] as $keyx => $valuex) {
          if ($valuex['Tipo'] == 'N') {
            if ($valuex['Video'] == '') {
              if ( $retornoAva ) {
                die('<div><li class=""><p class="icoVid"></p><div class="aula"><p class="nome">Desculpe, ainda não temos vídeos cadastrados no sistema. Volte mais tarde.</p></div><input type="hidden" id="totalNovaAulas" value="0"></li></div>');
              } else {
                return ['success' => false, 'error' => 'Vídeo não encontrado'];
              }
            } else {
              $temVideo = true;
            }
          }
        }
        if ($perfilid == PERFIL_ALUNO) {
          $questao = [];
          $revisao = [];
          foreach ($array['aulas'] as $aula) {
            switch ($aula['Tipo']) {
              case 'Q':
                $questao = $this->curso->getQuestoesAula($disciplinaId, $aula['AulaID']);
                break;
              case 'R':
                $revisao = $this->curso->getQuestoesAula($disciplinaId, $aula['AulaID']);
            }
          }
          if (!$temVideo && (count($questao) === 0 || count($revisao) === 0)){
            if ( $retornoAva ) {
              die('<div><li class=""><p class="icoVid"></p><div class="aula"><p class="nome">Desculpe, ainda não temos questões/vídeos cadastrados no sistema. Volte mais tarde.</p></div><input type="hidden" id="totalNovaAulas" value="0"></li></div>');
            } else {
              return ['success' => false, 'error' => 'Questoes nao encontradas'];
            }
          }
          foreach ($configuracoes as $v) {
            if (isset($v['Serie']) && $v['Serie'] == $turma[0]['SerieID']) {
              $metaPercentual = isset($v['Percentual']) ? $v['Percentual'] : 0;
              $metaQuestao = isset($v['Meta']) ? $v['Meta'] : 60;
            }
          }
          foreach ($array['aulas'] as $key => $value) {
            $questoes = $this->curso->getQuestoesAluno($pessoaid, $disciplinaId, $assuntoId, $value['AulaID']);
          //  echo "dsaidsaji";
         //   echo json_encode($value);
           // d($questoes);
            if (empty($questoes)) {
              $descAssunto = $this->curso->verificaDisciplinas($disciplinaId, $value['DisciplinaID'], $frenteId);
              switch ($value['Tipo']) {
                case 'Q':
                case 'R':
                  $this->dadosrelatorio_lib->insereQuestao($disciplinaId, $value['AulaID'], $frenteId, $descricaoPacote, $descAssunto[0]['Descricao'], $value, $metaQuestao, $dadosUsuario);
                  break;
                case 'N':
                  $this->dadosrelatorio_lib->insereVideo($disciplinaId, $value['AulaID'], $frenteId, $descricaoPacote, $descAssunto[0]['Descricao'], $value, $dadosUsuario);
                  break;
              }
            }
          }
          if ($data['perfil'] == PERFIL_ALUNO) {
            $array['percentualVideo'] = $this->curso->getTempoVideo($array);
          }
        }

        // verifica percentual das aulas:
        $param[0]['DisciplinaID'] = $assuntoId;
        $param[0]['Tipo'] = 'Q';
        $param[1]['Tipo'] = 'R';
        $this->load->model('disciplina_model');
        $array['reforco']['TotalReforco'] = count($this->disciplina_model->questoesReforco($param, $disciplinaId));

        $ordemAulas = ['Q', 'N', 'R'];
        usort($array['aulas'], function ($a, $b) use ($ordemAulas) {
          $pos_a = array_search($a['Tipo'], $ordemAulas);
          $pos_b = array_search($b['Tipo'], $ordemAulas);
          return $pos_a - $pos_b;
        });

        if ((int)$perfilid === Perfil::ALUNO) {
          $data['idAssunto'] = $assuntoId;
          $data['idDisciplina'] = $disciplinaId;
          $data['idBimestre'] = $frenteId;
          $data['idAluno'] = $pessoaid;
        }
        $array['disciplina'] = $disciplina;
        /** @var BuscarAgendamentoPorTurmaAssunto $scheduleService */
        $scheduleService = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class);
        $schedules = $scheduleService->handle($turmaid, $assuntoId, $disciplinaId, $pessoaid, TipoAgendamento::TRILHA);
        $reviews = $scheduleService->handle($turmaid, $assuntoId, $disciplinaId, $pessoaid, TipoAgendamento::REFORCO);
        $metadata = [
          'hasSchedules' => count($schedules) > 0,
          'hasReviews' => count($reviews) > 0,
          'tipoAgendamento' => $tipoAgendamento
        ];
        if ($this->input->get('json') && filter_var($this->input->get('json'), FILTER_VALIDATE_BOOLEAN)) {
          $common = [
            'exibeDisciplina' => $exibeDisciplina,
            'liberaQuestao' => $liberaQuestao,
            'metaPercentual' => $metaPercentual,
            'percentual' => $percentual,
            'metaQuestao' => $metaQuestao,
            'metadata' => $metadata
          ];
          $json = array_merge($array, $common, $data, $bimestre);
          return $this->responseJson($json);
        }
      if ($retornoAva){
        echo $this->disciplina_lib->htmlListaAulasCurso($array, $exibeDisciplina, $liberaQuestao, $metaPercentual, $percentual, $metaQuestao, $data, $bimestre, $metadata);
        die;
      }
		  return ['success' => true, 'error' => ''];
    }

    /*
     * Fun??o para gerar Calend?rio automatico por semana
     */
    public function calendarioPorSemana()
    {
        // Teste Calendario automatico por semana
        // Par?metros {$totalsemanas int ex: 6, $sequencia_data date ex: 2015-10-29}
        $resposta = array();

        $hoje = new DateTime();
        $data = DateTime::createFromFormat(DataAgendamento::FORMAT, $this->input->post('sequencia_data', TRUE));

        if (!($this->input->post('sequencia_data', TRUE))) {
            $resposta['status'] = FALSE;
            $resposta['mensagem'] = 'Parâmetro sequência data inválido';
        } else if (!($this->input->post('total_semanas', TRUE))) {
            $resposta['status'] = FALSE;
            $resposta['mensagem'] = 'Parêmetro total semanas inválido';
        } else if ($data < $hoje) {
            $resposta['status'] = FALSE;
            $resposta['mensagem'] = 'A data inicial não pode ser inferior ao dia de hoje';
        } else {
            $data = array();
            $sequencia_data = $this->input->post('sequencia_data', TRUE);
            $total_semanas = $this->input->post('total_semanas', TRUE);
            for ($i = 0; $i < $total_semanas; $i++) {
                $data[$i]['data_inicio'] = $sequencia_data = ($i == 0) ? $sequencia_data : date("Y-m-d", strtotime("+7 days", strtotime(date("Y-m-d", strtotime("+1 days", strtotime($sequencia_data))))));
                $data[$i]['data_fim'] = date("Y-m-d", strtotime("+7 days", strtotime($sequencia_data)));
            }

            // Monta html - sem tempo para ser library
            $html = '<table >
				<tr>
                                    <td>
                                            Semana
                                    </td>
                                    <td >
                                            Data iní­cio
                                    </td>
                                    <td>
                                            Data fim
                                    </td>
				</tr>';
            foreach ($data as $key => $value) {
                $datainicio = date('d/m/Y', strtotime($value['data_inicio']));
                $datafim = date('d/m/Y', strtotime($value['data_fim']));
                $html .= '   <tr>
                                <td >
                                    ' . ($key + 1) . 'ª Semana
                                </td>
                                <td>
                                    ' . $datainicio . '
                                </td>
                                <td>
                                    ' . $datafim . '
                                </td>
                            </tr>';


            }
            $html .= '</table>';

            $resposta['status'] = TRUE;
            $resposta['mensagem'] = 'Estrutura gerada com sucesso';
            $resposta['html'] = ($html);
        }
        $resposta = (object)$resposta;

        print_r(json_encode($resposta));
        die;
    }

    /*
    * Fun??o para salvar Calend?rio automatico por semana
    */
    public function salvaCalendarioPorSemana()
    {
        try {
            $this->load->model('curso_model', 'curso');

            $resposta = array();
            if (!($this->input->post('sequencia_data', TRUE))) {
                $resposta['status'] = FALSE;
                $resposta['mensagem'] = 'Parâmetro sequência data inválido';
            } else if (!($this->input->post('total_semanas', TRUE))) {
                $resposta['status'] = FALSE;
                $resposta['mensagem'] = 'Parâmetro total semanas inválido';
            } else if (!($this->input->post('grupoaulaid', TRUE))) {
                $resposta['status'] = FALSE;
                $resposta['mensagem'] = 'Parâmetro Grupo aula ID inválido';
            } else if (!($this->input->post('categoriaid', TRUE))) {
                $resposta['status'] = FALSE;
                $resposta['mensagem'] = 'Parâmetro Categoria ID inválido';
            }
            //  p($this->input->post());die;
            // monta per?odo de semanas
            $data = array();
            $sequencia_data = Carbon::createFromFormat(DataAgendamento::FORMAT, $this->input->post('sequencia_data', TRUE));
            $total_semanas = $this->input->post('total_semanas', TRUE);
            for ($i = 0; $i < $total_semanas; $i++) {
                if ($i === 0) {
                    $data[$i]['dtinicio'] = $sequencia_data->toDateString();
                    $data[$i]['dtfim'] = $sequencia_data->addDays(7)->toDateString();
                } else {
                    $data[$i]['dtinicio'] = $sequencia_data->addDays(1)->toDateString();
                    $data[$i]['dtfim'] = $sequencia_data->addDays(7)->toDateString();
                }
            }

            // monta array de aulas
            $escola = $this->session->userdata('escola');
            $turma = $this->input->post('turmaId');
            $disciplina = $this->input->post('grupoaulaid', TRUE); // Grupoaulaid ser? enviado via post
            $categoriaid = $this->input->post('categoriaid', TRUE);
            $array = $this->curso->verificaVideoAulasDisciplina($disciplina, $categoriaid); /* GrupoAulaID */
            $aulas = array();
            foreach ($array as $key => $value) {
                unset($value['DescricaoCategoria']);
                $sequencia = 0;
                foreach ($value as $key2 => $value2) {
                    $aulas[$sequencia]['assunto'] = $value2['info']['DisciplinaID'];
                    $aulas[$sequencia]['frete'] = $key;
                    $sequencia++;
                }
            }

            // Chegou arrepiar como isso funciona , realmente inacreditavel!!!!!
            $mount_array = function ($d, $a) {
                return array_merge($d, $a);
            };


            $result_gravar = array_map($mount_array, $data, $aulas);
            // array pronto para gravar
            foreach ($result_gravar as $key_rg => $value_rg) {
                $datainicio = $value_rg['dtinicio'];
                $dtfinal = $value_rg['dtfim'];
                $assunto = $value_rg['assunto'];
                $frente = $value_rg['frete'];

                // l?gica para gravar
                $dataInicio = $datainicio;
                $dataFim = $this->input->post('dtfim');

                $dtTempIni = explode('-', $dataInicio);
                /*  COMENTADO POIS ESTAVA INVERTENDO A DATA, FICANDO ERRADO O FORMATO NO SIMPLEDB
                $dtInicio = $dtTempIni[2] . '-' . $dtTempIni[1] . '-' . $dtTempIni[0];
                */
                if ($dataFim) {
                    $dtTempFim = explode('-', $dataFim);
                    $dtFim = $dtTempFim[2] . '-' . $dtTempFim[1] . '-' . $dtTempFim[0];
                } else if ($dtfinal) {
                    $dtFim = $dtfinal;
                } else {
                    $dtFim = '-';
                }

                $edit = 0;

                $id = $edit ? $edit : md5(uniqid(rand(), true));

                $fields['DisciplinaID'] = $disciplina;
                $fields['AssuntoID'] = $assunto;
                $fields['FrenteID'] = $frente;
                $fields['EscolaID'] = $escola;
                $fields['TurmaID'] = $turma;
                $fields['tipo_agendamento'] = TipoAgendamento::PLATAFORMA_LITERARIA;

                $agendamentos = SaeDigital::make(BuscarAgendamentoPorTurmaAssuntoLivro::class)->handle(
                    $escola, $turma, $disciplina, $frente, $assunto
                );

                if (!empty($agendamentos)) {
                    throw new DuplicatedEntryException('Já existe agendamento para um dos módulos selecionados!');
                }

                $fields['DtFim'] = $dtFim;
                $fields['DtInicio'] = $datainicio;//$dtInicio;
                $fields['UsuarioAlt'] = $this->session->userdata('pessoaid');
                $fields['DtAlt'] = date('Y-m-d H:i:s');

                if ($this->session->userdata('redirecionar') == 'professor' || $this->session->userdata('redirecionar') == 'coordenador') {
                    $fields['NotificacaoResponsavel'] = $this->session->userdata('notificacaoresponsavel');
                }

                if ($edit == 0) {
                    $fields['UsuarioCad'] = $this->session->userdata('pessoaid');
                    $fields['DtCad'] = date('Y-m-d H:i:s');
                }

                // Atualiza tabela de logs sms e emails para reenvio - FV 31/08/2015
                $this->curso->atualizaEnviosEmailsSms($fields);

                $result = $this->curso->gravaDados('D024_Ava_Sae_Agenda', $id, $fields, FALSE);

                //altera todos os registros da tabela avasae.R001_RespostasQuestoes com a nova data inicio e data fim
                if ($datainicio == '-')
                    $dtInicio = null;

                if ($dtFim == '-')
                    $dtFim = null;

                $update['DtAgendaInicio'] = date(DataAgendamento::FORMAT, strtotime($datainicio));
                $update['DtAgendaFim'] = date(DataAgendamento::FORMAT, strtotime($dtFim));

                $where['DisciplinaID'] = $disciplina;
                $where['AssuntoID'] = $assunto;
                $where['FrenteID'] = $frente;
                $where['EscolaID'] = $escola;
                $where['TurmaID'] = $turma;

                $this->curso->gravaRespostaAluno($update, $where);
           
            }

            $resposta['status'] = TRUE;
            $resposta['message'] = ('Processo concluído!');

            return $this->responseJson($resposta, 200);
        } catch (DuplicatedEntryException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 422);
        }
    }

    private function agendamentoExpirado($dataFim)
    {
        if (is_null($dataFim)) {
            return false;
        }

        $dataAgendamentoFim = \DateTime::createFromFormat('Y-m-d', $dataFim);
        $dataAgendamentoFim = $dataAgendamentoFim->setTime(0, 0, 0);
        $hoje = new \DateTime();
        $hoje = $hoje->setTime(0, 0, 0);

        return ($dataAgendamentoFim <= $hoje);
    }

    private function validarLiberacaoAtividade($idAluno, $idAssunto, $turma, $tipoAtividade, $frenteId)
    {
        $plataforma = $this->curso->validarAgendamentoPlataformaLiteraria($turma, $idAssunto, $frenteId);

        if ($plataforma) {
            return null;
        }
        $data = $this->curso->validarLiberacaoDeAtividades($idAluno, $idAssunto, $turma, $tipoAtividade);

        $agendamentoExpirado = false;
        if ($tipoAtividade == 'N') {
            $agendamento = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class)->handle(
                $turma, $idAssunto
            );

            $agendamentoAluno = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class)->handle(
                $turma, $idAssunto, null, $this->session->userdata('pessoaid')
            );

            if ($agendamento && $agendamentoAluno) {
                $dtFimAgendamentoTurma = Carbon::createFromFormat('Y-m-d', $agendamento['DtFim']);
                $dtFimAgendamentoAluno = Carbon::createFromFormat('Y-m-d', $agendamentoAluno['DtFim']);

                if ($dtFimAgendamentoTurma->lt($dtFimAgendamentoAluno)) {
                    $agendamento = $agendamentoAluno;
                }
            }

            if (!$agendamento && $agendamentoAluno) {
                $agendamento = $agendamentoAluno;
            }

            if (!$agendamento) {
                return 'Você precisa responder as questões primeiro ou não possuí agendamento para esse assunto.';
            }

            $agendamentoExpirado = $this->agendamentoExpirado($agendamento['DtFim']);
        }

        if ($tipoAtividade == 'N' && $agendamentoExpirado) {
            return null;
        } elseif (!$data && $tipoAtividade == 'R') {
            $msg = 'Você deve terminar de assistir ao vídeo ou não possuí agendamento para esse assunto.';
        } elseif (!$data && $tipoAtividade == 'N') {
            $msg = 'Você precisa responder as questões primeiro ou não possuí agendamento para esse assunto.';
        } elseif (!$data) {
            $msg = 'Você não possuí agendamento para esse assunto.';
        } else {
            return null;
        }

		return $msg;
    }


    public function video($Ancora = null)
    {
        $this->cssMinify[] = 'mensagem';
        $this->cssMinify[] = 'style';
        $this->cssMinify[] = 'redactor/redactor';
        $this->cssMinify[] = 'glyphicon';
        $this->cssMinify[] = 'css-responsive';
      
        $this->css[] = $this->minify->getCSS('video_curso.min', $this->cssMinify, ENVIRONMENT);

        $this->js[] = 'jquery.oembed.min';
        $this->js[] = 'jquery.paginate.min';
        $this->js[] = 'bootstrap-tooltip';

        $this->load->library('dadosrelatorio_lib');
        // widgets class esquerda
        
        $Escola = (array) $this->session->userdata('school'); 
        $escolaId = $Escola['id'];

        $configuracoes = $this->curso->getConfiguracoesescola($escolaId);

        //seta valores padrao caso a escola ainda nao tenha cadastrado as configura?oes
        $data['dadoComplementar'] = '';

        $retornoVerificaPacotesAluno = $this->home->verificaGrupoAulaAncora($Ancora);
        if (count($retornoVerificaPacotesAluno) == 0) {
            $retornoVerificaPacotesAluno = $this->home->verificaGrupoAulaAncora(str_replace("a-ano", "-ordm-ano", $Ancora));
        }

        if ($configuracoes && isset($configuracoes[0])) {
            $data['RespostaFinalAgendamentoAluno'] = isset($configuracoes[0]['RespostaFinalAgendamentoAluno']) ? $configuracoes[0]['RespostaFinalAgendamentoAluno'] : 'N';
        }

        $data['cursoNome'] = isset($retornoVerificaPacotesAluno[0]['Descricao']) ? $retornoVerificaPacotesAluno[0]['Descricao'] : '';
        $dados = $this->curso->verificaVideoAula();
        $data['serieID'] = $retornoVerificaPacotesAluno[0]['SerieID'];
        $data['perfil'] = $this->session->userdata('perfil');
     
        if (!empty($retornoVerificaPacotesAluno) && !empty($dados)) {
            $Turma = (array) $this->session->userdata('teams')[0]; 
            $turmaId = $Turma['id'];

            $urlRetorno = $this->urlRetorno($Ancora, $turmaId, $retornoVerificaPacotesAluno[0]['ClassificacaoID']);
            $data['urlRetorno'] = $urlRetorno;
            $idUsuario = $this->session->userdata('pessoaid');
            $classificacaoID = $this->session->userdata('ClassificacaoPacotePai');
            $grupoAulaID = $retornoVerificaPacotesAluno[0]['itemName'];
            $disciplinaID = $dados[0]['DisciplinaID'];

            $aulaID = $dados[0]['AulaID'];
            $linkVideoaula = $dados[0]['Video'];

            $data['videoNome'] = $dados[0]['Tema'];
            $data['aulaID'] = $aulaID;
            $data['grupoAulaID'] = $grupoAulaID;
            $data['pdf'] = str_replace('.mp4', '.pdf', $dados[0]['Video']);

            $result = $this->curso->verificaDisciplina($disciplinaID, $grupoAulaID);

            $data['disciplinaNome'] = $result[0]['Descricao'];
            $data['assuntoID'] = $result[0]['DisciplinaID'];
            $data['frenteID'] = $result[0]['CategoriaID'];
            // XPTO

            // verificar se existe agendamento
            // se existir agendamento, verificar se existe a estrutura
            // se nao existir a estrutura, criar
            if( $result[0]['ClassificacaoID'] == ClassificacaoConteudo::PLATAFORMA_LITERARIA && $this->input->get('questao') == 'true' ) {
                $this->dadosrelatorio_lib->insereQuestao($grupoAulaID, $aulaID, $result[0]['CategoriaID'], $data['cursoNome'], $result[0]['Descricao'], $dados[0], false, false, true);
            }

            $validacaoLiberacaoAtividade = $this->validarLiberacaoAtividade($idUsuario, $data['assuntoID'], $turmaId, $dados[0]['Tipo'], $data['frenteID']);
          
            if (!is_null($validacaoLiberacaoAtividade) && $this->session->userdata('perfil') == PERFIL_ALUNO) {
                $data['bloqueiaQuestoes'] = true;
                $data['mensagemBloqueioQuestoes'] = $validacaoLiberacaoAtividade;
                $this->load->view('questao', $data);
                return;
            }

            switch ($result[0]['ClassificacaoID']) {
                case ClassificacaoConteudo::PLATAFORMA_LITERARIA:
                    $tipoAgendamento = TipoAgendamento::PLATAFORMA_LITERARIA;
                    break;
                default:
                    $tipoAgendamento = TipoAgendamento::TRILHA;
            }
            //            $agendamento = end($this->curso->buscarAgendamentoTurmaAssunto($turmaId, $result[0]['DisciplinaID'], $tipoAgendamento));
            //            $agendamentoAluno = end($this->curso->buscarAgendamentoAlunoTurmaAssunto($this->session->userdata('pessoaid'), $turmaId, $result[0]['DisciplinaID'], $tipoAgendamento));

            $agendamento = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class)->handle(
                $turmaId, $result[0]['DisciplinaID'], null, null, $tipoAgendamento
            );

            $agendamentoAluno = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class)->handle(
                $turmaId, $result[0]['DisciplinaID'], null, $this->session->userdata('id'), $tipoAgendamento
            );
            
            if ($agendamento && $agendamentoAluno) {
                $dtFimAgendamentoTurma = Carbon::createFromFormat('Y-m-d', $agendamento['DtFim']);
                $dtFimAgendamentoAluno = Carbon::createFromFormat('Y-m-d', $agendamentoAluno['DtFim']);

                if ($dtFimAgendamentoTurma->lt($dtFimAgendamentoAluno)) {
                    $agendamento = $agendamentoAluno;
                }
            }

            if (!$agendamento && $agendamentoAluno) {
                $agendamento = $agendamentoAluno;
            }

            $frente = $this->curso->verificaCategoriaOrdem($grupoAulaID, $result[0]['CategoriaID']);
            $data['DescFrente'] = $frente[0]['Descricao'];

            $data['situacaoVideoAula'] = '';

            // monta todas v?deos aulas relacionadas a disciplina para que posssa ir para os pr?ximos.
            $data['videoaulas'] = $this->curso->verificaVideoAulasDisciplinaVideo($grupoAulaID, $disciplinaID, 'N', false);
            $data['videoPlayer'] = $linkVideoaula;
            $data['videoAulaVer'] = $this->uri->segment(5) ? $this->uri->segment(5) : 1;

            $data['Ancora'] = $Ancora;

            $data['possuiQuestoes'] = 0;

            //verifica se ja foram gravadas as questoes do aluno
			$questoesUsuario = $this->curso->getQuestoesAluno($idUsuario, $grupoAulaID, $disciplinaID, $aulaID);
			
            //abre tela de questoes
            if ($this->input->get('questao') == 'true') {
                $questoes = 0;
                $data['qtdQuestoes'] = count($questoesUsuario);

                if (empty($questoesUsuario)) {
                    // cadastra as quest?es:
                    $retorno = $this->dadosrelatorio_lib->insereQuestao($grupoAulaID, $aulaID, $result[0]['CategoriaID'], $data['cursoNome'], $result[0]['Descricao'], $dados[0], false, false, $result[0]['ClassificacaoID'] == ClassificacaoConteudo::PLATAFORMA_LITERARIA);
                    //print_pre($retorno);die;
                    $data['qtdQuestoes'] = $retorno['qtdQuestoes'];
                    $data['possuiQuestoes'] = ($retorno['qtdQuestoes'] > 0) ? 1 : 0;
                    $data['questaoAtual'] = 0;
                    $questaoAtual = $retorno['questaoAtual'];

                    // busca a quest?o inserida
                    $questoesUsuario = $this->curso->getQuestoesAluno($idUsuario, $grupoAulaID, $disciplinaID, $aulaID);

                } else {
                    foreach ($questoesUsuario as $key => $questao) {
                        if (is_null($questao->Resposta)) {
                            $questaoAtual = $questao->QuestaoID;
                            $data['questaoAtual'] = $key;
                            break;
                        } else {
                            $questaoAtual = $questoesUsuario[0]->QuestaoID;
                            $data['questaoAtual'] = 0;
                        }
                    }
                }

                $dadosLinkVideo = $this->curso->getLinkVideo($disciplinaID);

                if (!empty($dadosLinkVideo)) {
                    $data['linkVideo'] = base_url() . 'curso/' . $Ancora . '/' . encodeString($dadosLinkVideo[0]['Tema']) . '/' . str_pad($dadosLinkVideo[0]['DisciplinaID'], 7, '0', 0) . str_pad($dadosLinkVideo[0]['AulaID'], 7, '0', 0) . '/1/';
                }

                $array = array('questao' => $questaoAtual);

                $resultApi = $this->curso->CarregaQuestaoAPI(
                    $array['questao'],
                    $retornoVerificaPacotesAluno[0]['ClassificacaoID'],
                    $disciplinaID
                );

                if ($resultApi['success'] === 0) {
                    $data['message'] = $resultApi['message'];
                    $data['code'] = $resultApi['code'];

                    return $this->load->view('questao', $data);
                }

                foreach ($questoesUsuario as $item) {
                    if ($item->QuestaoID == $array['questao']) {
                        $dataConclusao = $item->DtConclusao;
                    }
                }

                if (isset($resultApi['success']) && $resultApi['success'] == 1) {
                    $data['ultimaQuestao'] = count($questoesUsuario) == ($data['questaoAtual'] + 1) ? 1 : 0;
                    $data['dadosQuestao'] = $resultApi['message'];

                    //salva a alternativa correta
                    for ($a = 0; count($data['dadosQuestao']['questao']['alternativas']) > $a; $a++) {

                        if ($data['dadosQuestao']['questao']['alternativas'][$a]['opcaoCorreta'] == 1) {
                            $data['altCorreta'] = $data['dadosQuestao']['questao']['alternativas'][$a]['id'];
                            $data['opcaoCorreta'] = $data['dadosQuestao']['questao']['alternativas'][$a]['valorOpcao'];
                        }
                    }

                    if ($data['perfil'] != PERFIL_ALUNO) {
                        $tipoQuestao = $this->curso->getTipoQuestao($aulaID);
                    }
                    $data['tipoQuestao'] = isset($questoesUsuario[0]->Tipo) ? $questoesUsuario[0]->Tipo : $tipoQuestao[0]['Tipo'];
                    $data['aulaID'] = $aulaID;

                    $date = new DateTime($dataConclusao);
                    $dataOnly = date_format($date, "d/m/Y");
                    $horaOnly = date_format($date, "H:i:s");
                    $data['DataConclusao'] = $dataOnly;
                    $data['HoraConclusao'] = $horaOnly;

                    $data['disciplinaID'] = $dados[0]['DisciplinaID'];

                    $data['questaoRespondida'] = isset($questoesUsuario[$data['questaoAtual']]->RespostaCorreta) || $this->session->userdata('perfil') != 273 ? 1 : 0;

                    $data['respostaCorreta'] = isset($questoesUsuario[$data['questaoAtual']]->RespostaCorreta) ? $questoesUsuario[$data['questaoAtual']]->RespostaCorreta : '';

                    $data['respostaAluno'] = isset($questoesUsuario[$data['questaoAtual']]->Resposta) ? $questoesUsuario[$data['questaoAtual']]->Resposta : null;

					// Improviso para garantir horário fixo em GMT-3
					$horarioBrasilia 	= strtotime( gmdate('Y-m-d H:i:s') ) - 10800;
					$horarioAgendamento = strtotime($agendamento['DtFim'] . "23:59:59");					
                    $data['finalizado'] = $horarioAgendamento < $horarioBrasilia ? 1 : 0;
                    
                    $data['dadosQuestao']['linkRefreshImg'] = '';
                    
                    $linkRefreshImg = "  <div class='nomargin alert alert'>
                                        Caso a imagem na questão não carregue, atualize a página clicando
                                    	<a href='#' title='Clique aqui para recarregar a página' onclick='window.location.reload()'>
                       					 aqui
                   					 	</a>
                   					 </div> ";
                    
                    $iconRefreshImgQuestion = strstr($data['dadosQuestao']['questao']['enunciado'], '<img') ? true : false;
                    
                    for($i = 0; count($data['dadosQuestao']['questao']['alternativas']) > $i; $i++){
                        $iconRefreshImgAlternative = strstr($data['dadosQuestao']['questao']['alternativas'][$i]['opcao'], '<img') ? true: false;
                        if($iconRefreshImgAlternative) break;
                    }
                    
                    if($iconRefreshImgQuestion){
                        $data['dadosQuestao']['linkRefreshImg'] = $linkRefreshImg;
                    }elseif($iconRefreshImgAlternative){
                        $data['dadosQuestao']['linkRefreshImg'] = $linkRefreshImg;
                    }else{
                        $data['dadosQuestao']['linkRefreshImg'] = "";
                    } 

                }

                $data['RespostaFinalAgendamentoAluno'] = 'S';
                if ((int)$this->session->userdata('perfil') === Perfil::ALUNO) {
                    $configResposta = $configuracoes[0]['RespostaFinalAgendamentoAluno'];
                    $dataExpiracao = \DateTime::createFromFormat('Y-m-d', $agendamento['DtFim'])->setTime(23, 59, 59);
                    $data['RespostaFinalAgendamentoAluno'] = $this->exibirRespostaCorreta(
                        $configResposta,
                        $dataExpiracao
                    );
                }

                $var = get_defined_vars();
                $cursonome = $var['data']['cursoNome'];
                $cursonome2 = explode("-", $cursonome);
                $cursonome_f = explode(" ", trim($cursonome2[0]));
                if ($cursonome_f[0] == 'Plataforma' || strstr($cursonome2[1], 'Plataforma')) {
                    $pl = 1;
                } else {
                    $pl = 0;
                }

                $data['plataforma_lit'] = $pl;
                
                $this->load->view('questao', $data);
            } else {
                //FIXME: ABRE TELA DE VIDEOS
                if (!$questoesUsuario && $data['perfil'] == PERFIL_ALUNO) {
                    // grava o registro no AVA
                    $this->dadosrelatorio_lib->insereVideo($grupoAulaID, $aulaID, $result[0]['CategoriaID'], $data['cursoNome'], $result[0]['Descricao'], $dados[0]);
                }

                $this->session->set_userdata('recalcularPercentual_' . $this->session->userdata('TurmaID'), TRUE);
                $this->session->set_userdata('link_video_aula', $linkVideoaula);
                $this->session->set_userdata('aulaid', $aulaID);
                $this->session->set_userdata('tema', $data['videoNome']);
                $this->session->set_userdata('grupoAulaID', $grupoAulaID);
                $this->session->set_userdata('cursonome', $data['cursoNome']);
                $this->session->set_userdata('disciplinaid', $data['assuntoID']);
                $this->session->set_userdata('disciplinanome', $data['disciplinaNome']);
                $this->session->set_userdata('frenteid', $data['frenteID']);
                $this->session->set_userdata('frentenome', $data['DescFrente']);

                $usuarioID = $this->session->userdata('pessoaid');
                $videoAulaInfo = $this->curso->getVideoAula($usuarioID, $aulaID, $grupoAulaID);


                if (!empty($videoAulaInfo)) {
					
					$data['percentualVideo'] = isset($videoAulaInfo->PercentualVideo) ? $videoAulaInfo->PercentualVideo : 0;
                    $data['inicioVideo'] = isset($videoAulaInfo->InicioVideo) ? $videoAulaInfo->InicioVideo : 0;
                    $data['fimVideo'] = isset($videoAulaInfo->FimVideo) ? $videoAulaInfo->FimVideo : 0;
					$data['videoAulaAssistida'] = $videoAulaInfo->VideoAulaAssistida;
					
					// // Improviso para garantir horário fixo em GMT-3
					$horarioBrasilia 				= strtotime( gmdate('Y-m-d H:i:s') ) - 10800;
					$horarioAgendamento 			= strtotime($agendamento['DtFim'] . "23:59:59");					
					
                    $data['agendamentoExpirado'] 	= $horarioAgendamento < $horarioBrasilia;
                }


                $data['usuarioid'] = $usuarioID;

                $data['videoURL'] = $linkVideoaula;

                $data['videoType'] = 'video/vimeo';
                $data['origin'] = 'vimeo';

                $jsVideo = [
                    '../dist/js/player/vimeo'
                ];

                if (pathinfo($linkVideoaula, PATHINFO_EXTENSION) !== "") {
                    $data['origin'] = 'mp4';
                    $data['videoType'] = 'video/mp4';

                    $this->cssMinify[] = 'video';
                    $this->css[] = 'videojs/video-js';

                    $jsVideo = [
                        'flowplayer-3.2.12.min',
                        'videojs/video.min',
                        'video'
                    ];
                }

                $this->js = array_merge($this->js, $jsVideo);

                $acao = "Entrou para assistir o video " . $data['videoNome'];
                $log['loginid'] = $this->session->userdata['pessoaid'];
                $log['login'] = $this->session->userdata['login'];
                $log['acao'] = ($acao);
                $log['nomeescola'] = ($this->session->userdata['nomeEscola']);
                $log['escola'] = ($this->session->userdata['escola']);
                $log['codigo'] = '4'; //Assistir Video

                $this->load->model('Log_model', 'logacesso');
                $this->logacesso->GravaLog($log);
                $nome_video = $data['videoNome'];
                log_system_action("Começou a asisstir o vídeo $nome_video");
                $var = get_defined_vars();
                if (strpos($var['data']['cursoNome'], 'Plataforma')) {
                    $pl = 1;
                } else {
                    $pl = 0;
                }

                $data['plataforma_lit'] = $pl;
                //$this->js[] = 'trigger_hotjar_pagina_video';
                $this->load->view('video', $data);
            }
        } else {
            //show_404('page');
            $params = array_slice($this->uri->rsegment_array(), 0);
            header("Location:" . base_url() . 'curso/' . $params[2] . '/');
            die();
        }
    }

    private function exibirRespostaCorreta($configuracao, DateTime $dataExpiracaoAgendamento)
    {
        if ($configuracao == 0) {
            return 'N';
        } elseif ($configuracao == 1) {
            $hoje = new DateTime();
            $hoje->setTime(0, 0, 0);

            return $hoje > $dataExpiracaoAgendamento ? 'S' : 'N';
        } elseif ($configuracao == 2) {
            return 'S';
        }

        return 'N';
    }

    private function urlRetorno($ancora, $turma, $classificacaoId)
    {
        $param = "curso/{$ancora}?turmaID={$turma}";
        if ((int)$this->session->userdata('perfil') === Perfil::ALUNO && (int)$classificacaoId === 11) {
            $param = "curso-plataforma-literaria/{$ancora}?turmaID={$turma}";
        }

        return $param;
    }


    /**
     * Buscar
     *
     * Busca e retorna todas v?deo aulas, caso contenha para consulta realizada..
     *
     * @param string $termoBusca descri??o do termo da pesquisa
     * @access    private
     * @return    void
     */
    function buscar($termoBusca = null)
    {

        $this->cssMinify[] = 'buscar';
        $this->css[] = $this->minify->getCSS('buscar_curso.min', $this->cssMinify, ENVIRONMENT);

        $this->menu_vertical = $this->load->view('view_menu', '', true);

        $data['videoaulas'] = array();
        if ($termoBusca) {
            $data['videoaulas'] = $this->curso->buscaVideoAulas($termoBusca);
        }


        $this->load->view('buscar', $data);
    }

    /**
     * Resultado Busca
     *
     * retorna todas v?deo aulas que h? cadastradas de acordo com o termo buscado.
     *
     * @param string $termoBuscado palavra digitada no campo buscar.
     * @access    private
     * @return    void
     */
    function resultadoBusca($termoBuscado = null)
    {

        $termoBuscado = urldecode($termoBuscado);
        $termoBuscado = removeAcentos($termoBuscado);

        $this->layout = '';
        $this->cssMinify[] = 'buscar';
        $this->css[] = $this->minify->getCSS('resultadoBusca_curso.min', $this->cssMinify, ENVIRONMENT);

        if ($termoBuscado) {

            if ($termoBuscado == '%27%27' || $termoBuscado == '%22%22') {
                $termoBuscado = '';
            }

            $data['videoaulas'] = $this->curso->buscaVideoAulas($termoBuscado);
            $totalVideoAulas = count($data['videoaulas']);
            $conteudo = $this->load->view('resultadoBuscaVideoAulas', $data, true);

            $obj['li.direita'] = ("<html>$conteudo</html>");

            if ($totalVideoAulas == 1)
                $obj['li.direita p.res'] = ("<html>Foi encontrado <b>$totalVideoAulas</b> disciplina, que cont?m v?deos aulas relacionadas ao termo buscado</html>");
            else
                $obj['li.direita p.res'] = ("<html>Foram encontrados <b>$totalVideoAulas</b> disciplinas, que cont?m v?deos aulas relacionadas ao termo buscado</html>");
        }

        print_r(json_encode($obj));
        die;
    }

    /**
     * Material Adicional
     *
     * Exibe os materiais adicionais para os cursos.
     *
     * @access    private
     * @return    void
     */
    function materialAdicional()
    {

        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'material-adicional';
        $this->css[] = $this->minify->getCSS('materialAdicionalv4.min', $this->cssMinify, ENVIRONMENT);

        //$fields['matriculaID'] = $this->session->userdata('matriculaid');
        //$fields['Ancora'] = $this->session->userdata('Ancora');
        $fields['AssinaturaMatriculaID'] = $this->session->userdata('assinaturaMatriculaID');
        $data['pacotesAluno'] = $this->home->verificaPacotesAluno($fields, $this->configuracoes[0]['Base']);

        $this->menu_vertical = $this->load->view('view_menu', '', true);

        $this->load->view('material-adicional', $data);

    }

    /**
     * Material Adicional
     *
     * Exibe os materiais adicionais para as disciplinas do curso.
     *
     * @access    private
     * @return    void
     */
    function materialAdicionalDisciplinas()
    {

        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'material-adicional';
        $this->css[] = $this->minify->getCSS('materialAdicionalv4.min', $this->cssMinify, ENVIRONMENT);

        $pdf = array();
        // Materiais Adicionais upx, por pacote

        $pdf = $this->curso->getPdfGrupoAluno('', $this->session->userdata('grupoAulaID'));


        // Materiais Adicionas S3, por disciplina
        $disciplinas = $this->curso->verificaDisciplinas($this->session->userdata('grupoAulaID'));

        $materiais = array();
        if ($disciplinas) {
            foreach ($disciplinas as $key => $value) {
                $materiais[$value['Descricao']] = array();
                $materiaisAdicionais = $this->curso->getMaterialGrupoAluno($this->session->userdata('grupoAulaID'), $value['DisciplinaID']);
                if ($materiaisAdicionais) {
                    $materiais[$value['Descricao']] = array_merge($materiais[$value['Descricao']], $materiaisAdicionais);
                } else {
                    unset($materiais[$value['Descricao']]);
                }
            }
        }

        $data['pdf'] = $pdf;
        $data['materiais'] = $materiais;

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $this->load->view('material-adicional-disciplinas', $data);
    }

    /**
     * Finalizar  Videoaula
     *
     * Finaliza a videoaula de acordo com os par?metros identificadores
     * @param int aulaID identificador da aula
     * @param int pessoaid identificador da pessoa
     * @access    private
     * @return    int
     */
    function finalizarVideoAula() {

        $this->layout = '';

        $dadosAluno = $this->curso->buscaDadosUsuario($this->session->userdata('pessoaid'));

        $fields['EscolaID'] = $this->session->userdata('escola');
        $fields['DisciplinaID'] = $this->session->userdata('grupoAulaID');
        $fields['FrenteID'] = $this->input->post('frenteID');
        $fields['AulaID'] = $this->input->post('aulaID');
        $fields['AssuntoID'] = $this->input->post('assuntoID');
        $fields['TurmaID'] = $this->session->userdata('TurmaID');
        $fields['UsuarioID'] = $this->session->userdata('pessoaid');

        $agendamento = $this->curso->getAgendamento($fields['EscolaID'], $fields['DisciplinaID'], $fields['FrenteID'], $fields['AssuntoID'], $fields['TurmaID']);
        if ($agendamento) {
            $fields['DtAgendaInicio'] = $agendamento['DtInicio'];
            $fields['DtAgendaFim'] = $agendamento['DtFim'];

            if ($agendamento['DtFim'] == '-' || $agendamento['DtFim'] == '--') {
                $fields['DtAgendaFim'] = null;
            }
        }

        $videoAulasAssistidas = $this->curso->buscaQuestoesAluno($fields['UsuarioID'], $fields['DisciplinaID'], $fields['AulaID'], false, false, 'N');

        if ($videoAulasAssistidas) {
            if ($videoAulasAssistidas[0]->VideoAulaAssistida != 'S') {
                $fields['DtConclusao'] = date('Y-m-d H:i:s');
            }

            $fields['DtAlt'] = date('Y-m-d H:i:s');
            $fields['VideoAulaAssistida'] = 'S';

            $where['UsuarioID'] = $fields['UsuarioID'];
            $where['AulaID'] = $fields['AulaID'];
            $where['DisciplinaID'] = $fields['DisciplinaID'];

            $result = $this->curso->gravaRespostaAluno($fields, $where);
        } else {

            $videoAulas = $this->curso->getVideoAulasPacote($fields['AssuntoID']);
            $frente = $this->curso->verificaCategoriaOrdem($fields['DisciplinaID'], $fields['FrenteID']);
            $fields['DescFrente'] = $frente[0]['Descricao'];
            $fields['Meta'] = $this->session->userdata('meta');
            $fields['DescAula'] = ($this->input->post('descAula'));
            $fields['NomeEscola'] = $dadosAluno[0]['NomeEscola'];
            $fields['NomeAluno'] = $this->session->userdata('nome');
            $fields['DescDisciplina'] = ($this->input->post('disciplinaNome'));
            $fields['DtCad'] = date('Y-m-d H:i:s');
            $fields['DtAlt'] = date('Y-m-d H:i:s');
            $fields['Tipo'] = 'N';
            $fields['DescAssunto'] = ($this->input->post('assuntoNome'));
            $fields['DescFrente'] = ($this->input->post('descFrente'));
            $fields['DescTurma'] = $dadosAluno[0]['DescricaoTurma'];
            $fields['SerieID'] = $dadosAluno[0]['Serie'];
            $fields['descSerie'] = $dadosAluno[0]['DescricaoSerie'];
            $fields['VigenciaTurma'] = $dadosAluno[0]['VigenciaTurma'];
            $fields['Resposta'] = Null;
            $fields['RespostaCorreta'] = Null;

            for ($i = 0; count($videoAulas) > $i; $i++) {
                $fields['AulaID'] = $videoAulas[$i]['AulaID'];
                $fields['VideoAulaAssistida'] = 'N';

                if ($this->input->post('aulaID') == $videoAulas[$i]['AulaID']) {
                    $fields['VideoAulaAssistida'] = 'S';
                    $fields['DtConclusao'] = date('Y-m-d H:i:s');
                }

                $result = $this->curso->gravaQuestoesAluno($fields);
            }
        }

        print_pre($result);
        die;
    }


    /**
     * Minhas Anota??es
     *
     * Exporta todas as anota??es do Curso ou de apenas uma disciplina
     *
     * @param string $Ancora determinanda qual ? a identificador da disciplina
     * @access    public
     * @return    void
     */
    function minhasAnotacoes($Ancora = null)
    {

        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'curso';
        $this->css[] = $this->minify->getCSS('curso_index.min', $this->cssMinify, ENVIRONMENT);

        $fields['AssinaturaMatriculaID'] = ($this->input->post('assinaturaMatriculaID')) ? $this->encrypt_v2->decode($this->input->post('assinaturaMatriculaID'), KEY_PLAYER) : $this->session->userdata('assinaturaMatriculaID');
        $retornoVerificaPacotesAluno = $this->home->verificaPacotesAluno($fields, $this->configuracoes[0]['Base']);

        $data = '';

        // Grupo aula vinculada a assinaturaMatricula
        $grupoAula = $this->home->verificaGrupoAulaAluno($retornoVerificaPacotesAluno[0]['GrupoAulaID']);
        $data['videosAssistidosAnotacoes'] = $this->curso->verificaVideoAssistidos_Anotacoes();

        // S?rie Grandes Concursos
        $dtLiberacao = $retornoVerificaPacotesAluno[0]['DtInicio'];
        if ($grupoAula['ClassificacaoID'] == '6' && $grupoAula['DtInicio'] != '-') {

            $timeGrupo = strtotime($grupoAula['DtInicio']);
            $timeCompra = strtotime($retornoVerificaPacotesAluno[0]['DtInicio']);

            if ($timeGrupo > $timeCompra) {
                $dtLiberacao = $grupoAula['DtInicio'];
            }
        }

        if ($grupoAula['ClassificacaoID'] != 5) {
            $data['cursoNome'] = isset($retornoVerificaPacotesAluno[0]['DescricaoPacote']) ? $retornoVerificaPacotesAluno[0]['DescricaoPacote'] : '';
            $data['grupoAulaID'] = isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) ? $retornoVerificaPacotesAluno[0]['GrupoAulaID'] : '';
            $data['ClassificacaoID'] = $grupoAula['ClassificacaoID'];

            $data['videoaulas'] = $this->curso->verificaVideoAulasDisciplina($data['grupoAulaID'], null);
        } // Assinatura completa
        else if ($grupoAula['ClassificacaoID'] == 5) {
            // grupo aula post pela assinatura completa
            $grupoAulaID = $this->input->post('grupoAulaID');

            // clicando no botao voltar curso
            if (empty($grupoAulaID) && $this->session->userdata('ClassificacaoPacotePai') == 5) {
                $grupoAulaID = $this->session->userdata('grupoAulaID');
            }

            // Grupo aula selecionada pelo aluno
            $grupoAula = $this->home->verificaGrupoAulaAluno($grupoAulaID);

            $data['cursoNome'] = $grupoAula['Descricao'];
            $data['grupoAulaID'] = $grupoAula['itemName'];
            $data['ClassificacaoID'] = $grupoAula['ClassificacaoID'];

            $data['videoaulas'] = $this->curso->verificaVideoAulasDisciplina($data['grupoAulaID'], null);
        }

        $data['DtLiberacao'] = $dtLiberacao;
        $data['QtAnotacoes'] = $this->curso->verifica_quantidadeAnotacoes($data['grupoAulaID'], $data['videosAssistidosAnotacoes']);
        $data['Disciplina'] = array();
        foreach ($data['QtAnotacoes'] as $key)
            array_push($data['Disciplina'], $key->Descricao);
        $data['Disciplina'] = array_unique($data['Disciplina']);

        // banner simulado
        $id = isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) ? $retornoVerificaPacotesAluno[0]['GrupoAulaID'] : 0;
        $banners = $this->curso->verificaBannerSimulado($id);
        if (!empty($banners)) {
            // selecionar o banner v?lido
            foreach ($banners as $banner) {
                // data de hoje sem a hora
                $hoje = mktime(0, 0, 0, date('m'), date('d'), date('Y'));

                // data final n?o ? obrigat?ria
                $dtfim = '';
                if (!empty($banner['DtFimSimulado'])) {
                    list($a2, $m2, $d2) = explode('-', $banner['DtFimSimulado']);
                    $dtfim = mktime(0, 0, 0, $m2, $d2, $a2);
                }

                if (empty($dtfim) || $dtfim > $hoje) {
                    $data['bannerSimulado'] = $banner;
                }
            }
        }

        $this->menu_vertical = $this->load->view('view_menu', '', true);

        $this->load->view('minhasAnotacoes', $data);
    }

    /**
     * Exportar Anota??es
     *
     * Verifica se o curso ou disciplina foi selecionado e exporta as anota??es
     *
     */
    function exportarAnotacoes()
    {
        $this->layout = '';
        $fields['Disciplina'] = $this->input->get('Disciplina');
        $fields['Curso'] = $this->input->get('Curso');
        $fields['GrupoAulaID'] = $this->input->get('GrupoAulaID');

        $result = $this->curso->exporta_AnotacoesVideoAula($fields);

        $filename = $this->input->get('Curso') . ".txt";
        $dados = $disciplina = $data = $aulaID = '';

        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
        foreach ($result as $lista) {
            if ($disciplina != $lista->Descricao) {
                if ($disciplina != '')
                    $dados .= "\r\n\r\n";
                $disciplina = $lista->Descricao;
                echo "[" . iconv("ISO-8859-1", "UTF-8", $lista->Descricao) . "]\r\n";
            }
            if ($aulaID != $lista->AulaID) {
                $aulaID = $lista->AulaID;
                echo "\r\n[" . $lista->AulaID . "  " . iconv("ISO-8859-1", "UTF-8", $lista->Tema) . "]\r\n";
                $data = '';
            }
            if ($data != $lista->DtAnotacao) {
                $data = $lista->DtAnotacao;
                echo "[" . $lista->DtAnotacao . "]\r\n";
            }
            echo "[" . iconv("ISO-8859-1", "UTF-8", $lista->Anotacoes) . "]\r\n";
            //flush(); // this is essential for large downloads
        }
        exit;
    }

    /**
     * Conte?do V?deo
     *
     * Realiza a atualiza??o do conte?do da p?gina html sem necessidade de refresh
     *
     * @param string $controller identificador da a??o
     * @param string $ancora identificador da disciplina
     * @access private
     * @return json
     */
    function paramsContentVideo($controller = null, $ancora = null)
    {

        $this->layout = '';

        $anotacoes = '';

        $data['AssinaturaMatriculaID'] = $this->session->userdata('assinaturaMatriculaID');
        $retornoVerificaPacotesAluno = $this->home->verificaGrupoAulaAncora($this->session->userdata('Ancora'));
        if (count($retornoVerificaPacotesAluno) == 0)
            $retornoVerificaPacotesAluno = $this->home->verificaGrupoAulaAncora(str_replace("a-ano", "-ordm-ano", $this->session->userdata('Ancora')));
        $curso = isset($retornoVerificaPacotesAluno[0]['Descricao']) ? $retornoVerificaPacotesAluno[0]['Descricao'] : '';

        if (!empty($retornoVerificaPacotesAluno)) {
            $classificacaoID = $this->session->userdata('ClassificacaoPacotePai');

            $grupoAulaID = $retornoVerificaPacotesAluno[0]['itemName'];

            $dados = $this->curso->verificaVideoAula(5);
            $nomeVideo = $dados[0]['Tema'];
            $aulaID = $dados[0]['AulaID'];
            $linkVideoaula = $dados[0]['Video'];
            $pdf = str_replace('.mp4', '.pdf', $dados[0]['Video']);

            $result = $this->curso->verificaDisciplina($dados[0]['DisciplinaID'], $grupoAulaID);
            $disciplina = $result[0]['Descricao'];

            $htmlAnotacoes = '';
            if ($anotacoes) {
                $total = count($anotacoes);

                for ($i = 0; $i < $total; $i++) {

                    $descricao = $anotacoes[$i]->Anotacoes;
                    $sequencia = $i + 1;
                    $display = 'display:none;';
                    $current = '_current';

                    if ($sequencia <= '3') {
                        $display = '';
                        $current = '';
                    }

                    $htmlAnotacoes .= '<ul  id="p' . $sequencia . '" style="' . $display . '"  class="anotacao ' . $current . '">
                                         <li class="data">' . $anotacoes[$i]->DtAnotacao . '</li>
                                         <li class="texto">' . $descricao . '</li>
                                      </ul>';
                }
            }

            $this->session->set_userdata('link_video_aula', $linkVideoaula);
            $this->session->set_userdata('aulaid', $aulaID);
            $this->session->set_userdata('tema', $nomeVideo);
        } else {
            $obj['.titulo'] = ("Nenhum videoaula encontrada para sequ?ncia!");
            print(json_encode($obj));
        }

        $videoPlayer = $data['videoPlayer'] = '<iframe class="player" width="100%" height="100%" scrolling="no" src="' . base_url() . 'api-video" mozallowfullscreen webkitallowfullscreen allowfullscreen></iframe>';


        $obj['.curso a'] = ("$curso");
        $obj['.disciplina'] = ("$disciplina");
        $obj['.titulo'] = ("$nomeVideo");
        $obj['#params'] = ("<html><input id='aulaID' value='$aulaID' type='hidden'><input id='situacaoVideo' type='hidden' value=''><input type='hidden' value='' id='VideoAulaAcaoID'><input type='hidden' name='motivoid' > <input type='hidden' name='observacao'></html>");
        $obj['.player'] = ("<html>$videoPlayer</html>");

        print(json_encode($obj));
        die;
    }

    /**
     * Conte?do Quest?o
     *
     * Realiza a atualiza??o do conte?do da p?gina html sem necessidade de refresh
     *
     * @param string $controller identificador da a??o
     * @param string $ancora identificador da disciplina
     * @access private
     * @return json
     */
    function paramsContentQuestao($controller = null, $ancora = null)
    {
        $this->layout = '';
        $perfil = (int)$this->session->userdata('perfil');
        $ancora = $this->uri->segment(3);
        $isPlataformaLiteraria = (strpos($ancora, 'plataforma-literaria') !== false);
        $dadosQuestao = [];
        $configuracoes = $this->curso->getConfiguracoesescola($this->session->userdata('escola'));
        //seta valores padrao caso a escola ainda nao tenha cadastrado as configura?oes
        $RespostaFinalAgendamentoAluno = '';
        if ($configuracoes && isset($configuracoes[0])) {
            $RespostaFinalAgendamentoAluno = isset($configuracoes[0]['RespostaFinalAgendamentoAluno']) ? $configuracoes[0]['RespostaFinalAgendamentoAluno'] : 'N';
        }

        $data['AssinaturaMatriculaID'] = $this->session->userdata('assinaturaMatriculaID');
        $retornoVerificaPacotesAluno = $this->home->verificaGrupoAulaAncora(str_replace("a-ano", "-ordm-ano", $ancora));

        if (!empty($retornoVerificaPacotesAluno)) {
            $grupoAulaID = $retornoVerificaPacotesAluno[0]['itemName'];
            $dados = $this->curso->verificaVideoAula(5);
            $aulaID = $dados[0]['AulaID'];

            //busca dados da questao
            $data['questaoAtual'] = $this->uri->segment(7) ? $this->uri->segment(7) : 0;
            $idUsuario = $this->session->userdata('pessoaid');

            //busca as questoes do aluno
            if ($perfil === Perfil::ALUNO) {
                $questoesUsuario = $this->curso->getQuestoesAluno($idUsuario, $grupoAulaID, $dados[0]['DisciplinaID'], $aulaID);
                foreach ($questoesUsuario as $item) {
                    if ($item->QuestaoID == $questoesUsuario[$data['questaoAtual']]->QuestaoID) {
                        $dataConclusao = $item->DtConclusao;
                    }
                }

            } else {
                $questoesUsuario = $isPlataformaLiteraria ?
                    $this->curso->getQuestoesPlataformaLiteraria($grupoAulaID, $aulaID) :
                    $this->curso->getQuestoesAula($grupoAulaID, $aulaID);
            }

            $questaoUsuario = (object)$questoesUsuario[$data['questaoAtual']];
            $data['qtdQuestoes'] = count($questoesUsuario);

            $date = new DateTime($dataConclusao);
            $dataOnly = date_format($date, "d/m/Y");
            $horaOnly = date_format($date, "H:i:s");

            $array = array('questao' => $questaoUsuario->QuestaoID);

            $result = $this->curso->CarregaQuestaoAPI(
              $array['questao'],
              $retornoVerificaPacotesAluno[0]['ClassificacaoID'],
              $dados[0]['DisciplinaID']
            );

            if ($result['success'] === 0) {
              header("Content-type:application/json");
              $obj['titulo'] = $result['message'];
              $obj['code'] = $result['code'];
              exit(json_encode($obj));
            }

            $ult = count($questoesUsuario) == ($data['questaoAtual'] + 1) ? 1 : 0;
            $obj['#ult'] = ('<input type="hidden" id="ultimaQuestao" value="' . $ult . '" />');

            if (isset($result['success']) && $result['success'] == 1) {
              //dados da questao
              $dadosQuestao = $result['message'];
              $questaoAtual = $this->uri->segment(7) ? ($this->uri->segment(7) + 1) : 1;
              $qtdQuestoes = count($questoesUsuario);
            }
        } else {
            $obj['.titulo'] = ("Nenhum qFuest&atilde;o encontrada para sequ&ecirc;ncia!");
            print(json_encode($obj));
            die;
        }

        //monta o html que sera utilizado
        //cabe?alho da questao
        $assunto = (isset($dadosQuestao['questao']['assunto'][0]['nome'])) ? ($dadosQuestao['questao']['assunto'][0]['nome']) : '';

        $obj['.prova'] = ("Prova: <a>" . ($dadosQuestao['questao']['prova'][0]['nome']) . " </a><br>");
        $obj['#idQuestao'] = ("Q" . ($dadosQuestao['questao']['id']));
        $obj['#jarvisItemId'] = $dadosQuestao['questao']['jarvisItemId'];
        $obj['.spanQuestoes'] = ($questaoAtual . " de " . $qtdQuestoes);

        //pergunta e alternativas
        if ($dadosQuestao['questao']['textoAssociado'] != '') {
          $obj['.texto-associado'] = (
            '<a onClick="toogleTxtAssociado();" class="btn btn-mini btn-default" style="width: 230px;"><span class="icon-align-left"></span> <em id="btnAssociado">Mostrar texto associado Ã  questão</em></a><br>
              <div class="texto-associado-content" style="display: none;">
                ' . ($dadosQuestao['questao']['textoAssociado']) . '
              </div><br/>'
          );
        } else {
          $obj['.texto-associado'] = '';
        }

        $obj['.enunciado'] = ($dadosQuestao['questao']['enunciado']);
        $altHTML = '';
        $respondida = (isset($questaoUsuario->RespostaCorreta) && $questaoUsuario->RespostaCorreta) || $this->session->userdata('perfil') != 273 ? 1 : 0;
        $respostaCorreta = (isset($questaoUsuario->RespostaCorreta) && $questaoUsuario->RespostaCorreta) ? $questaoUsuario->RespostaCorreta : '';
        $respostaAluno = (isset($questaoUsuario->Resposta) && $questaoUsuario->Resposta) ? $questaoUsuario->Resposta : '';

        for ($i = 0; count($dadosQuestao['questao']['alternativas']) > $i; $i++) {
          $altHTML .= '<li>';
          if ($respondida == 0) {
            $altHTML .= '<input id="alternativa_q' . $dadosQuestao['questao']['id'] . '_' . $dadosQuestao['questao']['alternativas'][$i]['id'] . '" class="radio-resposta" name="questao-' . $dadosQuestao['questao']['id'] . '" type="radio" data-opcao="' . $dadosQuestao['questao']['alternativas'][$i]['valorOpcao'] . '" value="' . $dadosQuestao['questao']['alternativas'][$i]['id'] . '" name="questao-' . $dadosQuestao['questao']['id'] . '" data-exibirac="sim">';
          }
          $altHTML .= '<label style="width: 100%;" for="alternativa_q' . $dadosQuestao['questao']['id'] . '_' . $dadosQuestao['questao']['alternativas'][$i]['id'] . '">';
          if ($dadosQuestao['questao']['tipoResposta']['nome'] == 'Certo/Errado') {
            $altHTML .= permissaoTags($dadosQuestao['questao']['alternativas'][$i]['opcao']);
          } else {
            if ($respostaAluno == $dadosQuestao['questao']['alternativas'][$i]['id']) {
              $hl = ' style="margin: 0px 0px 0px -5px;padding: 2px 2px 2px 3px;width:100%;" ';
              $rAluno = '<span class="anterior-response">(<b>Resposta do aluno em </b>' . $dataOnly . ' <b>as</b> ' . $horaOnly . ')</span>';
            } else {
              $hl = '';
              $rAluno = '';
            }
            $altHTML .= '<div' . $hl . '><span class="option-letter">' . $dadosQuestao['questao']['alternativas'][$i]['valorOpcao'] . '</span> ' . permissaoTags($dadosQuestao['questao']['alternativas'][$i]['opcao']) . $rAluno;
          }
          $altHTML .= '</label></li>';
        }
        $obj['#alternativas'] = $altHTML;
        $dadosQuestao['linkRefreshImg'] = '';
        $linkRefreshImg = "<div class='nomargin alert alert'>
                            Caso a imagem na questão não carregue, atualize a página clicando
                            <a href='#' title='Clique aqui para recarregar a página' onclick='window.location.reload()'>aqui/a>
                          </div>";
        
        $iconRefreshImgQuestion = strstr($dadosQuestao['questao']['enunciado'], '<img') ? true : false;
        
        for($i = 0; count($dadosQuestao['questao']['alternativas']) > $i; $i++){
          $iconRefreshImgAlternative = strstr($dadosQuestao['questao']['alternativas'][$i]['opcao'], '<img') ? true: false;
          if($iconRefreshImgAlternative) break;
        }
        
        if($iconRefreshImgQuestion) {
          $dadosQuestao['linkRefreshImg'] = $linkRefreshImg;
        }elseif($iconRefreshImgAlternative) {
          $dadosQuestao['linkRefreshImg'] = $linkRefreshImg;
        }else{
          $dadosQuestao['linkRefreshImg'] = "";
        }
        
        $obj['linkRefreshImg'] = $dadosQuestao['linkRefreshImg'];

        //hiddens da questao
        //resposta
        for ($a = 0; count($dadosQuestao['questao']['alternativas']) > $a; $a++) {
          if ($dadosQuestao['questao']['alternativas'][$a]['opcaoCorreta'] == 1) {
            $altCorreta = $dadosQuestao['questao']['alternativas'][$a]['id'];
            $opcaoCorreta = $dadosQuestao['questao']['alternativas'][$a]['valorOpcao'];
          }
        }

        $mostraResposta = 'S';
        if ((int)$this->session->userdata('perfil') === Perfil::ALUNO) {
          $agendamento = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class)->handle(
            $questoesUsuario[0]->TurmaID,
            $questoesUsuario[0]->AssuntoID,
            $questoesUsuario[0]->DisciplinaID
          );
          $dataExpiracao = \DateTime::createFromFormat('Y-m-d', $agendamento['DtFim'])->setTime(23, 59, 59);
          $mostraResposta = $this->exibirRespostaCorreta($RespostaFinalAgendamentoAluno, $dataExpiracao);
        }
        if ($this->session->userdata('perfil') != PERFIL_ALUNO) {
          $tipoQuestao = $this->curso->getTipoQuestao($aulaID);
        }

        $tipo = isset($questaoUsuario->Tipo) ? $questaoUsuario->Tipo : $tipoQuestao[0]['Tipo'];
        $quest = (($mostraResposta == 'S' && !empty($respostaAluno)) || $this->session->userdata('perfil') != PERFIL_ALUNO) ? $altCorreta . '_' . $opcaoCorreta : 0;
        $obj['#dadosQuestao'] = ('<input id="questaoID" type="hidden" value="' . $dadosQuestao['questao']['id'] . '">
                                  <input id="questaoRespondida" type="hidden" value="' . $respondida . '">
                                  <input id="jarvisItemId" type="hidden" value="' . $dadosQuestao['questao']['jarvisItemId'] . '">
                                  <input id="respostaCorreta" type="hidden" value="' . $respostaCorreta . '">
                                  <input id="RespostaFinalAgendamentoAluno" type="hidden" value="' . $mostraResposta . '">
                                  <input id="quest" type="hidden" value="' . $quest . '">
                                  <input id="tipoQuestao" type="hidden" value="' . $tipo . '">');

        $obj['#slugDisciplina'] = $dadosQuestao['questao']['disciplina'][0]['slug'];
        $obj['#aulaID'] = $aulaID;
        $obj['#disciplinaID'] = $dados[0]['DisciplinaID'];
        //print_pre($obj);die;
        header("Content-type:application/json");
        exit(json_encode($obj));
    }

    /**
     * V?deo SMIL
     *
     * Monta o XML para listagem dos videos
     *
     * @param object $nomearquivo [optional]
     * @param object $link [optional]
     * @access private
     * @return xml
     */
    function videoSmil($nomearquivo = '', $link = '') {
        $this->layout = '';
        header("Cache-Control: no-cache, must-revalidate");
        header("Expires: Mon, 29 Jul 2014 07:00:00 GMT");
        header("Content-Type: application/smil");
        header('Content-Disposition: attachment; filename="' . $link . '"');
        if (strchr(base64_decode($nomearquivo), '.mp4')) {
          $arquivo = 'mp4:videos1/aulas/' . base64_decode($nomearquivo);
        } else {
          $arquivo = 'flv:videos1/aulas/' . str_replace('.flv', '', base64_decode($nomearquivo));
        }
        // Monta o xml SMIL com a URL utilizada para o arquivo de video
        $smil = '<smil>
                  <head>
                    <meta base="rtmp://videoaulas.portalava.com.br/fb48-1/" />
                  </head>
                  <body>
                    <switch>
                      <video src="' . $arquivo . '" />
                    </switch>
                  </body>
                </smil>';
        print($smil);
    }

    /**
     * Download PDF
     *
     * Realiza o download do arquivo pdf
     *
     * @param object $arquivo descricao do arquivo criptografado em base64_encode
     * @param object $nome titulo do arquivo
     * @access public
     * @return void
     */
    public function downloadPDF($arquivo, $nome)
    {

        $this->layout = '';

        $arquivo = PATH_PDF . base64_decode($arquivo);
        header("Content-Disposition: attachment; filename=" . base64_decode($nome) . ".pdf");
        header("Content-Type: application/octet-stream");
        readfile($arquivo);
        die;
    }

    function questoesEsimulados()
    {
        if ($this->session->userdata('logado') == TRUE) {
            $this->cssMinify[] = 'questoes-e-simulados';
            $this->css[] = $this->minify->getCSS('questoesEsimulados_v1.min', $this->cssMinify, ENVIRONMENT);

            $this->menu_vertical = $this->load->view('view_menu', '', true);

            $this->load->view('questoes-e-simulados');
        } else {

            echo
                '<script>
                window.location.href=\'' . base_url() . '\';
            </script>';
            die;
        }
    }

    function responderQuestao() {
        try {
            $session = $this->session->userdata();
            $usuarioId = $session['id'];
            $login = $session['login'];
            $nomeEscola = $session['nomeEscola'];

            
            $Turma = (array) $this->session->userdata('teams')[0]; 
            $turmaId = $Turma['id'];

            $graylog = [
                'uuid' => Ramsey\Uuid\Uuid::uuid4()->toString(),
                "login" => $login,
                "usuarioId" => $usuarioId,
                "nomeEscola" => $nomeEscola,
                "turmaId" => $turmaId,
                "moduloId" => false,
                "questaoId" => false,
                "jarvisItemId" => false,
                "disciplinaId" => false,
                "aulaId" => false,
                "respostaId" => false,
                "DtConclusao" => false,
                "gabarito" => false,
                'finish' => false,
                'exception_message' => false,
                'jarvisResponse' => false
            ];
            $this->load->model('curso_model', 'curso');
            $assuntoID = $this->input->post('disciplinaId');
            $questaoID = $this->input->post('questaoId', true);
            $jarvisItemId = $this->input->post('jarvisItemId', true);
            $disciplinaId = $this->input->post('grupoaulaID', true);

            $graylog['moduloId'] = $assuntoID;
            $graylog['questaoId'] = $questaoID;
            $graylog['jarvisItemId'] = $jarvisItemId;

            $agendamento = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class)->handle(
                $turmaId, $assuntoID, $disciplinaId, $usuarioId
            );

            //caso o tipo de agendamento não seja plataforma literária
            if( $agendamento['tipo_agendamento'] != "3")
                $questaoID = isset($jarvisItemId) && !empty($jarvisItemId) ? (int)$jarvisItemId : (int)$questaoID;
            
            if (empty($agendamento) || is_null($agendamento)) {
                throw new NotFoundException('Você não possui agendamento para esta atividade!', 404);
            }

            $disciplina = SaeDigital::make(PegaDisciplinaPeloId::class)->handle($agendamento['DisciplinaID']);
            $questao = $this->curso->CarregaQuestaoAPI($questaoID, $disciplina['ClassificacaoID'], $assuntoID);
            $graylog['jarvisResponse'] = $questao;
            if ($questao['success'] === 0) {
                throw new NotFoundException($questao['message'], 404);
            }

            $graylog['disciplinaId'] = $agendamento['DisciplinaID'];
            $graylog['aulaId'] = $this->input->post('aulaId', true);

            $where['AulaID'] = $this->input->post('aulaId', true);
            $where['AssuntoID'] = $agendamento['AssuntoID'];
            $where['DisciplinaID'] = $agendamento['DisciplinaID'];
            $where['Situacao'] = Situacao::ATIVO;
            $where['UsuarioID'] = $this->session->userdata('pessoaid', true);
            $where['QuestaoID'] = $questaoID;
            $gabarito = $this->curso->verificaRespondida($where);

            if (!is_null($gabarito->Resposta) && !is_null($gabarito->DtConclusao)) {
                $dtConclusao = DateTime::createFromFormat('Y-m-d H:i:s', $gabarito->DtConclusao);
                $message = 'Questão já respondida em: ' . $dtConclusao->format('d/m/Y H:i:s');
                throw new DuplicatedEntryException($message, 422);
            }

            $dados['Resposta'] = $this->input->post('resposta', true);
            $dados['DtAlt'] = date('Y-m-d H:i:s');
            $dados['DtConclusao'] = date('Y-m-d H:i:s');

            $graylog['respostaId'] = $this->input->post('resposta', true);
            $graylog['DtConclusao'] = $where['DtConclusao'];

            $respostaCorreta = array_filter($questao['message']['questao']['alternativas'],
                function ($resposta) {
                    return (strval($resposta['opcaoCorreta']) === '1');
                }
            );
            $respostaCorreta = array_pop($respostaCorreta);


            $configuracao = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle(
                $this->session->userdata('escola')
            );

            $configuracaoSerie = SaeDigital::make(BuscarConfiguracaoEscolaPorSerie::class)->handle(
                $this->session->userdata('escola'), $this->session->userdata('Serie')
            );

            $result['letra_correta'] = null;
            if (!is_null($agendamento['DtFim'])) {
                $dataExpiracao = \DateTime::createFromFormat('Y-m-d', $agendamento['DtFim'])->setTime(23, 59, 59);
                if ($this->exibirRespostaCorreta($configuracao['RespostaFinalAgendamentoAluno'], $dataExpiracao) == 'S') {
                    $result['letra_correta'] = $respostaCorreta["valorOpcao"];
                }
            }

            $result['exibirMsgRespostaFinalAgendamento'] = true;
            if ($configuracao['RespostaFinalAgendamentoAluno'] == 0) {
                $result['exibirMsgRespostaFinalAgendamento'] = false;
            }

            $dados['Gabarito'] = $respostaCorreta["id"];
            $graylog['gabarito'] = $dados['Gabarito'];

            if ($dados['Resposta'] == $respostaCorreta["id"]) {
                $dados['RespostaCorreta'] = 'S';
                $message = 'Parabéns, você acertou... Aguarde um instante!';
                $result['acertou'] = TRUE;
                $resp = 'Acertou';
            } else {
                $dados['RespostaCorreta'] = 'N';
                $result['acertou'] = FALSE;
                $message = 'Você errou!';
                $resp = 'Errou';
            }

            $acao = "Respondeu a questão Q" . $where['QuestaoID'] . " (" . $resp . ")";

            $log['loginid'] = $this->session->userdata['pessoaid'];
            $log['login'] = $this->session->userdata['login'];
            $log['acao'] = ($acao);
            $log['nomeescola'] = ($this->session->userdata['nomeEscola']);
            $log['escola'] = ($this->session->userdata['escola']);

            $log['disciplina'] = $where['DisciplinaID'];
            $log['assunto'] = $where['AssuntoID'];
            $log['aula'] = $where['AulaID'];

            $log['codigo'] = '3'; //Responder quest?o

            $this->load->model('Log_model', 'logacesso');

            $this->logacesso->GravaLog($log);

            /**
             * @var $update PDOStatement
             */
            $update = SaeDigital::make(GravarRespostasAluno::class)->handle($dados, $where, $questaoID);
            $result['rows_affected'] = $update->rowCount();

            $graylog['rows_affected'] = $result['rows_affected'];

            $result['retorno'] = true;
            if ($result['rows_affected'] === 0) {
                /**
                 * Valida se houve update da resposta do aluno e retorna mensagem para o usuário caso nenhuma alteração
                 * tenha acontecido, informando o mesmo para abrir chamado.
                 *
                 * Retorna erro ao aluno.
                 */
                throw new StudentAnswerUpdateException();
            } else if ($result['rows_affected'] > 1) {
                /**
                 * Caso houver atualizar mais de uma questão no banco de dados Ã© evidência de que existe problema na
                 * estrutura criada para o aluno.
                 *
                 * Envia as informaçÃµes para o Sentry.
                 */
                SaeDigital::make(Sentry::class)->captureException(
                    new TooManyQuestionFoundException('Too many question found for a single student answer.'),
                    array_merge($graylog, $log)
                );
            }

            $result['escola'] = $log['escola'];

            $result['atingiuMeta'] = false;
            $desempenho = SaeDigital::make(CalcularDesempenhoAlunoPorAssunto::class)->handle(
                $where['UsuarioID'], $where['AssuntoID']
            );

            if ((int)$desempenho >= (int)$configuracaoSerie['Meta']) {
                $result['atingiuMeta'] = true;
            }
            // tentar usar meta e desempenho pro feedback de acertos do aluno
            $result['desempenho'] = $desempenho;
            $result['meta'] = $configuracaoSerie['Meta'];


            $Escola = (array) $this->session->userdata('school'); 
            $escolaId = $Escola['id'];

			$this->curso->AtualizaMetaVideo($dados['UsuarioID'], $escolaId, $dados['AssuntoID']);
			
			$stats = SaeDigital::make(BuscaEstatisticasQuestao::class)->handle( $where['UsuarioID'], $where['AssuntoID'], $where['QuestaoID'] );
            if ( $stats['questao']==1 ){
				$result['acertos'] 					= intval( $stats['acertosQuestoes'] );
				$result['erros'] 					= intval( $stats['errosQuestoes'] );
				$result['quantidade_questoes']		= intval( $stats['quantidade_questoes'] );
				$result['tipo'] 					= $stats['quiz'] ? "Quiz" : "Questão";
				$result['revisao']					= false;
			} else {
				$result['acertos'] 					= intval( $stats['acertosRevisoes'] );
				$result['erros'] 					= intval( $stats['errosRevisoes'] );
				$result['quantidade_questoes']		= intval( $stats['quantidade_revisoes'] );
				$result['tipo'] 					= $stats['quiz'] ? "Quiz" : "Revisão";
				$result['revisao']					= true;
			}

			$result['message'] = $message;

            $graylog['finish'] = true;

            return $this->responseJson([$result], 200);
        } catch (NotFoundException $e) {
            $graylog['exception_message'] = $e->getMessage();
            return $this->responseJson([
                'message' => $e->getMessage()
            ], 404);
        } catch (DuplicatedEntryException $e) {
            $graylog['exception_message'] = $e->getMessage();
            return $this->responseJson([
                'message' => $e->getMessage()
            ], 422);
        } catch (StudentAnswerUpdateException $e) {
            $graylog['exception_message'] = $e->getMessage();

            log_error($e->getMessage());

            SaeDigital::make(Sentry::class)->captureException($e, array_merge($graylog, $log));

            return $this->responseJson(['message' => 'Não foi possível computar sua resposta, entre em contato com o suporte.'], 404);
        } catch (Exception $e) {
            $graylog['exception_message'] = $e->getMessage();
            return $this->responseJson(['message' => 'Não foi possível computar sua resposta, <a href="'.$_SERVER['HTTP_REFERER'].'">Clique Aqui</a> para recarregar a página e tentar novamente.'], 400);
        } finally {
            $message = new \Gelf\Message();
            $message
                ->setShortMessage('DEBUG: Responder Questão')
                ->setLevel(\Psr\Log\LogLevel::DEBUG)
                ->setFullMessage(json_encode($graylog));

            $publisher = SaeDigital::make('Graylog');
            $publisher->publish($message);
        }
    }

    public function carregarModalAgendamento() {
        $acao = $this->input->post('acao');
        $assunto = $this->input->post('assunto');
        $frente = $this->input->post('frente');
        $escola = $this->session->userdata('escola');
        $disciplina = $this->input->post('disciplinaId');
        $turma = $this->input->post('turmaId');
        $perfil = $this->session->userdata('perfil');

        $descAssunto = $this->curso->DadosAssunto($assunto)[0]["Descricao"];
        $descTurma = $this->curso->DadosTurma($turma)[0]["Descricao"];

        if ($acao == 'modal') {
            // Busca as datas agendadas
            $dados = $this->curso->getAgendamento($escola, $disciplina, $frente, $assunto, $turma);
            $configuracoes = $this->curso->getConfiguracoesescola($escola, 'G');

            $inicio = '';
            $fim = '';
            $edit = 0;

            $professor = $this->session->userdata["nome"];
            $disciplina = SaeDigital::make(PegaDisciplinaPeloId::class)->handle($disciplina)['Descricao'];
            $assunto = $descAssunto;
            $turma = $descTurma;

            if (count($dados) > 0) {
                if ($dados[0]['DtInicio'] != '' && $dados[0]['DtInicio'] != '-') {
                    $dtTempIni = explode('-', $dados[0]['DtInicio']);
                    //valida?ao para formato de datas (YYYY-MM-DD ou DD-MM-YYYY)
                    if (strlen($dtTempIni[0]) == 4) {
                        $inicio = $dtTempIni[2] . '-' . $dtTempIni[1] . '-' . $dtTempIni[0];
                    } else {
                        $inicio = $dtTempIni[0] . '-' . $dtTempIni[1] . '-' . $dtTempIni[2];
                    }
                }

                if ($dados[0]['DtFim'] != '' && $dados[0]['DtFim'] != '-') {
                    $dtTempFim = explode('-', $dados[0]['DtFim']);
                    $fim = $dtTempFim[2] . '-' . $dtTempFim[1] . '-' . $dtTempFim[0];
                }

                $edit = $dados[0]['itemName'];
            }
            $html = "<div><div>";
            if ($inicio == '') {
              $html .= "<div  style='font-size: 12pt;'> Olá $professor!</div>
                      <div style='font-size: 12pt;'>Você está prestes a agendar uma atividade de $disciplina - $assunto para a turma $turma.
                      Se confirmar, os alunos e responsáveis receberão notificações de agendamento.
                      Deseja realmente continuar?</div><hr>";
              $html .= "<label>Data &iacute;nicio:</label> <input type='text' class='agendaDatePicker' id='dtinicio' onkeyup='limpaCampo()' value='" . $inicio . "' style='width:150px;' data-date-format='dd-mm-yyyy'>";
            } else {
              $html .= " <div style='font-size: 12pt;'> Olá $professor!</div>,
                        <div style='font-size: 12pt;'>Você está prestes a remover o agendamento de uma atividade $disciplina - $assunto para a turma $turma.
                        Se confirmar, os alunos não poderão efetuar essa atividade.
                        Deseja realmente continuar ?</div><hr>";
              $html .= "<label>Data &iacute;nicio:</label> <input type='text' value='" . $inicio . "' style='width:150px;' data-date-format='dd-mm-yyyy' disabled>
                        <input type='hidden' id='dtinicio' value='" . $inicio . "'>";
            }
            $html .= " </div>
                        <br/>
                        <div>";

            if ($fim == '' && (($perfil == PERFIL_COORDENADOR && $configuracoes[0]['AgendaCoordenador'] == 'S') || ($perfil == PERFIL_PROFESSOR && $configuracoes[0]['AgendaProfessor'] == 'S'))) {
                $html .= " <label>Data fim:</label> <input type='text' class='agendaDatePicker' id='dtfim' onkeyup='limpaCampoDtFim()' value='" . $fim . "' style='width:150px;' data-date-format='dd-mm-yyyy'>";
            } else {
                $html .= " <label>Data fim:</label> <input type='text' class='agendaDatePicker' id='dtfim' value='" . $fim . "' style='width:150px;' data-date-format='dd-mm-yyyy' disabled>
                            <input type='hidden' id='dtinicio' value='" . $fim . "'>";
            }
            if ($inicio != '' || $fim != '') {
              $html .= "<div class='remove-agendamento' style='margin-top: 20px; font-size: 10pt;'><a href='javascript:void(0)' class='btn btn-primary btn-lg' role='button' onclick='removerAgendamentos()'><span class='glyphicon glyphicon-remove' style='color: white;'></span> Remover agendamento</a></div>";
            }
            $html .= "</div>
                      </div>
                      <br><img id='load_agendamento' style='display:none;' src='" . base_url() . "public/imagens/loading.gif' border='0' align='Absmiddle' />
                      <div id='mensagem' style='margin-top:15px;'></div>
                      <input type='hidden' id='edit' value='" . $edit . "'>
                      <script>
                          var nowTemp = new Date();
                          var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);
                          $('.agendaDatePicker').datepicker({
                              onRender: function(date) {
                                  return date.valueOf() < now.valueOf() ? 'disabled' : '';
                              }
                          });
                      </script>";

            exit($html);

        }
    }

    public function salvaAgendamento()
    {
        try {
            $this->allowProfile([Perfil::COORDENADOR, Perfil::PROFESSOR]);

            // $jsonData = $this->getJsonRequestData();

            $this->layout = null;
            //Declaração das variáveis recebidas pelo POST
            $acao = $this->input->post('acao') ?: $jsonData['acao'];
            $assunto = $this->input->post('assunto')  ?: $jsonData['assunto'];
            $frente = $this->input->post('frente')  ?: $jsonData['frente'];
            $escola = $this->session->userdata('escola')  ?: $jsonData['escola'];
            $turma = $this->input->post('turmaId')  ?: $jsonData['turmaId'];
            $disciplina = $this->input->post('disciplinaId')  ?: $jsonData['disciplina'];
            $dataInicio = $this->input->post('dtinicio', true)  ?: $jsonData['dtinicio'];
            $dataFim = $this->input->post('dtfim', true)  ?: $jsonData['dtfim'];
            $perfil = $this->session->userdata('perfil');
            //fim

            //Validação de campos obrigatórios
            if (empty($assunto) || empty($dataFim) || empty($frente) || empty($escola) || empty($disciplina) || empty($turma)) {
              return $this->responseJson([
                'success'=> false,
                'message'=>"Faltando informações obrigatórias"
              ]);
            }

            /** @var AssuntosPorDisciplinaAssunto $assuntoService */
            $assuntoService = SaeDigital::make(AssuntosPorDisciplinaAssunto::class);
            $assuntoData = $assuntoService->handle($disciplina, $assunto);

            if ($acao == 'gravar') {
                switch ((int)$assuntoData[0]['ClassificacaoID']){
                    case ClassificacaoConteudo::PLATAFORMA_LITERARIA:
                        $tipo_agendamento = TipoAgendamento::PLATAFORMA_LITERARIA;
                        break;
                    default:
                        $tipo_agendamento = null;
                }

                $hoje = date("Y-m-d");
                $fields['DisciplinaID'] = $disciplina;
                $fields['AssuntoID'] = $assunto;
                $fields['FrenteID'] = $frente;
                $fields['EscolaID'] = $escola;
                $fields['TurmaID'] = $turma;
                $fields['DtFim'] = date('Y-m-d', strtotime($dataFim));
                $fields['DtInicio'] = date('Y-m-d', strtotime($dataInicio));
                $fields['UsuarioAlt'] = $this->session->userdata('pessoaid');
                $fields['DtAlt'] = date('Y-m-d H:i:s');
                $fields['UsuarioCad'] = $this->session->userdata('pessoaid');
                $fields['DtCad'] = date('Y-m-d H:i:s');
                $fields['tipo_agendamento'] = $tipo_agendamento;
                if ($perfil == PERFIL_COORDENADOR || $perfil == PERFIL_PROFESSOR) {
                    $fields['NotificacaoResponsavel'] = $this->session->userdata('notificacaoresponsavel');
                }

                if ($fields['DtInicio'] < $hoje OR $fields['DtFim'] < $hoje) {
                    return $this->responseJson([
                        'success' => false,
                        'message' => 'Datas inválidas'
                    ], 400);
                }
                // Atualiza tabela de logs sms e emails para reenvio - FV 31/08/2015
                $this->curso->atualizaEnviosEmailsSms($fields);

                try {
                    //Cadastra o agendamento na D024
                    $id = md5(uniqid(rand(), true));
                    $this->curso->removeAgendamentos('D024_Ava_Sae_Agenda', $fields['EscolaID'], $fields['AssuntoID'], $fields['FrenteID'], $fields['DisciplinaID'], $fields["TurmaID"], true);
                    $result = $this->curso->gravaDados('D024_Ava_Sae_Agenda', $id, $fields, FALSE);

                    //aqui colocar o log
                    $dadosAssunto = $this->curso->DadosAssunto($fields['AssuntoID']);
                    $dadosTurma = $this->curso->DadosTurma($turma);

                    $datei = date_create($fields['DtInicio']);
                    $date_inicio = date_format($datei, "d/m/Y");
                    $datef = date_create($fields['DtFim']);
                    $date_fim = date_format($datef, "d/m/Y");

                    $acao = "Realizado agendamento da atividade " . $dadosAssunto[0]['Descricao'] . " (" . $date_inicio . " atÃ© " . $date_fim . "), para a turma " . $dadosTurma[0]['Descricao'] . " (" . $turma . ")";

                    $log['loginid'] = $this->session->userdata['pessoaid'];
                    $log['login'] = $this->session->userdata['login'];
                    $log['acao'] = ($acao);
                    $log['nomeescola'] = ($this->session->userdata['nomeEscola']);
                    $log['escola'] = ($this->session->userdata['escola']);
                    $log['disciplina'] = $fields['DisciplinaID'];
                    $log['assunto'] = $fields['AssuntoID'];

                    $log['codigo'] = '6'; // Agendou atividade

                    $this->load->model('Log_model', 'logacesso');

                    $this->logacesso->GravaLog($log);

                } catch (Exception $exception) {
                    return $this->responseJson([
                        'success' => true,
                        'message' => 'Já existe um agendamento para este assunto. Remova o agendamento atual primeiro.'
                    ], 400);
                }

                //Fixme: altera todos os registros da tabela avasae.R001_RespostasQuestoes com a nova data inicio e data fim
                if ($dataInicio == '-')
                    $dataInicio = null;

                if ($dataFim == '-')
                    $dataFim = null;

                $update['DtAgendaInicio'] = $dataInicio;
                $update['DtAgendaFim'] = $dataFim;

                $where['DisciplinaID'] = $disciplina;
                $where['AssuntoID'] = $assunto;
                $where['FrenteID'] = $frente;
                $where['EscolaID'] = $escola;
                $where['TurmaID'] = $turma;

                $this->curso->gravaRespostaAluno($update, $where);

                return $this->responseJson([
                    'success' => true,
                    'message' => 'Agendamento realizado com sucesso'
                ]);
            }
        } catch (NotAllowedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => 'Você não tem permissão para realizar agendamentos.'
            ]);
        }
    }

    function removeAgendamentos()
    {
        $this->layout = '';
        $itemName = $this->input->post('itemName');
        $dados = $this->curso->getDadosAgendamento($itemName);
        $update['DtAgendaInicio'] = null;
        $update['DtAgendaFim'] = null;

        $where['DisciplinaID'] = $dados[0]['DisciplinaID'];
        $where['AssuntoID'] = $dados[0]['AssuntoID'];
        $where['FrenteID'] = $dados[0]['FrenteID'];
        $where['EscolaID'] = $dados[0]['EscolaID'];
        $where['TurmaID'] = $dados[0]['TurmaID'];
        $this->curso->gravaRespostaAluno($update, $where);
        if (count($dados) > 0) {
            $result = $this->curso->removeAgendamentos('D024_Ava_Sae_Agenda', $dados[0]['EscolaID'],
                $dados[0]['AssuntoID'], $dados[0]['FrenteID'], $dados[0]['DisciplinaID'], $dados[0]['TurmaID'], false);
            exit($result);
        }

    }

    public function removerAgendamento()
    {
        try {
            $this->layout = '';
            $idAgenda = $this->input->post('idAgenda');
            $idAluno = $this->input->post('idAluno');

            if (!isset($idAgenda) || !isset($idAluno)) {
                throw new \InvalidArgumentException('Requisição inválida, parâmetros faltando.');
            }

            $agenda = $this->curso->buscarAgendamento($idAgenda, $idAluno);
            $deleted = $this->curso->removerAgendamento($idAgenda, $idAluno);

            echo json_encode(
                [
                    'status' => $deleted ? 'success' : 'error',
                    'message' => $deleted ? 'Agendamento removido' : 'Agendamento não pode ser removido',
                    'agenda' => [
                        'assunto' => $agenda[0]['AssuntoID'],
                        'frente' => $agenda[0]['FrenteID']
                    ]
                ]
            );
        } catch (\InvalidArgumentException $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        } catch (\Exception $e) {
            echo json_encode(['status' => 'error', 'message' => 'Ocorreu um problema durante o processamento.']);
        }
    }

    function carregavideo()
    {
        $this->layout = '';

        $param_playerapi['escolaid'] = $this->session->userdata('escola');
        $param_playerapi['nomealuno'] = ($this->session->userdata('nome'));
        $param_playerapi['pessoaid'] = $this->session->userdata('pessoaid');
        $param_playerapi['grupoaulaid'] = $this->session->userdata('grupoAulaID');
        $param_playerapi['descricaogrupoaula'] = ($this->session->userdata('cursonome'));
        $param_playerapi['aulaid'] = $this->session->userdata('aulaid');
        $param_playerapi['descricaoaula'] = ($this->session->userdata('tema'));
        $param_playerapi['disciplinaid'] = $this->session->userdata('disciplinaid');
        $param_playerapi['descricaodisciplina'] = ($this->session->userdata('disciplinanome'));
        $param_playerapi['frenteid'] = $this->session->userdata('frenteid');
        $param_playerapi['descricaofrente'] = ($this->session->userdata('frentenome'));
        $param_playerapi['turmaid'] = $this->session->userdata('TurmaID');
        $param_playerapi['video'] = $this->session->userdata('link_video_aula');
        $param_playerapi['modulo'] = 'pseudo-events';

        $param_playerapi['chave-flowplayer'] = KEY_LOGO_PLAYER_FLASH;
        if ($this->agent->is_mobile() || ($this->agent->browser() == 'Firefox' && $this->agent->version() >= 11) || ($this->agent->browser() == 'Chrome' && $this->agent->version() >= 25) || ($this->agent->browser() == 'Safari' && $this->agent->version() >= 6)) { // true
            $param_playerapi['chave-flowplayer'] = KEY_LOGO_PLAYER_HTML5;
        }

        print(player($param_playerapi));
    }


    public function carregarModalAgendamentoAlunos()
    {
        $this->layout = '';

        $acao = $this->input->post('acao');
        $assunto = $this->input->post('assunto');
        $frente = $this->input->post('frente');
        $escola = $this->session->userdata('escola');
        $turma = $this->input->post('turmaId');
        $disciplina = $this->input->post('disciplinaId');

        $html = '';
        $edit = '';

        $alunos = $this->curso->getAlunosTurma($escola, $turma, $disciplina);
        $configuracoes = $this->curso->getConfiguracoesescola($escola, 'G');
        $data['configuracoes'] = $configuracoes[0];
        $data['assunto'] = $assunto;
        $data['frente'] = $frente;
        $data['disciplina'] = $disciplina;
        $data['turma'] = $turma;

        /**
             * Start calendar events
             *
             * 1 - Get data from D024_Ava_Sae_agenda.
             * 2 - Make objects from return data.
             * 3 - Serialize to json to parse in JS.
             */
        $data["events"] = [];

        $agendamentos = SaeDigital::make(BuscarCalendarioPorTurma::class)->handle($dadosUsuario[0]['Turma']);

        $events = new StudentCalendarCollection();

        array_walk($agendamentos, function ($agendamento) use ($events) {
            $startDate = new DateTime($agendamento['DtInicio']);
            $endDate = new DateTime($agendamento['DtFim']);

            $events->push(new StudentCalendarEvent(
                $this->parseDisciplineService->handle($agendamento['DisciplinaDescricao']),
                true,
                $startDate,
                $startDate,
                $agendamento['AgendaID'],
                [
                    'StartDate' => $startDate->format('d/m/Y'),
                    'EndDate' => $endDate->format('d/m/Y')
                ]
            ));
        });

        $data['events'] = $events->toJson();

        // Busca as datas agendadas
        $dados = $this->curso->getAgendamento($escola, $disciplina, $frente, $assunto, $turma);

        if ($alunos) {
            foreach ($alunos as $i => $aluno) {
                $alunos[$i]['Nome'] = trim($aluno['Nome']);
                $alunos[$i]['EditaInicio'] = 'S';
                $alunos[$i]['EditaFim'] = 'S';
                $alunos[$i]['DtInicio'] = '';
                $alunos[$i]['DtFim'] = '';
                $alunos[$i]['Agendamento'] = '';

                if (!$dados)
                    continue;

                // verifica agendamento existente
                foreach ($dados as $agenda) {
                    if (isset($agenda['AlunoID']) && $agenda['AlunoID'] == $aluno['id']) {
                        $inicio = '';
                        $fim = '';
                        $atual = mktime(0, 0, 0, date('m'), date('d'), date('Y'));

                        if (isset($agenda['DtInicio']) && $agenda['DtInicio'] != '' && $agenda['DtInicio'] != '-') {
                            list($ano, $mes, $dia) = explode('-', $agenda['DtInicio']);
                            $inicio = "$dia-$mes-$ano";

                            $time = mktime(0, 0, 0, $mes, $dia, $ano);
                            if ($atual > $time)
                                $alunos[$i]['EditaInicio'] = 'N';
                        }

                        if (isset($agenda['DtFim']) && $agenda['DtFim'] != '' && $agenda['DtFim'] != '-') {
                            list($ano, $mes, $dia) = explode('-', $agenda['DtFim']);
                            $fim = "$dia-$mes-$ano";

                            $time = mktime(0, 0, 0, $mes, $dia, $ano);
                            if ($atual > $time)
                                $alunos[$i]['EditaFim'] = 'N';
                        }

                        $alunos[$i]['DtInicio'] = $inicio;
                        $alunos[$i]['DtFim'] = $fim;
                        $alunos[$i]['Agendamento'] = $agenda['itemName'];
                        $alunos[$i]['DtCad'] = $agenda['DtCad'];
                    }
                }
            }
        }

        $data['alunos'] = $alunos;
        $data['perfil'] = $this->session->userdata('perfil');
        $this->load->view('agendamento_aluno', $data);
    }


    function salvaAgendamentoAlunos()
    {
        $this->layout = '';
        $resultado['invalidos'] = [];
        $resultado['validos'] = 0;
        $resultado['agendamentos'] = [];

        $acao = $this->input->post('acao');
        $assunto = $this->input->post('assunto');
        $frente = $this->input->post('frente');
        $escola = $this->session->userdata('escola');
        $turma = $this->input->post('turma');
        $disciplina = $this->input->post('disciplina');

        if ($acao == 'gravar') { // gravar
            $aluno = $this->input->post('aluno');
            $resultado["total"] = count($aluno);
            $agenda = $this->input->post('agenda');
            $dataInicio = $this->input->post('dtinicio');
            $dataFim = $this->input->post('dtfim');
            $fields['DisciplinaID'] = $disciplina;
            $fields['AssuntoID'] = $assunto;
            $fields['FrenteID'] = $frente;
            $fields['EscolaID'] = $escola;
            $fields['TurmaID'] = $turma;

            $update['DtAgendaInicio'] = '';
            $update['DtAgendaFim'] = '';
            foreach ($aluno as $i => $id) {
                $date = \DateTime::createFromFormat('d-m-Y', $dataInicio[$i]);
                if (!$date instanceof \DateTime) {
                    $resultado["total"]--;
                    continue;
                }

                unset($fields['DtInicio']);
                unset($fields['DtFim']);

                unset($update['DtAgendaInicio']);
                unset($update['DtAgendaFim']);

                $fields['AlunoID'] = $id;

                if (isset($dataInicio[$i]) && $dataInicio[$i] != '') {
                  list($dia, $mes, $ano) = explode('-', $dataInicio[$i]);
                  $fields['DtInicio'] = "$ano-$mes-$dia";
                  $update['DtAgendaInicio'] = "$ano-$mes-$dia";
                }

                if (isset($dataFim[$i]) && $dataFim[$i] != '') {
                  list($dia, $mes, $ano) = explode('-', $dataFim[$i]);
                  $fields['DtFim'] = "$ano-$mes-$dia";
                  $update['DtAgendaFim'] = "$ano-$mes-$dia";
                }

                $dtInicio = date("Y-m-d", strtotime($fields['DtInicio']));
                $hoje = date("Y-m-d");

                $aluno = $this->cadastro->getDados(null, $id)[0];

                $agendamentoAluno = SaeDigital::make(BuscarAgendamentoReforco::class)->handle(
                  $aluno['id'],
                  (int)$assunto
                );

                if ($dtInicio < $hoje && count($agendamentoAluno) === 0) {
                  array_push($resultado["invalidos"],
                    array(
                      "nome" => $aluno["Nome"],
                      "causa" => "A data inicial não pode ser menor do que hoje.",
                      "data" => date("d-m-Y", strtotime($dtInicio))
                    )
                  );
                  continue;
                }

                // edi??o
                if ($agenda[$i] != '') {
                  $itNameAgenda = $agenda[$i];
                  $existe = true;
                } else { // novo agendamento
                  $itNameAgenda = md5(uniqid(rand(), true));
                  $fields['UsuarioCad'] = $this->session->userdata('pessoaid');
                  $fields['DtCad'] = date('Y-m-d H:i:s');
                  $existe = false;
                }

                if (isset($fields['DtFim']) || isset($fields['DtInicio'])) {
                    $fields['UsuarioAlt'] = $this->session->userdata('pessoaid');
                    $fields['DtAlt'] = date('Y-m-d H:i:s');
                    $resultado["validos"] += 1;
                    if ($this->session->userdata('redirecionar') == 'professor' || $this->session->userdata('redirecionar') == 'coordenador') {
                        $fields['NotificacaoResponsavel'] = $this->session->userdata('notificacaoresponsavel');
                    }

                    $result = $this->curso->gravaDados('D024_Ava_Sae_Agenda', $itNameAgenda, $fields, $existe);

                    //altera todos os registros da tabela avasae.R001_RespostasQuestoes com a nova data inicio e data fim
                    $where['DisciplinaID'] = $disciplina;
                    $where['AssuntoID'] = $assunto;
                    $where['FrenteID'] = $frente;
                    $where['EscolaID'] = $escola;
                    $where['TurmaID'] = $turma;
                    $where['UsuarioID'] = $fields['AlunoID'];

                    $this->curso->gravaRespostaAluno($update, $where);

                    // Atualiza tabela de logs sms e emails para reenvio - FV 31/08/2015
                    $this->curso->atualizaEnviosEmailsSms($where);
                }
                $resultado['agendamentos'][] = ['aluno' => $aluno["Nome"], 'data' => $date->format('d-m-Y')];
            }
            header("Content-type:application/json");
            $resultado["status"] = TRUE;
            exit(json_encode($resultado));
        }
    }


    /*
     * Validar se atualiza o video baseado na informacao anterior do video
     */
    function validarAtualizaVideo($usuarioID, $aulaID, $grupoAulaID, $videoPercentual, $assuntoID, $disciplinaID) {
        try {
        $turma = (array) $this->session->userdata('teams')[0];
        $turmaId = $turma['id'];
        $agendamento = SaeDigital::make(BuscarAgendamentoPorTurmaAssunto::class)->handle(
            $turmaId,
            $assuntoID,
            $disciplinaID,
            $usuarioID
          );

          /** @var \DateTime $agendaFim */
          $agendaFim = \DateTime::createFromFormat('Y-m-d', $agendamento['DtFim']);

          if (!$agendaFim instanceof DateTime) {
            $agendaFim = new \DateTime();
            $agendaFim->sub(new DateInterval('P1D'));
          }
          $agendaFim->setTime(0, 0, 0);

          /** @var \DateTime $dataAtual */
          $dataAtual = new \DateTime();
          $dataAtual->setTime(0, 0, 0);

          $prazoExpirado = ($dataAtual > $agendaFim);
          if ($prazoExpirado) {
            return false;
          }

          $videoAulaInfo = $this->curso->getVideoAula($usuarioID, $aulaID, $grupoAulaID);

          if (isset($videoAulaInfo)) {
            if ($videoAulaInfo->PercentualVideo) {
              $videoAulaInfo->PercentualVideo = ($videoAulaInfo->year === (new DateTime)->format("Y")) ? $videoAulaInfo->PercentualVideo : 0;
              if (($videoPercentual < $videoAulaInfo->PercentualVideo)) {
                return false;
              }
            }
          }

          return true;
        } catch (Exception $e) {
          exit(json_encode(array("status" => "fail", "message" => $e->getMessage())));
        }
    }

    public function verificaAtingiuMeta() {
      try {
        $jsonData = $this->getJsonRequestData();

        $this->layout = '';
        $usuarioID = $this->input->post('usuarioID') ?: $jsonData['usuarioID'];
        $assuntoID = $this->input->post('assuntoID') ?: $jsonData['assuntoID'];
        $grupoAulaID = $this->input->post('grupoAulaID') ?: $jsonData['grupoAulaID'];
        $aulaID = $this->input->post('aulaID') ?: $jsonData['aulaID'];
        $videoPercentual = $this->input->post('videoPercentual') ?: $jsonData['videoPercentual'];
        $videoInicio = $this->input->post('videoInicio') ?: $jsonData['videoInicio'];
        $videoFim = $this->input->post('videoFim') ?: $jsonData['videoFim'];
        $videoFinished = $this->input->post('videoFinished') ?: $jsonData['videoFinished'];
        $ancora = $this->input->post('ancora') ?: $jsonData['ancora'];

        $extra_data_log = array(
            "usuarioID" => $usuarioID,
            "assuntoID" => $assuntoID,
            "grupoAulaID" => $grupoAulaID,
            "aulaID" => $aulaID,
            "videoPercentual" => $videoPercentual,
            "videoInicio" => $videoInicio,
            "videoFim" => $videoFim,
            "videoFinished" => $videoFinished,

        );
        log_system_action("Verificando o percentual do vídeo",
            $extra_data_log
        );
        //para retorno do post
        $metaAtingida = false;
        $videoTerminado = false;
        $link = null;
        $video = null;

        if (isset($usuarioID, $assuntoID, $ancora)) {
            $params['usuarioID'] = $usuarioID;
            $params['assuntoID'] = $assuntoID;
            $dadosAluno = $this->curso->getDadosAluno($params);
            $turmaID = $dadosAluno->TurmaID;
            $disciplinaID = $dadosAluno->DisciplinaID;

            $is_valid = $this->validarAtualizaVideo($usuarioID, $aulaID, $grupoAulaID, $videoPercentual, $assuntoID, $disciplinaID);

            if ($is_valid) {
                $this->curso->atualizaPorcentagemVideoNovaTabela($usuarioID, $turmaID, $assuntoID,
                    $disciplinaID, $videoPercentual, $videoInicio, $videoFim);
            }

            if ($videoFinished === 'true' || $videoFinished === true) {
                log_system_action("O vídeo $aulaID foi finalizado",
                    $extra_data_log
                );
                $videoTerminado = true;
                $correta = 0;
                $errada = 0;
                $metaQuestaoAtingida = 0;
                $metaQuestao = 0;
                $questoesRespondidas = $this->curso->verificaQuestoesRespondidas($disciplinaID, $assuntoID, $usuarioID, false, 'Q');
                if ($questoesRespondidas) {
                    foreach ($questoesRespondidas as $key => $value) {
                        if ($value->RespostaCorreta == 'S') {
                            $correta++;
                        } elseif($value->RespostaCorreta == 'N') {
                            $errada++;
                        }
                    }

                    $metaQuestaoAtingida = ($correta / $questoesRespondidas[0]->TotalQuestoesAula * 100);
                    $metaQuestao = $questoesRespondidas[0]->Meta;
                }

                if ($metaQuestaoAtingida < $metaQuestao && ($correta + $errada) >= 4) {
                    $revisao = $this->curso->verificaQuestoesRespondidas($disciplinaID, $assuntoID, $usuarioID, false, 'R');

                    $linkDesc = $revisao[0]->DescAula;
                    $linkID = str_pad($assuntoID, 7, '0', 0) . str_pad($revisao[0]->AulaID, 7, '0', 0);
                    $linkRevisao = base_url() . 'curso/' . $ancora . '/' . encodeString($linkDesc) . '/' . $linkID . '/3?questao=true';
                    $metaVideo = $this->curso->captaMetaVideo(null, $usuarioID);
                    $videoAssistido = $this->curso->getVideoAula($usuarioID, $aulaID, $grupoAulaID);

                    #atingiu a meta Meta da Escola = Percentual do Aluno assistido
                    if (intval($videoAssistido->PercentualVideo) >= intval($metaVideo[0]['Percentual'])) {
                        $metaAtingida = true;
                        $link = $linkRevisao;
                        $video = array("metaEscola" => intval($metaVideo[0]['Percentual']), "aluno" => intval($videoAssistido->PercentualVideo));
                        log_system_action("vídeo finalizado e meta atingida",
                            $extra_data_log
                        );
                    } else {
                        log_system_action("vídeo finalizado com percentual inferior ao da meta",
                            $extra_data_log
                        );
                    }
                } else {
					$link = base_url() . 'curso/' . $ancora;
                }
            }
        }

        $data['formCursos'] = $formCursos;

        //para todos os returnos
        header('Content-Type: application/json');
        $result = array('metaAtingida' => $metaAtingida,
            'status' => true,
            'message' => null,
            'videoTerminado' => $videoTerminado,
            'link' => $link,
            'video' => $video);
        return $this->responseJson($result);
      } catch (Exception $e) {
          header('Content-Type: application/json');
          $result = array('metaAtingida' => $metaAtingida,
              'status' => false,
              'message' => $e->getMessage(),
              'videoTerminado' => null,
              'link' => null);

          return $this->responseJson($result);
      }
    }

    public function logVideoSeek()
    {
        header('Content-Type: application/json');
        try {
            $this->layout = '';
            $titulo = $this->input->post('tituloVideo') ? $this->input->post('tituloVideo') : "";
            $dados['acao'] = sprintf("Avançou o vídeo %s", $titulo);
            $dados['loginid'] = $this->session->userdata("pessoaid");
            $dados['login'] = $this->session->userdata("login");
            $dados['nomeescola'] = $this->session->userdata("nomeEscola");
            $dados['escola'] = $this->session->userdata("escola");
            $dados['disciplina'] = $this->input->post('grupoAulaID');
            $dados['assunto'] = $this->input->post('assuntoID');
            $dados['aula'] = $this->input->post('aulaID');
            $dados['codigo'] = 5;

            $this->load->model('Log_model', 'logacesso');
            $this->logacesso->GravaLog($dados);
            $result = array(
                'status' => true,
                'message' => "success");
            exit(json_encode($result));
        } catch (Exception $e) {
            $result = array(
                'status' => false,
                'message' => "error saving the log");
            exit(json_encode($result));
        }
    }

    public function logCloseTab()
    {
        $this->layout = false;
        $titulo = $this->input->post('tituloVideo') ? $this->input->post('tituloVideo') : "";
        $dados['acao'] = sprintf("Fechou ou saiu da página do vídeo %s", $titulo);
        $dados['loginid'] = $this->session->userdata("pessoaid");
        $dados['login'] = $this->session->userdata("login");
        $dados['nomeescola'] = $this->session->userdata("nomeEscola");
        $dados['escola'] = $this->session->userdata("escola");

        $dados['disciplina'] = $this->input->post('grupoAulaID');
        $dados['assunto'] = $this->input->post('assuntoID');
        $dados['aula'] = $this->input->post('aulaID');
        $dados['codigo'] = 5;

        $this->load->model('Log_model', 'logacesso');
        $this->logacesso->GravaLog($dados);
    }

    public function logEndedVideo()
    {
        $this->layout = false;
        $titulo = $this->input->post('tituloVideo') ? $this->input->post('tituloVideo') : "";
        $dados['acao'] = sprintf("Terminou de ver o vídeo %s", $titulo);
        $dados['loginid'] = $this->session->userdata("pessoaid");
        $dados['login'] = $this->session->userdata("login");
        $dados['nomeescola'] = $this->session->userdata("nomeEscola");
        $dados['escola'] = $this->session->userdata("escola");

        $dados['disciplina'] = $this->input->post('grupoAulaID');
        $dados['assunto'] = $this->input->post('assuntoID');
        $dados['aula'] = $this->input->post('aulaID');
        $dados['codigo'] = 5;

        $this->load->model('Log_model', 'logacesso');
        $this->logacesso->GravaLog($dados);
    }

    public function corrigeBugEstruturaPorAssunto()
    {
        $this->layout = false;
        try {
            if ($this->input->method() !== 'get') {
                throw new NotAllowedException('Method not Allowed');
            }
			$idAssunto	= $this->input->get('assunto');
			
            $bugs = SaeDigital::make(CorrigirEstruturaQuestoes::class)->handle($idAssunto);
       
            $i = 0;
            foreach($bugs as $bug) {
                if( $i < 5 ) {
                    $turmaId   = $bug['TurmaID'];
                    $agendamento = SaeDigital::make(CorrigirEstruturaQuestoes::class)->handleAgendamento($idAssunto, $turmaId);

                    $usuarioId = $bug['UsuarioID'];
                    $respostas = SaeDigital::make(CorrigirEstruturaQuestoes::class)->handleR001($usuarioId, $idAssunto);

                    //deletar estrutura antiga
                    SaeDigital::make(CorrigirEstruturaQuestoes::class)->handleR001Deletion($usuarioId, $idAssunto);
        

                    //gerar novamente a estrutura das questoes para esse usuários
                    $this->coletarDadosEstrutura($usuarioId, $agendamento["id"]);


                    
                    //update nas respostas que ja existiam
                    foreach($respostas as $resp) {
                        

                        $dadosResposta = array(
                            'QuestaoID'       =>  $resp['QuestaoID'],
                            'DtAlt'           =>  $resp['DtAlt'],
                            'Resposta'        =>  $resp['Resposta'],
                            'RespostaCorreta' =>  $resp['RespostaCorreta'],
                            'DtConclusao'     =>  $resp['DtConclusao'],
                            'Tipo'            =>  $resp['Tipo'],
                        );
                        $dadosVideo = array(
                            'ControleQuery' =>  $resp['ControleQuery'],
                            'PercentualVideo' =>  $resp['PercentualVideo'],
                            'InicioVideo' =>  $resp['InicioVideo'],
                            'FimVideo' => $resp['FimVideo']
                        );
                        SaeDigital::make(CorrigirEstruturaQuestoes::class)->handleUpdateR001($usuarioId, $dadosResposta, $dadosVideo, $idAssunto);
                    
                    
                    }
                    $i++;
                }
                
              
            }
            

            $nBugs = sizeof($bugs);
            
            return $this->responseJson(['success' => true, 'message' => $nBugs == 0 ? 'Não há bugs para esse assunto' : "Assunto corrigido para $i de $nBugs estruturas."], 200);

        } catch (Exception $e) {
            return $this->responseJson(['message' => $e->getMessage(), 'success' => false], 500);
        }
    }

    public function gerarEstrutura()
    {
        $this->layout = false;
        try {
            if ($this->input->method() !== 'post') {
                throw new NotAllowedException('Method not Allowed');
            }
			
			
			$itemNameAluno 				= $this->input->post('itemName');
			$idAgendamento 				= $this->input->post('agendamento');
			
	
			$result = $this->coletarDadosEstrutura($itemNameAluno, $idAgendamento);
		
            return $this->responseJson(['success' => $result['success'], 'message' => 'Activity structure created.'], $result['success'] ? 200 : 500);

        } catch (Exception $e) {
            return $this->responseJson(['message' => $e->getMessage(), 'success' => false], 500);
        }
    }


    public function coletarDadosEstrutura($aluno, $agendamento)
    {
        $this->layout = false;
        try {			
			$this->load->model('disciplina_model');
			$this->load->library('Dadosrelatorio_lib');
			
			$itemNameAluno 				= $aluno;
			$idAgendamento 				= $agendamento;
			
			$aluno 						= SaeDigital::make(BuscarAluno::class)->handle($itemNameAluno);
			$agendamento 				= SaeDigital::make(BuscarAgendamentoPorId::class)->handle($idAgendamento);
			$disciplina 				= SaeDigital::make(PegaDisciplinaPeloId::class)->handle($agendamento['DisciplinaID']);

			$dadosUsuario 				= [
				'pessoaid'				=> $aluno['itemName'],
				'perfilid' 				=> $aluno['Perfil'],
				'turmaid' 				=> $aluno['Turma'],
				'escolaid' 				=> $aluno['Escola'],
				'nomeAluno'				=> $aluno['Nome'],
				'descricaoPacote' 		=> $disciplina['Descricao'],
				'recalcularPercentual' 	=> null,
				'percentual' 			=> null
			];

			$dadosDisciplina 			= [
				'assuntoId' 			=> $agendamento['AssuntoID'],
				'disciplinaId' 			=> $agendamento['DisciplinaID'],
				'frenteId' 				=> $agendamento['FrenteID'],
				'exibeDisciplina' 		=> '1',
				'liberaQuestao' 		=> '1',
			];
			
			$result = $this->obterEstruturaQuestoes($dadosUsuario, $dadosDisciplina, false);
						
            
            return $result;

        } catch (Exception $e) {
            return $this->responseJson(['message' => $e->getMessage(), 'success' => false], 500);
        }
    }

   
}

/* End of file curso.php */
/* Location: ./application/controllers/curso.php */
