<?php
use Ava\App\Exceptions\NotFoundException;
use Ava\App\Services\Respostas\ValidarQuestaoEstruturaAluno;
use Ava\App\Support\Perfil;
use Ava\App\Exceptions\MissingArgumentException;
use Ava\App\Services\Escola\BuscarDadosEscola;
use Ava\App\Services\EscolaEmMovimento\EscolaEmMovimento;

class EscolaEmovimento extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();

        $this->load->model('cadastro_model', 'cadastro');
        $this->allowProfile(Perfil::ESCOLA);
        $this->layout = false;
    }

    public function listToken()
    {
        try {
            $escola = SaeDigital::make(BuscarDadosEscola::class)->handle($this->session->userdata('escola'));

            if (!is_array($escola)) {
                throw new NotFoundException('Escola não encontrada!');
            }

            $itemname = $this->session->userdata('pessoaid');

            $tokens = $this->cadastro->verifyToken($itemname);

            return $this->responseJson(['items' => $tokens], 200);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        }
    }

    public function saveToken()
    {
        try {
            $itemName = $this->session->userdata('pessoaid');
            $fields['tokenEscolaMov'] = $this->input->post('token');
            $fields['AmbienteEEM'] = $this->input->post('ambiente');

            $cad = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $itemName, $fields, FALSE);

            return $this->responseJson(['Status' => $cad], 200);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        } catch (MissingArgumentException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 400);
        }
    }

    public function deleteToken()
    {
        try {
            $itemName = $this->session->userdata('pessoaid');
            $fields['tokenEscolaMov'] = null;
            $fields['AmbienteEEM'] = null;

            $cad = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $itemName, $fields, FALSE);

            return $this->responseJson(['Status' => $cad], 200);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        } catch (MissingArgumentException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 400);
        }
    }

    public function listTurmas()
    {
        try{
            $escolaid = $this->session->userdata('pessoaid');
            $ano = (int)date("Y");

            $turmas = $this->cadastro->getTurmasEscola($escolaid, $ano);
            foreach ($turmas as $turma => $value) {
                $response[$turma]['Descricao'] = $value['Descricao'];
                $response[$turma]['turmaId'] = $value['itemName'];
            }
            return $this->responseJson(['Turmas' => $response], 200);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        }
    }

    public function listAlunos($idTurma)
    {
        try{
            $alunos = $this->cadastro->alunosPturma($idTurma);
            foreach ($alunos as $aluno => $value) {
                $response[$aluno]['nome'] = $value['Nome'];
                $response[$aluno]['login'] = $value['Login'];
                $response[$aluno]['alunoid'] = $value['itemName'];
                $response[$aluno]['escolaid'] = $value['Escola'];
                $response[$aluno]['turma'] = $value['Turma'];
                $response[$aluno]['alunora'] = $value['alunora'];
            }
            return $this->responseJson(['alunos' => $response], 200);
        } catch (NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        }
    }

    public function saveAlunos()
    {
        try{
            $alunos = json_decode($this->input->post()['alunos'][0], true);

          foreach($alunos as $aluno) {
              $aluno = array_filter($aluno, function($k) {
                  return ( $k !== 'nome' && $k !== 'login');
              }, ARRAY_FILTER_USE_KEY);
              $exist = empty($this->cadastro->verificaAlunoEM($aluno['alunoid'])) ? true : false ;
              $this->cadastro->salvaAlunoEEM( $aluno, $exist);
            }

        } catch(NotFoundException $e) {
            return $this->responseJson(['message' => $e->getMessage()], 404);
        }
    }
}