<?php

use Ava\App\Exceptions\FileNotFoundException;
use Ava\App\Services\Aulas\ValidarAulaPorSerie;
use Ava\App\Support\Perfil;
use League\Flysystem\AwsS3v3\AwsS3Adapter;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

                    //CI_Controller alterado no momento
class Preparatorio extends MY_Controller {

    public $layout = 'default';
    public $title = 'AVA SAE - Curso';
    public $description = 'Ambiente Virtual de Aprendizagem - SAE';
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'preparatorio', 'redactor.min', 'pt_pt', 'redactor_special_character', 'redactor.fontcolor', 'redactor.fontsize', 'jquery.cookie'); //'curso.min','chosen'
    public $keywords = array('sae', 'curso');
    public $sdb;
    public $configuracoes;
    public $sessao;
    public $header = '';
    public $menu_vertical = '';

    public function __construct() {

        parent::__construct();

        $this->load->model('curso_model', 'curso');
        $this->load->model('cadastro_model', 'cadastro');
        $this->load->helper('cookie');
        $this->load->library('disciplina_lib');

        // define os arquivos para juntar e comprimir
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'mensagem');
    }

    /**
     * Index
     *
     * Exibe a página inicial de curso.
     *
     * @param string $Ancora determinanda qual ? a identificador da disciplina
     * @access	public
     * @return	void
     */
 	public function index($Ancora = null)
    {
        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'curso';
        $this->cssMinify[] = 'glyphicon';
        $this->cssMinify[] = 'datepicker';
        $this->css[] = $this->minify->getCSS('curso_index.min', $this->cssMinify, ENVIRONMENT);

        // lista de séries para lista do combo.
        $listaSeries[10]['ancora'] = 'sae-arrase-no-enem-2021-1-ordf-serie';
        $listaSeries[10]['desc'] = '1ª Série';
        $listaSeries[11]['ancora'] = 'sae-arrase-no-enem-2021-2-ordf-serie';
        $listaSeries[11]['desc'] = '2ª Série';
        $listaSeries[13]['ancora'] = 'sae-arrase-no-enem-2021-extensivo';
        $listaSeries[13]['desc'] = '3ª Série - Aprova Mais';
        $listaSeries[20]['ancora'] = 'sae-arrase-no-enem-2021-extensivo-mega';
        $listaSeries[20]['desc'] = 'Extensivo Mega';
        $listaSeries[21]['ancora'] = 'sae-arrase-no-enem-2021-extensivo';
        $listaSeries[21]['desc'] = '3ª Série - Aprova Mais';
        // Link do botão Curso completo
        $cursoCompleto = 'sae-arrase-no-enem-curso-completo';

        //Ancora vazia vem $1
        if($Ancora === '$1'){
            // Usuario perfil professor ou coordenador ancora é a primeira pois exibe lista de séries
            if (in_array($this->session->userdata('perfil'), [PERFIL_PROFESSOR, PERFIL_COORDENADOR])){
                $Ancora = $listaSeries[10]['ancora'];
            }else{ // senão joga para série do aluno correta.
                $serie = $this->session->userdata('Serie');
                $Ancora = $listaSeries[$serie]['ancora'];
            }
            // esse redirect é para o conteúdo do vídeo funcionar
            redirect('/preparatorio/'.$Ancora);
            exit();
        }


        //envio para view
        $data['listaSeries'] = $listaSeries;
        $data['cursoCompleto'] = $cursoCompleto;
        $data['Ancora'] = $Ancora;

        $this->js[] = 'bootstrap-datepicker';
        $grupoAula = $Ancora ? $this->home->verificaGrupoAulaAncora($Ancora) : '';

        $this->session->set_userdata('grupoAulaID', $grupoAula[0]['id']);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['perfil'] = $this->session->userdata('perfil');

        $configuracoes = $this->curso->getConfiguracoesescola($this->session->userdata('escola'));

        if ($this->input->get('turmaID')) :
            $this->session->set_userdata('TurmaID', $this->input->get('turmaID'));
        endif;

        //seta valores padrao caso a escola ainda nao tenha cadastrado as configurações
        if ($configuracoes && isset($configuracoes[0])) {
            $this->session->set_userdata('escola', $configuracoes[0]['EscolaID']);
            $data['configuracoes'] = $configuracoes[0];
            unset($configuracoes[0]);
        } else {
            $data['configuracoes']['QuestaoCoordenador'] = 'N';
            $data['configuracoes']['QuestaoProfessor'] = 'N';
            $data['configuracoes']['AgendaCoordenador'] = 'N';
            $data['configuracoes']['AgendaProfessor'] = 'N';
        }

        $turmaid = $this->input->get('turmaID') != '' ? $this->input->get('turmaID') : $this->session->userdata('TurmaID');

        $turma = $this->home->verificaTurmas($turmaid, $this->session->userdata('escola'));

        if ($Ancora === 'audios-lingua-estrangeira') {
            $dados['serieID'] = $turma[0]['SerieID'];
            $dados['serieDescricao'] = $turma[0]['DescricaoSerie'];

            $getJson = $this->input->get('json');
            if ($getJson && filter_var($getJson, FILTER_VALIDATE_BOOLEAN)) {
                return $this->responseJson($data);
            }

            return $this->load->view('audios-lingua-estrangeira', $dados);
        }


        $metaPercentual = 0;
        $percentual = NULL;
        if (isset($configuracoes[0]))
            unset($configuracoes[0]);

        $acessa = FALSE;

        if (!empty($grupoAula)) {
            $data['cursoNome'] = $grupoAula[0]['Descricao'];
            $data['grupoAulaID'] = $grupoAula[0]['itemName'];
            $data['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];

            $data['meta'] = $this->session->userdata('meta');

            $data['videoaulas'] = $this->disciplina_lib->arrayDisciplinas($data['grupoAulaID']);

            $data['videosAssistidosAnotacoes'] = $this->curso->verificaVideoAssistidos_Anotacoes();

            if($data['videoaulas']){
            	foreach ($data['videoaulas'] as $grid => $val) {
            		$data['qtdSemanas'] = count($val)-1;
            	}
            }

            //dados para gravar na sessao
            $array['Ancora'] = $Ancora;
            $array['grupoAulaID'] = $grupoAula[0]['id'];
            $array['DescricaoPacote'] = utf8_encode($grupoAula[0]['Descricao']);
            $array['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];
            $array['TipoPDF'] = isset($grupoAula[0]['TipoPDF']) ? $grupoAula[0]['TipoPDF'] : 'L';
            $array['TurmaID'] = $turmaid;
       }

        $this->session->set_userdata($array);
        $data['metaPercentual'] = $metaPercentual;
        $data['percentual'] = $percentual;

        $serieAluno = $this->home->RetornaSerieTurma($array['TurmaID']);

        $data['serieAluno'] = $serieAluno[0]['SerieID'];

        $getJson = $this->input->get('json');
        if ($getJson && filter_var($getJson, FILTER_VALIDATE_BOOLEAN)) {
            return $this->responseJson($data);
        }

        $this->load->view('preparatorio', $data);
    }

    function buscaAulasDisciplinas(){

    	$disciplinaid = $this->input->post('disciplinaid');
    	$grupoaulaid = $this->input->post('grupoaulaid');
    	$categoriaid = $this->input->post('categoriaid');
        $this->session->set_userdata('Ancora', $this->input->post('ancora', true));

    	$array = $this->disciplina_lib->arrayAulas($grupoaulaid,$disciplinaid,$categoriaid, true);
    	$html = $this->disciplina_lib->htmlListaAulas($array);

    	print($html);die;

    }


    /**
     * @param $serie
     * @param $alunoID
     *
     * @return bool
     */
    private function validarAcessoPreparatorio($serie, $alunoID)
    {
        $dadosAluno = $this->cadastro->getDadosUsuario($alunoID);

        $serieAluno = intval($dadosAluno[0]['Serie']);

        if (strpos($serie, '|') !== false) {
            $serie = explode('|', $serie);

            return in_array($serieAluno, $serie);
        }

        return ($serieAluno == $serie);
    }

    /**
     * Vídeo
     *
     * Exibe a página inicial de vídeo da disciplina.
     *
     * @param string $Ancora determinanda qual ? a identificador da disciplina
     * @access	public
     * @return	void
     */
    public function video($Ancora = null) {
        $aula_numero = $this->uri->segment(5);
        $this->cssMinify[] = 'mensagem';
        $this->cssMinify[] = 'video';
        $this->cssMinify[] = 'style';
        $this->cssMinify[] = 'redactor/redactor';
        $this->cssMinify[] = 'glyphicon';


        $this->css[] = $this->minify->getCSS('video_curso.min', $this->cssMinify, ENVIRONMENT);

        $this->js[] = 'jquery.oembed.min';
        $this->js[] = 'jquery.paginate.min';
        $this->js[] = 'bootstrap-tooltip';
        $this->css[] = 'videojs/video-js';
        $this->js[] = 'videojs/video.min';
        $this->js[] = 'video';


        // widgets class esquerda
        $data['AssinaturaMatriculaID'] = $this->session->userdata('assinaturaMatriculaID');

        $fields['Login'] = $this->session->userdata('login');
        $retornoVerificaPacotesAluno = $this->home->verificaDisciplinas($fields, $this->configuracoes[0]['Base']);
        $grupoAula = $this->home->verificaGrupoAulaAncora($Ancora);

        // if (!$this->validarAcessoPreparatorio($grupoAula[0]['SerieID'], $this->session->userdata('pessoaid')) && $this->session->userdata('perfil') == PERFIL_ALUNO) {
        //     $data['bloqueiaQuestoes'] = true;
        //     $data['mensagemBloqueioQuestoes'] = 'Você não possui acesso a esse conteúdo.';
        //     $this->load->view('questao', $data);
        //     return;
        // }

        $data['cursoNome'] = isset($grupoAula[0]['Descricao']) ? $grupoAula[0]['Descricao'] : null;
        $dados = $this->curso->verificaVideoAula();
        if ($dados) {

            $classificacaoID = $this->session->userdata('ClassificacaoPacotePai');

            $grupoAulaID = $grupoAula[0]['itemName'];

            $this->session->set_userdata('grupoAulaID', $grupoAulaID);

            $aulaID = $dados[0]['AulaID'];
            $linkVideoaula = $dados[0]['Video'];

            $data['videoNome'] = $dados[0]['Tema'];
            $data['aulaID'] = $aulaID;
            $data['grupoAulaID'] = $grupoAulaID;

            //$pastaS3 = (strpos($data['cursoNome'],'2017') === false) ? '/antigos/' : '/2017/';
            $data['pdf'] = replace_extension($dados[0]['pdf'],'pdf');
            $extension   = pathinfo($data['pdf'], PATHINFO_EXTENSION);
            $data['pdf'] = pathinfo($data['pdf'], PATHINFO_FILENAME);
            $data['pdf'] = 'pdf' . '/pdf/' . $data['pdf'] . '.' . $extension;
            $allowedExtensions = ['pdf'];

            /** @var AwsS3Adapter $adapter */
            $adapter = SaeDigital::make(AwsS3Adapter::class);

            $data['urlPdfExiste'] = in_array(pathinfo($data['pdf'], PATHINFO_EXTENSION), $allowedExtensions)
                ? $adapter->has($data['pdf'])
                : false;

            $result = $this->curso->verificaDisciplina($dados[0]['DisciplinaID'], $grupoAulaID);

            $data['disciplinaNome'] = $result[0]['Descricao'];

            $verificaAcaoVideoAula = $this->curso->verificaAcaoVideoAula($aulaID);

            $id = '';
            $aulaAssistida = '';
            $curtir = 'N';
            $data['situacaoVideoAula'] = '';

            if (empty($verificaAcaoVideoAula)) {
                $id = $this->curso->inserir_acaoVideoAula($aulaID);
                $aulaAssistida = 'N';
            }


            $data['situacaoVideoAula'] = $aulaAssistida ? $aulaAssistida : $verificaAcaoVideoAula[0]['AulaAssistida'];
            $this->session->set_userdata('VideoAulaAcaoID', $id ? $id : $verificaAcaoVideoAula[0]['VideoAulaAcaoID']);
            $data['curtir'] = isset($verificaAcaoVideoAula[0]['AulaCurtida']) ? $verificaAcaoVideoAula[0]['AulaCurtida'] : null;


            // monta todas vídeos aulas relacionadas a disciplina para que posssa ir para os próximos.
            $data['videoaulas'] = $this->curso->verificaVideoAulasDisciplinaVideo($grupoAulaID, $dados[0]['DisciplinaID']);

            $this->session->set_userdata('link_video_aula', $linkVideoaula);
            $this->session->set_userdata('cursonome', utf8_encode($data['cursoNome']));
            $this->session->set_userdata('aulaid', $dados[0]['AulaID']);
            $this->session->set_userdata('tema', utf8_encode($dados[0]['Tema']));

            $usuarioID = $this->session->userdata('pessoaid');

            $videoAulaInfo = $this->curso->getVideoAula($usuarioID, $aulaID, $grupoAulaID);

            if (!empty($videoAulaInfo)){
                $data['percentualVideo'] = isset($videoAulaInfo->PercentualVideo) ? $videoAulaInfo->PercentualVideo : 0;
                $data['inicioVideo'] = isset($videoAulaInfo->InicioVideo) ? $videoAulaInfo->InicioVideo: 0;
                $data['fimVideo'] = isset($videoAulaInfo->FimVideo) ? $videoAulaInfo->FimVideo : 0;
                $data['videoAulaAssistida'] = $videoAulaInfo->VideoAulaAssistida;
            }

            $data['usuarioid'] = $usuarioID;
            $data['videoPlayer'] = null;
            $data['videoURL'] = null;
            $strHttp = 'http';
            if (strpos($linkVideoaula, $strHttp) === 0)
            {
                $data['videoURL'] = $linkVideoaula;
                //TODO: validar formato dos videos
                $data['videoType'] = 'video/mp4';
            }else
            {
                $data['videoPlayer'] = '<iframe id="player" width="100%" height="100%" scrolling="no" style="min-height: 420px;" src="' . base_url() . 'api-video" mozallowfullscreen webkitallowfullscreen allowfullscreen></iframe>';
                if ($this->agent->is_mobile() || ($this->agent->browser() == 'Firefox' && $this->agent->version() >= 11) || ($this->agent->browser() == 'Chrome' && $this->agent->version() >= 25) || ($this->agent->browser() == 'Safari' && $this->agent->version() >= 6)) { // true
                    $data['tipo'] = 'playerHTML5';
                } else {
                    $data['tipo'] = 'player';
                }
            }


            $data['VideoAulaAcaoID'] =  $id ? $id : $verificaAcaoVideoAula[0]['VideoAulaAcaoID'];

            // Verifica se há anotações para o Vídeo Aula.
            $data['anotacoes'] = $this->curso->verifica_AnotacoesVideoAula($aulaID, $data['VideoAulaAcaoID']);
            $data['videoAulaVer'] = $this->uri->segment(5) ? $this->uri->segment(5) : 1;

            $data['Ancora'] = $Ancora;

            $questoes = $this->curso->getQuestoesAula($grupoAulaID, $aulaID);

            $data['possuiQuestoes'] = 0;
            if (!empty($questoes)) {
                $data['possuiQuestoes'] = 1;
            }

            //abre tela de questoes
            if (isset($_GET['questao'])) {

                $data['questaoAtual'] = $this->uri->segment(6) ? $this->uri->segment(6) : 0;

                $data['qtdQuestoes'] = count($questoes);

                //faz o login para buscar as questoes com os dados do usuario
                $login = $this->curso->getDadosUsuario();
                $log = api_use('cliente/login-ava', $login, 1);

                //grava na sessao o id do cliente do site de questoes
                if ($log['success'] == 1) {
                    $this->session->set_userdata('idUserQuestoes', $log['message']['id']);
                }

                //dados questao
                $array = array('questao' => $questoes[$data['questaoAtual']]['QuestaoID']);

                $resultApi = $this->curso->CarregaQuestaoAPI($array['questao'], $grupoAula[0]['ClassificacaoID']);

                if (isset($resultApi['success']) && $resultApi['success'] == 1) {
                    $data['dadosQuestao'] = $resultApi['message'];

                    //salva a alternativa correta
                    for ($a = 0; count($data['dadosQuestao']['questao']['alternativas']) > $a; $a++) {
                        if ($data['dadosQuestao']['questao']['alternativas'][$a]['opcaoCorreta'] == 1) {
                            $data['altCorreta'] = $data['dadosQuestao']['questao']['alternativas'][$a]['id'];
                            $data['opcaoCorreta'] = $data['dadosQuestao']['questao']['alternativas'][$a]['valorOpcao'];
                        }
                    }

                    //grava no cookie as alternativas da questao para buscar no combo de erros
                    $cookie = array(
                        'name' => 'alternativas',
                        'value' => json_encode($data['dadosQuestao']['questao']['alternativas']),
                        'expire' => 14400,
                        'domain' => ".aprovaconcursos.com.br",
                        'secure' => FALSE
                    );
                    $this->input->set_cookie($cookie);

                    //comentarios
                    $coments = api_use('questao/comentarios/listar', $array);
                    $data['dadosQuestaoComent'] = $this->comentariosQuestoes($coments['message']);
                    $data['qtdComentarios'] = count($coments['message']['comentarios']) > 0 ? count($coments['message']['comentarios']) : 0;

                    //estatisticas
                    $estatisticas = api_use('questao/estatistica', $array);
                    $data['estatisticas'] = $this->estatisticasQuestoes($estatisticas['message']);

                    //tipo erro
                    $tipoErro = api_use('dados-auxiliares/questao-erro-tipo', array("tipo" => 1));
                    $data['tipoErro'] = $tipoErro['message'];

                    $data['aulaID'] = $aulaID;
                    $data['disciplinaID'] = $dados[0]['DisciplinaID'];

                    if (isset($resultApi['message']['questao']['urlVideo']) && $resultApi['message']['questao']['urlVideo'] != '') {
                        $data['videoQuestoes'] = player($resultApi['message']['questao']['urlVideo'], 'questoes');
                        $data['existevideo'] = 1;
                        $data['classificacaoVideo'] = $this->classificacaoVideo($array['questao'], $data['dadosQuestao']['questao']);
                    } else {
                        $data['videoQuestoes'] = '';
                        $data['existevideo'] = 0;
                        $data['classificacaoVideo'] = '';
                    }
                }

                $this->load->view('questao', $data);
            } else {
                $url_prox_video = null;
                $url_video_anterior = null;
                if (isset($dados[0]['DisciplinaID'])) {
                    if ($dados[0]['DisciplinaID'] && is_numeric($aula_numero)) {
                        if ($aula_numero) {
                            $dadosProximaAula = $this->curso->verificaProximaVideoAula($dados[0]['DisciplinaID'], $aula_numero);
                            if ($dadosProximaAula) {
                                $url_prox_video = base_url() . 'preparatorio/' . $Ancora . '/' . encodeString($dadosProximaAula['Tema']) . '/' . $dadosProximaAula['itemName'] . '/' . ($aula_numero + 1);
                            }
                            if ($aula_numero != 1) {
                                $dadosProximaAula = $this->curso->verificaProximaVideoAula($dados[0]['DisciplinaID'],$aula_numero - 2);
                                $url_video_anterior = base_url() . 'preparatorio/' . $Ancora . '/' . encodeString($dadosProximaAula['Tema']) . '/' . $dadosProximaAula['itemName'] . '/' . ($aula_numero - 1);
                            }
                        }
                    }
                }
                $data['url_prox_video'] = $url_prox_video;
                $data['url_video_anterior'] = $url_video_anterior;
                $this->load->view('video_preparatorio', $data);
            }
        } else {

            show_404('page');
        }
    }

    function api_video() {

        $param_playerapi['nomealuno']             = utf8_encode($this->session->userdata('nome'));
        $param_playerapi['pessoaid']              = $this->session->userdata('pessoaid');
        $param_playerapi['matriculaid']           = $this->session->userdata('matriculaid');
        $param_playerapi['assinaturamatriculaid'] = $this->session->userdata('assinaturaMatriculaID');
        $param_playerapi['grupoaulaid']           = $this->session->userdata('grupoAulaID');
        $param_playerapi['descricaogrupoaula']    = $this->session->userdata('cursonome');
        $param_playerapi['aulaid']                = $this->session->userdata('aulaid');
        $param_playerapi['descricaoaula']         = $this->session->userdata('tema');
        $param_playerapi['video']                 = $this->session->userdata('link_video_aula');
        $param_playerapi['modulo']                = 'pseudo-events';
        $param_playerapi['hash']                  = $this->session->userdata('pessoaid').$this->session->userdata('aulaid');
        $param_playerapi['eventohash']            = 'requisito_certificado';

        echo player_api($param_playerapi);die;

    }

    /**
     * Buscar
     *
     * Busca e retorna todas vídeo aulas, caso contenha para consulta realizada..
     *
     * @param string $termoBusca descrição do termo da pesquisa
     * @access	private
     * @return	void
     */
    function buscar($termoBusca = null) {

        $this->cssMinify[] = 'buscar';
        $this->css[] = $this->minify->getCSS('buscar_curso.min', $this->cssMinify, ENVIRONMENT);

        $this->menu_vertical = $this->load->view('view_menu', '', true);

        $data['videoaulas'] = array();
        if ($termoBusca) {
            $data['videoaulas'] = $this->curso->buscaVideoAulas($termoBusca);
        }


        $this->load->view('buscar', $data);
    }

    /**
     * Resultado Busca
     *
     * retorna todas vídeo aulas que há cadastradas de acordo com o termo buscado.
     *
     * @param string $termoBuscado palavra digitada no campo buscar.
     * @access	private
     * @return	void
     */
    function resultadoBusca($termoBuscado = null) {

        $termoBuscado = urldecode($termoBuscado);
        $termoBuscado = removeAcentos($termoBuscado);

        $this->layout = '';
        $this->cssMinify[] = 'buscar';
        $this->css[] = $this->minify->getCSS('resultadoBusca_curso.min', $this->cssMinify, ENVIRONMENT);

        if ($termoBuscado) {

            if ($termoBuscado == '%27%27' || $termoBuscado == '%22%22') {
                $termoBuscado = '';
            }

            $data['videoaulas'] = $this->curso->buscaVideoAulas($termoBuscado);
            $totalVideoAulas = count($data['videoaulas']);
            $conteudo = $this->load->view('resultadoBuscaVideoAulas', $data, true);

            $obj['li.direita'] = utf8_encode("<html>$conteudo</html>");

            if ($totalVideoAulas == 1)
                $obj['li.direita p.res'] = utf8_encode("<html>Foi encontrado <b>$totalVideoAulas</b> disciplina, que contém vídeos aulas relacionadas ao termo buscado</html>");
            else
                $obj['li.direita p.res'] = utf8_encode("<html>Foram encontrados <b>$totalVideoAulas</b> disciplinas, que contém vídeos aulas relacionadas ao termo buscado</html>");
        }

        print_r(json_encode($obj));
        die;
    }

    /**
     * Material Adicional
     *
     * Exibe os materiais adicionais para os cursos.
     *
     * @access	private
     * @return	void
     */
    function materialAdicional() {

        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'material-adicional';
        $this->css[] = $this->minify->getCSS('materialAdicionalv4.min', $this->cssMinify, ENVIRONMENT);

        //$fields['matriculaID'] = $this->session->userdata('matriculaid');
        //$fields['Ancora'] = $this->session->userdata('Ancora');
        $fields['AssinaturaMatriculaID'] = $this->session->userdata('assinaturaMatriculaID');
        $data['pacotesAluno'] = $this->home->verificaPacotesAluno($fields, $this->configuracoes[0]['Base']);

        $this->menu_vertical = $this->load->view('view_menu', '', true);

        $this->load->view('material-adicional', $data);

    }

    /**
     * Material Adicional
     *
     * Exibe os materiais adicionais para as disciplinas do curso.
     *
     * @access	private
     * @return	void
     */
    function materialAdicionalDisciplinas() {


        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'material-adicional';
        $this->css[] = $this->minify->getCSS('materialAdicionalv4.min', $this->cssMinify, ENVIRONMENT);

        $pdf = array();
        // Materiais Adicionais upx, por pacote

        $pdf = $this->curso->getPdfGrupoAluno($this->session->userdata('matriculaid'), $this->session->userdata('grupoAulaID'));


        // Materiais Adicionas S3, por disciplina
        $disciplinas = $this->curso->verificaDisciplinas($this->session->userdata('grupoAulaID'));
        $materiais = array();
        if ($disciplinas) {
            foreach ($disciplinas as $key => $value) {
                $materiais[$value['Descricao']] = array();
                $materiaisAdicionais = $this->curso->getMaterialGrupoAluno($this->session->userdata('grupoAulaID'), $value['DisciplinaID']);

                if ($materiaisAdicionais)
                    $materiais[$value['Descricao']] = array_merge($materiais[$value['Descricao']], $materiaisAdicionais);
                else
                    unset($materiais[$value['Descricao']]);
            }
        }

        $data['pdf'] = $pdf;
        $data['materiais'] = $materiais;
        $this->menu_vertical = $this->load->view('view_menu', '', true);

        $this->load->view('material-adicional-disciplinas', $data);
    }

    /**
     * Finalizar  Videoaula
     *
     * Finaliza a videoaula de acordo com os parâmetros identificadores
     * @param int aulaID identificador da aula
     * @param int pessoaid identificador da pessoa
     * @access	private
     * @return	int
     */
    function finalizarVideoAula() {

        $this->layout = '';

        $fields['aulaID'] = $this->input->post('aulaID');
        $fields['pessoaID'] = $this->session->userdata('pessoaid');
        $fields['situacaoVideoAula'] = $this->input->post('situacaoVideoAula');

        // TODO: FDD-429 - ISSO ESTA SENDO FEITO DO JEITO ERRADO CARA!!
        print_r($this->curso->finalizar_videoAula($fields));
        die;
    }

    /**
     * Minhas Anotações
     *
     * Exporta todas as anotações do Curso ou de apenas uma disciplina
     *
     * @param string $Ancora determinanda qual ? a identificador da disciplina
     * @access	public
     * @return	void
     */
    function minhasAnotacoes($Ancora = null) {

        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'curso';
        $this->css[] = $this->minify->getCSS('curso_index.min', $this->cssMinify, ENVIRONMENT);

        $fields['AssinaturaMatriculaID'] = ($this->input->post('assinaturaMatriculaID')) ? $this->encrypt_v2->decode($this->input->post('assinaturaMatriculaID'), KEY_PLAYER) : $this->session->userdata('assinaturaMatriculaID');
        $retornoVerificaPacotesAluno = $this->home->verificaPacotesAluno($fields, $this->configuracoes[0]['Base']);

        $data = '';

        // Grupo aula vinculada a assinaturaMatricula
        $grupoAula = $this->home->verificaGrupoAulaAluno($retornoVerificaPacotesAluno[0]['GrupoAulaID']);
        $data['videosAssistidosAnotacoes'] = $this->curso->verificaVideoAssistidos_Anotacoes();

        // Série Grandes Concursos
        $dtLiberacao = $retornoVerificaPacotesAluno[0]['DtInicio'];
        if ($grupoAula['ClassificacaoID'] == '6' && $grupoAula['DtInicio'] != '-') {

            $timeGrupo = strtotime($grupoAula['DtInicio']);
            $timeCompra = strtotime($retornoVerificaPacotesAluno[0]['DtInicio']);

            if ($timeGrupo > $timeCompra) {
                $dtLiberacao = $grupoAula['DtInicio'];
            }
        }

        if ($grupoAula['ClassificacaoID'] != 5) {
            $data['cursoNome'] = isset($retornoVerificaPacotesAluno[0]['DescricaoPacote']) ? $retornoVerificaPacotesAluno[0]['DescricaoPacote'] : null;
            $data['grupoAulaID'] = isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) ? $retornoVerificaPacotesAluno[0]['GrupoAulaID'] : null;
            $data['ClassificacaoID'] = $grupoAula['ClassificacaoID'];

            $data['videoaulas'] = $this->curso->verificaVideoAulasDisciplina($data['grupoAulaID'], null);
        } // Assinatura completa
        else if ($grupoAula['ClassificacaoID'] == 5) {
            // grupo aula post pela assinatura completa
            $grupoAulaID = $this->input->post('grupoAulaID');

            // clicando no botao voltar curso
            if (empty($grupoAulaID) && $this->session->userdata('ClassificacaoPacotePai') == 5) {
                $grupoAulaID = $this->session->userdata('grupoAulaID');
            }

            // Grupo aula selecionada pelo aluno
            $grupoAula = $this->home->verificaGrupoAulaAluno($grupoAulaID);

            $data['cursoNome'] = $grupoAula['Descricao'];
            $data['grupoAulaID'] = $grupoAula['id'];
            $data['ClassificacaoID'] = $grupoAula['ClassificacaoID'];

            $data['videoaulas'] = $this->curso->verificaVideoAulasDisciplina($data['grupoAulaID'], null);
        }

        $data['DtLiberacao'] = $dtLiberacao;
        $data['QtAnotacoes'] = $this->curso->verifica_quantidadeAnotacoes($data['grupoAulaID'], $data['videosAssistidosAnotacoes']);
        $data['Disciplina'] = array();
        foreach ($data['QtAnotacoes'] as $key)
            array_push($data['Disciplina'], $key->Descricao);
        $data['Disciplina'] = array_unique($data['Disciplina']);

        // banner simulado
        $banners = $this->curso->verificaBannerSimulado(isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) ? $retornoVerificaPacotesAluno[0]['GrupoAulaID'] : null);
        if (!empty($banners)) {
            // selecionar o banner válido
            foreach ($banners as $banner) {
                // data de hoje sem a hora
                $hoje = mktime(0, 0, 0, date('m'), date('d'), date('Y'));

                // data final não é obrigatória
                $dtfim = '';
                if (!empty($banner['DtFimSimulado'])) {
                    list($a2, $m2, $d2) = explode('-', $banner['DtFimSimulado']);
                    $dtfim = mktime(0, 0, 0, $m2, $d2, $a2);
                }

                if (empty($dtfim) || $dtfim > $hoje) {
                    $data['bannerSimulado'] = $banner;
                }
            }
        }

        $this->menu_vertical = $this->load->view('view_menu', '', true);

        $this->load->view('minhasAnotacoes', $data);
    }

    /**
     * Exportar Anotações
     *
     * Verifica se o curso ou disciplina foi selecionado e exporta as anotações
     *
     */
    function exportarAnotacoes() {
        $this->layout = '';
        $fields['Disciplina'] = $_GET['Disciplina'];
        $fields['Curso'] = $_GET['Curso'];
        $fields['GrupoAulaID'] = $_GET['GrupoAulaID'];

        $result = $this->curso->exporta_AnotacoesVideoAula($fields);

        $filename = $_GET['Curso'] . ".txt";
        $dados = $disciplina = $data = $aulaID = '';

        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . basename($filename) . '"');
        foreach ($result as $lista) {
            if ($disciplina != $lista->Descricao) {
                if ($disciplina != '')
                    $dados.= "\r\n\r\n";
                $disciplina = $lista->Descricao;
                echo "[" . iconv("ISO-8859-1", "UTF-8", $lista->Descricao) . "]\r\n";
            }
            if ($aulaID != $lista->AulaID) {
                $aulaID = $lista->AulaID;
                echo "\r\n[" . $lista->AulaID . "  " . iconv("ISO-8859-1", "UTF-8", $lista->Tema) . "]\r\n";
                $data = '';
            }
            if ($data != $lista->DtAnotacao) {
                $data = $lista->DtAnotacao;
                echo "[" . $lista->DtAnotacao . "]\r\n";
            }
            echo "[" . iconv("ISO-8859-1", "UTF-8", $lista->Anotacoes) . "]\r\n";
            //flush(); // this is essential for large downloads
        }
        exit;
    }

    /**
     * Conteúdo Vídeo
     *
     * Realiza a atualização do conteúdo da página html sem necessidade de refresh
     *
     * @param string $controller  identificador da ação
     * @param string $ancora      identificador da disciplina
     * @access private
     * @return json
     */
    function paramsContentVideo($controller = null, $ancora = null) {
        $this->layout = '';

        $anotacoes = '';



        $data['AssinaturaMatriculaID'] = $this->session->userdata('assinaturaMatriculaID');
        $retornoVerificaPacotesAluno = $this->home->verificaGrupoAulaAncora($this->session->userdata('Ancora'));
        $curso = isset($retornoVerificaPacotesAluno[0]['Descricao']) ? $retornoVerificaPacotesAluno[0]['Descricao'] : '';

        if ($retornoVerificaPacotesAluno) {

            $classificacaoID = $this->session->userdata('ClassificacaoPacotePai');

			$curso = $this->session->userdata('DescricaoPacote');
			$grupoAulaID = $retornoVerificaPacotesAluno[0]['id'];

            $dados = $this->curso->verificaVideoAula(5);//print_pre($this->uri->segment(5));die;
            $nomeVideo = $dados[0]['Tema'];
            $aulaID = $dados[0]['AulaID'];
            $linkVideoaula = $dados[0]['Video'];
            $pdf = str_replace('.mp4', '.pdf', $dados[0]['Video']);
            $pdf = str_replace('.flv', '.pdf', $dados[0]['Video']);

            $result = $this->curso->verificaDisciplina($dados[0]['DisciplinaID'], $grupoAulaID);
            $disciplina = $result[0]['Descricao'];
            $verificaAcaoVideoAula = $this->curso->verificaAcaoVideoAula($aulaID);

            $id = '';
            $situacaoVideoAula = 'N';
            $estiloBtnFinalizar = '';
            if (empty($verificaAcaoVideoAula)) {
                $id = $this->curso->inserir_acaoVideoAula($aulaID);
            } else if (isset($verificaAcaoVideoAula[0]['AulaAssistida']) && $verificaAcaoVideoAula[0]['AulaAssistida'] === 'S') {
                $situacaoVideoAula = $verificaAcaoVideoAula[0]['AulaAssistida'];
            }

            // Verifica Curtir / Descurtir
            if (isset($verificaAcaoVideoAula[0]['AulaCurtida']) && $verificaAcaoVideoAula[0]['AulaCurtida'] == 'S') {

                $curtir = "style='background-position: -426px -90px;')";
                $descurtir = '';
            } else if (isset($verificaAcaoVideoAula[0]['AulaCurtida']) && $verificaAcaoVideoAula[0]['AulaCurtida'] == 'N') {

                $curtir = '';
                $descurtir = "style='background-position: -563px -90px;'";
            } else {

                $curtir = '';
                $descurtir = '';
            }


            if ($situacaoVideoAula == 'S') {
                $estiloBtnFinalizar = "style='background-position: -143px -90px;'";
            }


            $this->session->set_userdata('VideoAulaAcaoID', $id ? $id : $verificaAcaoVideoAula[0]['VideoAulaAcaoID']);
            $anotacoes = $this->curso->verifica_AnotacoesVideoAula($aulaID);


            $VideoAulaAcaoID = $id ? $id : $verificaAcaoVideoAula[0]['VideoAulaAcaoID'];

            $htmlAnotacoes = '';
            if ($anotacoes) {
                $total = count($anotacoes);

                for ($i = 0; $i < $total; $i++) {

                    $descricao = $anotacoes[$i]->Anotacoes;
                    $sequencia = $i + 1;
                    $display = 'display:none;';
                    $current = '_current';

                    if ($sequencia <= '3') {
                        $display = '';
                        $current = '';
                    }

                    $htmlAnotacoes .= '<ul  id="p' . $sequencia . '" style="' . $display . '"  class="anotacao ' . $current . '">
                                         <li class="data">' . $anotacoes[$i]->DtAnotacao . '</li>
                                         <li class="texto">' . $descricao . '</li>
                                      </ul>';
                }
            }
        } else {

            $obj['.titulo'] = utf8_encode("Nenhum videoaula encontrada para sequência!");
            print(json_encode($obj));
        }

            $this->session->set_userdata('link_video_aula', $linkVideoaula);
            $this->session->set_userdata('cursonome', utf8_encode($curso));
            $this->session->set_userdata('aulaid', $dados[0]['AulaID']);
            $this->session->set_userdata('tema', utf8_encode($dados[0]['Tema']));
            $videoPlayer = '<iframe width="100%" height="100%" scrolling="no" src="'.base_url().'api-video" mozallowfullscreen webkitallowfullscreen allowfullscreen></iframe>';

        if ($this->agent->is_mobile() ||  ($this->agent->browser() == 'Firefox' && $this->agent->version() >= 11) || ($this->agent->browser() == 'Chrome' && $this->agent->version() >= 25) || ($this->agent->browser() == 'Safari' && $this->agent->version() >= 6)  ) { // true
            $data['tipo'] = 'playerHTML5';
        } else {
            $data['tipo'] = 'player';
        }


        $descricaopdfString = explode('/', $pdf);
        $descricaopdf = '"' . base64_encode($descricaopdfString[0]) . '"';
        $pdf = '"' . base64_encode($pdf) . '"';
        $arquivo = PATH_PDF . base64_decode($pdf);
        $urlPdfExiste = verificaURL($arquivo);

        if ($urlPdfExiste) {
            $htmlPDF = "<a onClick= 'downloadPDf($pdf, $descricaopdf)' href='JavaScript:void(0);' class='btn btn-primary' title='Ler livro'>ler livro</a>";
        } else {
            $htmlPDF = 'Nenhum Livro Encontrado!';
        }


        $hrefBtnFinalizar = "id='finalizar_aula'";
        $hrefBtnCurtir = "id='curtir_aula'";
        $hrefBtnDescurtir = "id='descurtir_aula'";


        $obj['.curso a'] = utf8_encode("$curso");
        $obj['.disciplina'] = utf8_encode("$disciplina");
        $obj['.titulo'] = utf8_encode("$nomeVideo");
        $obj['#livros p span'] = utf8_encode("$nomeVideo");
        $obj['.lerLivro'] = utf8_encode("<html>$htmlPDF</html>");
        $obj['#update'] = utf8_encode("<html>$htmlAnotacoes</html>");
        $obj['.btns ul li.finalizar'] = utf8_encode("<html><a $hrefBtnFinalizar href='#' $estiloBtnFinalizar title='Clicando aqui você irá marcar como aula já vista'></a></html>");


        $obj['.curtir'] = utf8_encode("<html><a $hrefBtnCurtir href='#' $curtir title='Clicando você irá curtir esta aula'></a></html>");
        $obj['.descurtir'] = utf8_encode("<html><a $hrefBtnDescurtir href='#' $descurtir title='Clicando você irá descurtir esta aula'></a></html>");

        $obj['#params'] = utf8_encode("<html><input id='aulaID' value='$aulaID' type='hidden'><input id='situacaoVideo' type='hidden' value='$situacaoVideoAula'><input type='hidden' value='$VideoAulaAcaoID' id='VideoAulaAcaoID'><input type='hidden' name='motivoid' > <input type='hidden' name='observacao'></html>");
        $obj['.playerHTML5'] = utf8_encode("<html>$videoPlayer</html>");

		$questoes = $this->curso->getQuestoesAula($grupoAulaID,$aulaID);
		if(!empty($questoes)){
			$obj['#linkQuestoes'] = utf8_encode('Questões - <a href="'.base_url().'curso/'.$this->uri->segment(3).'/'.$this->uri->segment(4).'/'. $this->uri->segment(5).'/'.$this->uri->segment(6).'?questao=true">'.$nomeVideo.'</a>');
		}else{
			$obj['#linkQuestoes'] = '';
		}

        print(json_encode($obj));
        die;
    }

    /**
     * Conteúdo Questão
     *
     * Realiza a atualização do conteúdo da página html sem necessidade de refresh
     *
     * @param string $controller  identificador da ação
     * @param string $ancora      identificador da disciplina
     * @access private
     * @return json
     */
    function paramsContentQuestao($controller = null, $ancora = null) {

        $this->layout = '';


        $anotacoes = '';

        $data['AssinaturaMatriculaID'] = $this->session->userdata('assinaturaMatriculaID');
        $retornoVerificaPacotesAluno = $this->home->verificaPacotesAluno($data, $this->configuracoes[0]['Base']);
        $curso = isset($retornoVerificaPacotesAluno[0]['DescricaoPacote']) ? $retornoVerificaPacotesAluno[0]['DescricaoPacote'] : null;

        if ($retornoVerificaPacotesAluno) {

            $classificacaoID = $this->session->userdata('ClassificacaoPacotePai');

            // assinatura completa
            if ($classificacaoID == 5) {
                $grupoAulaID = $this->session->userdata('grupoAulaID');
                $curso = $this->session->userdata('DescricaoPacote');
            } else {
                $grupoAulaID = $retornoVerificaPacotesAluno[0]['GrupoAulaID'];
            }

            $dados = $this->curso->verificaVideoAula(5);
            $nomeVideo = $dados[0]['Tema'];
            $aulaID = $dados[0]['AulaID'];

            //busca dados da questao
            $data['questaoAtual'] = $this->uri->segment(7) ? $this->uri->segment(7) : 0;

            $questoes = $this->curso->getQuestoesAula($grupoAulaID, $aulaID);
            $data['qtdQuestoes'] = count($questoes);
            $array = array('questao' => $questoes[$data['questaoAtual']]['QuestaoID']);

            $result = $this->curso->CarregaQuestaoAPI($array['questao']);

            if (isset($result['success']) && $result['success'] == 1) {
                //dados da questao
                $dadosQuestao = $result['message'];

                $questaoAtual = $this->uri->segment(7) ? ($this->uri->segment(7) + 1) : 1;
                $qtdQuestoes = count($questoes);

                //comentarios da questao
                $coments = api_use('questao/comentarios/listar', $array);
                $dadosQuestaoComent = $this->comentariosQuestoes($coments['message']);

                //estatisticas
                $estatisticas = api_use('questao/estatistica', $array);
                $estatisticas = $this->estatisticasQuestoes($estatisticas['message']);

                //grava no cookie as alternativas da questao para buscar no combo de erros
                $cookie = array(
                    'name' => 'alternativas',
                    'value' => json_encode($dadosQuestao['questao']['alternativas']),
                    'expire' => 14400,
                    'domain' => ".aprovaconcursos.com.br",
                    'secure' => FALSE
                );
                $this->input->set_cookie($cookie);
            }
        } else {

            $obj['.titulo'] = utf8_encode("Nenhum quest&atilde;o encontrada para sequ&ecirc;ncia!");
            print(json_encode($obj));
        }

        //monta o html que sera utilizado
        //cabeçalho da questao
        $obj['.prova'] = utf8_encode("Prova: <a>" . utf8_decode($dadosQuestao['questao']['prova'][0]['nome']) . " </a><br>");
        $obj['#disciplinaAssunto'] = utf8_encode("Disciplina: <a>" . utf8_decode($dadosQuestao['questao']['disciplina'][0]['nome']) . "</a> | Assuntos: <a> " . (isset($dadosQuestao['questao']['assunto'][0]['nome']) ? utf8_decode($dadosQuestao['questao']['assunto'][0]['nome']) : '') . "</a>");
        $obj['#idQuestao'] = utf8_encode("Q" . utf8_decode($dadosQuestao['questao']['id']));
        $obj['.spanQuestoes'] = utf8_encode($questaoAtual . " de " . $qtdQuestoes);


        $dificuldade = '';
        if (utf8_decode($dadosQuestao['questao']['dificuldade']['nome']) == 'Muito Fácil') {
            $dificuldade = 1;
        } else if (utf8_decode($dadosQuestao['questao']['dificuldade']['nome']) == 'Fácil') {
            $dificuldade = 2;
        } else if (utf8_decode($dadosQuestao['questao']['dificuldade']['nome']) == 'Médio') {
            $dificuldade = 3;
        } else if (utf8_decode($dadosQuestao['questao']['dificuldade']['nome']) == 'Difícil') {
            $dificuldade = 4;
        } else if (utf8_decode($dadosQuestao['questao']['dificuldade']['nome']) == 'Muito Difícil') {
            $dificuldade = 5;
        }

        $hide = '';
        $titleAcompanharQuestao = 'Acompanhar questão';
        $icoAcompanhar = 'icon-desacompanhar';
        $titleResponderQuestao = 'Responder mais tarde';
        $icoResponder = 'icon-naoresponder';

        if ($dadosQuestao['questao']['acompanhando'] == 1) {
            $titleAcompanharQuestao = 'Desacompanhar questão';
            $icoAcompanhar = 'icon-acompanhar';
        }

        if ($dadosQuestao['questao']['responderMaisTarde'] == 1) {
            $titleResponderQuestao = 'Deixar de responder mais tarde';
            $icoResponder = 'icon-responder';
        }

        $obj['#icones-questao'] = utf8_encode('<a class="btn-mais-tarde show-tooltip" id="respMaisTarde" onClick="responderMaisTarde();" style="cursor:pointer;' . $hide . '" title="' . $titleResponderQuestao . '">
													<span id="ico-responder" class="' . $icoResponder . '"></span>
												</a>

												<a class="btn-acompanhar btn-on show-tooltip" id="queAcompanhar" onClick="acompanharQuestao();" style="cursor:pointer;' . $hide . '" title="' . $titleAcompanharQuestao . '">
													<span id="ico-acompanhar" class="' . $icoAcompanhar . '"></span>
												</a>');


        $obj['#iconeDificuldade'] = utf8_encode('<span class="ico-group status " style="display:none;" id="dificuldadeQuestao" >
													<span class="icon-level-' . $dificuldade . ' dificuldade show-tooltip" title="Difícil"></span>
													<span class="txt">Dificuldade:</span>
												</span>
												<span class="ico-group status " id="status-questao"></span>');

        if ($dadosQuestao['questao']['respondidaAnteriormente'] == 1) {
            if ($dadosQuestao['questao']['acertouAnteriormente'] == 1) {
                $obj['#status-questao'] = utf8_encode('<span class="icon-acertou show-tooltip" title="Você acertou essa questão."></span>');
            } else {
                $obj['#status-questao'] = utf8_encode('<span class="icon-errou show-tooltip" title="Você errou essa questão."></span>');
            }
        }

        //pergunta e alternativas

        if ($dadosQuestao['questao']['textoAssociado'] != '') {
            $obj['.texto-associado'] = utf8_encode('<a onClick="toogleTxtAssociado();" class="btn btn-mini btn-default" style="width: 230px;"><span class="icon-align-left"></span> <em id="btnAssociado">Mostrar texto associado à questão</em></a><br>
													<div class="texto-associado-content" style="display: none;">
														' . utf8_decode($dadosQuestao['questao']['textoAssociado']) . '
													</div><br/>');
        } else {
            $obj['.texto-associado'] = '';
        }

        $obj['.enunciado'] = utf8_encode(utf8_decode($dadosQuestao['questao']['enunciado']));

        $altHTML = '';
        for ($i = 0; count($dadosQuestao['questao']['alternativas']) > $i; $i++) {

            $altHTML .= '<li>
						<input id="alternativa_q' . $dadosQuestao['questao']['id'] . '_' . $dadosQuestao['questao']['alternativas'][$i]['id'] . '" class="radio-resposta" name="questao-' . $dadosQuestao['questao']['id'] . '" type="radio" data-opcao="' . $dadosQuestao['questao']['alternativas'][$i]['valorOpcao'] . '" value="' . $dadosQuestao['questao']['alternativas'][$i]['id'] . '" data-correta="' . $dadosQuestao['questao']['alternativas'][$i]['opcaoCorreta'] . '" name="questao-' . $dadosQuestao['questao']['id'] . '" data-exibirac="sim">
						<label for="alternativa_q' . $dadosQuestao['questao']['id'] . '_' . $dadosQuestao['questao']['alternativas'][$i]['id'] . '">';

            if ($dadosQuestao['questao']['tipoResposta']['nome'] == 'Certo/Errado') {
                $altHTML .= utf8_decode($dadosQuestao['questao']['alternativas'][$i]['opcao']);
            } else {
                $altHTML .= '<span>' . $dadosQuestao['questao']['alternativas'][$i]['valorOpcao'] . ')</span> ' . utf8_decode($dadosQuestao['questao']['alternativas'][$i]['opcao']);
            }


            $altHTML .= '</label>
					</li>';
        }
        $obj['#alternativas'] = utf8_encode("$altHTML");

        //hiddens da questao
        //resposta
        for ($a = 0; count($dadosQuestao['questao']['alternativas']) > $a; $a++) {
            if ($dadosQuestao['questao']['alternativas'][$a]['opcaoCorreta'] == 1) {
                $altCorreta = $dadosQuestao['questao']['alternativas'][$a]['id'];
                $opcaoCorreta = $dadosQuestao['questao']['alternativas'][$a]['valorOpcao'];
            }
        }

        $obj['#dadosQuestao'] = utf8_encode('<input id="questaoID" type="hidden" value="' . $dadosQuestao['questao']['id'] . '">
												<input id="questaoRespondida" type="hidden" value="0">
												<input id="quest" type="hidden" value="' . $altCorreta . '_' . $opcaoCorreta . '">');

        //comentarios
        $qtdComments = count($coments['message']['comentarios']) > 0 ? count($coments['message']['comentarios']) : 0;
        $obj['#spanComment'] = utf8_encode('<a id="btComments" class="btn btn-default btn-golden" data-tab="comentario" onclick="toogleComments()">
												<i class="glyphicon glyphicon-comment"></i>
												Comentários (' . $qtdComments . ')
											</a>');
        $obj['#comments'] = utf8_encode($dadosQuestaoComent);

        //estatisticas
        $obj['.estatisticas'] = utf8_encode($estatisticas);

        $obj['#slugDisciplina'] = $dadosQuestao['questao']['disciplina'][0]['slug'];

        $obj['#aulaID'] = $aulaID;
        $obj['#disciplinaID'] = $dados[0]['DisciplinaID'];


        //video
        if (isset($resultApi['message']['questao']['urlVideo']) && $resultApi['message']['questao']['urlVideo'] != '') {
            $obj['#videoQuestoes'] = player($resultApi['message']['questao']['urlVideo'], 'questoes');
            $existevideo = 1;
            $obj['#classVideo'] = $this->classificacaoVideo($dadosQuestao['questao']['id'], $dadosQuestao['questao']['questao']);
        } else {
            $obj['#videoQuestoes'] = '';
            $existevideo = 0;
            $obj['#classVideo'] = '';
        }
        $actionVideo = $existevideo == 1 ? 'onclick="toogleVideo()"' : '';
        $qtdComments = count($coments['message']['comentarios']) > 0 ? count($coments['message']['comentarios']) : 0;
        $obj['#spanVideo'] = utf8_encode('<a id="btVideo" class="btn btn-default btn-golden" data-tab="comentario" ' . $actionVideo . '>
												<i class="glyphicon glyphicon-stats"></i>
												Vídeo (' . $existevideo . ')
											</a>');

        print(json_encode($obj));
        die;
    }

    /**
     * Vídeo SMIL
     *
     * Monta o XML para listagem dos videos
     *
     * @param object $nomearquivo[optional]
     * @param object $link[optional]
     * @access private
     * @return xml
     */
    function videoSmil($nomearquivo = '', $link = '') {

        $this->layout = '';

        header("Cache-Control: no-cache, must-revalidate");
        header("Expires: Mon, 29 Jul 2014 07:00:00 GMT");
        header("Content-Type: application/smil");
        header('Content-Disposition: attachment; filename="' . $link . '"');

        if (strchr(base64_decode($nomearquivo), '.mp4')) {
            $arquivo = 'mp4:videos1/aulas/' . base64_decode($nomearquivo);
        } else {
            $arquivo = 'flv:videos1/aulas/' . str_replace('.flv', '', base64_decode($nomearquivo));
        }

        // Monta o xml SMIL com a URL utilizada para o arquivo de video
        $smil = '<smil>
                      <head>
                         <meta base="rtmp://videoaulas.portalava.com.br/fb48-1/" />
                      </head>
                      <body>
                        <switch>
                            <video src="' . $arquivo . '" />
                        </switch>
                    </body>
              </smil>';

        print($smil);
    }

    /**
     * Download PDF
     *
     * Realiza o download do arquivo pdf
     *
     * @param object $arquivo  descricao do arquivo criptografado em base64_encode
     * @param object $nome     titulo do arquivo
     * @access public
     * @return void
     */
    public function downloadPDF($arquivo, $nome) {

        $this->layout = '';
        $arquivo = str_replace('.mp4', '.pdf', $arquivo);
        $arquivo = str_replace('.flv', '.pdf', $arquivo);
        header("Content-Disposition: attachment; filename=" . base64_decode($nome) . ".pdf");
        header("Content-Type: application/octet-stream");
        readfile($arquivo);
        die;
    }

    public function downloadPDFAjax($arquivo, $nome) {

        $this->layout = '';
        if (strpos(base64_decode($arquivo),PDFS)===false){
            $arquivo = PATH_PDF . base64_decode($arquivo);
            $arquivo = str_replace('.mp4', '.pdf', $arquivo);
            $arquivo = str_replace('.flv', '.pdf', $arquivo);
        }else
            $arquivo = base64_decode($arquivo);

        $exist = get_headers($arquivo);
        $exist = stripos($exist[0],"200 OK");
        if($exist){
            //arquivo existe no link passado
            print(json_encode(1));
        } else {
            //arquivo não existe no link passado
            print(json_encode(2));
        }
        die;
    }

    function questoesEsimulados() {

        if ($this->session->userdata('logado') == TRUE) {
            $this->cssMinify[] = 'questoes-e-simulados';
            $this->css[] = $this->minify->getCSS('questoesEsimulados_v1.min', $this->cssMinify, ENVIRONMENT);

            $this->menu_vertical = $this->load->view('view_menu', '', true);

            $this->load->view('questoes-e-simulados');
        } else {

            echo
            '<script>
                 window.location.href=\'' . base_url() . '\';
            </script>';
            die;
        }
    }

    function responderQuestaoAprova() {

        $dados['questao'] = $this->input->post('questaoId');
        $dados['opcao'] = $this->input->post('resposta');

        $aulaId = $this->input->post('aulaId');
        $disciplinaId = $this->input->post('disciplinaId');

        $result = api_use('questao/responder', $dados, 2);

        //grava log das questoes respondidas
        if ($result['success']) {

            $this->curso->gravaQuestoesRespondidadas($dados['questao'], $aulaId, $disciplinaId);
        }

        print_r($result['success']);
        die;
    }

    function classificaComentario() {

        $dados['comentario'] = $this->input->post('comentarioID');
        $dados['tipo'] = $this->input->post('classificacao');
        $qtdClassificacao = $this->input->post('qtdClass');

        $result = api_use('questao/comentario/classificar', $dados, 2);

        $return = new stdClass();

        if (!$result['success']) {

            $return->success = 0;
            $return->message = $result['message'];
        } else {
            $return->success = 1;

            if ($dados['tipo'] == 1) {
                $return->classificacao = '<a id="classPos-' . $dados['comentario'] . '" class="btn btn-link btn-bom show-tooltip btn-disabled" title="' . $result['tooltip'] . '">
						<span class="icon-bom"></span>
						<em>' . ($qtdClassificacao + 1) . '</em>
						</a>';
            } else if ($dados['tipo'] == 2) {
                $return->classificacao = '<a id="classNeg-' . $dados['comentario'] . '" class=" btn btn-link btn-ruim show-tooltip btn-disabled" title="' . $result['tooltip'] . '">
						<span class="icon-ruim"></span>
						<em>' . ($qtdClassificacao + 1) . '</em>
						</a>';
            } elseif ($dados['tipo'] == 3) {
                $return->classificacao = '<a id="classReg-' . $dados['comentario'] . '" class="btn btn-link btn-regular show-tooltip btn-disabled" title="' . $result['tooltip'] . '">
						<span class="icon-regular"></span>
						<em>' . ($qtdClassificacao + 1) . '</em>
						</a>';
            }
        }

        print( json_encode($return));
        die;
    }

    function comentariosQuestoes($dadosQuestaoComent) {

        $usuarioQuestoes = $this->session->userdata('idUserQuestoes');
        $html = '';


        $html .= '<div class="comentarios">';

        if (count($dadosQuestaoComent['comentarios']) == 0) {
            $html .= '<h3>Nenhum comentário encontrado</h3>';
        } else {
            $html .= '<h3>Comentários Recentes</h3>';
        }

        for ($i = 0; count($dadosQuestaoComent['comentarios']) > $i; $i++) {

            $classPos = '';
            //$classReg = '';
            //$classNeg = '';
            if ($dadosQuestaoComent['comentarios'][$i]['classificou'] == true) {

                $classPos = 'btn-disabled';
                /* if($dadosQuestaoComent['comentarios'][$i]['classificouTipo'] == 'Positivo'){
                  $classPos = 'btn-disabled';
                  }else if ($dadosQuestaoComent['comentarios'][$i]['classificouTipo'] == 'Regular'){
                  $classReg = 'btn-disabled';
                  }else if ($dadosQuestaoComent['comentarios'][$i]['classificouTipo'] == 'Negativo'){
                  $classNeg = 'btn-disabled';
                  } */
            }

            $html .= '

						<div class="comentario-box row">
							<div class="span11 comentario-header">
								<h5>Comentado por <a ><strong>' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['cliente']['nome']) . '</strong></a></h5>
								<div class="pull-right votacao votacao-comentario-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '">
									<div class="pull-left">
										<span id="avaliacao-comentarios-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '" >';

            //o usuario nao pode classificar o proprio comentario
            if ($usuarioQuestoes != $dadosQuestaoComent['comentarios'][$i]['cliente']['id'] && $dadosQuestaoComent['comentarios'][$i]['classificou'] == false) {
                $html .= '<span id="txtPositivo-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '">
												<a id="classPos-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '" href="javascript:classificar(1, ' . $dadosQuestaoComent['comentarios'][$i]['id'] . ',' . $dadosQuestaoComent['comentarios'][$i]['voto']['positivo'] . ');" class="btn btn-link btn-bom show-tooltip " title="' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['voto']['positivo_title']) . '">
												<span class="icon-bom"></span>
												<em>' . $dadosQuestaoComent['comentarios'][$i]['voto']['positivo'] . '</em>
												</a>
											</span>
											<span id="txtNeutro-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '">
												<a id="classReg-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '" href="javascript:classificar(3, ' . $dadosQuestaoComent['comentarios'][$i]['id'] . ',' . $dadosQuestaoComent['comentarios'][$i]['voto']['neutro'] . ');" class="btn btn-link btn-regular show-tooltip" title="' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['voto']['neutro_title']) . '">
												<span class="icon-regular"></span>
												<em>' . $dadosQuestaoComent['comentarios'][$i]['voto']['neutro'] . '</em>
												</a>
											</span>
											<span id="txtNegativo-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '" >
												<a id="classNeg-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '" href="javascript:classificar(2, ' . $dadosQuestaoComent['comentarios'][$i]['id'] . ',' . $dadosQuestaoComent['comentarios'][$i]['voto']['negativo'] . ');" class=" btn btn-link btn-ruim show-tooltip" title="' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['voto']['negativo_title']) . '">
												<span class="icon-ruim"></span>
												<em>' . $dadosQuestaoComent['comentarios'][$i]['voto']['negativo'] . '</em>
												</a>
											</span>
											<input type="hidden" id="classComment-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '" value="0">';
            } else {
                $html .= '<span id="txtPositivo-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '">
												<a id="classPos-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '" class="btn btn-link btn-bom show-tooltip ' . $classPos . '" title="' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['voto']['positivo_title']) . '" style="cursor:initial;">
												<span class="icon-bom"></span>
												<em>' . $dadosQuestaoComent['comentarios'][$i]['voto']['positivo'] . '</em>
												</a>
											</span>
											<span id="txtNeutro-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '">
												<a id="classReg-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '" class="btn btn-link btn-regular show-tooltip ' . $classPos . '" title="' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['voto']['neutro_title']) . '" style="cursor:initial;">
												<span class="icon-regular"></span>
												<em>' . $dadosQuestaoComent['comentarios'][$i]['voto']['neutro'] . '</em>
												</a>
											</span>
											<span id="txtNegativo-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '">
												<a id="classNeg-' . $dadosQuestaoComent['comentarios'][$i]['id'] . '" class=" btn btn-link btn-ruim show-tooltip ' . $classPos . '" title="' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['voto']['negativo_title']) . '" style="cursor:initial;">
												<span class="icon-ruim"></span>
												<em>' . $dadosQuestaoComent['comentarios'][$i]['voto']['negativo'] . '</em>
												</a>
											</span>';
            }


            $html .= '</span>
									</div>
								</div>
								<div class="clear"></div>
							</div>
							<div class="span2 comentario-profile">
								<div class="">
									<a >';

            if ($dadosQuestaoComent['comentarios'][$i]['cliente']['foto'] != '') {
                $foto = $dadosQuestaoComent['comentarios'][$i]['cliente']['foto'];
            } else {
                //trocar a imagem para o link de produçao antes de subir
                $foto = PATH_IMG_SITE . 'sem-foto.gif';
            }

            $html .= '<img class="foto-comentario" src="' . $foto . '" href="http://www.aprovaconcursos.com.br/questoes-de-concurso/cliente/perfil/' . $dadosQuestaoComent['comentarios'][$i]['cliente']['id'] . '">
									</a>
								</div>
								<div class="">
									<div class="nivel">
										<span class="icon icon-' . $dadosQuestaoComent['comentarios'][$i]['cliente']['rankingAvatarCss'] . '"></span>
										<strong class="ranking">' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['cliente']['rankingAvatar']) . '</strong>
									</div>
									<ul class="list-unstyled">
										<li>Comentários: <span>' . $dadosQuestaoComent['comentarios'][$i]['cliente']['qtdComentario'] . '</span></li>
										<li>Questões resolvidas: <span>' . $dadosQuestaoComent['comentarios'][$i]['cliente']['qtdQuestoes'] . '</span></li>
										<li>Data registro: <span>' . date('d/m/Y', strtotime($dadosQuestaoComent['comentarios'][$i]['cliente']['qtdQuestoes'])) . '</span></li>
										<li>Localização: <span>' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['cliente']['cidade']) . ' - ' . $dadosQuestaoComent['comentarios'][$i]['cliente']['estado'] . '</span></li>
									</ul>';

            if ($usuarioQuestoes != $dadosQuestaoComent['comentarios'][$i]['cliente']['id']) {
                $html .= '<div class="responder-recado">
											<a href="javascript:enviarMsg(' . $dadosQuestaoComent['comentarios'][$i]['cliente']['id'] . ');" data-para="' . $dadosQuestaoComent['comentarios'][$i]['cliente']['id'] . '" class="enviar-recado-para"><span class="icon-comment"></span> Enviar Mensagem</a>
										</div>';
            }

            $html .= '</div>
							</div>
							<div class="span9 comentario-content">
								' . utf8_decode($dadosQuestaoComent['comentarios'][$i]['comentario']) . '
							</div>';

            if ($usuarioQuestoes != $dadosQuestaoComent['comentarios'][$i]['cliente']['id']) {
                $html .= '<div class="comentario-footer clear row">
									<div class="span2"></div>
									<div class="span9">
										<span class="pull-left denunciar">
											<a class="denunciar-comentario btn btn-link btn-xs" href="javascript:denunciarMsg(' . $dadosQuestaoComent['comentarios'][$i]['id'] . ');" data-comentario="9589"><span class="icon-warning-sign"></span> Denunciar</a>
										</span>
									</div>
									<div class="clear"></div>
								</div>';
            } else {
                $html .= '<div class="col-md-9">
									<span class="pull-left excluir">
										<a onclick="excluirComentario(' . $dadosQuestaoComent['comentarios'][$i]['id'] . ')" class="btn btn-link btn-xs"><span class="icon-trash"></span> Excluir</a>
									</span>
									<span class="pull-left editar">
										<a onclick="editarComentario(' . $dadosQuestaoComent['comentarios'][$i]['id'] . ')" class="btn btn-link btn-xs"><span class="icon-pencil"></span> Editar</a>
									</span>
								</div>
								';
            }

            $html .= '</div>
					';
        }

        if (count($dadosQuestaoComent['comentarios']) == 0) {
            $hide = 'block';
        } else {
            $hide = 'none';
        }


        $html .= '<div class="spacing-bottom spacing-left">
					<a class="abrirTextareaComentario btn btn-primary btn-questao" data-questaoid="107" id="btnComentario" onClick="enviarComment();"><span class="icon-plus icon-white"></span> Adicionar novo Comentário</a>
				</div>
				</br>
				<div id="newComment" class="spacing-left spacing-right spacing-top spacing-bottom" style="display:none">
					<h3 class="spacing-top spacing-bottom" style="display:none;" id="titleEdit">Editar Comentário </h3>
					<textarea id="novoComentario" style="width: 459px; height: 121px;" rows="10" cols="30"></textarea><br><br>
					<button class="abrirTextareaComentario btn btn-primary btn-questao" id="salvarComentario" onClick="salva_comentario();">Salvar</button>
					<button class="abrirTextareaComentario btn btn-primary btn-questao" id="cancelarComentario" onClick="enviarComment();">Cancelar</button>
					<input type="hidden" id="acao" value="G">
					<input type="hidden" id="commentID" value="">
				</div>
			</div>';


        return $html;
    }

    function estatisticasQuestoes($estatisticas) {

        $valores = '';
        $alt = '';

        if (!isset($estatisticas['estatistica']['alternativas'])) {
            return false;
        }


        foreach ($estatisticas['estatistica']['alternativas'] as $value) {

            $valores .= $value['resposta'] . ',';
            $alt .= $value['nome'] . '|';
        }

        $valores = substr($valores, 0, -1);
        $alt = substr($alt, 0, -1);


        $html = '<h3>Esta questo foi resolvida ' . $estatisticas['estatistica']['total'] . ' vezes</h3>
				<div class="row">
					<div class="span6 estatistica-box">
						<h4>Quantidade de acertos e erros:</h4>
						<div id="boxStats">
							<img src="https://chart.googleapis.com/chart?chs=330x100&amp;chd=t:' . $estatisticas['estatistica']['acerto'] . ',' . $estatisticas['estatistica']['erro'] . '&amp;cht=p3&amp;chl=Acertaram (' . $estatisticas['estatistica']['acerto'] . ')|Erraram (' . $estatisticas['estatistica']['erro'] . ')&amp;&amp;chma=5,5,5,5&amp;chds=0,430&amp;chco=13b745,cb1414">
						</div>
					</div>
					<div class="span5 estatistica-box">
						<h4>Alternativas mais respondidas:</h4>
						<div id="boxStats">
							<img src="https://chart.googleapis.com/chart?chs=330x100&amp;chd=t:' . $valores . '&amp;cht=p3&amp;chl=' . $alt . '&amp;&amp;chma=5,5,5,5&amp;chds=0,67&amp;chco=39608e,4572a7,4f81bd,93a9cf,bcc8df">
						</div>
					</div>
				</div>
				<hr>';

        return $html;
    }

    function classificacaoVideo($questaoID, $dados) {

        $html = '';

        if ($dados['videoClassificou'] == false) {
            $html .= '<span id="vidPositivo-' . $questaoID . '">
							<a id="classVidPos-' . $questaoID . '" href="javascript:classificarVideo(1, ' . $questaoID . ');" class="btn btn-link btn-bom show-tooltip " title="' . utf8_decode($dados['videoClassificacaoPositivaTitle']) . '" >
							<span class="icon-bom"></span>
							<em>' . $dados['videoClassificacaoPositiva'] . '</em>
							</a>
						</span>
						<span id="vidNegativo-' . $questaoID . '" >
							<a id="classVidNeg-' . $questaoID . '" href="javascript:classificarVideo(2, ' . $questaoID . ');" class=" btn btn-link btn-ruim show-tooltip" title="' . utf8_decode($dados['videoClassificacaoNegativaTitle']) . '">
							<span class="icon-ruim"></span>
							<em>' . $dados['videoClassificacaoNegativa'] . '</em>
							</a>
						</span>
						<input type="hidden" id="classVidComment-' . $questaoID . '" value="0">';
        } else {
            $html .= '<span id="vidPositivo-' . $questaoID . '">
							<a id="classVidPos-' . $questaoID . '" class="btn btn-link btn-bom show-tooltip btn-disabledVideo"  style="cursor:initial;" title="' . utf8_decode($dados['videoClassificacaoPositivaTitle']) . '">
							<span class="icon-bom"></span>
							<em>' . $dados['videoClassificacaoPositiva'] . '</em>
							</a>
						</span>
						<span id="vidNegativo-' . $questaoID . '">
							<a id="classVidNeg-' . $questaoID . '" class=" btn btn-link btn-ruim show-tooltip btn-disabledVideo"  style="cursor:initial;" title="' . utf8_decode($dados['videoClassificacaoNegativaTitle']) . '">
							<span class="icon-ruim"></span>
							<em>' . $dados['videoClassificacaoNegativa'] . '</em>
							</a>
						</span>';
        }

        return $html;
    }

    function enviarMsg() {

        $this->layout = '';
        $fields['clienteID'] = $this->input->post('idCliente');
        $fields['acaoMsg'] = $this->input->post('acaoMsg');

        $html = '';

        if ($fields['acaoMsg'] == 'modal') {
            // Busca todas motivos cadastrados ativos para Descurtir
            $todos = $this->curso->busca_motivos($fields);

            // Monta Layout
            $html .= '<textarea id="descricaoMsg-' . $fields['clienteID'] . '" style="width: 459px; height: 121px;" rows="10" cols="30">Escreva aqui a mensagem!</textarea><br><br>
			<input type="checkbox" id="recadoPrivado-' . $fields['clienteID'] . '"> Recado privado';

            print_r($html);
            die;
        } elseif ($fields['acaoMsg'] == 'gravar') { // gravar
            $dados['clientePara'] = $fields['clienteID'];
            $dados['privado'] = $this->input->post('msgPrivada');
            $dados['recado'] = utf8_decode($this->input->post('descricaoMsg'));

            $result = api_use('recado/cadastrar', $dados, 2);

            print_r($result['success']);
            die;
        }
    }

    function denunciarMsg() {

        $this->layout = '';
        $fields['idMsg'] = $this->input->post('idMsg');
        $fields['acaoMsg'] = $this->input->post('acaoMsg');

        $html = '';

        if ($fields['acaoMsg'] == 'modal') {
            // Busca todas motivos cadastrados ativos para Descurtir
            $todos = $this->curso->busca_motivos($fields);

            // Monta Layout
            $html .= '<textarea id="descricaoDenuncia-' . $fields['idMsg'] . '" style="width: 459px; height: 121px;" rows="10" cols="30">Informe aqui a denuncia!</textarea><br>';

            print_r($html);
            die;
        } elseif ($fields['acaoMsg'] == 'gravar') { // gravar
            $dados['comentario'] = $fields['idMsg'];
            $dados['denuncia'] = utf8_decode($this->input->post('descricaoDenuncia'));

            $result = api_use('questao/comentario/denunciar', $dados, 2);

            print_r($result['success']);
            die;
        }
    }

    function salvarComentario() {

        $this->layout = '';

        $acao = $this->input->post('acao');

        //novo comentario
        if ($acao == 'G') {
            $dados['questao'] = $this->input->post('questaoID');
            $dados['comentario'] = $this->input->post('comentario');

            $result = api_use('questao/comentario/inserir', $dados, 2);
        } else { //edita Comentario
            $dados['comentario'] = $this->input->post('comentarioID');
            $dados['comentarioTexto'] = $this->input->post('comentario');

            $result = api_use('questao/comentario/editar', $dados, 2);
        }

        print_r($result['success']);
        die;
    }

    function excluirComentario() {

        $this->layout = '';
        $dados['comentario'] = $this->input->post('comentarioID');

        $result = api_use('questao/comentario/excluir', $dados, 2);

        print_r($result['success']);
        die;
    }

    function buscaOpcoesErro() {

        $this->layout = '';
        $tipoErro = $this->input->post('tipoErro');
        $slugDisciplina = $this->input->post('slugDisciplina');
        $questaoID = $this->input->post('questaoID');

        $dados = array();

        if ($tipoErro == 2) {
            $dados['questao'] = $questaoID;

            $result = json_decode(get_cookie('alternativas'));

            if (!empty($result)) {

                $html = '<h3><b style="color:red;">* </b>Op&ccedil;&atilde;o</h3>
						<select id="erroMotivo" name="erroMotivo" >';
                foreach ($result as $value) {

                    if ($value->valorOpcao != '') {
                        $html .= '<option value=" ">' . $value->valorOpcao . ') ' . $value->opcao . '</option>';
                    } else {
                        $html .= '<option value="' . $value->id . '">' . $value->opcao . '</option>';
                    }
                }
                $html .= '</select>';

                $result['success'] = 1;
            }
        } else if ($tipoErro == 3) {
            $dados['slug'] = $slugDisciplina;

            $result = api_use('disciplina/ver', $dados, 2);

            if ($result['success'] == 1) {

                $html = '<h3><b style="color:red;">* </b>Assunto</h3>
					<select id="erroMotivo" name="erroMotivo" >';
                foreach ($result['message']['disciplina']['assunto'] as $value) {
                    $html .= '<option value="' . $value['id'] . '">' . $value['nome'] . '</option>';
                }
                $html .= '</select>';
            }
        } else if ($tipoErro == 4) {
            $result = api_use('disciplinas/listar', $dados, 2);

            if ($result['success'] == 1) {

                $html = '<h3><b style="color:red;">* </b>Disciplina</h3>
						<select id="erroMotivo" name="erroMotivo" >';
                foreach ($result['message']['disciplinas'] as $value) {
                    $html .= '<option value="' . $value['id'] . '">' . $value['nome'] . '</option>';
                }
                $html .= '</select>';
            }
        }
        $return = new stdClass();

        $return->success = $result['success'];
        $return->html = $html;

        print( json_encode($return));
        die;
    }

    function enviaErro() {

        $this->layout = '';
        $dados['questao'] = $this->input->post('questaoID');
        $dados['questaoErroTipo'] = $this->input->post('tipoErro');
        $erroMotivo = $this->input->post('erroMotivo');
        $dados['justificativa'] = $this->input->post('justificativa');

        if ($dados['questaoErroTipo'] == 2) {
            $dados['questaoOpcaoResposta'] = $erroMotivo;
        } else if ($dados['questaoErroTipo'] == 3) {
            $dados['disciplina'] = $erroMotivo;
        } else if ($dados['questaoErroTipo'] == 4) {
            $dados['assunto'] = $erroMotivo;
        }


        $result = api_use('questao/informar-erro', $dados, 2);

        print_r($result['success']);
        die;
    }

    function responderMaisTarde() {

        $dados['questao'] = $this->input->post('questaoID');

        $result = api_use('questao/responder-mais-tarde', $dados, 2);

        $return = new stdClass();

        //marcado para responder mais tarde
        //print_pre(strpos($result['message'], 'removida'));die;
        if (strpos($result['message'], 'removida') === false) {

            $return->message = $result['message'];
            $return->titleHtml = 'Deixar de responder mais tarde';
            $return->classIcone = 'icon-responder';
        } else {

            $return->message = $result['message'];
            $return->titleHtml = 'Responder mais tarde';
            $return->classIcone = 'icon-naoresponder';
        }

        print( json_encode($return));
        die;
    }

    function acompanharQuestao() {

        $dados['questao'] = $this->input->post('questaoID');

        $result = api_use('questao/acompanhar', $dados, 2);

        $return = new stdClass();

        //marcado para responder mais tarde
        //print_pre(strpos($result['message'], 'removida'));die;
        if (strpos($result['message'], 'Desacompanhando') === false) {

            $return->message = $result['message'];
            $return->titleHtml = 'Desacompanhar quest&atilde;o';
            $return->classIcone = 'icon-acompanhar';
        } else {

            $return->message = $result['message'];
            $return->titleHtml = 'Acompanhar quest&atilde;o';
            $return->classIcone = 'icon-desacompanhar';
        }

        print( json_encode($return));
        die;
    }

    function classificarVideo() {

        $this->layout = '';
        $fields['idQuestao'] = $this->input->post('idQuestao');
        $fields['acaoVideo'] = $this->input->post('acaoVideo');
        $fields['classificacao'] = $this->input->post('classificacao');
        $fields['justificativa'] = $this->input->post('justificativa');
        $fields['motivo'] = $this->input->post('motivo');

        $html = '';

        if ($fields['acaoVideo'] == 'modal') {

            //descurtir
            if ($fields['classificacao'] == 2) {

                $array['tipo'] = 2;

                $result = api_use('dados-auxiliares/questao-erro-tipo', $array, 2);

                $html .= '<b style="color:red">* </b> Motivo: <br/>';

                for ($i = 0; count($result['message']) > $i; $i++) {
                    $html .= '<div style="margin-bottom: 6px;"><input type="radio" value="' . $result['message'][$i]['id'] . '" name="motivoClass-' . $fields['idQuestao'] . '" id="motivoClass-' . $fields['idQuestao'] . '"><span style="font-size:12px;padding-left: 6px;">' . $result['message'][$i]['nome'] . '</span></div>';
                }
            }

            // Monta Layout
            $html .= '<br/> Justificativa: <br/> <textarea id="justificativaClass-' . $fields['idQuestao'] . '" style="width: 459px; height: 121px;" rows="10" cols="30"></textarea><br>';

            print_r($html);
            die;
        } elseif ($fields['acaoVideo'] == 'gravar') { // gravar
            if ($fields['classificacao'] == 1) {
                $motivo = 12;
            } else {
                $motivo = $fields['motivo'];
            }

            $dados['questao'] = $fields['idQuestao'];
            $dados['questaoErroTipo'] = $motivo;
            $dados['justificativa'] = utf8_decode($fields['justificativa']);

            $result = api_use('questao/informar-erro', $dados, 1);

            print_r($result);
            die;
        } elseif ($fields['acaoVideo'] == 'classificar') {

            $dadosClass['questao'] = (int) trim($fields['idQuestao']);
            $dadosClass['tipo'] = (int) trim($fields['classificacao']);

            $resultClass = api_use('classificar-video', $dadosClass, 1);

            $obj = new stdClass();

            $obj->success = $resultClass['success'];


            if (!$resultClass['success']) {
                if ($dados['tipo'] == 1) {
                    $return->classificacao = '<a id="classVidPos-' . $dadosClass['questao'] . '" class="btn btn-link btn-bom show-tooltip btn-disabledVideo"  style="cursor:initial;" title="' . utf8_decode($dados['videoClassificacaoPositivaTitle']) . '">
							<span class="icon-bom"></span>
							<em>' . $dados['videoClassificacaoPositiva'] . '</em>
							</a>';
                } else if ($dados['tipo'] == 2) {
                    $return->classificacao = '<a id="classVidNeg-' . $dadosClass['questao'] . '" class=" btn btn-link btn-ruim show-tooltip btn-disabledVideo"  style="cursor:initial;" title="' . utf8_decode($dados['videoClassificacaoNegativaTitle']) . '">
							<span class="icon-ruim"></span>
							<em>' . $dados['videoClassificacaoNegativa'] . '</em>
							</a>';
                }
            } else {
                $obj->message = $resultClass['message'];
            }

            print( json_encode($obj));
            //print_r(true);
            die;
        }
    }

    /**
     * Certificado
     *
     * Exibe o certificado se os requisitos foram alcançados.
     * Senão exibe os requisitos que faltam.
     *
     * @param string $Ancora determinanda qual ? a identificador da disciplina
     * @access	public
     * @return	void
     */
    public function certificado($Ancora = null) {

        $this->load->model('video_model', 'video');

        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'curso';
        $this->css[] = $this->minify->getCSS('curso_index.min', $this->cssMinify, ENVIRONMENT);

        $data = '';

        $fields['AssinaturaMatriculaID'] = ($this->input->post('assinaturaMatriculaID')) ? $this->encrypt_v2->decode($this->input->post('assinaturaMatriculaID'), KEY_PLAYER) : $this->session->userdata('assinaturaMatriculaID');
        $retornoVerificaPacotesAluno = $this->home->verificaPacotesAluno($fields, $this->configuracoes[0]['Base'], $this->configuracoes[0]['id']);

        // Verifica se existe algum requisito cadastrado no preparatório
        if ($this->session->userdata('Certificado') == 'N')
        // Se não houver, redireciona para a página principal do curso
            redirect(base_url() . 'curso/' . $Ancora);

        // Grupo aula vinculada a assinaturaMatricula
        $grupoAula = $this->home->verificaGrupoAulaAluno(isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) ? $retornoVerificaPacotesAluno[0]['GrupoAulaID'] : null);

        if ($grupoAula['ClassificacaoID'] != 5) {
            $data['cursoNome'] = isset($retornoVerificaPacotesAluno[0]['DescricaoPacote']) ? $retornoVerificaPacotesAluno[0]['DescricaoPacote'] : null;
            $data['grupoAulaID'] = isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) ? $retornoVerificaPacotesAluno[0]['GrupoAulaID'] : null;
            $data['ClassificacaoID'] = $grupoAula['ClassificacaoID'];
        } // Assinatura completa
        else if ($grupoAula['ClassificacaoID'] == 5) {
            // grupo aula post pela assinatura completa
            $grupoAulaID = $this->input->post('grupoAulaID');

            // clicando no botao voltar curso
            if (empty($grupoAulaID) && $this->session->userdata('ClassificacaoPacotePai') == 5) {
                $grupoAulaID = $this->session->userdata('grupoAulaID');
            }

            // Grupo aula selecionada pelo aluno
            $grupoAula = $this->home->verificaGrupoAulaAluno($grupoAulaID);

            $data['cursoNome'] = $grupoAula['Descricao'];
            $data['grupoAulaID'] = $grupoAula['id'];
            $data['ClassificacaoID'] = $grupoAula['ClassificacaoID'];
        }

        $retornoVerificaPacotesAluno[0]['RequisitosCertificado'] = isset($retornoVerificaPacotesAluno[0]['RequisitosCertificado']) ? $retornoVerificaPacotesAluno[0]['RequisitosCertificado'] : 'N';

        if ($retornoVerificaPacotesAluno[0]['RequisitosCertificado'] != 'S') :

            $data['liberado'] = 'N';
            $requisitos = $this->curso->getRequisitos(isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) ? $retornoVerificaPacotesAluno[0]['GrupoAulaID'] : null);

            $requisito = new stdClass();
            foreach ($requisitos as $requisito) {

                if ($requisito->ID == 1) {

                    $total = $this->curso->getTotalAulas(isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) ? $retornoVerificaPacotesAluno[0]['GrupoAulaID'] : null);
                    $logs = $this->video->getPlayerLogs();
                    $play = array();
                    if ($logs) {

                        $aula = array();
                        foreach ($logs as $v) {
                            list($dtcad, $hora) = explode(' ', $v['datacadastro']);
                            list($h, $m, $s) = explode(':', $hora);
                            $hc = $h * 60 * 60 + $m * 60 + $s; // hora cadastro

                            $aula[$v['aulaid']][$dtcad][$hc] = array('evento' => $v['evento'],
                            );
                        }


                        foreach ($aula as $id => $dt) {
                            //
                            ksort($dt);
                            $play[$id] = 0;
                            $perc = 0;
                            foreach ($dt as $tempo) {

                                ksort($tempo);
                                foreach ($tempo as $p) {

                                    if ($p['evento'] === 'start') {
                                        $perc = $perc + 1;
                                    }
                                }
                                $play[$id] = $perc;
                            }
                        }
                    }

                    // soma da quantidade de player
                    $play = array_filter($play);
                    $percentual = (count($play) / $total) * 100;

                    if (round($percentual,2) >= $requisito->Valor) {
                        $liberado1 = 'S';
                    } else {
                        $liberado1 = 'N';
                        $data['pendente1'] = 'Você precisa dar o play em ' . round(($requisito->Valor - $percentual),2) . '% das aulas restantes.';
                    }

                } else if ($requisito->ID == 2) {

                    $logs = $this->video->getPlayerLogs();

                    /* ***************************** */
                    if ($logs) {
                        $aula = array();
                        foreach ($logs as $v) {
                            list($dtcad, $hora) = explode(' ', $v['datacadastro']);
                            list($h, $m, $s) = explode(':', $hora);
                            $hc = $h * 60 * 60 + $m * 60 + $s; // hora cadastro

                            list($h, $m, $s) = explode(':', $v['tempocorrente']);
                            $tc = $h * 60 * 60 + $m * 60 + $s; //tempo corrente assistido

                            $aula[$v['aulaid']][$dtcad][$hc] = array('evento' => $v['evento'], 'tempocorrente' => $tc,
                                'tempode' => (isset($v['tempode'])) ? $v['tempode'] : 0,
                                'tempopara' => (isset($v['tempopara'])) ? $v['tempopara'] : 0
                            );
                        }

						//print_pre($aula);die;

                        $percentual = array();
                        foreach ($aula as $id => $dt) {
                            ksort($dt);
                            $percentual[$id] = 0;

                            foreach ($dt as $tempo) {
                                ksort($tempo);
                                $anterior = 0;
                                $perc = 0;

                                foreach ($tempo as $p) {
                                    if ($p['evento'] == 'resume')
                                        continue; // pula

                                    if ($p['tempode'] == 0) {
                                        $anterior = 0; // reinicia
                                    }

                                    $perc += $p['tempode'] - $anterior;

                                    if ($p['evento'] == 'seek') {
                                        $anterior = $p['tempopara'];
                                    } else {
                                        $anterior = $p['tempode'];
                                    }
                                }

                                $percentual[$id] += $perc;
                            }
                        }
                    }
                    /* ***************************** */

                    $requisitoValorSegundos = $requisito->Valor * 3600;
                    if (is_array(@$percentual)) {

                        // Horário zero
                        $dataini = new DateTime('00:00:00');

                        // Horário para soma
                        $total = new DateTime('00:00:00');
						$totalseconds = 0;

                        foreach ($percentual as $key => $seconds) {

                            // converte segundos em horas
                            $hours = $this->foo($seconds);

                            // Intervalos de tempo
                            $addHora = new DateTime($hours);

                            // Retorna o intervalo de tempo, no formato DateInterval e adiciona no horário para soma.
                            $total->add($dataini->diff($addHora));
							$totalseconds += $seconds;

                        }

                        // 00:15:31
                        $horasVista = $dataini->diff($total)->format('%H:%I:%S'); //'%H:%I:%S'

						//print_r($horasVista);die;

                        // Formata hora requisito para //'%H:%I:%S'
                        if ($totalseconds >= $requisitoValorSegundos) {

                            $liberado2 = 'S';
                        } else {
                            $liberado2 = 'N';
                            // Diferença horas
                            $requisitoValorHoras = $this->foo($requisitoValorSegundos);
                            $HoraEntrada = new DateTime($requisitoValorHoras);
                            $HoraSaida   = new DateTime($horasVista);
                            $diffHoras = $HoraEntrada->diff($HoraSaida)->format('%H:%I:%S');
                            $horasPendentes = $diffHoras;
                            $data['pendente2'] = "Você precisa assistir mais {$horasPendentes} hora(s) de aulas.";
                        }

                    } else {

                        $liberado2 = 'N';
                        $horasPendentes = $this->foo($requisitoValorSegundos);
                        $data['pendente2'] = "Você precisa assistir mais {$horasPendentes} hora(s) de aulas.";
                    }

                } else if ($requisito->ID == 3) {

                    $dados['email'] = $this->session->userdata('usuario');
                    $dados['curso'] = $this->session->userdata('grupoAulaID');
                    $result = api_use('cursos/aproveitamento/curso/aluno', $dados, 2);

                    if ($result['success'] == TRUE) {

                       if ($result['message'][0]['questoes'] > 0) {

                           // Ter respondido (independente de erro e acerto) XX% das questões indicadas pelos professores em seu preparatório
                            $percentual = $result['message'][0]['respondidas'] * 100 / $result['message'][0]['questoes'];

                            $liberado3 = 'N';
                            if (round($percentual,2) < $requisito->Valor) {

                                $porcRestante = $requisito->Valor - round($percentual,2);
                                $data['pendente3'] = "Você precisa responder mais $porcRestante % das questões restantes sugeridas pelos professores.";
                            } else {
                                $liberado3 = 'S';
                            }
                       }
                    } else {

                        $data['pendente3'] = "Ocorreu um erro ao definir resultados do requisito Nº $requisito->ID ";
                    }

                } else if ($requisito->ID == 4) {

                    $dados['email'] = $this->session->userdata('usuario');
                    $dados['curso'] = $this->session->userdata('grupoAulaID');
                    $result = api_use('cursos/aproveitamento/curso/aluno', $dados, 2);

                    if ($result['success'] == TRUE) {
                       if ($result['message'][0]['questoes'] > 0) {

                            // Ter acertado XX% das questões
                            $percentual = ($result['message'][0]['corretas']  / $result['message'][0]['questoes']) * 100;
                            $liberado4 = 'N';
                            if (round($percentual,2) < $requisito->Valor) {

                                $porcRestante = $requisito->Valor - round($percentual,2);
                                $data['pendente4'] = "Você precisa acertar mais $porcRestante % das questões.";
                            } else {
                                $liberado4 = 'S';
                            }
                       }
                    } else {

                        $data['pendente4'] = "Ocorreu um erro ao definir resultados do requisito Nº $requisito->ID ";
                    }
                }
            }
        endif;

        // Verifica se os requisitos que possui estão todos ok
        $array = array();
        $array[] = isset($liberado1) ? $liberado1 : NULL;
        $array[] = isset($liberado2) ? $liberado2 : NULL;
        $array[] = isset($liberado3) ? $liberado3 : NULL;
        $array[] = isset($liberado4) ? $liberado4 : NULL;

        $key = array_search('N', $array);

         if (is_numeric($key)) {

            $this->session->set_userdata('certLiberado', 'N');
        } else {

            // Grava na D003 caso tenha atingido todos os requisitos
            $this->curso->requisitosCertificado($fields['AssinaturaMatriculaID']);
            $this->session->set_userdata('certLiberado', 'S');
        }

        // banner simulado
        $banners = $this->curso->verificaBannerSimulado(isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) ? $retornoVerificaPacotesAluno[0]['GrupoAulaID'] : null);
        if (!empty($banners)) {
            // selecionar o banner válido
            foreach ($banners as $banner) {
                // data de hoje sem a hora
                $hoje = mktime(0, 0, 0, date('m'), date('d'), date('Y'));

                // data final não é obrigatória
                $dtfim = '';
                if (!empty($banner['DtFimSimulado'])) {
                    list($a2, $m2, $d2) = explode('-', $banner['DtFimSimulado']);
                    $dtfim = mktime(0, 0, 0, $m2, $d2, $a2);
                }

                if (empty($dtfim) || $dtfim > $hoje) {
                    $data['bannerSimulado'] = $banner;
                }
            }
        }

        // Monta compra Certificado
         $data['urlGateway'] = 'javascript:void(0)';
        if ($retornoVerificaPacotesAluno[0]['ValorPacote'] != '') {
            $fields = new stdClass();
            $fields->id = trim($retornoVerificaPacotesAluno[0]['GrupoAulaID']);
            $fields->nome = utf8_encode($retornoVerificaPacotesAluno[0]['DescricaoPacote']);
            $fields->ancora = trim($retornoVerificaPacotesAluno[0]['Ancora']);
            $fields->prazo = $grupoAula['Duracao'];
            $fields->dtFimPacote = "";
            $fields->ClassificacaoID = "";
            $fields->qtdPacotes = "1";
            $fields->tipoProduto = "certificado";
            $fields->valor = 100.00;
            $fields->apikey = 'ef6fbb81bd6a4f26a3283988230e6f871e54c9e1';
            $fields->email = $this->session->userdata('usuario');
            $fields->assinaturamatriculaid = $grupoAula['id'];

            $dadosPostGateway = json_encode($fields);
            $Secure_url_params = new Secure_url_params();
            $dadosPostGateway = $Secure_url_params->encode($dadosPostGateway);
            $dadosPostGateway = trim($dadosPostGateway, '=');
            $data['urlGateway'] = URL_PAGAMENTO . 'pedido/addItem/' . $dadosPostGateway;
        }

        $this->menu_vertical = $this->load->view('view_menu', '', true);

        $this->load->view('certificado', $data);
    }

    /*
     * convert seconds em horas formata com hora minuto e segundos
     */
    function foo($seconds) {
        $t = round($seconds);
        return sprintf('%02d:%02d:%02d', ($t/3600),($t/60%60), $t%60);
    }

    function timeDiff($firstTime, $lastTime) {
        $firstTime = strtotime($firstTime);
        $lastTime = strtotime($lastTime);
        $timeDiff = $lastTime - $firstTime;
        return $timeDiff;
    }

    /**
     * Gerar Certificado
     *
     * Gera o certificado do curso com os dados do aluno.
     *
     * @access	public
     * @return	void
     */
    public function gerarCertificado($Ancora = null) {

        $this->layout = '';

        $fields['AssinaturaMatriculaID'] = ($this->input->post('assinaturaMatriculaID')) ? $this->encrypt_v2->decode($this->input->post('assinaturaMatriculaID'), KEY_PLAYER) : $this->session->userdata('assinaturaMatriculaID');
        $retornoVerificaPacotesAluno = $this->home->verificaPacotesAluno($fields, $this->configuracoes[0]['Base'], $this->configuracoes[0]['id']);



        if ($this->session->userdata('certLiberado') != 'S')
        // Se não houver, redireciona para a página principal do curso
            redirect(base_url() . 'certificado/' . $Ancora);

        $data = '';

        if (isset($retornoVerificaPacotesAluno[0]['GrupoAulaID']) && (isset($retornoVerificaPacotesAluno[0]['Rec']) && $retornoVerificaPacotesAluno[0]['Rec'] != 'N' || $acessa == TRUE)) {
            // Grupo aula vinculada a assinaturaMatricula
            $grupoAula = $this->home->verificaGrupoAulaAluno($retornoVerificaPacotesAluno[0]['GrupoAulaID']);
            // Série Grandes Concursos
            $dtLiberacao = $retornoVerificaPacotesAluno[0]['DtInicio'];
            if ($grupoAula['ClassificacaoID'] == '6' && $grupoAula['DtInicio'] != '-') {
                $timeGrupo = strtotime($grupoAula['DtInicio']);
                $timeCompra = strtotime($retornoVerificaPacotesAluno[0]['DtInicio']);
                if ($timeGrupo > $timeCompra)
                    $dtLiberacao = $grupoAula['DtInicio'];
            }
            if ($grupoAula['ClassificacaoID'] != 5) {
                $data['cursoNome'] = isset($retornoVerificaPacotesAluno[0]['DescricaoPacote']) ? $retornoVerificaPacotesAluno[0]['DescricaoPacote'] : null;
                $data['videoaulas'] = $this->curso->verificaVideoAulasDisciplina($this->session->userdata('grupoAulaID'), null);
            } // Assinatura completa
            else if ($grupoAula['ClassificacaoID'] == 5) {
                // grupo aula post pela assinatura completa
                $grupoAulaID = $this->input->post('grupoAulaID');
                // clicando no botao voltar curso
                if (empty($grupoAulaID) && $this->session->userdata('ClassificacaoPacotePai') == 5)
                    $grupoAulaID = $this->session->userdata('grupoAulaID');
                // Grupo aula selecionada pelo aluno
                $grupoAula = $this->home->verificaGrupoAulaAluno($grupoAulaID);
                $data['cursoNome'] = $grupoAula['Descricao'];
                $data['videoaulas'] = $this->curso->verificaVideoAulasDisciplina($data['grupoAulaID'], null);
            }
            $data['DtLiberacao'] = $dtLiberacao;
        } else if (isset($retornoVerificaPacotesAluno[0]['Rec']) && $retornoVerificaPacotesAluno[0]['Rec'] == 'N') {
            $data['cursoNome'] = isset($retornoVerificaPacotesAluno[0]['DescricaoPacote']) ? $retornoVerificaPacotesAluno[0]['DescricaoPacote'] : null;
        }

        $dados['Nome'] = $this->session->userdata('nome');
        $dados['CPF'] = $this->curso->getCPFAluno();

        $keys['Disciplinas'] = array();
        foreach ($data['videoaulas'] as $videos => $video) {
            // Nome do Curso
            $curso = explode(':', array_shift($video));
            $curso = (count($curso) > 1) ? explode('-', removeAcentos(utf8_encode($curso[1]))) : explode('-', removeAcentos(utf8_encode($curso[0])));
            $curso = array_map('trim', $curso);
            // Nome das disciplinas
            if (empty($keys['Disciplinas']))
                $keys['Disciplinas'] = array_keys($video);
            else
                $keys['Disciplinas'] = array_merge($keys['Disciplinas'], array_keys($video));
            // Quantidades de aulas por disciplinas
            foreach ($video as $key => $value)
                $keys['Aulas'][] = count($value['aulas']);
            // Remove as substrings das disciplinas que repetem o nome do curso
            $keys = $this->removeSubStrCurso($keys, $curso);
        }
        // Ordena a array
        $keys['Disciplinas'] = array_flip($keys['Disciplinas']);
        ksort($keys['Disciplinas']);
        // Carga horária total
        $cargaHoraria = 0;
        foreach ($keys['Disciplinas'] as $key => $value) {
            $disciplinas[$key] = $keys['Aulas'][$value];
            $cargaHoraria += $keys['Aulas'][$value];
        }
        $cargaHoraria = $cargaHoraria * 30 / 60;
        unset($keys);
        // Quantidade de disciplinas
        $qtdDisciplinas = count($disciplinas);

        $this->load->library("Fpdf");

        // Certificado - Paisagem
        if ($qtdDisciplinas <= 54) {
            // Novo PDF
            $fpdf = new FPDF('L');
            $fpdf->SetTitle('AVA SAE - Certificado');
            // Página 1
            $fpdf->AddPage();
            // Montagem do background do pdf
            $fpdf->Image(PATH_IMG_SITE . 'certificado/certificado-frente-P.jpg', 0, 0, $fpdf->w, $fpdf->h);
            // Cor do texto
            $fpdf->SetTextColor(92, 92, 92);
            // Nome do Aluno
            $fpdf->SetFont('times', '', 30);
            $fpdf->SetY(55);
            $fpdf->MultiCell(0, 10, strtoupper($dados['Nome']), 0, 'C');
            // Informações do certificado
            $fpdf->SetFont('times', '', 20);
            $fpdf->SetXY(30, 82);
            $texto = 'concluiu seus estudos no preparatório ' . mb_strtoupper($data['cursoNome'], 'ISO-8859-1') .
                    ', com carga horária total de ' . $cargaHoraria .
                    ' horas realizado no período de ' . date('d/m/Y', strtotime($data['DtLiberacao'])) .
                    ' a ' . date('d/m/Y') . ', em modalidade online.';
            $fpdf->MultiCell(237, 9, $texto, 0, 'C');
            // Data do certificado
            $fpdf->SetXY(30, 121);
            $fpdf->MultiCell(237, 10, 'Curitiba, ' . dataextenso(date('Y-m-d')), 0, 'C');

            // Página 2
            $fpdf->AddPage();
            // Montagem do background do pdf
            $fpdf->Image(PATH_IMG_SITE . 'certificado/certificado-verso-P.jpg', 0, 0, $fpdf->w, $fpdf->h);
            // Nome do preparatório
            $fpdf->SetFont('times', '', 24);
            $fpdf->SetY(5.5);
            $fpdf->MultiCell(0, 9, mb_strtoupper($data['cursoNome'], 'ISO-8859-1'), 0, 'C');
            // Texto certificado
            $fpdf->SetFont('times', '', 16);
            $fpdf->SetY($fpdf->GetY() + 0.5);
            $fpdf->MultiCell(0, 9, 'Certificado conferido a:', 0, 'C');
            // Nome e CPF do Aluno
            $fpdf->SetY($fpdf->GetY() - 1.5);
            $fpdf->MultiCell(0, 9, strtoupper($dados['Nome']) . ' - CPF: ' . $dados['CPF'], 0, 'C');

            // Tabela Caso 1 - Quando a quantidade de disciplinas for menor ou igual que 20, gera apenas uma tabela
            if ($qtdDisciplinas <= 27) {
                // Colunas disciplinas e aulas
                $fpdf->SetFont('times', '', 12);
                $fpdf->SetTextColor(255, 255, 255);
                $fpdf->SetFillColor(30, 80, 105);
                $fpdf->SetX(45);
                $fpdf->MultiCell(160, 5, 'DISCIPLINAS', 0, 'L', 1);
                $fpdf->SetXY(205.5, $fpdf->GetY() - 5);
                $fpdf->MultiCell(47, 5, 'Nº AULAS', 0, 'C', 1);
                // Disciplinas e número de aulas
                $fpdf->SetFont('times', '', 10);
                $fpdf->SetTextColor(92, 92, 92);
                $fpdf->SetFillColor(235, 235, 235);
                $color = 0;
                foreach ($disciplinas as $key => $value) {
                    $fpdf->SetX(45);
                    $fpdf->MultiCell(160, 5, $key, 0, 'L', $color);
                    $fpdf->SetXY(205.5, $fpdf->GetY() - 5);
                    $fpdf->MultiCell(47, 5, $value, 0, 'C', $color);
                    if ($color)
                        $color = 0;
                    else
                        $color = 1;
                }
                // Carga horária total
                $fpdf->SetFont('times', '', 12);
                $fpdf->SetTextColor(255, 255, 255);
                $fpdf->SetFillColor(30, 80, 105);
                $fpdf->SetX(45);
                $fpdf->MultiCell(160, 5, 'CARGA HORÁRIA TOTAL', 0, 'R', 1);
                $fpdf->SetXY(205.5, $fpdf->GetY() - 5);
                $fpdf->MultiCell(47, 5, $cargaHoraria . ' Horas', 0, 'C', 1);
            }
            // Tabela Caso 2 - Quando a quantidade de disciplinas for maior que 20, gera duas tabela
            else {
                // Colunas disciplinas e aulas
                $fpdf->SetFont('times', '', 12);
                $fpdf->SetTextColor(255, 255, 255);
                $fpdf->SetFillColor(30, 80, 105);
                // Tabela 1 - Títulos
                $fpdf->SetX(10);
                $fpdf->MultiCell(110, 5, 'DISCIPLINAS', 0, 'L', 1);
                $fpdf->SetXY(120.5, $fpdf->GetY() - 5);
                $fpdf->MultiCell(27, 5, 'Nº AULAS', 0, 'L', 1);
                $tabela1 = (int) ($qtdDisciplinas / 2) + (($qtdDisciplinas % 2 == 0) ? 0 : 1);
                // Tabela 2 - Títulos
                $fpdf->SetXY($fpdf->w / 2, $fpdf->GetY() - 5);
                $fpdf->MultiCell(109, 5, 'DISCIPLINAS', 0, 'L', 1);
                $fpdf->SetXY($fpdf->w / 2 + 109.5, $fpdf->GetY() - 5);
                $fpdf->MultiCell(27, 5, 'Nº AULAS', 0, 'L', 1);
                // Disciplinas e número de aulas
                $fpdf->SetFont('times', '', 10);
                $fpdf->SetTextColor(92, 92, 92);
                $fpdf->SetFillColor(235, 235, 235);
                $color = $cont = 0;
                foreach ($disciplinas as $key => $value) {
                    $cont++;
                    if ($cont <= $tabela1) {
                        // Tabela 1 - Linhas
                        $fpdf->SetX(10);
                        $fpdf->MultiCell(110, 5, $key, 0, 'L', $color);
                        $fpdf->SetXY(120.5, $fpdf->GetY() - 5);
                        $fpdf->MultiCell(27, 5, $value, 0, 'C', $color);
                        if ($cont == $tabela1) {
                            $fpdf->SetY($fpdf->GetY() - 5 * ($tabela1 - 1));
                            $color = 1;
                        }
                    } else {
                        // Tabela 2 -Linhas
                        $fpdf->SetXY($fpdf->w / 2, $fpdf->GetY() - 5);
                        $fpdf->MultiCell(109, 5, $key, 0, 'L', $color);
                        $fpdf->SetXY($fpdf->w / 2 + 109.5, $fpdf->GetY() - 5);
                        $fpdf->MultiCell(27, 5, $value, 0, 'C', $color);
                        $fpdf->SetY($fpdf->GetY() + 5);
                    }
                    if ($color)
                        $color = 0;
                    else
                        $color = 1;
                }
                // Carga horária total
                $fpdf->SetFont('times', '', 12);
                $fpdf->SetTextColor(255, 255, 255);
                $fpdf->SetFillColor(30, 80, 105);
                $fpdf->SetXY($fpdf->w / 2, $fpdf->GetY() - 5);
                $fpdf->MultiCell(109, 5, 'CARGA HORÁRIA TOTAL', 0, 'R', 1);
                $fpdf->SetXY($fpdf->w / 2 + 109.5, $fpdf->GetY() - 5);
                $fpdf->MultiCell(27, 5, $cargaHoraria . ' Horas', 0, 'C', 1);
            }
        }
        // Certificado - Retrato
        else {
            // Novo PDF
            $fpdf = new FPDF();
            $fpdf->SetTitle('AVA SAE - Certificado');
            // Página 1
            $fpdf->AddPage();
            // Montagem do background do pdf
            $fpdf->Image(PATH_IMG_SITE . 'certificado/frente/certificado-R_01.jpg', 0, 0, $fpdf->w);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/frente/certificado-R_02.jpg', 0, 78.7, 10.3);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/frente/certificado-R_03.jpg', 10.3, 78.7, 189.6);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/frente/certificado-R_04.jpg', 199.8, 78.7, 10.3);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/frente/certificado-R_05.jpg', 10.3, 103.7, 189.6);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/frente/certificado-R_06.jpg', 10.3, 164.9, 189.6);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/frente/certificado-R_07.jpg', 10.3, 184.7, 189.6);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/frente/certificado-R_08.jpg', 0, 212.5, $fpdf->w);
            // Cor do texto
            $fpdf->SetTextColor(92, 92, 92);
            // Nome do Aluno
            $fpdf->SetFont('times', '', 30);
            $fpdf->SetY(84);
            $fpdf->MultiCell(0, 10, strtoupper($dados['Nome']), 0, 'C');
            // Informações do certificado
            $fpdf->SetFont('times', '', 20);
            $fpdf->SetY(114);
            $texto = 'concluiu seus estudos no preparatório ' . mb_strtoupper($data['cursoNome'], 'ISO-8859-1') .
                    ', com carga horária total de ' . $cargaHoraria .
                    ' horas realizado no período de ' . date('d/m/Y', strtotime($data['DtLiberacao'])) .
                    ' a ' . date('d/m/Y') . ', em modalidade online.';
            $fpdf->MultiCell(0, 9, $texto, 0, 'C');
            // Data do certificado
            $fpdf->SetY(167);
            $fpdf->MultiCell(0, 10, 'Curitiba, ' . dataextenso(date('Y-m-d')), 0, 'C');

            // Página 2
            $fpdf->AddPage();
            // Montagem do background do pdf
            $fpdf->Image(PATH_IMG_SITE . 'certificado/verso/certificado-R_01.jpg', 0, 0, 12.33);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/verso/certificado-R_02.jpg', 12.33, 0, 184.28);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/verso/certificado-R_03.jpg', 197.67, 0, 13.39);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/verso/certificado-R_04.jpg', 0, 37.04, $fpdf->w);
            $fpdf->Image(PATH_IMG_SITE . 'certificado/verso/certificado-R_05.jpg', 0, 277.95, $fpdf->w);
            // Nome do preparatório
            $fpdf->SetFont('times', '', 24);
            $fpdf->SetY(4);
            $fpdf->MultiCell(0, 9, mb_strtoupper($data['cursoNome'], 'ISO-8859-1'), 0, 'C');
            // Texto certificado
            $fpdf->SetFont('times', '', 16);
            $fpdf->SetY($fpdf->GetY() + 0.5);
            $fpdf->MultiCell(0, 9, 'Certificado conferido a:', 0, 'C');
            // Nome e CPF do Aluno
            $fpdf->SetY($fpdf->GetY() - 1.5);
            $fpdf->MultiCell(0, 9, strtoupper($dados['Nome']) . ' - CPF: ' . $dados['CPF'], 0, 'C');

            // Colunas disciplinas e aulas
            $fpdf->SetFont('times', '', 12);
            $fpdf->SetTextColor(255, 255, 255);
            $fpdf->SetFillColor(30, 80, 105);
            // Tabela 1 - Títulos
            $fpdf->SetX(10);
            $fpdf->MultiCell($fpdf->w / 2 - 33, 5, 'DISCIPLINAS', 0, 'L', 1);
            $fpdf->SetXY($fpdf->w / 2 - 22.5, $fpdf->GetY() - 5);
            $fpdf->MultiCell(22, 5, 'Nº AULAS', 0, 'L', 1);
            $tabela1 = (int) ($qtdDisciplinas / 2) + (($qtdDisciplinas % 2 == 0) ? 0 : 1);
            // Tabela 2 - Títulos
            $fpdf->SetXY($fpdf->w / 2, $fpdf->GetY() - 5);
            $fpdf->MultiCell($fpdf->w / 2 - 33, 5, 'DISCIPLINAS', 0, 'L', 1);
            $fpdf->SetXY($fpdf->w / 2 + $fpdf->w / 2 - 32.5, $fpdf->GetY() - 5);
            $fpdf->MultiCell(22, 5, 'Nº AULAS', 0, 'L', 1);
            // Disciplinas e número de aulas
            $fpdf->SetFont('times', '', 10);
            $fpdf->SetTextColor(92, 92, 92);
            $fpdf->SetFillColor(235, 235, 235);
            $color = $cont = 0;
            foreach ($disciplinas as $key => $value) {
                $cont++;
                if ($cont <= $tabela1) {
                    // Tabela 1 - Linhas
                    $fpdf->SetX(10);
                    $fpdf->MultiCell($fpdf->w / 2 - 33, 5, $key, 0, 'L', $color);
                    $fpdf->SetXY($fpdf->w / 2 - 22.5, $fpdf->GetY() - 5);
                    $fpdf->MultiCell(22, 5, $value, 0, 'C', $color);
                    if ($cont == $tabela1) {
                        $fpdf->SetY($fpdf->GetY() - 5 * ($tabela1 - 1));
                        $color = 1;
                    }
                } else {
                    // Tabela 2 -Linhas
                    $fpdf->SetXY($fpdf->w / 2, $fpdf->GetY() - 5);
                    $fpdf->MultiCell($fpdf->w / 2 - 33, 5, $key, 0, 'L', $color);
                    $fpdf->SetXY($fpdf->w / 2 + $fpdf->w / 2 - 32.5, $fpdf->GetY() - 5);
                    $fpdf->MultiCell(22, 5, $value, 0, 'C', $color);
                    $fpdf->SetY($fpdf->GetY() + 5);
                }
                if ($color)
                    $color = 0;
                else
                    $color = 1;
            }
            // Carga horária total
            $fpdf->SetFont('times', '', 12);
            $fpdf->SetTextColor(255, 255, 255);
            $fpdf->SetFillColor(30, 80, 105);
            $fpdf->SetXY($fpdf->w / 2, $fpdf->GetY() - 5);
            $fpdf->MultiCell($fpdf->w / 2 - 33, 5, 'CARGA HORÁRIA TOTAL', 0, 'R', 1);
            $fpdf->SetXY($fpdf->w / 2 + $fpdf->w / 2 - 32.5, $fpdf->GetY() - 5);
            $fpdf->MultiCell(22, 5, $cargaHoraria . ' Horas', 0, 'C', 1);
            //}
        }
        $fpdf->Output();
    }

    function removeSubStrCurso($array, $curso) {
        $filterDisc = array();
        $filterCurso = array();
        foreach ($array['Disciplinas'] as $key => $value) {
            //Remove as revisões das disciplinas
            if (strpos(removeAcentos(utf8_encode($value)), 'revisao') !== false) {
                unset($array['Disciplinas'][$key]);
                unset($array['Aulas'][$key]);
            }
            // Obtem as palavras depois do primeiro hífen ou hashtag
            else {
                $this->substr_disciplina($filterDisc[], removeAcentos(utf8_encode($value)));
                if (end($filterDisc) == '')
                    array_pop($filterDisc);
            }
        }
        // Encontra a palavra que mais se repete
        $total = array_count_values($filterDisc);
        $repetido = array_search(max($total), $total);
        // Remove a palavra mais repetida da array
        foreach ($array['Disciplinas'] as $key => $value) {
            $pos = strpos(removeAcentos(utf8_encode($value)), $repetido);
            if ($pos !== false)
                $array['Disciplinas'][$key] = trim(substr($value, 0, $pos - 2));
            // Obtem as palavras que contêm no nome do curso
            $filterCurso = $this->substr_curso($array['Disciplinas'][$key]);
            // Remove as palavras que contêm no nome do curso
            if (!empty($filterCurso)) {
                foreach ($filterCurso as $filter => $word) {
                    if (in_array($word, $curso)) {
                        $pos = strpos(removeAcentos(utf8_encode($array['Disciplinas'][$key])), $word);
                        if ($pos !== false)
                            $array['Disciplinas'][$key] = trim(substr($array['Disciplinas'][$key], 0, $pos - 2));
                    }
                }
            }
        }
        $array['Disciplinas'] = array_values($array['Disciplinas']);
        $array['Aulas'] = array_values($array['Aulas']);
        return($array);
    }

    function substr_disciplina(&$filter, $string) {
        $posHyphen = substr_count($string, '-');
        $posSharp = substr_count($string, '#');
        if ($posHyphen == 0 && $posSharp == 0)
            $filter = '';
        else if ($posHyphen > 0 && $posSharp == 0 || $posHyphen < $posSharp)
            $filter = trim(explode('-', $string)[1]);
        else if ($posHyphen == 0 && $posSharp > 0 || $posHyphen > $posSharp)
            $filter = trim(explode('#', $string)[1]);
    }

    function substr_curso($string) {
        $posHyphen = substr_count($string, '-');
        $posSharp = substr_count($string, '#');
        if ($posHyphen == 0 && $posSharp == 0)
            return array();
        else if ($posHyphen > 0 && $posSharp == 0 || $posHyphen < $posSharp)
            return array_map('trim', explode('-', $string));
        else if ($posHyphen == 0 && $posSharp > 0 || $posHyphen > $posSharp)
            return array_map('trim', explode('#', $string));
    }

    public function download($idAula)
    {
        try {
            $this->layout = false;
            $idSerie = (int)$this->session->userdata('Serie');

            $validar = SaeDigital::make(ValidarAulaPorSerie::class)->handle((int)$idAula, $idSerie);

            if (!$validar && $this->session->userdata('perfil') === Perfil::ALUNO) {
                throw new FileNotFoundException($idAula, 404);
            }

            $this->load->model('aula_model', 'aula');

            $aula = $this->aula->buscarAulaPorID($idAula);
            $arquivo = str_replace('.mp4', '.pdf', explode('/', $aula['pdf']))[1];

            $cursoNome = $this->aula->buscarNomeCursoPorAulaID($idAula);

            $pastaS3 = 'pdf';

            /** @var AwsS3Adapter $adapter */
            $adapter = SaeDigital::make(AwsS3Adapter::class);

            $filePath = "pdf/{$pastaS3}/{$arquivo}";


            if (!$adapter->has($filePath)) {
                throw new FileNotFoundException($idAula, 404);
            }

            $cmd = $adapter->getClient()->getCommand(
                'GetObject',
                [
                    'Bucket' => env('AWS_DEFAULT_BUCKET', 'avasae-teste'),
                    'Key' => $filePath
                ]
            );

            $request = $adapter->getClient()->createPresignedRequest($cmd, '+2 hours');

            $url = (string)$request->getUri();

            header("Location: " . $url );
        } catch (FileNotFoundException $e) {
            show_404();
        } catch (\Exception $e) {
            show_404();
        }
    }

}

/* End of file curso.php */
/* Location: ./application/controllers/curso.php */
