<?php

use Ava\App\Services\Assuntos\PegaAssuntoPeloId;
use Ava\App\Services\Notificacoes\MarcarNotificacoesComoLida;

class Notificacao extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->layout = false;
    }

    public function listarNotificacoes()
    {
        try {
            $tipo = (int)$this->input->get('tipo_id');

            $notificacoes = $this->session->userdata('notificacoes');

            $notificacoes = collect($notificacoes)->where('tipo_notificacao_id', $tipo)->map(
                function ($notificacao) {
                    $data = json_decode($notificacao['json'], true);
                    $data = is_array($data) ? $data : [];
                    if (is_array($data)) {
                        $data['modulo'] = SaeDigital::make(PegaAssuntoPeloId::class)->handle($data['modulo_id']);
                    }
                    $notificacao['data'] = $data;

                    return $notificacao;
                }
            )->toArray();

            $html = $this->twig()->render('/templates/mensagens/' . $notificacoes[0]['template'] . '.html.twig', [
                'notificacoes' => $notificacoes
            ]);

            $this->marcarNotificacoesComoLida($tipo);

            return $this->responseJson(['html' => $html], 200);
        } catch (\Exception $e) {
            log_error($e->getMessage());
        }
    }

    public function marcarNotificacoesComoLida($tipo)
    {
        try {
            SaeDigital::make(MarcarNotificacoesComoLida::class)->handle(
                $this->session->userdata('login'),
                $this->session->userdata('escola'),
                $tipo
            );

            $notificacoes = $this->session->userdata('notificacoes');
            $notificacoes = collect($notificacoes)->whereNotIn('tipo_notificacao_id', $tipo)->toArray();
            $this->session->set_userdata('notificacoes', $notificacoes);
        } catch (\Exception $e) {
            log_error($e->getMessage());
        }
    }
}
