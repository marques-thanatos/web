<?php

use Ava\App\Services\Jarvis\JarvisApi;

class Jarvis extends MY_Controller
{
    public $layout = 'default';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $js = [
        'jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'curso.min', 'redactor.min',
        'pt_pt', 'redactor_special_character', 'redactor.fontcolor', 'redactor.fontsize', 'jquery.cookie', 'mensagem'
    ];

    public $keywords = array('sae', 'curso');

    public function __construct()
    {
        parent::__construct();

        $this->load->model('curso_model', 'curso');
        $this->load->model('disciplina_model', 'disciplina');
        $this->load->library('disciplina_lib');

        $this->cssMinify = ['bootstrap', '_reset', 'geral', 'messi', 'mensagem', 'jarvis'];
    }

    public function showItem()
    {
        $this->cssMinify[] = 'mensagem';
        $this->cssMinify[] = 'style';
        $this->cssMinify[] = 'redactor/redactor';
        $this->cssMinify[] = 'glyphicon';
        $this->cssMinify[] = 'css-responsive';

        $this->css[] = $this->minify->getCSS('video_curso.min', $this->cssMinify, ENVIRONMENT);

        $this->js[] = 'jquery.oembed.min';
        $this->js[] = 'jquery.paginate.min';
        $this->js[] = 'bootstrap-tooltip';

        try {
            $itemId = $this->input->post('item');
            $token = $this->input->post('token');

            if (($_SERVER['HTTP_REFERER'] === getenv('JARVIS_REFERER')) || getenv('CI_ENV') === 'dev') {
                $client = new \GuzzleHttp\Client([
                    'base_uri' => getenv('JARVIS_API'),
                    'headers' => ['Authorization' => "Bearer {$token}"]
                ]);

                $item = $client->request('GET', "items/{$itemId}");
                $item = (array) json_decode($item->getBody()->getContents());

                $data['item'] = $item;
                $data['item']['attributes'] = collect($item['attributes'])->filter(function ($itemAttribute) {
                    return in_array($itemAttribute->attribute->id,[
                        JarvisApi::ALTERNATIVA_1,
                        JarvisApi::ALTERNATIVA_2,
                        JarvisApi::ALTERNATIVA_3,
                        JarvisApi::ALTERNATIVA_4,
                        JarvisApi::ALTERNATIVA_5,
                        JarvisApi::ALTERNATIVA_CORRETA
                    ]); //alternativa, alternativa correta
                })->toArray();
                $data['serie'] = $item['module_items'][0]->serie->name;
                $data['discipline'] = $item['module_items'][0]->discipline->name;
                $data['module'] = $item['module_items'][0]->name;

                return $this->load->view('jarvis', $data);
            }
            throw new InvalidArgumentException('Referer não autorizado');
        } catch (\GuzzleHttp\Exception\GuzzleException $e) {
            show_404();
        } catch (InvalidArgumentException $e){
            show_404();
        }
    }
}
