<?php
use Ava\App\Support\Perfil;

class LerProduzir extends MY_Controller {
    public $layout = 'new-ava';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    public function __construct() {
        parent::__construct();
    }
    public function index() {
        try {
            $data = [
                'perfil' => (
                    $this->session->userdata('perfil') == Perfil::PROFESSOR ? 'p' : (
                        $this->session->userdata('perfil') == Perfil::COORDENADOR ? 'c' : 'a'
                    )
                ),
                'extra_link' => ($this->session->userdata('perfil') == Perfil::PROFESSOR || $this->session->userdata('perfil') == Perfil::COORDENADOR) ? '&redirect=/teachers-panel/my-activities/extras?tags=Aprova%2B+Reda%C3%A7%C3%A3o' : ''
            ];
            return $this->load->view('ler-produzir/index', $data);
        } catch (\Exception $e) {
            log_error($e->getMessage());
        }
    }
}
