<?php

use Ava\App\Exceptions\RecordInUseException;
use Ava\App\Services\Enqueue\Enqueue;
use Ava\App\Services\Jarvis\JarvisMigration;
use Ava\App\Services\VersaoEstrutura\AtualizaRegistroEstrutura;
use Ava\App\Services\VersaoEstrutura\CadastrarEstrutura;
use Ava\App\Services\VersaoEstrutura\ListaDeVersoesDaEstrutura;
use Ava\App\Services\VersaoEstrutura\ListaDeVersoesDaEstruturaAtivas;
use Ava\App\Services\VersaoEstrutura\PegaEstruturaPeloId;
use Ava\App\Services\VersaoEstrutura\PermiteDesativarEstrutura;
use Ava\App\Services\VersaoEstrutura\PropagaNovaEstruturaDeConteudo;
use Ava\App\Services\VersaoEstrutura\TrocaStatusEstrutura;

/**
 * Class VersoesEstruturas
 *
 * @package Ava\App\Controllers
 */
class VersoesEstruturas extends MY_Controller
{

    /**
     * Exibe a view com a lista de estruturas.
     *
     * @return $this
     * @throws Twig_Error_Loader
     * @throws Twig_Error_Runtime
     * @throws Twig_Error_Syntax
     */
    public function index()
    {
        $this->twigRender('versoesEstruturas/index.twig');

        return $this;
    }


    /**
     * Exibe a view para cadastrar estruturas.
     *
     * @return $this
     * @throws Twig_Error_Loader
     * @throws Twig_Error_Runtime
     * @throws Twig_Error_Syntax
     */
    public function create()
    {

        $this->twigRender('versoesEstruturas/create.twig', [
            'estruturas' => SaeDigital::make(ListaDeVersoesDaEstruturaAtivas::class)->handle(),
            'basepath' => base_url(),
            'csrf' => [
                'name' => $this->security->get_csrf_token_name(),
                'hash' => $this->security->get_csrf_hash()
            ]
        ]);

        return $this;
    }


    /**
     * Exibe view para editar uma estrutura.
     *
     * @return $this
     * @throws Twig_Error_Loader
     * @throws Twig_Error_Runtime
     * @throws Twig_Error_Syntax
     */
    public function edit()
    {
        $id = (int)$this->input->get('id');

        $this->twigRender('versoesEstruturas/edit.twig', [
            'csrf' => [
                'name' => $this->security->get_csrf_token_name(),
                'hash' => $this->security->get_csrf_hash()
            ],
            'estrutura' => SaeDigital::make(PegaEstruturaPeloId::class)->handle($id)
        ]);

        return $this;
    }


    /**
     * Cadastra nova estrutura
     *
     * @throws Exception
     */
    public function store()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            throw new \Exception('method not allowed.', 405);
        }

        $dados = [
            'descricao' => $this->input->post('descricao'),
            'status' => (int)$this->input->post('status'),
            'responsavel' => (int)$this->session->userdata('id'),
            'reference' => (int)$this->input->post('referencia'),
            'jarvis_version_id' => (int)$this->input->post('jarvis_version_id') ?: null,
            'migrate_from_jarvis' => $this->input->post('migrate_from_jarvis') === 'on' ? 1 : null
        ];

        try {
            if ((bool)$dados['migrate_from_jarvis'] && !is_int($dados['jarvis_version_id'])) {
                throw new \Exception("O ID para importação do Jarvis não foi informado.");
            }

            $lastContentVersionID = SaeDigital::make(CadastrarEstrutura::class)->handle($dados);

//            if ((bool)$this->input->get('async', true)) {
                SaeDigital::make(Enqueue::class)->sendMessage([
                    'content_version' => $lastContentVersionID,
                    'migrate_from_jarvis' => (bool)$dados['migrate_from_jarvis'] && is_int($dados['jarvis_version_id']),
                    'jarvis_version_id' => $dados['jarvis_version_id'],
                    'data' => $dados
                ], getenv('CI_ENV') . '_platform_migrate_content_version');
//            } else {
//                SaeDigital::make(PropagaNovaEstruturaDeConteudo::class)->handle($dados);
//
//                if ((bool)$dados['migrate_from_jarvis'] && is_int($dados['jarvis_version_id'])) {
//                    SaeDigital::make(JarvisMigration::class)->handle($lastContentVersionID);
//                }
//            }

            $statusCode = 201;
            $msg = 'Cadastrado com sucesso.';
        } catch (\Exception $e) {

            $statusCode = 500;
            $msg = $e->getMessage() . ' :: ' . $e->getFile() . ' :: ' . $e->getLine();
        }

        $this->responseJson(['msg' => $msg], $statusCode);
    }


    /**
     * Atualiza dados da estrutura.
     *
     * @throws Exception
     */
    public function update()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            throw new \Exception('method not allowed.', 405);
        }

        $dados = [
            'id' => (int)$this->input->post('id'),
            'descricao' => $this->input->post('descricao'),
            'status' => (int)$this->input->post('status'),
            'responsavel' => (int)$this->session->userdata('id')
        ];

        try {
            $statusCode = 200;
            $msg = 'Editado com sucesso.';

            if ($dados['status'] === 0) {
                SaeDigital::make(PermiteDesativarEstrutura::class)->handle($dados['id']);
            }

            SaeDigital::make(AtualizaRegistroEstrutura::class)->handle($dados);

        } catch (RecordInUseException $e) {

            $statusCode = $e->getCode();
            $msg = $e->getMessage();

        } catch (\Exception $e) {

            $statusCode = 500;
            $msg = $e->getMessage() . ' :: ' . $e->getFile() . ' :: ' . $e->getLine();
        }

        $this->responseJson(['msg' => $msg], $statusCode);
    }


    /**
     * Retorna a lista com todas as estruturas cadastradas.
     *
     * @return string
     */
    public function getAll()
    {
        $lista = SaeDigital::make(ListaDeVersoesDaEstrutura::class)->handle();

        $this->responseJson(['data' => $lista]);
    }


    /**
     * Ativa ou desativa o status de uma estrutura.
     *
     * @return string
     */
    public function toggleStatus()
    {
        try {

            $id = (int)$this->input->get('id');
            $usuario = (int)$this->session->userdata('id');
            $statusCode = 200;
            $msg = 'Atualizado com sucesso.';

            SaeDigital::make(TrocaStatusEstrutura::class)->handle($id, $usuario);

        } catch (RecordInUseException $e) {
            $statusCode = 400;
            $msg = $e->getMessage();

        } catch (\Exception $e) {
            $statusCode = 500;
            $msg = $e->getMessage() . ' :: ' . $e->getFile() . ' :: ' . $e->getLine();
        }

        $this->responseJson(['msg' => $msg], $statusCode);
    }

    public function migrateFromJarvis()
    {
        try {
            $contentVersion = (int)$this->input->get('versaoConteudo', null);

            if (!$contentVersion) {
                throw new HttpRequestException('Versão de conteúdo não informada.');
            }

            SaeDigital::make(JarvisMigration::class)->handle($contentVersion);

            $statusCode = 200;
            $msg = 'Importação de conteúdo iniciada.';
        } catch (Exception $e) {
            $statusCode = 500;
            $msg = $e->getMessage() . ':: ' . $e->getFile() . ' :: ' . $e->getLine();
        }

        $this->responseJson(['msg' => $msg], $statusCode);
    }
}
