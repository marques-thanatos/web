<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Simulado extends MY_Controller {

    public $layout = 'relatorio';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $cssMinify = array('style_avasae_bootstrap3', 'botao_imprimir', 'mensagem');
    public $css = array();
    public $js = array('jquery/dist/jquery.min','bootstrap/dist/js/bootstrap.min','jquery.cookie','mensagem');
    public $keywords = array('avasae', 'simulado');
    public $perfil = null;
    public $usuarioid = null;
    public $login = null;

    public function __construct() {
        parent::__construct();

        //FIXED: ATRIBUTOS GLOBAIS
        $this->perfil = $this->session->userdata('perfil');
        $this->usuarioid = $this->session->userdata('pessoaid');
        $this->login = $this->session->userdata('login');
        $this->css[] = $this->minify->getCSS('relatorio_desempenhogeral.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->perfil);
        $dados['menu_com_legenda'] = false;
        $this->menu_vertical = $this->load->view('view_menurelatorio', $dados, true);
    }

    public function homeAluno(){
        $dados = array();
        $this->load->view('simulado/simuladoAluno',$dados);
    }

    public function homeProfessor(){
        $dados = array();
        $this->load->view('simulado/simuladoProfessor',$dados);
    }

    public function homeCoordenador(){
        $dados = array();
        $this->load->view('simulado/simuladoCoordenador',$dados);
    }

    public function homeDiretor(){
        $dados = array();
        $this->load->view('simulado/simuladoDiretor',$dados);
    }

    public function homeResponsavel(){
        $dados = array();
        $this->load->view('simulado/simuladoResponsavel',$dados);
    }


}