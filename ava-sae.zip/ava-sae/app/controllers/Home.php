<?php

use Ava\App\Services\JWT\CreateEducatJWT;
use Ava\App\Support\ClassificacaoConteudo;
use Ava\App\Services\Disciplinas\BuscarDisciplinasPorSerieVersao;
use Ava\App\Services\Turma\BuscaDadosTurmaNextAva;
use Ava\App\Services\Turma\BuscarTurmasRelatorioNextAva;
use Ava\App\Services\Turma\BuscarTurmasPorCategoria;
use Ava\App\Services\Usuario\ObterUsuarioNextAva;
use Ava\App\Support\Perfil;


if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home extends MY_Controller
{

    public $layout = 'default';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    //public $css = array('bootstrap', '_reset', 'css-responsive', 'geral', 'messi', 'home');                               
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'flowplayer-3.2.12.min', 'geral_v5', 'messi.min', 'home_v10.min', 'mensagem', 'arrase.no.enem');

    public $keywords = array('sae', 'home');


    public function __construct()
    {
        parent::__construct();
        $this->load->model('curso_model', 'curso');
        $this->load->model('cadastro_model', 'cadastro');
        // define os arquivos para juntar e comprimir
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'home', 'mensagem');
        $this->css[] = $this->minify->getCSS('home_construct.min', $this->cssMinify, ENVIRONMENT);
    }

    /**
     * index - [página principal área logada]
     *
     * Exibe a página inicial do usuário quando logado.
     *
     * @access    public
     * @return    void
     */
    public function index($turma = null)
    {
        
        try {
            $arraseNoEnem = [];
            $this->allowProfile([Perfil::PROFESSOR, Perfil::COORDENADOR]);

            $this->js[] = 'jquery.countdown.min';
            $this->load->helper('form_cursos');

            
            //$mValorPago[] = 0;
            $fields['Login'] = $this->session->userdata('login');

            if (!$this->session->userdata('professorPlataformaLiteraria') && $this->session->userdata('perfil') == PERFIL_PROFESSOR) {
                $disciplinas = $this->home->pegaDisciplinaArrayIds($this->session->userdata('subjects'));
                $professorPlataformaLiteraria = $this->cadastro->professorPlataformaLiteraria($disciplinas);

                $this->session->set_userdata('professorPlataformaLiteraria', $professorPlataformaLiteraria);
            }

            $pacotes = array();
            $formAssinatura = '';
            $formCursos = '';
            $dados = array();
            $turmas = array();
            $categorias = array();
            $data['comboTurma'] = '';
            //$vigencia = 0;
            //Verifica se é para pesquisar por categoria de coordenador

            $isPlataformaLiteraria = $this->uri->segment(2) == 'plataforma-literaria';
            $isAudioLinguaEstrangeira = $this->uri->segment(2) == 'audio-lingua-estrangeira';
            $isArraseNoEnem = $this->uri->segment(2) == 'arrase-no-enem';


            if($isArraseNoEnem){
                $this->redirect('/preparatorio');
                exit();
            }

            # SEMANA DE FORMACAO PEDAGOGICA
            $formacaoDateLimit = \Carbon\Carbon::create(2020, 06, 29, 23, 59);
            $datetimeNow = \Carbon\Carbon::now();

            if ($datetimeNow->lessThan($formacaoDateLimit)) {
                $data['formacaoPedagogica'] = true;
            } else {
                $data['formacaoPedagogica'] = false;
            }

            $teamsArray = $this->session->userdata('teams');
            $series = SaeDigital::make(BuscarTurmasRelatorioNextAva::class)->handle($teamsArray);

            //monta o combo
            $addSeries = [];
            $serieIdEnsinoInfantil = [15, 16, 17, 18, 19];
            $serieArraseNoEnem = [10, 11, 12, 13, 20];
            if (!empty($series)) {
                uasort($turmas, function ($a, $b) {
                    return strcmp($a['DescricaoTurma'], $b['DescricaoTurma']);
                });
                $data['comboTurma'] .= '<option value="">Selecione uma turma</option>';
                $data['comboSerie'] .= '<option value="">Selecione uma série</option>';
                foreach ($series as $key => $dados) {
                    $selected = $key == $turma ? 'selected' : '';
                    $data['comboTurma'] .= '<option value="' . $key . '" ' . $selected . '>' . $key . '</option>';
                    if ($isAudioLinguaEstrangeira && !in_array($dados->descricaoSerie, $addSeries) && !in_array($dados->idSerie, $serieIdEnsinoInfantil)) {
                        $data['comboSerie'] .= '<option value="' . $key . '" ' . $selected . '>' . $dados->descricaoSerie . '</option>';
                        $addSeries[] = $dados->descricaoSerie;
                    }

                    if ($isArraseNoEnem && !in_array($dados->descricaoSerie, $addSeries) && in_array($dados->idSerie, $serieArraseNoEnem)) {
                        $data['comboSerie'] .= '<option value="' . $key . '" ' . $selected . '>' . $dados->descricaoSerie . '</option>';
                        $addSeries[] = $dados->descricaoSerie;
                    }
                }
            }

            // Muda combo de turma para combo série
            if ($isAudioLinguaEstrangeira || $isArraseNoEnem) {
                $data['comboTurma'] = $data['comboSerie'];
            }

            //mostras dados apenas depois de selecionar alguma turma
            if (!empty($turma)) {
                $this->session->set_userdata('TurmaID', $turma);
                $perfilID = $this->session->userdata('perfil');
                $serie = $this->home->verificaTurmas($turma);
                $dataTurma = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($turma);

                $grupoAula = $this->home->pegaDisciplinaArrayIds($this->session->userdata('subjects'));

                if (!empty($grupoAula)) {
                    foreach ($grupoAula as $key => $val) {
                        if (strpos(strtolower($val['Descricao']), '(anos iniciais)') !== false) {
                            continue;
                        }

                        if ($isPlataformaLiteraria && $val['ClassificacaoID'] != ClassificacaoConteudo::PLATAFORMA_LITERARIA) {
                            continue;
                        }

                        $assuntos = $this->curso->verificaAssuntos($val['itemName']);

                        $value['Ancora'] = $val['Ancora'];
                        $value['QtdAssuntos'] = empty($assuntos) ? 0 : count($assuntos);
                        $value['DescricaoPacote'] = $val['Descricao'];
                        $value['Turma'] = $turma;
                        $value['linkCurso'] = '';
                        $value['btnIniciar'] = 2;
                        $value['imprimeBoleto'] = 0;
                        $value['bloqueado'] = '';
                        $value['ItemName'] = $val['itemName'];
                        $value['ClassificacaoID'] = $val['ClassificacaoID'];

                        if (!empty($value['Ancora'])) {
                            $value['linkCurso'] = base_url() . 'curso/' . trim($value['Ancora']);

                            if ($this->session->userdata('situacaoSessao') == 'I') {
                                $value['linkCurso'] = 'javascript:void(0)';
                                $value['btnIniciar'] = 3;
                            }
                        }

                        //print_pre($value);print('<br>');
                        $formCursos .= form_home(2, $key, $value, $this);
                    }
                }

                if ($isPlataformaLiteraria && count($grupoAula)) {
                    $filterPl = array_filter($grupoAula, function ($item) use ($dataTurma) {
                        return ($item['ClassificacaoID'] == ClassificacaoConteudo::PLATAFORMA_LITERARIA && intval($item['SerieID']) == intval($dataTurma[0]->gradeId));
                    });
                    $pl = array_pop($filterPl);
                    if ($pl) {
                        $this->redirect("/curso/{$pl['Ancora']}?turmaID={$turma}");
                    } else {
                        $this->redirect("/curso/plataforma-literaria");
                    }
                }

                if ($isAudioLinguaEstrangeira && count($grupoAula)) {
                    $this->redirect("/preparatorio/audios-lingua-estrangeira?turmaID={$turma}");
                }

                if (isset($serie)) {
                    $id = $key + 1;
                    $grupoAula = [];
                    if (isset($serie[0]['SerieID'])) {
                        $grupoAula = $this->home->getDisciplinasPermanentes($serie[0]['SerieID']);
                        $disciplinaExclusivaBoxVerde = $this->home->getDisciplinasExclusivas($this->session->userdata('escola'), $serie[0]['SerieID'], 12);
                        if (!empty($disciplinaExclusivaBoxVerde)) {
                            for ($i = 0; $i < count($disciplinaExclusivaBoxVerde); $i++) {
                                $grupoAula2 = $this->home->buscaDisciplinasExclusivas($disciplinaExclusivaBoxVerde[$i]['DisciplinaID']);
                                if (is_array($grupoAula2)) {
                                    $grupoAula = is_array($grupoAula) ? array_merge($grupoAula, $grupoAula2) : $grupoAula2;
                                }
                            }
                        }
                    }

                    $grupoAula = array_filter($grupoAula, function ($value) use (&$arraseNoEnem) {
                        if (stripos($value['Descricao'], 'arrase no enem')) {
                            $arraseNoEnem[$value['id']] = [
                                'DescricaoDisciplina' => $value['Descricao'],
                                'Ancora' => $value['Ancora'],
                                'DataInicio' => $value['DtInicio'],
                                'DataFim' => $value['DtFim'],
                                'Classificacao' => $value['ClassificacaoID'],
                                'Controller' => $value['Controller'],
                            ];
                            return false;
                        }
                        return true;
                    });

                    if (!empty($grupoAula)) {
                        foreach ($grupoAula as $k => $val) {
                            if ($isPlataformaLiteraria && $val['ClassificacaoID'] != ClassificacaoConteudo::PLATAFORMA_LITERARIA) {
                                continue;
                            }

                            if ($isArraseNoEnem && $val['ClassificacaoID'] != ClassificacaoConteudo::ARRASE_ENEM) {
                                continue;
                            }

                            $value['Controller'] = $val['Controller'];
                            $value['QtdPacotesSimultaneos'] = isset($val['QtdAcessosSimultaneos']) ? $val['QtdAcessosSimultaneos'] : '';
                            $value['ClassificacaoID'] = $val['ClassificacaoID'];
                            $value['Ancora'] = $val['Ancora'];
                            $value['Duracao'] = isset($val['Duracao']) ? $val['Duracao'] : '0';
                            $value['GrupoAulaID'] = $val['itemName'];
                            $value['ClassificacaoID'] = $val['ClassificacaoID'];
                            $value['DescricaoPacote'] = $val['Descricao'];

                            if (!isset($value['ValorPacote']) && $value['Ancora'] != 'meu-primeiro-concurso') {
                                if (isset($val['Valor'])) {
                                    $value['ValorPacote'] = $val['Valor'];
                                } else {
                                    $value['ValorPacote'] = 0;
                                }
                            }

                            $timeGrupo = strtotime($val['DtInicio']);

                            $DiasRestantesPacote = '';
                            $DiasRestantesBoleto = '';
                            $dtInicioPacote = '';
                            $dtFimPacote = '';
                            $value['linkCurso'] = '';
                            $value['btnIniciar'] = 2;
                            $value['imprimeBoleto'] = 0;
                            $value['bloqueado'] = '';

                            $exibeDisciplina = true;
                            if ($val['DtFim'] != '-') {
                                $form = 1;
                                $value['DtFim'] = $val['DtFim'];
                                if ($val['DtInicio'] == '-') {
                                    $value['DtInicio'] = date('Y-m-d H:i:s');
                                } else {
                                    $value['DtInicio'] = $val['DtInicio'];
                                }

                                $dtInicioPacote = date_create($value['DtInicio']);
                                $dtAtual = date_create(date('Y-m-d H:i:s'));
                                $DiasRestantesBoleto = $dtAtual->diff($dtInicioPacote);

                                $value['dtInicioPacote'] = $dtInicioPacote;

                                $dtFimPacote = date_create($value['DtFim']);
                                $DiasRestantesPacote = date_diff($dtAtual, $dtFimPacote);

                                if ($dtAtual > $dtFimPacote) {
                                    $exibeDisciplina = false;
                                }

                                $bloqueado = '';
                                $value['DiasRestantesPacote'] = $DiasRestantesPacote;
                                $value['dtFimPacote'] = $dtFimPacote;
                                $value['bloqueado'] = $bloqueado;

                                $value['linkCurso'] = base_url() . $value['Controller'] . '/' . trim($value['Ancora']);
                                $value['btnIniciar'] = 3;
                            }
                            if ($exibeDisciplina) {
                                $formCursos .= form_home_prep($form, $id, $value, $this);
                            }
                            $id++;
                        }
                    }
                }
            }


            if ($isArraseNoEnem && count($arraseNoEnem)) {
                $cursoCompleto = $this->input->get('cursoCompleto');

                if ($cursoCompleto && filter_var($cursoCompleto, FILTER_VALIDATE_BOOLEAN)) {
                    $currentArraseNoEnem = array_shift($arraseNoEnem);
                } else {
                    $currentArraseNoEnem = array_pop($arraseNoEnem);
                }

                return $this->redirect("/preparatorio/{$currentArraseNoEnem['Ancora']}?turmaID={$turma}");
            }

            //salva o cookie dos pacotes para ser usado nas mensagens
            $cookie = array(
                'name' => 'pacotes' . $this->session->userdata('id'),
                'value' => json_encode($pacotes),
                'expire' => 14400,
                'domain' => '',
                'secure' => FALSE
            );
            $this->input->set_cookie($cookie);

            $data['formCursos'] = $formCursos;
            $data['formAssinatura'] = $formAssinatura;
            // $data['boxNoticias'] = $this->home->verificaNoticias();
            $data['controller'] = $this->uri->segment(1);

            krsort($arraseNoEnem);
            $data['arraseNoEnem'] = newFormCurso($arraseNoEnem, $turma);

            //$data['boxVideo'] = $this->home->verificaProgramadaSemana();
            $this->session->set_userdata('siteID', $data['boxVideo'][0]['id']);

            $perfilid = $this->session->userdata('perfil');
            //FIXME: Simulado 2017
            if ($perfilid == PERFIL_PROFESSOR || $perfilid == PERFIL_COORDENADOR) {
                $mostraSimulado = false;
                $login = $this->session->userdata('login');
                $turmasAcesso = $this->home->getTurmasSeriesPorLogin($login);
                foreach ($turmasAcesso as $key => $turma) {
                    if (intval($turma->SerieID) >= 10) {
                        $mostraSimulado = true;
                        break;
                    }
                }

                if ($perfilid == PERFIL_COORDENADOR) {
                    $urlCondicaoSimulado = SIMULADO_CONDICOES;
                    $urlInscricao = SIMULADO_INSCRICAO;
                    $data['urlCondicaoSimulado'] = $urlCondicaoSimulado;
                    $data['urlInscricao'] = $urlInscricao;
                }

                $data["perfil"] = $perfilid;
                $data["mostraSimulado"] = $mostraSimulado;
            }

            $data['educatSignedUrl'] = null;
            try {
                $educatUserId = $this->session->userdata('pessoaid');
                $data['educatSignedUrl'] = SaeDigital::make(CreateEducatJWT::class)->generateUrl($educatUserId);
            } catch (Exception $e) {

            }

            $data['metadata'] = [
                'page_head' => $isPlataformaLiteraria ? 'Plataforma Literária' : 'Componente Curricular'
            ];

            $data['isPlataformaLiteraria'] = $isPlataformaLiteraria;
            $data['isAudioLinguaEstrangeira'] = $isAudioLinguaEstrangeira;
            $data['isArraseNoEnem'] = $isArraseNoEnem;

            if ($this->input->get('json') && filter_var($this->input->get('json'), FILTER_VALIDATE_BOOLEAN)) {
                return $this->responseJson($data);
            }

            $this->load->view('home', $data);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    function search($array, $key, $value)
    {

        if (!is_array($value)) {
            return;
        }

        $results = array();
        foreach ($value as $key2) {
            $this->search_r($array, $key, $key2, $results);
        }
        return $results;
    }

    function search_r($array, $key, $value, &$results)
    {
        if (!is_array($array)) {
            return;
        }

        if (isset($array[$key]) && $array[$key] == $value) {
            $results[] = $array;
        }

        foreach ($array as $subarray) {
            $this->search_r($subarray, $key, $value, $results);
        }
    }
}

/* End of file home.php */
/* Location: ./application/controllers/home.php */
