<?php
//header("Content-Type: text/html; charset=ISO-8859-1",true);
//header ('Content-type: text/html; charset=UTF-8');
header("Content-Type: text/html; charset=UTF-8",true);

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tickets extends MY_Controller {
    public $layout = 'default';
    public $title = 'Informativo de erros';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min', 'jquery.maskedinput.min', 'mensagem', 'jquery.cookie', 'jquery.dataTables', 'cadastro', 'chosen.jquery.min', 'ticket');
    
    public $keywords = array('sae', 'tickets');

    const TICKET_LIDO = 114096189771;

    public function __construct()
    {
        parent::__construct();              
      
        $this->load->model('ticket_model', 'tickets');
        $this->load->model('mensagemsae_model', 'mensagem');
        $this->load->helper('url');
        $this->load->helper('cookie');
        $this->load->helper('menu_helper');
        
        $this->load->library("pagination");
        
        $this->cssMinify = array('bootstrap-new.min', 'bootstrap', '_reset', 'geral', 'messi', 'mensagem', 'chosen');
         

    }
    
    
    public function ListTicketsView()       
    {

        $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
        $this->css[] = 'ticket-list';

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $dados = array('dados' => null, 'sortedTickets' => array(), 'tickets' => array());

        $client = $this->tickets->getClient();

        $search = $client->users()->search(['query' => 'email:' . $this->tickets->getRequesterEmail()]);

        if (!empty($search->users)) {

            $user = $search->users[0];

            $client->users()->update($user->id, [
                'user_fields' => [
                    'login' => $this->session->userdata('login')
                ]

            ]);

            $tickets = $client->search()->find(
                'requester:' . $this->tickets->getRequesterEmail(),
                array( 'sort_by' => 'created_at', 'sort_order' => 'desc')
            );

            foreach ($tickets->results as $ticket) {

                $dadosTicket = array(
                    "id" => $ticket->id,
                    "zd_ticket_id" => $ticket->id,
                    "assunto" => $ticket->subject,
                    "criado_em" => $ticket->created_at,
                    "modificado_em" => $ticket->updated_at,
                    "zd_status" => $ticket->status,
                    $dados["nao_lido"] = false,
                );
                if ($ticket->tags) {
                    $dadosTicket["nao_lido"] = in_array('nao_lido', $ticket->tags);
                }
                $dados['tickets'][] = $dadosTicket;

            }

            $sortedTickets = array();
            foreach ($dados['tickets'] as $ticket) {
                $timestamp = strtotime($ticket['criado_em']);
                $date = date("d/M/Y", $timestamp); //truncate hours:minutes:seconds
                if (!isSet($sortedTickets[$date])) { //first entry of that day
                    $sortedTickets[$date] = array($ticket);
                } else { //just push current element onto existing array
                    $sortedTickets[$date][] = $ticket;
                }
            }
            $dados['sortedTickets'] = $sortedTickets;
        }
        $this->load->view('tickets_list_view', $dados);
    }

    public function TicketView($ticket_id)       
    {

        $client = $this->tickets->getClient();
        $dadosTicket = $this->getTicket($ticket_id);

        $ticket = $dadosTicket->ticket;
        $user = $this->getEndUser($dadosTicket);

        if ($this->podeAcessarOTicket($user)) {
            $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
            $this->css[] = 'ticket';

            $dados['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            if ($ticket->status !== 'closed') {
                $client->tickets()->update($ticket->id, [
                    "tags" => array_diff($ticket->tags, ['nao_lido']),
                    "custom_fields" => array_merge($ticket->fields, [
                        [
                            "id" => self::TICKET_LIDO,
                            "value" => true
                        ]
                    ])
                ]);
            }

            $this->mensagem->removerNotificacaoDeMensagemNaoLida(
                $ticket->id,
                $this->session->userdata('pessoaid')
            );

            $this->removeTicketSession((int)$ticket_id);

            $comments = $client->tickets($ticket_id)->comments()->findAll();

            $dados['comments'] = $comments;
            $dados['ticket'] = $ticket;
            $dados['user'] = $user;


            $this->load->view('ticket_view', $dados);
        } else {
            show_404();
        }
             
    }

    /**
     * @param $ticketId
     */
    private function removeTicketSession($ticketId)
    {
        $novaSessao = [];
        foreach ($this->session->userdata('mensagens') as $key => $mensagem) {
            if ($mensagem->id != $ticketId) {
                $novaSessao[] = $mensagem;
            }
        }

        $this->session->set_userdata('mensagens', $novaSessao);
    }

    public function addTicketComment()       
    {               
        header('Content-Type: application/json');
        $ticket_id =  $this->input->post('zd_ticket_id', true);

        $client = $this->tickets->getClient();
        $dadosTicket = $this->getTicket($ticket_id);
        
        $file = $_FILES['media'];

        $ticket = $dadosTicket->ticket;
        $user = $this->getEndUser($dadosTicket);

        if($this->podeAcessarOTicket($user)){

            if (isset($file)) {
               $attachment = $client->attachments()->upload([
                    'file' => $file["tmp_name"],
                    'type' => $file["type"],
                    'name' => $file["name"]
                ]); 
            }

            if ($ticket->status !== 'closed') {
                $comment_body_post =  $this->input->post('comment_body', true);

                $comment_body = "Mensagem sem corpo";

                if ($comment_body_post !== '') {
                    $comment_body = $comment_body_post;
                }

                if ($ticket->status !== 'closed') {
                    $client->tickets()->update($ticket_id, [
                        'comment' => [
                            'body' => $comment_body,
                            'author_id' => $user->id,
                            'uploads' => (isset($attachment)) ? [$attachment->upload->token] : []
                        ],
                        'status' => 'open'

                    ]);
                }
            }
        }

        $result = array(
            "title" => "Sucesso",
            "status" => true, 
            "message" => "Comentário recebido",
            "comment" => $comment_body,
            "attachment" => (isset($attachment)) ? $attachment->upload->attachment : NULL
        );
        exit(json_encode($result));
    }


    /**
     * @param $ticket_id
     * @return mixed
     */
    private function getTicket($ticket_id)
    {
        return $this->tickets->getClient()->tickets()->sideload(['users'])->find($ticket_id);
    }

    /**
     * @param $user
     * @return bool
     */
    private function podeAcessarOTicket($user)
    {
        return $user->email == $this->tickets->getRequesterEmail();
    }

    /**
     * @param $dadosTicket
     * @return mixed
     */
    private function getEndUser($dadosTicket)
    {
        foreach ($dadosTicket->users as $zendeskUser) {
            if ($zendeskUser->role == 'end-user') {
                $user = $zendeskUser;
            }
        }
        return $user;
    }

    public function zendeskNotificationHook()
    {
        $this->layout = false;

        $code = 404;

        if ($this->input->server('REQUEST_METHOD') == 'POST' && $this->input->post('token') === getenv('ZENDESK_WEBHOOK_TOKEN')) {
            $this->load->model('cadastro_model', 'cadastro');

            $ticketId = $this->input->post('ticketId');
            $idSolicitante = explode('@', $this->input->post('requesterEmail'))[0];

            // BUSCAR DADOS NEXT AVA PARA PREENCHER
            // APENAS BUSCAVA OS DADOS DO USUÁRIO PARA SABER SE ELE EXISTE

            // $usuario = $this->login->getUsuario($idSolicitante);

            // if ($usuario) {
                $this->load->model('mensagemsae_model', 'mensagemsae');
                $this->mensagemsae->salvarNotificacaoDeMensagemNaoLida($ticketId, $idSolicitante);
                $code = 201;
            // }
        } else {
            $code = 401;
        }

        http_response_code($code);
        header('Content-type: application/json');
        echo json_encode(['code' => $code]);
    }
}
