<?php

use Ava\App\Aggregates\DocxQuestoesAggregate;
use Ava\App\Entities\GroupOfQuestionsEntity;
use Ava\App\Services\Aluno\AtualizarAcessoLivroDigitalUsuario;
use Ava\App\Services\Aluno\BuscarAlunosPorTurma;
use Ava\App\Services\Aluno\BuscarAlunosPorVigenciaTurma;
use Ava\App\Services\Aluno\BuscarTurmasDisponiveisPorLogin;
use Ava\App\Services\AprovaQuestoes\Questoes\ValidarAlteracaoDeGabarito;
use Ava\App\Services\Auth\ValidarLoginPrimeiroLogin;
use Ava\App\Exceptions\NotFoundException;
use Ava\App\Services\Aluno\BuscarLoginsAlunosResponsaveisPorTurma;
use Ava\App\Services\Aluno\BuscarLoginsAlunosResponsaveisPorTurmaNextAva;
use Ava\App\Services\Aluno\CriarAluno;
use Ava\App\Services\Cadastro\AtualizarDadosPrimeiroLogin;
use Ava\App\Services\Cadastro\InativarUsuarios;
use Ava\App\Services\Cadastro\InativarUsuariosNextAVA;
use Ava\App\Services\Cadastro\MigrarAlunosNextAVA;
use Ava\App\Services\Cadastro\ValidarDuplicidadeEmail;
use Ava\App\Services\Usuario\BuscarDadosUsuariosNextAva;
use Ava\App\Services\NextAVA\AlunosResponsavelNextAva;
use Ava\App\Services\NextAVA\ObterDisciplinasTurmasNextAVA;
use Ava\App\Services\NextAVA\UsuarioNextAVA;
use Ava\App\Services\ConfiguracaoEscola\AtualizarConfiguracaoGeral;
use Ava\App\Services\ConfiguracaoEscola\AtualizarConfiguracaoSerie;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracao;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracaoGeralEscola;
use Ava\App\Services\ConfiguracaoEscola\BuscarConfiguracaoSeriesPorEscola;
use Ava\App\Services\ConfiguracaoEscola\RemoverConfiguracaoInvalida;
use Ava\App\Services\Escola\AtualizarEscolaNextAva;
use Ava\App\Services\Escola\BuscarDadosEscola;
use Ava\App\Services\Escola\BuscarDadosEscolaNextAva;
use Ava\App\Services\Escola\BuscarDadosEscolaEspecificaNextAva;
use Ava\App\Services\Escola\BuscarSegmentosVersaoConteudoNextAva;
use Ava\App\Services\Escola\CadastrarEscolaNextAva;
use Ava\App\Services\Escola\ListarEscolas;
use Ava\App\Services\Faq\PegarCategoriasPorFaqId;
use Ava\App\Services\Faq\ListarCategorias;
use Ava\App\Services\Faq\PegarFaqPorID;
use Ava\App\Services\Gabarito\AlteraGabaritoQuestao;
use Ava\App\Services\LivroDigital\AtualizarAcessoLivroDigitalPorConfigSerie;
use Ava\App\Services\LivroDigital\BuscarConfiguracoesSeriePorEscola;
use Ava\App\Services\Questoes\Docx2Html;
use Ava\App\Services\Questoes\Html2Object;
use Ava\App\Services\Questoes\ImportarQuestoes;
use Ava\App\Services\Questoes\UploadDocxService;
use Ava\App\Services\Questoes\ValidateGroupQuestions;
use Ava\App\Services\Responsavel\AtualizarSituacaoResponsavelPorAluno;
use Ava\App\Services\Responsavel\ListarResponsaveisPorEscola;
use Ava\App\Services\Series\BuscarSeriesNextAva;
use Ava\App\Services\Series\BuscarSeriesPorEscola;
use Ava\App\Services\Series\BuscarSeriesPorSegmentoEscolar;
use Ava\App\Services\Turma\BuscaDadosTurmaNextAva;
use Ava\App\Services\Turma\BuscarTurmaPorAluno;
use Ava\App\Services\Turma\BuscarTurmasEscolaPorSerie;
use Ava\App\Services\Turma\BuscarTurmasNextAva;
use Ava\App\Services\Turma\BuscarTurmasNextAvaVigencia;
use Ava\App\Services\Turma\BuscarTurmasEscolaPorVigencia;
use Ava\App\Services\Turma\CadastrarTurmaNextAva;
use Ava\App\Services\Turma\ValidarAlteracaoVigencia;
use Ava\App\Services\Responsavel\CriarResponsavel;
use Ava\App\Services\Turma\BuscarDadosTurma;
use Ava\App\Services\Usuario\BuscarUsuarioPorItemName;
use Ava\App\Services\Usuario\BuscarUsuarioPorLogin;
use Ava\App\Services\Usuario\EnqueueDeletarUsuarioPortal;
use Ava\App\Services\Usuario\ObterUsuariosPorTurmaNextAva;
use Ava\App\Services\Usuario\VerificarDuplicidadeUsuario;
use Ava\App\Services\Usuario\ObterUsuarioNextAva;
use Ava\App\Support\Perfil;
use Ava\App\Support\Segmento;
use Ava\App\Support\Senha;
use Ava\App\Support\Situacao;
use Hashids\Hashids;
use Illuminate\Support\Collection;
use League\Csv\Reader;
use League\Flysystem\AwsS3v3\AwsS3Adapter;
use WSW\SimpleUpload\Services\SimpleUpload;
use WSW\SimpleUpload\Services\Translator;
use Ava\App\Services\Upload\UploadImageS3;
use Ava\App\Services\Demonstrativo\CadastrarDemo;

use Ava\App\Services\Disciplinas\BuscarDisciplinasPorTurmaNextAva;

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cadastro extends MY_Controller
{
    public $layout = 'default';
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';
    //public $css = array('bootstrap', '_reset', 'css-responsive','geral', 'messi');
    //public $css = array('redactor/redactor');

    public $js = array('jquery.min', 'bootstrap.min', 'bootstrap-button.min', 'geral_v5', 'messi.min',
        'jquery.maskedinput.min', 'mensagem', 'jquery.cookie', 'jquery.dataTables', 'cadastro', 'simulado', 'plataforma');
    public $keywords = array('sae', 'curso');
    public $regexLogin = "/^(?=.{6,}$)[a-z0-9\_\-\@\.]*$/";

    public function __construct() {

        parent::__construct();

        $this->load->model('cadastro_model', 'cadastro');
        $this->load->model('questao_model', 'questao');
        $this->load->model('plataformaliteraria_model', 'literaria');
        $this->load->model('ticket_model', 'tickets');
        $this->load->library('dadosrelatorio_lib');
        $this->load->library('PHPExcel');
        $this->load->library('pagination');

        // define os arquivos para juntar e comprimir
        $this->cssMinify = array('bootstrap-new.min', 'bootstrap', '_reset', 'geral', 'messi', 'mensagem');
        $this->css[] = 'bootstrap/bootstrap.min';
        $this->css[] = 'jquery-ui-1.12.1.custom/jquery-ui';
        $this->css[] = 'redactor/redactor';
    }

    public function index()
    {
        try {
            $this->allowProfile([Perfil::ESCOLA, Perfil::DIRETOR, Perfil::ADMIN, Perfil::CONTEUDO]);

            $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
            $perfilid = $this->session->userdata('perfil');
            $dados['dados'] = montaMenu($perfilid);
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            if($perfilid == PERFIL_DIRETOR){
                $urlCondicaoSimulado = SIMULADO_CONDICOES;
                $urlInscricao = SIMULADO_INSCRICAO;
                $data['urlCondicaoSimulado'] = $urlCondicaoSimulado;
                $data['urlInscricao'] = $urlInscricao;
                $data['urlInscricao'] = $urlInscricao;

                $data['perfil'] = $perfilid;
                $this->load->view('simulado/home_diretor', $data);
            }

            if ($perfilid == PERFIL_ESCOLA) {
                $this->load->view('simulado/home_diretor', ['exibirComunicado' => true]);
            }

            if (in_array((int)$perfilid, [Perfil::CONTEUDO])) {
                $this->load->view('informativos/informativo-conteudo');
            }

        } catch (Exception $e) {
            // if ($myProfile == Perfil::ALUNO) {
            //     $this->redirect('/aluno');
            // } else if ($myProfile == Perfil::RESPONSAVEL) {
            //     $this->redirect('/responsavel');
            // } else if ($myProfile == Perfil::PROFESSOR) {
            //     $this->redirect('/professor');
            // } else if ($myProfile == Perfil::COORDENADOR) {
            //     $this->redirect('/coordenador');
            // }

            log_error($e->getMessage());
            show_404();
        }
    }

    public function listarEscola()
    {
        if($this->session->userdata('perfil') != 268)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';

        $this->css[] = $this->minify->getCSS('cadastro_escola_lista.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);
        $token = $this->session->userdata('token');
        $data['lista'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle($token,'269');
        $this->load->view('cadastro/listarEscola', $data);
    }

    public function cadastrarEscola($id = null)
    {
        if($this->session->userdata('perfil') != 268)
        {
            Redirect('/');
        }

        $this->load->helper('form');

        $this->css[] = $this->minify->getCSS('cadastro_escola.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['edit'] = 0;

        $dadosEscolaSegmentos = SaeDigital::make(BuscarSegmentosVersaoConteudoNextAva::class)->handle();

        $segmentos = $dadosEscolaSegmentos->segments;

        foreach ($segmentos as $segmento) {
            $data['segmentos'][] = [
                'id' => $segmento->id,
                'text' => ucwords(strtolower(str_replace('_', ' ', $segmento->name)))
            ];
        }


        $data['segmentosEscola'] = [];
        if ($id) {
            $configuracaoEscola = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle($id);
            $data['segmentosEscola'] = explode(',', $configuracaoEscola['segmentos']);
            $data['dadosEscola'] = SaeDigital::make(BuscarDadosEscolaEspecificaNextAva::class)->handle($id);
            $data['edit'] = 1;
        }

        $versoesConteudo = $dadosEscolaSegmentos->versao_conteudo;

        $versoesConteudo = array_reduce($versoesConteudo, function ($result, $item) {
            $result[$item->id] = $item->name;
            return $result;
        }, array());

        $data["form_versao_conteudo"] = form_dropdown('versao_conteudo', $versoesConteudo, '1', 'id="versao_conteudo"');

        $this->load->view('cadastro/cadastrarEscola', $data);
    }

    private function getExtension($filename)
    {
        $x = explode('.', $filename);

        if (count($x) === 1)
        {
            return '';
        }

        return strtolower(end($x));
    }

    private function validarDimensoesImagem($imagem)
    {
        list($width, $height) = getimagesize($imagem);

        return  ((int)$width <= 600 || (int)$height <= 264);
    }

    public function salvarEscola()
    {
        try {
            if ($this->session->userdata('perfil') != 268) {
                Redirect('/');
            }

            $this->layout = '';

            $inputNome = $this->input->post('inputNome');
            $edit = $this->input->post('edit');
            $idEscola = $this->input->post('idEscola');
            $itemNameEscola = $this->input->post('itemNameEscola');
            $situacao = $this->input->post('situacao');
            $inputLogin = $this->input->post('inputLogin');
            $inputSenha = $this->input->post('inputSenha');
            $inputGrupo = $this->input->post('inputGrupo');
            $inputQAlunos = $this->input->post('inputQAlunos');
            $inputIdProtheus = $this->input->post('inputIdProtheus');
            $inputEmail = $this->input->post('inputEmail');
            $segmentos = $this->input->post('segmentos');
            $versao_conteudo = $this->input->post('versao_conteudo');

            $fields['name'] = trim($inputNome);
            $fields['login'] = removeAcentos(trim($inputLogin));
            $fields['email'] = trim($inputEmail);
            if ( $edit == 1 && strlen($inputSenha)>5 ){
                $fields['password'] = $inputSenha;
            }
            $fields['studentCount'] = (int) $inputQAlunos;
            $fields['Redirecionar'] = 'cadastro';

            $fields['idProtheus'] = $inputIdProtheus;
            $itemName = ($edit == 1) ? $idEscola : md5(uniqid(rand(), true));

            if (isset($_FILES['arquivo'])) {
                if (!$this->validarDimensoesImagem($_FILES['arquivo']['tmp_name'])) {
                    throw new Exception('Imagem com dimensões fora do permitido.');
                }

                $file = SimpleUpload::create($_FILES['arquivo'], SaeDigital::make(AwsS3Adapter::class), Translator::locate('pt-BR'));
                $file->setAllowedExtensions(['jpeg','jpg','png']);
                $file->setPath('avasae/logos');
                $file->setName($itemName . $this->getExtension($_FILES['arquivo']['name']));

                if (!$file->send()) {
                    throw new Exception('Ocorreu um problema com o upload da logo.');
                }
            }
            $stringArray = explode(",", $segmentos);
            $segmentosInt = array_map(
                function($value) { return (int)$value; },
                $stringArray
            );

            $fields['segments'] = $segmentosInt;
            if ($edit == 1) {
                $fields['active'] = $situacao;

                $whereUpdate = [];
                $whereUpdate['Escola'] = $idEscola;
                $whereTurma['EscolaID']= $idEscola;

                $fields['schoolId'] = (int) $idEscola;

                if($itemNameEscola)
                    $fields['itemName'] = $itemNameEscola;

                $resultado = SaeDigital::make(AtualizarEscolaNextAva::class)->handle($fields);
            } else {
                $fields['versao_conteudo_id'] = (int) $versao_conteudo;
                $fields['password'] = $inputSenha;

                $resultado = SaeDigital::make(CadastrarEscolaNextAva::class)->handle($fields);
            }

            return $this->responseJson(['resultado' => $resultado], 200);
        } catch (Exception $e) {
            $message = json_decode($e->getResponse()->getBody()->getContents());
            return $this->responseJson(['message' => $message->message], 500);
        }
    }

    public function listarDiretor()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269)
        {
            Redirect('/');
        }
        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'listarDiretor';

        $this->css[] = $this->minify->getCSS('cadastro_diretor_lista.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $escolaid = null;

        if ($this->session->userdata('school')) {
            $escolaid = $this->session->userdata('school')->id;
        }
        $token = $this->session->userdata('token');
        $data['lista'] = SaeDigital::make(BuscarDadosUsuariosNextAva::class)->handle($token, 5, $escolaid);

        $this->load->view('cadastro/listarDiretor', $data);

    }

    public function cadastrarDiretor($id = null)
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';

        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';

        $this->css[] = $this->minify->getCSS('cadastro_diretor.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['edit'] = 0;

        // $data['dadosEscola'] = $this->cadastro->getDados(269, null, 'A');
        $data['dadosEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle();

        if ($id) {
            // $data['dadosDiretor'] = $this->cadastro->getDados(270, $id);
            // $data['livrodigital'] = $this->cadastro->getAcessoLD($data['dadosDiretor'][0]['Escola']);
            $data['personId'] = $id;

            $usuario = SaeDigital::make(UsuarioNextAVA::class)->get($id, 5);
            $data['dadosDiretor'] = $usuario;

            $data['escolaID'] = $usuario->schoolId;
            $data['descEscola'] = $usuario->schoolName;

            $data['edit'] = 1;
        }

        if ($this->session->userdata('escola')) {
            $data['escolaID'] = $this->session->userdata('school')->id;
            $data['livrodigital'] = $this->cadastro->getAcessoLD($this->session->userdata('escola'));
            $data['descEscola'] = $this->session->userdata('nomeEscola') ? $this->session->userdata('nomeEscola') : $this->session->userdata('nome');
        }

        $this->load->view('cadastro/cadastrarDiretor', $data);
    }

    public function salvarDiretor()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);
        extract($post);

        $userData['name'] = trim($nome);
        $userData['login'] = strtolower(removeAcentos(trim($login)));
        $userData['password'] = $senha;
        $userData['type'] = 5;
        $userData['email'] = trim($email);
        $userData['schoolId'] = 1 * $escola;
        $userData['personId'] = 1 * $idDiretor;
        $userData['active'] = $active == 'A';

        $usuario = SaeDigital::make(UsuarioNextAVA::class);

        if ( $personId )
            $save = $usuario->update($userData);
        else
            $save = $usuario->create($userData);

        echo json_encode($save);

        return;
    }

    public function listarTurma()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'listarTurma';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';

        $this->css[] = $this->minify->getCSS('cadastro_turma_lista.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $escolaid = null;
        if ($this->session->userdata('school')) {
            $data['escolaid'] = $this->session->userdata('school')->id;
            //$data['lista'] = $this->cadastro->getDadosTurma($escolaid);
        } else {
            $data['comboEscola'] = $this->cadastro->getEscolas();
        }



        $this->load->view('cadastro/listarTurma', $data);
    }

    public function buscaListaTurma(){
        $this->layout = '';
        $escolaid = $this->input->post('escolaid', true);
        $vigencia = $this->input->post('vigencia', true);

        $token = $this->session->userdata('token');
        $turmas = SaeDigital::make(BuscarTurmasNextAvaVigencia::class)->handle($token, $escolaid, $vigencia);

        $table = '';
        foreach ($turmas as $key) {
            $table .= '<tr>';
            if ($this->session->userdata('perfil') == 268) {
                $table .= '<td style="text-align:center;"><input onClick="mostrarBotaoApagar(\''.$key->id.'\')" type="checkbox" class="excluir" name="excluir[]" value="'.$key->id.'"/></td>';
            }
            $situacao = $key->active == true ? 'Ativa' : 'Inativa';
            $descricao = $key->name ? ($key->name) : '';
            $descricaoSerie = $key->grade ? ($key->grade) : '';
            $descricaoCategoriaTurma = isset($key->segment) ? ($key->segment->name) : '';
            $nomeEscola = $key->schoolName ? ($key->schoolName) : '';
            $table .= '<td style="text-align:center;">'. $descricao .'</td>
                <td style="text-align:center;">'. $descricaoSerie .'</td>
                <td style="text-align:center;">'. $key->year .'</td>
                <td style="text-align:center;">'. $descricaoCategoriaTurma.'</td>
                <td style="text-align:center;">'. $nomeEscola .'</td>
                <td style="text-align:center;">'. $situacao .'</td>
                <td style="text-align:center;"><a id="btAtualizar" href="'. base_url() .'cadastro/cadastrarTurma/'. $key->id .'"><i class="glyphicon glyphicon-edit"></i></a></td></tr>';
        }

        print($table);die;
    }

    public function cadastrarTurma($id = null)
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'chosen.jquery.min';
        $this->js[] = 'axios.min';
        $this->cssMinify[] = 'chosen';

        $this->css[] = $this->minify->getCSS('cadastro_turma.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['edit'] = 0;

        $token = $this->session->userdata('token');
        $data['dadosEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle($token,'269');

        //$configEscola = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle($this->session->userdata('escola'));

        //$serie = $this->cadastro->getSerie(null, null, $configEscola['segmentos']);

        $serie = SaeDigital::make(BuscarSeriesNextAva::class)->handle($this->session->userdata('school')->id);



        $dadosSerie = array();
        $categoria = array();
        $categoriaExistentes = array();
        $data['permitirAlteracaoVigencia'] = ($id === null);

        if ($this->session->userdata('escola')) {
            $data['escolaID'] = $this->session->userdata('school')->id;
            $data['descEscola'] = $this->session->userdata('nomeEscola') ? $this->session->userdata('nomeEscola') : $this->session->userdata('nome');

            //busca todas as categorias da escola
            $categoriaExistentes = $this->cadastro->getCategoriaEscola($data['escolaID']);

            if ($id == null) {
                //busca a categoria da turma
                $categoria = $this->cadastro->getCategoriaEscola($data['escolaID'], $id);
            }
        }


        foreach($serie as $grupoSerie)
        {
            foreach($grupoSerie as $dadosGrupo) {
                if($dadosGrupo->id == 13)
                {
                    $dadosGrupo->name = $dadosGrupo->name." / 3° Série";
                }
                if (strpos($dadosGrupo->name, 'ano') !== false) {
                    $dadosSerie['fundamental'][] = $dadosGrupo;
                } else if(strpos($dadosGrupo->name, 'Infantil') !== false){
                    $dadosSerie['infantil'][] = $dadosGrupo;
                }else{
                    $dadosSerie['medio'][] = $dadosGrupo;
                }
            }
        }

        $data['dadosSerie'] = $dadosSerie;

        if ($id) {
            $data['dadosTurma'] = SaeDigital::make(BuscarDadosTurma::class)->get($id);
            $data['dadosTurma']['id'] = $id;
            $data['edit'] = 1;
            /*if (SaeDigital::make(ValidarAlteracaoVigencia::class)->handle($data['dadosTurma'][0]['itemName'])) {
                $data['permitirAlteracaoVigencia'] = false;
            }


            //busca todas as categorias da escola
            $categoriaExistentes = $this->cadastro->getCategoriaEscola($data['dadosTurma'][0]['EscolaID']);*/
        }

        if ($categoriaExistentes) {

            $html = '<div class="input-icon col-md-10">
						<select class="form-control" id="inputCategoria">
		                	<option value="" >Selecione uma Categoria</option>';

            for ($i = 0; count($categoriaExistentes) > $i; $i++) {
                $selected = '';
                if (isset($data['dadosTurma'][0]['CategoriaTurmaID']) && $data['dadosTurma'][0]['CategoriaTurmaID'] == $categoriaExistentes[$i]['ItemName']) {
                    $selected = 'selected';
                }

                $html .= '<option value="' . $categoriaExistentes[$i]['ItemName'] . '" data-desc="' . $categoriaExistentes[$i]['Descricao'] . '" ' . $selected . '>' . $categoriaExistentes[$i]['Descricao'] . '</option>';
            }

            $html .= '</select>
					</div>
    				<spam onClick="alteraCategoria(2)" class="glyphicon glyphicon-plus-sign" title="Utilizar nova Categoria" style="cursor:pointer; color:green; padding-top:7px;"></spam>';

            $data['dadosCategoria'] = $html;
        }

        $this->load->view('cadastro/cadastrarTurma', $data);
    }

    public function seriesPorSegmentoEscolar()
    {
        try {
            $idEscola = ($this->input->get('idEscola')) ? $this->input->get('idEscola') : $this->session->userdata('school')->id ;

            $series = SaeDigital::make(BuscarSeriesNextAva::class)->handle($idEscola);
            $series = collect($series)->map(function(array $serie) {
                return collect($serie)->map(function($serieData) {
                    return array(
                        "SerieID" => $serieData->id,
                        "ID" =>  $serieData->id,
                        "Descricao" =>  $serieData->name
                    );
                })->toArray();
            })->toArray();


            return $this->responseJson($series, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            return $this->responseJson(['message' => 'Erro ao buscar séries'], 500);
        }
    }

    public function salvarTurma()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);
        extract($post);

        $fields['name'] = trim($descricao);


        if ($this->input->post('vigencia')) {
            $fields['schoolYear'] = $this->input->post('vigencia');
        }
        $fields['schoolId'] = $escola;
        $fields['NomeEscola'] = isset($descEscolaCombo) ? trim($descEscolaCombo) : $descEscolaHidden;

        if ($edit == 1) {

            $fields['gradeId'] = $serieId;
            $fields['id'] = $idTurma;
            $fields['active'] = $situacao;

            if( $itemName ) {
                $fields['itemName'] = $itemName;
            }

            $resultado = SaeDigital::make(CadastrarTurmaNextAva::class)->handle($fields);
        } else {
            $fields['gradeId'] = $serie;
            $resultado = SaeDigital::make(CadastrarTurmaNextAva::class)->handle($fields);
        }

        print($resultado);
        die;
    }

    public function buscaCategoriaEscola($id = null)
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);
        extract($post);

        $escolaID = $id ? id : $escola;

        $dados = $this->cadastro->getCategoriaEscola($escolaID);

        if ($dados) {

            $return = '<div class="input-icon col-md-10">
						<select class="form-control" id="inputCategoria">
		                	<option value="" >Selecione uma Categoria</option>';
            for ($i = 0; count($dados) > $i; $i++) {
                $return .= '<option value="' . $dados[$i]['ItemName'] . '" data-desc="' . ($dados[$i]['Descricao']) . '">' . ($dados[$i]['Descricao']) . '</option>';
            }
            $return .= '</select>
					</div>
					<spam onClick="alteraCategoria(2)" class="glyphicon glyphicon-plus-sign" title="Utilizar nova Categoria" style="cursor:pointer; color:green; padding-top:7px;"></spam>';
        } else {
            $return = 1;
        }

        print($return);
        die;
    }

    public function buscaTurmaEscola($id = null)
    {
        if($this->session->userdata('perfil') == 274)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);
        extract($post);

        $schoolId = $escola;
        $turmas = SaeDigital::make(BuscarTurmasNextAva::class)->get($schoolId);

        $return['turma'] = '<select class="form-control" id="inputTurma" multiple data-placeholder=" Selecione Turmas " onChange="buscaDisciplinasTurma();" > ';


        $dados = $turmas;
        for ($i = 0; count($dados) > $i; $i++) {
            $return['turma'] .= '<option value="' . $dados[$i]->id . '" '
                . 'data-desc="' . ($dados[$i]->name) . '" '
                . 'data-serie="' . ($dados[$i]->gradeId) . '" '
                . 'data-serieDesc="' . ($dados[$i]->gradeName) . '" '
                . 'data-vigencia="' . $dados[$i]->year . '">
                        ' . ($dados[$i]->name.' - '.$dados[$i]->year) . '</option>';
        }
        $return['turma'] .= '</select>';

        print_r(json_encode($return));
        exit;

        // $param = isset($param) ? $param : '';
        $escolaID = $id ? $id : $escola;
        $dados = $this->cadastro->getDadosTurma($escolaID, false, true, Date('Y'));
        $livrodigital = $this->cadastro->getAcessoLD($escolaID);

        $return = new ArrayObject(array());

        $token = $this->session->userdata('token');
        $dados = SaeDigital::make(BuscarTurmasNextAvaVigencia::class)->handle($token, $escolaID, Date('Y'));

        if ($param == 'P') {

            //salva o cookie das turmas
            $cookieName = 'turmasDisc' . $this->session->userdata('itemName');
            $cookie = array(
                'name' => $cookieName,
                'value' => json_encode($dados),
                'expire' => 14400,
                'domain' => '',
                'secure' => FALSE
            );
            $this->input->set_cookie($cookie);

            $input = ' multiple data-placeholder=" Selecione Turmas " onChange="buscaDisciplinasTurma();"';
            $option = ' ';
        } else {
            $input = ' onChange="montaUpload();"';
            $option = ' <option value="" >Selecione uma Turma</option>';
        }

        if ($dados) {
            $return['turma'] = '	<select class="form-control" id="inputTurma" ' . $input . ' > ' . $option;
            for ($i = 0; count($dados) > $i; $i++) {
                $return['turma'] .= '<option value="' . $dados[$i]->id . '" >
    						' . ($dados[$i]->name.' - '.$dados[$i]->year) . '</option>';
            }
            $return['turma'] .= '</select>';
        } else {
            $return['turma'] .= '	<select class="form-control" id="inputTurma" ' . $input . '>' . $option;
            $return['turma'] .= '</select>';
        }
        if ($livrodigital) {
            $return['limite'] = '<label class="col-md-3 control-label" >Limitar dispositivos</label>
                                    <div class="col-md-3">
                                        <select class="form-control" id="inputLimite" >
                                            <option value="S">Sim</option>
                                            <option value="N">N&atilde;o</option>
                                        </select>
                                    </div>';
        } else {
            $return['limite'] = false;
        }

        print_r(json_encode($return));
        die;
    }

    public function buscaDisciplinaTurma($idTurmas = null) {
        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);
        extract($post);

        $disciplinas = SaeDigital::make(ObterDisciplinasTurmasNextAVA::class)->handle($turma);

        for ($i = 0; count($disciplinas) > $i; $i++) {
            $d = $disciplinas[$i];

            $return .= '<optgroup label="Disciplinas turma : ' . ($d->name) . '">';
            $lista = $d->subjects;
            for ($x = 0; $x < count($lista[0]) ; $x++) {
                $dd = $lista[0][$x];
                $discSelected = '';

                // if(is_array($disc) && in_array(($disciplinas[$x]->DisciplinaID . '-' . $series[$i]['turmaID']), $disc) === true){
                //     $discSelected = 'selected';
                // }
                $add = '<option value="' . $dd->subjectId.'" data-turma="'.$d->id.'" data-serie="' . ($dd->gradeId) . '" '.$discSelected.'>' . ($dd->subjectName) . ' - '.($d->name).'</option>';
                $return .= $add;
            }
            $return .= '</optgroup>';

        }
        print($return);
        die;


        exit;

        $turma = $idTurmas ? $idTurmas : $turma;
        $escolaid = isset($escolaid) ? $escolaid : $this->session->userdata('escola');

        $cookieName = 'turmasDisc' . $this->session->userdata('itemName');
        $arrayTurma = json_decode($this->input->cookie($cookieName));
        $dados = array();
        if (!$arrayTurma) {
            if (count($turma) < 18) {
                $turmas = implode("','", $turma);

                $dados = $this->cadastro->getListaTurma(null, $turmas);
            } else {
                $arrTurma = array_chunk($turma, 18);

                for ($i = 0; count($arrTurma) > $i; $i++) {
                    $turmas = implode("','", $arrTurma[$i]);
                    $result = $this->cadastro->getListaTurma(null, $turmas);
                    $dados = array_merge($dados,$result);
                }
            }
        } else {
            //seleciona apenas as turmas da sessao que foram selecionadas
            for ($i = 0; count($arrayTurma) > $i; $i++) {
                if (in_array($arrayTurma[$i]->itemName, $turma)) {
                    $dados[] = $arrayTurma[$i];
                }
            }
        }

        $series = array();
        for ($i = 0; count($dados) > $i; $i++) {
            if (is_array($dados[$i])) {
                if (!in_array($dados[$i]['SerieID'], $series)) {
                    $series[$i]['serieID'] = $dados[$i]['SerieID'];
                    $series[$i]['turmaID'] = $dados[$i]['itemName'];
                    $series[$i]['turma'] = $dados[$i]['Descricao'];
                }
            } else {
                if (!in_array($dados[$i]->SerieID, $series)) {
                    $series[$i]['serieID'] = $dados[$i]->SerieID;
                    $series[$i]['turmaID'] = $dados[$i]->itemName;
                    $series[$i]['turma'] = $dados[$i]->Descricao;
                }
            }
        }

        $return = ' ';

        $escola = SaeDigital::make(BuscarDadosEscola::class)->handle($this->session->userdata('school')->id);
        for ($i = 0; count($series) > $i; $i++) {
            $disciplinas = $this->cadastro->getDadosDisciplina($series[$i]['serieID'], $escola['versao_conteudo_id']);
            $disciplinasExclusivas = $this->cadastro->getDisciplinasExclusivas($escolaid,$series[$i]['serieID'] );

            if ($disciplinas) {
                $return .= '<optgroup label="Disciplinas turma : ' . ($series[$i]['turma']) . '">';
                for ($x = 0; count($disciplinas) > $x; $x++) {
                    $discSelected = '';

                    if(is_array($disc) && in_array(($disciplinas[$x]->DisciplinaID . '-' . $series[$i]['turmaID']), $disc) === true){
                        $discSelected = 'selected';
                    }

                    $return .= '<option value="' . $disciplinas[$x]->DisciplinaID . '-' . $series[$i]['turmaID'] . '" data-serie="' . ($disciplinas[$x]->SerieID) . '" '.$discSelected.'>' . ($disciplinas[$x]->Descricao) . '</option>';
                }
                $return .= '</optgroup>';
            }
            //print_pre($disciplinasExclusivas);die;
            if ($disciplinasExclusivas) {
                $return .= '<optgroup label="Disciplinas Exclusivas">';
                for ($y = 0; $y < count($disciplinasExclusivas); $y++) {
                    $return .= '<option value="' . $disciplinasExclusivas[$y]['DisciplinaID'] . '-'  .$series[$i]['turmaID'] . '" data-serie="' . ($disciplinasExclusivas[$y]['SerieID']) . '" '.$discSelected.'>' . ($disciplinasExclusivas[$y]['Descricao']) . '</option>';
                }
                $return .= '</optgroup>';
            }
        }
        print($return);
        die;
    }

    public function buscaCategoriaTurma()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);
        extract($post);

        $turmas = SaeDigital::make(BuscarTurmasNextAva::class)->get($escola);

        $return = new stdClass();

        if ($turmas) {
            $return->turma = '	<select class="form-control" id="inputTurma" multiple data-placeholder="Selecione as Turmas">';
            for ($i = 0; count($turmas) > $i; $i++) {
                $return->turma .= '<option value="' . $turmas[$i]->id . '" data-desc="' . ($turmas[$i]->name) . '">' . ($turmas[$i]->name.' - '. $turmas[$i]->year) . '</option>';
            }
            $return->turma .= '</select>';
        } else {
            $return->turma = '	<select class="form-control" id="inputTurma" multiple data-placeholder=" ---- ">';
            $return->turma .= '</select>';
        }

        print(json_encode($return));
        die;

        $return = new stdClass();
        $turma = $this->cadastro->getDadosTurma($escola, false, true, Date('Y'));
        $categoria = $this->cadastro->getCategoriaEscola($escola);

        //salva o cookie das turmas
        $cookieName = 'turmas' . $this->session->userdata('itemName');
        $cookie = array(
            'name' => $cookieName,
            'value' => json_encode($turma),
            'expire' => 14400,
            'domain' => '',
            'secure' => FALSE
        );
        $this->input->set_cookie($cookie);

        if ($turma) {
            $return->turma = '	<select class="form-control" id="inputTurma" multiple data-placeholder="Selecione as Turmas">';
            for ($i = 0; count($turma) > $i; $i++) {
                $return->turma .= '<option value="' . $turma[$i]['itemName'] . '" data-desc="' . ($turma[$i]['Descricao']) . '">' . ($turma[$i]['Descricao'].' - '. $turma[$i]['Vigencia']) . '</option>';
            }
            $return->turma .= '</select>';
        } else {
            $return->turma = '	<select class="form-control" id="inputTurma" multiple data-placeholder=" ---- ">';
            $return->turma .= '</select>';
        }

        if ($categoria) {
            $return->categoria = '	<select class="form-control" id="inputCategoria" multiple data-placeholder="Selecione as Categorias"  onChange="atualizaTurmas();" >';
            for ($i = 0; count($categoria) > $i; $i++) {
                $return->categoria .= '<option value="' . $categoria[$i]['itemName'] . '" data-desc="' . ($categoria[$i]['Descricao']) . '">' . ($categoria[$i]['Descricao']) . '</option>';
            }
            $return->categoria .= '</select>';
        } else {
            $return->categoria = '	<select class="form-control" id="inputCategoria" multiple data-placeholder=" ---- ">';
            $return->categoria .= '</select>';
        }

        print(json_encode($return));
        die;
    }

    public function atualizaTurmas()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);
        extract($post);

        $return = new stdClass();
        $cookieName = 'turmas' . $this->session->userdata('itemName');
        $arrayTurma = json_decode($this->input->cookie($cookieName));

        if ($arrayTurma == '') {
            $arrayTurma = $this->cadastro->getDadosTurma($this->session->userdata('escola'));
        }

        $turmaCombo = array();
        //mostra na tela apenas as turmas que nao tiveram sua categoria selecionada
        if ($arrayTurma && $categoria) {
            for ($i = 0; $i < count($arrayTurma); $i++) {
                if (is_array($arrayTurma[$i])) {
                    if (in_array($arrayTurma[$i]['CategoriaTurmaID'], $categoria)) {
                        $turmaCombo[] = $arrayTurma[$i];
                    }
                } else {
                    if (in_array($arrayTurma[$i]->CategoriaTurmaID, $categoria)) {
                        $turmaCombo[] = $arrayTurma[$i];
                    }
                }
            }
        } else {
            $turmaCombo = $arrayTurma;
        }

        if ($turmaCombo) {
            $return->turma = '	<select class="form-control" id="inputTurma" multiple data-placeholder="Selecione as Turmas">';
            for ($i = 0; count($turmaCombo) > $i; $i++) {
                $selected = '';
                if ($turma) {
                    //verifica se a opção ja foi marcada
                    if (in_array($turmaCombo[$i]->itemName, $turma)) {
                        $selected = ' selected ';
                    }
                }
                if (is_array($arrayTurma[$i])) {
                    $return->turma .= '<option value="' . $turmaCombo[$i]['itemName'] . '" data-desc="' . ($turmaCombo[$i]['Descricao']) . '" ' . $selected . '>
    					' . ($turmaCombo[$i]['Descricao']) . '</option>';
                } else {
                    $return->turma .= '<option value="' . $turmaCombo[$i]->itemName . '" data-desc="' . ($turmaCombo[$i]->Descricao) . '" ' . $selected . '>
    					' . ($turmaCombo[$i]->Descricao) . '</option>';
                }
            }
            $return->turma .= '</select>';
        } else {
            $return->turma = ' <select class="form-control" id="inputTurma" multiple data-placeholder=" ---- ">';
            $return->turma .= '</select>';
        }

        print(json_encode($return));
        die;
    }

    public function buscaTurmaEscolaLista()
    {
        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post);

        //$vigencia = implode("','", $vigencia);
        if(!isset($vigencia)) $vigencia = null;
        //terceiro parametro passando para retornar apenas as turmas com situacao = A
        //$dados = $this->cadastro->getListaTurmaVigencia($escola, $vigencia , true);

        $token = $this->session->userdata('token');
        $dados = SaeDigital::make(BuscarTurmasNextAvaVigencia::class)->handle($token, $escola, $vigencia);

        $return = '<option value="" >Selecione uma Turma</option>';

        if($dados){
            for ($i = 0; count($dados) > $i; $i++) {
              if ( $dados[$i]->active )
                $return .= '<option value="' . $dados[$i]->id . '" >' . ($dados[$i]->name) . '</option>';
            }
        }
        print($return);
        die;
    }

    public function buscaListaAlunos()
    {
        $this->layout = '';

        $turmas = is_array($this->input->post('turma')) ? $this->input->post('turma') : [];

        $idEscola = $this->input->post('escola');
        $vigencia = $this->input->post('vigencia');

        $token = $this->session->userdata('token');
        $alunos = SaeDigital::make(BuscarDadosUsuariosNextAva::class)->handle($token, 1, $idEscola, $turmas, $vigencia, true);

        $table = '';
        if($alunos){
            foreach ($alunos as $v) {

                $situacao = $v->active == true ? 'Ativa' : 'Inativa';

                $table .= '<tr>';

                if($this->session->userdata('perfil') == 268){
                    $table .= '<td style="text-align:center;"><input onClick="mostrarBotaoApagar(\''.$v->personId.'\')" type="checkbox" class="excluir" name="excluir[]" value="'.$v->personId.'"/></td>';
                }

                $table.= '
			    	<td style="text-align:center;">'.((isset($v->name)) ? ($v->name) : '').'</td>
			        <td style="text-align:center;">'.((isset($v->email)) ? ($v->email) : '').'</td>
			        <td style="text-align:center;">'.((isset($v->login)) ? ($v->login) : '').'</td>
			        <td style="text-align:center;">'.((isset($v->team)) ? ($v->team) : '').'</td>
			        <td style="text-align:center;">'.((isset($v->schoolName)) ? ($v->schoolName) : '' ).'</td>
			        <td style="text-align:center;">'. $situacao.'</td>
			        <td style="text-align:center;">
			        	<a id="btAtualizar" href="'. base_url().'cadastro/cadastrarAluno/'.$v->personId.'"><i class="glyphicon glyphicon-edit"></i></a>
			        </td>
				</tr>';
            }
        }

        print($table);
        die;
    }

    public function listarAluno() {
        if ($this->session->userdata('perfil')!= 270 AND
            $this->session->userdata('perfil')!= 269 AND
            $this->session->userdata('perfil')!= 268 AND
            $this->session->userdata('perfil')!= 271)
            Redirect('/');
        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';
        $this->js[] = 'listarAluno';

        $this->css[] = $this->minify->getCSS('cadastro_aluno_lista.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        if ($this->session->userdata('school')) {
            $data['escolaid'] = $this->session->userdata('school')->id;
        }else{
            $token = $this->session->userdata('token');
            $data['dadosEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle($token,'269');
        }

        $this->load->view('cadastro/listarAluno', $data);
    }

    public function cadastrarAluno($id = null)
    {
        if ($this->session->userdata('perfil')!= 270 AND
            $this->session->userdata('perfil')!= 269 AND
            $this->session->userdata('perfil')!= 268 AND
            $this->session->userdata('perfil')!= 271)
            Redirect('/');

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';

        $this->css[] = $this->minify->getCSS('cadastro_aluno.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['edit'] = 0;

        if ($this->session->userdata('escola')) {
            $data['escolaID'] = $this->session->userdata('school')->id;
            $data['livrodigital'] = $this->cadastro->getAcessoLD($this->session->userdata('escola'));
            $data['descEscola'] = $this->session->userdata('nomeEscola') ? $this->session->userdata('nomeEscola') : $this->session->userdata('nome');

            $data['dadosTurma'] = SaeDigital::make(BuscarTurmasNextAva::class)->get($data['escolaID']);

        } else {
            $data['dadosEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle();
        }

        if ($id) {

            $resultado = SaeDigital::make(UsuarioNextAVA::class)->get($id);
            $data['dadosAluno'] = $resultado;
            $data['escolaID'] = $resultado->schoolId;
            $arrayTurmas = SaeDigital::make(BuscarTurmasNextAva::class)->get($resultado->schoolId);

            $turmas = [NULL=>'Selecione uma Turma'];
            foreach ($arrayTurmas as $turma) {
                if (!in_array($turma->id, $turmas)) {
                    $turmas[$turma->id] = $turma->name;
                }
            }

            $extra = array('id' => 'inputTurma', 'class' => 'form-control');
            $data['comboTurma'] = form_dropdown('inputTurma', $turmas, $data['dadosAluno']->team, $extra);
            //$data['dadosTurma'] = $this->cadastro->getDadosTurma($data['escolaID'], false, true);
            $data['livrodigital'] = $this->cadastro->getAcessoLD($data['escolaID']);

            $data['descEscola'] = $data['dadosAluno']->schoolName;
            $teamId = $data['dadosAluno']->team;
            $data['dadosAluno']->DescricaoTurma = $arrayTurmas[$teamId];
            $data['edit'] = 1;
        }
        $this->load->view('cadastro/cadastrarAluno', $data);
    }

    public function cadastroLogin($id = null) {

        $this->load->model('Curso_model', 'curso');
        $this->css[] = $this->minify->getCSS('cadastro_login.min', $this->cssMinify, ENVIRONMENT);

        $id = base64url_decode($id);

        $data['dados'] = $this->cadastro->getDadosUsuario($id);
        $data['edit'] = 1;

        $this->load->view('cadastro/cadastrarLogin', $data);
    }

    public function buscarLogins()
    {
        try {
            $idTurma = $this->input->get('idTurma');

            if (!(count($idTurma) > 0)) {
                throw new NotFoundException('Turma informada não esta cadastrada ou não atende a vigência atual.');
            }

            $logins = SaeDigital::make(BuscarLoginsAlunosResponsaveisPorTurmaNextAva::class)->handle([$idTurma]);

            return $this->responseJson(['logins' => $logins], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());

            return $this->responseJson(['message' => 'Ocorreu um problema ao buscar logins.']);
        }
    }

    public function cadastrarAlunoXls()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::ESCOLA, Perfil::DIRETOR, Perfil::COORDENADOR]);

            $this->cssMinify[] = 'jquery-ui';
            $this->cssMinify[] = 'jquery.dataTables_themeroller';
            $this->cssMinify[] = 'glyphicon';
            $this->cssMinify[] = 'chosen';
            $this->cssMinify[] = 'sae';

            $this->css[] = $this->minify->getCSS('cadastro_alunoxls.min', $this->cssMinify, ENVIRONMENT);

            $this->js[] = 'chosen.jquery.min';
            $this->js[] = 'jquery.ocupload';

            $dados['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            $data['dadosEscola'] = $this->cadastro->getDados(269, null, 'A');

            if ($this->session->userdata('escola')) {
                $data['escolaID'] = $this->session->userdata('school')->id;
                $data['descEscola'] = $this->session->userdata('nomeEscola') ? $this->session->userdata('nomeEscola') : $this->session->userdata('nome');
                $data['dadosTurma'] =  SaeDigital::make(BuscarTurmasNextAva::class)->get($data['escolaID'], Date('Y'));
            }
            
            $this->load->view('cadastro/cadastrarAlunoXls', $data);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    /**
     * A função "strtr" substitui os caracteres acentuados pelos não acentuados.
     * A função "preg_match" utiliza uma expressão regular que remove todos os caracteres que não são letras,
     * números e são diferentes de "_" (underscore).
     * @param $word
     * @return int
     */
    function remove_acentos_caracteres_especiais($word){
        $word = preg_match("[^a-zA-Z0-9_]", "", strtr($word, "áàãâéêíóôõúüçÁÀÃÂÉÊÍÓÔÕÚÜÇ ",
            "aaaaeeiooouucAAAAEEIOOOUUC_"));
        return $word;
    }

    /*
     *  A funcao procura o valor em uma chave do array
     *  @array = Array multidimensional
     *  @strKey = String contendo o nome da chave
     *  @value = Valor a ser procurado
     */
    function procurar_valor_por_chave($array, $strKey, $value) {
        foreach($array as $index => $key) {
            $word = $key[$strKey];
            //            $word = $this->remove_acentos_caracteres_especiais($word);
            //            $value = $this->remove_acentos_caracteres_especiais($value);
            if($word == $value) return TRUE;
        }
        return FALSE;
    }

    public function salvarAlunosImportacaoCsv()
    {

        try {
            $idEscola = $this->input->post('escolaID');
            $idTurma = $this->input->post('turmaID');

            $fileType = $_FILES['cslAlunos']['type'];
            if ($fileType !== 'text/csv' && ($fileType === 'application/vnd.ms-excel' && strpos($_FILES['cslAlunos']['name'], '.csv')) === false) {
                throw new InvalidArgumentException('Formato de arquivo inválido, por favor envie arquivo csv');
            }

            $escola = SaeDigital::make(BuscarDadosEscola::class)->handle($idEscola);
            if (!(count($escola) > 0)) {
                throw new Exception('Escola informada não encontrada');
            }

            if (count($idTurma) === 0) {
                throw new NotFoundException('Turma informada não esta cadastrada ou não atende a vigência atual.');
            }

            $reader = Reader::createFromPath($_FILES['cslAlunos']['tmp_name'], 'r');
            $reader->setOffset(1);
            $delimiterOccurrence = $reader->fetchDelimitersOccurrence([',', ';', '|'], 100);

            if (!empty($delimiterOccurrence)) {
                $delimiter = array_keys($delimiterOccurrence)[0];
                $reader->setDelimiter($delimiter);
            }

            $results = $reader->fetchAll();

            $inconsistencias = [];
            $responsaveis = [];
            foreach ($results as $index => $row) {
                if (mb_strlen(trim($row[0])) > 50) {
                    $linha = $index + 1;
                    $inconsistencias[$index] = "Aluno(a) {$row[0]} excede o tamanho máximo de 50 caracteres para nome.Linha: {$linha} ";
                    continue;
                }

                $aluno = $this->gerarDadosAluno($row, $idEscola, $idTurma, $index);
                if (is_array($aluno)) {
                    $resultado = SaeDigital::make(UsuarioNextAVA::class)->create($aluno);
                    if ($resultado->error) {
                        $linha = $index + 1;
                        $inconsistencias[$index] = "Aluno(a) {$aluno['login']} não pode ser criado. {$resultado->error}. Linha: {$linha} ";
                        continue;
                    }
                    $aluno['personId'] = $resultado->personId;
                    
                    if (trim(strlen($row[4])) > 0) {
                        $responsavel = $this->gerarDadosResponsavel($row[4], $row[5], $row[6], $row[7], $aluno, $idEscola, $index);
                        if (is_array($responsavel)) {

                            if(!$responsavel['login']){
                                $linha = $index + 1;
                                $inconsistencias[$index] = "Responsável na linha {$linha} não pode ser criado, o campo Login está vazio.";
                                continue;
                            }
                            $responsaveis[] = $responsavel;
                            continue;
                        }
                    }
                    continue;
                }

                $inconsistencias[$index] = $aluno;
            } 

            // Unifica o responsável que tem mais de um aluno
            $responsaveisLimpos = array_reduce($responsaveis, function($carry, $item) { 
                if(!isset($carry[$item["name"]])) {
                    $carry[$item["name"]] = $item;
                } else {
                    $carry[$item["name"]]['students'] = array_unique(
                        array_merge($carry[$item["name"]]['students'], $item['students'])
                    );
                }

                return $carry;
            });

            // Salva responsáveis
            if ($responsaveisLimpos) {
                foreach ($responsaveisLimpos as $responsavelLimpo) {
                    $resultado_resp = SaeDigital::make(UsuarioNextAVA::class)->create($responsavelLimpo);
                    if ($resultado_resp->error) {
                        $inconsistencias[$index] = "Responsável {$responsavelLimpo['name']} não pode ser criado. {$resultado_resp->error}.";
                    }
                }
            }

            $logins = SaeDigital::make(BuscarLoginsAlunosResponsaveisPorTurmaNextAva::class)->handle([$idTurma]);

            $response = [
                'logins' => $logins,
                'inconsistencias' => $inconsistencias
            ];

            return $this->responseJson($response, 200);
        } catch (NotFoundException $e) {
            log_error($e->getMessage());

            return $this->responseJson([
                'message' => $e->getMessage()
            ], 404);
        } catch (InvalidArgumentException $e) {
            log_error($e->getMessage());

            return $this->responseJson([
                'message' => $e->getMessage()
            ], 400);
        } catch (Exception $e) {
            log_error($e->getMessage());

            return $this->responseJson([
                'message' => 'Ocorreu um problema durante o processamento, por favor tente novamente.'
            ], 500);
        }
    }

    private function validarResponsaveis(array $row = [])
    {
        $arrayResponsaveis = [];

        $resp1 = $resp2 = [];
        foreach ($row as $key => $item) {
            if ($key >= 4) {
                $responsavel = explode('/', $item);
                if (is_array($responsavel)) {
                    array_push($resp1, array_key_exists(0, $responsavel) ? $responsavel[0] : null);
                    array_push($resp2, array_key_exists(1, $responsavel) ? $responsavel[1] : null);
                } else {
                    array_push($resp1, $responsavel);
                    array_push($resp2, null);
                }
            }
        }

        array_push($arrayResponsaveis, $resp1);
        if (count(array_filter($resp2)) > 0) {
            array_push($arrayResponsaveis, $resp2);
        }

        return $arrayResponsaveis;
    }

    private function formatarResponse($registros)
    {
        $data = [];

        foreach ($registros as $index => $registro) {
            $data[$index] = [
                'nome' => $registro['aluno']['Nome'],
                'login' => $registro['aluno']['Login']
            ];

            if ($registro['responsaveis']) {
                foreach ($registro['responsaveis'] as $key => $responsavel) {
                    $data[$index]["responsavel{$key}"] = $responsavel['Login'];
                }
            }
        }

        return $data;
    }

    private function gerarDadosResponsavel($name, $email, $login, $senha, $aluno, $escola, $linha)
    {
        if (isset($email) && $email !== '') {
            if (filter_var(trim($email), FILTER_VALIDATE_EMAIL)) {
                $email = trim(strtolower($email));
            } else {
                $linha++;
                return "E-mail ({$email}) do responsável inválido (linha {$linha}).";
            }
        }

        if (!$senha) {
            $senha = Senha::RESPONSAVEL;
        }

        $login = trim(strtolower(removeAcentos($login)));

        if (!$login) {
            $loginsDisponiveis = SaeDigital::make(UsuarioNextAVA::class)->getNewLoginOption('Responsavel '.$aluno['name']);
            if ($loginsDisponiveis->success) {
                $login = $loginsDisponiveis->suggestions[0];
            } else {
                return "Não foi possível criar um login para o responsável (linha {$linha}).";
            }
        }

        $name = ucwords(strtolower((trim($this->removeAcentos($name)))));
        $name = ($name == null) ? '' : $name;

        return [
            'name' => $name,
            'email' => $email,
            'phone' => '',
            'login' => $login,
            'password' => $senha,
            'schoolId' => (int) $escola,
            'type' => 3,
            'active' => true,
            'students' => [(int)$aluno['personId']]
        ];
    }

    private function gerarDadosAluno($aluno, $escola, $turma, $linha)
    {
        if (!$aluno[0] || $aluno[0] === '' || is_null($aluno[0])) {
            $linha++;
            return "Nome do aluno e um campo obrigatório (linha {$linha}).";
        }

        $loginsDisponiveis = SaeDigital::make(UsuarioNextAVA::class)->getNewLoginOption($aluno[0]);
        if ($loginsDisponiveis->success) {
            $login = $loginsDisponiveis->suggestions[0];
        } else {
            return "Não foi possível criar um login para o aluno (linha {$linha}).";
        }

        $name = ucwords(strtolower((trim($this->removeAcentos($aluno[0])))));
        $name = ($name == null) ? '' : $name;

        $email = null;
        $senha = Senha::ALUNO;

        //Login
        if ($aluno[2]) {
            $login = trim(strtolower(removeAcentos($aluno[2])));
        }
        //Email
        if ($aluno[1] && filter_var($aluno[1], FILTER_VALIDATE_EMAIL)) {
            $email = trim(strtolower($aluno[1]));
        }
        //Senha
        if ($aluno[3]) {
            $senha = $aluno[3];
        }

        return [
            'name' => $name,
            'email' => $email,
            'phone' => '',
            'login' => $login,
            'password' => $senha,
            'teamId' => (int)$turma,
            'schoolId' => (int)$escola,
            'type' => 1,
            'active' => true,
        ];
    }

    private function removeAcentos($string)
    {
        if (mb_detect_encoding($string, 'UTF-8', true) === false) {
            $string = utf8_encode($string);
        }

        /** @var \Cocur\Slugify\Slugify $slug */
        $slug = SaeDigital::make('slug');
        $slug->addRule('ç', 'c');

        return $slug->slugify($string, [
            'lowercase' => false,
            'separator' => ' '
        ]);
    }

    private function gerarLogin($nomeUsuario, $escola)
    {
        $nomeUsuario = $this->removeAcentos($nomeUsuario);
        $nomeUsuario = strtolower(trim($nomeUsuario));

        $login = explode(' ', $nomeUsuario);

        $hashids = new Hashids($login[0].end($login).$escola);
        $hash = $hashids->encode(1, 2, 3);

        return strtolower($login[0].end($login) . '_' . $hash);
    }

    public function salvarAlunosImportacao(){
        die;
        header('Content-Type: application/json');
        try{
            $this->layout = '';
            $data = $this->input->post(null, TRUE);

            if (!$data){
                throw new Exception("N&atildeo recebeu a requisi&ccedil;&atilde; com todos os dados.");
            }

            $escolaID = $data['escolaID'];
            $nomeEscola = $data['nomeEscola'];
            $turmaID = $data['turmaID'];
            $nomeTurma = $data['nomeTurma'];
            $vigenciaTurma = $data['vigenciaTurma'];
            $dados = $data['dados'];
            $serieTurma = $data['serieTurma'];
            $serieDescricaoTurma = $data['serieDescTurma'];

            //Correção chars
            $countInitDados = 0;
            $countDados = count($dados) -1;
            for($countInitDados;$countInitDados <= $countDados; $countInitDados++){
                $dados[$countInitDados] =  utf8_decode($dados[$countInitDados]);
            }
            if (!isset($nomeTurma, $vigenciaTurma, $dados)){
                throw new Exception("N&atildeo recebeu a requisi&ccedil;&atilde; com todos os dados.");
            }

            $this->session->set_userdata('descTurmaXls', $nomeTurma.' '. $vigenciaTurma);

            //FIXME: 1 - Validar nome do aluno em branco e duplicados
            $dadosAlunosXLS = array();
            $dadosAlunosErros = array();
            foreach ($dados as $key => $value) {
                $line = $key + 1;
                $array = preg_split("/(,|;|:)/", $value);
                if (!empty($array) && (isset($array[0]) && $array[0] != '')) {
                    $nome = utf8_encode($array[0]);
                    $responsaveis = explode("/", $array[1]);
                    $duplicado = $this->procurar_valor_por_chave($dadosAlunosXLS, "nome", $nome);

                    if($duplicado){
                        $info = array("message" => "Aluno " . $nome . " duplicado na linha " . $line . " do arquivo.");
                        array_push($dadosAlunosErros, $info);
                    }

                    $emailValido = true;
                    if (!empty($responsaveis) && $responsaveis[0] !== ''){
                        foreach ($responsaveis as $index => $email) {
                            $emailValido = validaEmail($email);
                            if (!$emailValido) {
                                $info = array("message" => "Responsável pelo aluno " . $nome . " possui e-mail inválido (" . $email . ").");
                                array_push($dadosAlunosErros, $info);
                            }
                        }
                    }

                    if (!$duplicado && $emailValido) {
                        array_push($dadosAlunosXLS, array("nome" => $nome, "responsaveis" => $responsaveis));
                    }

                }else {
                    $info = array("message" => "Nome do aluno em branco na linha " . $line . " do arquivo.");
                    array_push($dadosAlunosErros, $info);
                }
            }
            $arraySenha = array();
            //FIXME: 2 - Validar nome do aluno no banco
            $dadosImportar = array();
            $dadosAlunoDB = $this->cadastro->getDados(273, null, null, $escolaID, null, null, $turmaID, $vigenciaTurma);
            foreach ($dadosAlunosXLS as $index => $item) {
                $nomeXLS = $item["nome"];
                $valido = true;
                foreach ($dadosAlunoDB as $db => $dbItem){
                    $nomeDB = $dbItem["Nome"];
                    if (trim($nomeXLS) === trim($nomeDB)){
                        $valido = false;
                        $info = array("message" => "Aluno " .$nomeDB. " já existe na turma com login '".$dbItem["Login"]."'.");
                        array_push($dadosAlunosErros, $info);
                    }
                }
                if ($valido){
                    array_push($dadosImportar, $item);
                }

            }

            //FIXME: 3 - Importar apenas dados validados
            $dadosImportados = array();
            foreach($dadosImportar as $aluno){
                $insert = null;
                $nomeAluno = trim($aluno["nome"]);
                $arrayNome = explode(' ', $nomeAluno);
                $hashNome = $this->iesdehashid->getHashId($nomeAluno);
                $loginAluno = strtolower(removeAcentos(strtolower(end($arrayNome)))) . '_' . $hashNome;
                $itemName = md5(uniqid(rand(), true));
                $senhaAluno = $this->iesdehashid->getHashId($nomeEscola);

                //TODO: encontrar outra forma de inserir hashid para login
                $x = 1;
                while ($this->cadastro->getDados(null, null, 'A', null, $loginAluno)) {
                    $loginAluno = $this->iesdehashid->getHashId($nomeAluno . $x);
                    $x++;
                }
                $fields['Nome'] = $nomeAluno;
                $fields['Login'] = $loginAluno;
                $fields['Senha'] = md5($senhaAluno);
                $fields['Escola'] = trim($escolaID);
                $fields['NomeEscola'] = (trim($nomeEscola));
                $fields['Turma'] = trim($turmaID);
                $fields['DescricaoTurma'] = (trim($nomeTurma));
                $fields['Perfil'] = 273;
                $fields['Situacao'] = 'A';
                $fields['UsuarioCad'] = $this->session->userdata('pessoaid');
                $fields['UsuarioAlt'] = $this->session->userdata('pessoaid');
                $fields['DtCad'] = date('Y-m-d H:i:s');
                $fields['DtAlt'] = date('Y-m-d H:i:s');
                $fields['Redirecionar'] = 'aluno';
                $fields['VigenciaTurma'] = trim($vigenciaTurma);
                $fields['Serie'] = trim($serieTurma);
                $fields['DescricaoSerie'] = (trim($serieDescricaoTurma));
                $fields['PrimeiroLogin'] = 'S';
                $fields['itemName'] = $itemName;

                //FIXME: salvar dados do aluno
                $insert = $this->cadastro->salvaDados('D019_Ava_Sae', $itemName, $fields, TRUE);

                if ($insert){
                    $responsaveis = array();
                    if($aluno["responsaveis"] && $aluno["responsaveis"][0] !== ''){
                        $fieldsResp['Perfil'] = 274;
                        $fieldsResp['Aluno'] = $itemName;
                        $fieldsResp['NomeAluno'] = $nomeAluno;
                        $fieldsResp['Situacao'] = 'A';
                        $fieldsResp['UsuarioCad'] = $this->session->userdata('pessoaid');
                        $fieldsResp['DtCad'] = date('Y-m-d H:i:s');
                        $fieldsResp['UsuarioAlt'] = $this->session->userdata('pessoaid');
                        $fieldsResp['DtAlt'] = date('Y-m-d H:i:s');
                        $fieldsResp['Redirecionar'] = 'responsavel';
                        $fieldsResp['Escola'] = trim($escolaID);

                        $senhaResp = $this->iesdehashid->getHashId($nomeAluno);
                        foreach ($aluno["responsaveis"] as $resp){
                            $dadosResp = $this->cadastro->getDados(null, null, 'A', null, trim($resp));
                            if ($dadosResp) {
                                $fieldsResp['Login'] = $dadosResp[0]['Login'];
                                $fieldsResp['Senha'] = $dadosResp[0]['Senha'];
                                $fieldsResp['PrimeiroLogin'] = $dadosResp[0]['PrimeiroLogin'];
                            } else {
                                $fieldsResp['Login'] = trim($resp);
                                $fieldsResp['Senha'] = md5($senhaResp);
                                $fieldsResp['PrimeiroLogin'] = 'S';
                            }

                            //grava o novo responsavel
                            $itemNameResp = md5(uniqid(rand(), true));
                            $fieldsResp['Email'] = trim($resp);
                            $fieldsResp['itemName'] = $itemNameResp;

                            //FIXME: salvar dados dos responsaveis
                            $insertResp = $this->cadastro->salvaDados('D019_Ava_Sae', $itemNameResp, $fieldsResp, TRUE);
                            if ($insertResp){
                                $data = array("login" => $loginAluno,
                                    "senha" =>$senhaAluno,
                                    "senha_resp" =>$senhaResp,
                                    "email" => $fieldsResp['Email']);
                                array_push($responsaveis, $data);
                            }
                        }
                    }
                    $data = array("nome" =>  $fields['Nome'],
                        "login" => $loginAluno,
                        "senha" => $senhaAluno,
                        "turma" => $fields['Turma'],
                        "itemName" => $itemName,
                        "responsaveis" => $responsaveis);
                    array_push($dadosImportados, $data);
                }else{
                    //FIXME: nao importou aluno
                    $info = array("message" => "Aluno " .$nomeAluno. " não pode ser importado.");
                    array_push($dadosAlunosErros, $info);
                }
            }
            if (count($dadosAlunosErros) > 0){
                $message = "Algumas inconsistências foram encontradas.";
            }else{
                $message = "Alunos importados com sucesso.";
            }

            $data = array('data_success' => $dadosImportados,
                        'data_error' => $dadosAlunosErros,
                        'status' => true,
                        'message' => $message);
            exit(json_encode($data));

        }catch (Exception $e) {
            exit(json_encode(array('data_success' => null, 'data_error' => null, 'status' => false, 'message' => $e->getMessage())));
        }
    }

    //TODO: implementar modelo correto de gerar pdf
    public function downloadExcelAluno()
    {
       try{
           $descTurma = $this->session->userdata('descTurmaXls');
           $html = "<table>";
           $html .= "<tr>
                                <th>Nome</th>
                                <th>Login</th>
                                <th>Senha</th>
                                <th>Escola</th>
                                <th>Turma</th>
                                <th>Responsáveis</th>
                                <th>Senha dos Responsáveis</th>
                            </tr>";
           $html .= "<tr><td></td></tr>
                        <tr><td></td></tr>
                        <tr><th>ERROS</th></tr>
                        <tr><td></td></tr>";
           $html .= "</table>";
           $table = base64_encode($html);

           // cra??es header para forçar o download
           header("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
           header("Cache-Control: no-cache, must-revalidate");
           header("Pragma: no-cache");
           header("Content-type: application/x-msexcel");
           header("Content-Disposition: attachment; filename=\" ".$descTurma.".xls\"");
           header("Content-Description: PHP Generated Data");

           exit($table);

       }catch(Exception $e){
        //           exit(json_encode(array("message" => $e->getMessage(), "status" => false)));
           exit;
       }
    }

    public function salvarAluno()
    {
        $this->layout = '';
        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post); //analisar remoçao

        $edit = $this->input->post('edit', true);

        $senha = $this->input->post('senha');
        if(empty($senha)) {
            $senha = 'aluno@saedigital';
        }

        $fields['name']              = $this->input->post('nome', true);//trim($nome);
        $fields['email']             = $this->input->post('email',true);//trim($email);
        $fields['Redirecionar']      = 'aluno';
        $fields['phone']          = $this->input->post('telefone', true);//trim($telefone);
        $fields['LimiteDispositivo'] = $this->input->post('limite') ? $this->input->post('limite', true) : 'S';
        $fields['login']             = trim(strtolower(removeAcentos($this->input->post('login', true))));
        $fields['password']             = $senha;
        $fields['teamId']             =  (int) $this->input->post('turma', true);//trim($turma);
        $fields['Matricula']         = $this->input->post('matricula', true);

        $fields['schoolId'] = (int) $this->input->post('escola', true);//trim($escola);
        $fields['type']              = 1;

        $gerarLink = false;

        $resultado = new stdClass();
        $dados = $this->cadastro->verificaLogin($fields['login']);

        if (!preg_match($this->regexLogin, $fields['login'])) {
            $resultado->resultado = 3;
            exit(json_encode($resultado));
        }

        if ($edit == 1) {
            if ($gerarLink == false) {
                //validação para edição de senha, caso ela nao tenha sido alterada na tela ela ja estara em md5

                $idAluno = $this->input->post('idAluno', true);
                $itemName = $this->input->post('itemNameAluno', true);
                $fields['personId'] = (int) $idAluno;
                if($itemName)
                    $fields['itemName'] =  $itemName;

                $fields['active'] = $this->input->post('situacao', true) == 'A';
                $fields['UsuarioAlt'] = $this->session->userdata('pessoaid');
                $fields['DtAlt'] = date('Y-m-d H:i:s');
                //$resultado->resultado = $this->cadastro->salvaDados('D019_Ava_Sae', $itemName, $fields, FALSE);

                $resultado = SaeDigital::make(UsuarioNextAVA::class)->update($fields);
            }
        } else {
            $fields['active']   = true;
            $resultado = SaeDigital::make(UsuarioNextAVA::class)->create($fields);

        }

        print(json_encode($resultado));
        die;
    }

    public function salvarLogin()
    {
        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post);

        $fields['Nome'] = trim($nome);
        $fields['Email'] = trim($email);
        $fields['Login'] = strtolower(trim($login));
        $fields['Senha'] = md5($senha);
        $fields['DtAlt'] = date('Y-m-d H:i:s');

        if (isset($telefone)) {
            $fields['Telefone'] = trim($telefone);
        }

        if (SaeDigital::make(VerificarDuplicidadeUsuario::class)->handle($fields['Login'])) {
            print(2);
            die;
        }

        //altera todos os registros do responsavel
        if ($perfil == 274) {
            $resp = $this->cadastro->getDados(274, null, 'A', null, null, $email);

            if ($resp) {
                for ($i = 0; $i < count($resp); $i++) {
                    $itemName = $resp[$i]['itemName'];
                    $resultado = $this->cadastro->salvaDados('D019_Ava_Sae', $itemName, $fields, FALSE);
                }
            }
        } else {
            $itemName = $this->cadastro->getCadastroItemNameById($id);
            $resultado = $this->cadastro->salvaDados('D019_Ava_Sae', $itemName, $fields, FALSE);

            if ($resultado == 1) {
                //adiciona ao array os dados necessarios para os relatorios
                $fields['Escola'] = trim($escola);
                $fields['NomeEscola'] = trim($nomeEscola);
                $fields['Turma'] = trim($turma);
                $fields['DescricaoTurma'] = trim($descricaoTurma);
                $fields['Serie'] = trim($serie);
                $fields['DescricaoSerie'] = trim($descricaoSerie);
                $fields['VigenciaTurma'] = trim($vigenciaTurma);
                $fields['PessoaID'] = $itemName;

            }
        }

        print($resultado);
        die;
    }

    public function listarCoordenador()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'listarCoordenador';

        $this->css[] = $this->minify->getCSS('cadastro_coordenador_lista.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $escolaid = null;

        if ($this->session->userdata('school')) {
            $escolaid = $this->session->userdata('school')->id;
        }

       // $data['lista'] = arrayDistinct($this->cadastro->getListaCoordenador($escolaid));

        $token = $this->session->userdata('token');
        $data['lista'] =  SaeDigital::make(BuscarDadosUsuariosNextAva::class)->handle($token, 4, $escolaid);

        $this->load->view('cadastro/listarCoordenador', $data);
    }

    public function cadastrarCoordenador($id = null)
    {
        if ($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';

        $this->css[] = $this->minify->getCSS('cadastro_coordenador.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['edit'] = 0;
        $data['dadosEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle();

        $data['turmas'] = array();
        $data['categorias'] = array();

        if ($id) {
            $usuario = SaeDigital::make(UsuarioNextAVA::class)->get($id);
            $turmas = SaeDigital::make(BuscarTurmasNextAva::class)->get($usuario->schoolId);

            $data['dadosCoordenador'] = $usuario;

            $data['dadosTurmas'] = SaeDigital::make(BuscarTurmasNextAva::class)->get($escola);

            $data['escolaID'] = $usuario->schoolId;
            $data['descEscola'] = $usuario->schoolName;

            $data['turmas'] = $data['dadosCoordenador']->teams;
            $data['dadosTurma'] = $turmas;

            $data['edit'] = 1;
        }

        if ($this->session->userdata('escola')) {
            $data['escolaID'] = $this->session->userdata('school')->id;
            $data['livrodigital'] = $this->cadastro->getAcessoLD($this->session->userdata('escola'));
            $data['descEscola'] = $this->session->userdata('nomeEscola') ? $this->session->userdata('nomeEscola') : $this->session->userdata('nome');
            $data['dadosTurma'] = SaeDigital::make(BuscarTurmasNextAva::class)->get($this->session->userdata('school')->id);
            $data['dadosCategoria'] = $this->cadastro->getCategoriaEscola($this->session->userdata('escola'));
        }

        $this->load->view('cadastro/cadastrarCoordenador', $data);
    }

    public function removerEscola()
    {
        if ($this->session->userdata('perfil') == 268)
        {
            $post = $this->input->post(NULL, TRUE);
            extract($post);

            $itemName = $idEscola;

            $fields = array();
            $fields['Situacao'] = 'E';
            $fields['UsuarioAlt'] = $this->session->userdata('pessoaid');
            $fields['DtAlt'] = date('Y-m-d H:i:s');

            if ($idEscola != '') {
                $resultado = $this->cadastro->salvaDados('D019_Ava_Sae', $itemName, $fields, FALSE);
                echo $resultado;
                exit;
            }
        }

        echo "0";
    }

    public function salvarCoordenador()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post);

        $fields['name'] = trim($name);
        $fields['login'] = strtolower(removeAcentos(trim($login)));
        $fields['password'] = $password;
        $fields['email'] = trim($email);
        $fields['schoolId'] = 1 * $schoolId;
        $fields['personId'] = 1 * $personId;
        $fields['active'] = $active == 'A';
        $fields['type'] = 4;
        $fields['teams'] = [];
        foreach ( $teams as $team)
            $fields['teams'][] = 1 * $team;

        if (!preg_match($this->regexLogin, $fields['login'])) {
            $resultado = 3;
            exit(json_encode($resultado));
        }

        $usuario = SaeDigital::make(UsuarioNextAVA::class);

        if ( $personId )
            $save = $usuario->update($fields);
        else
            $save = $usuario->create($fields);

        echo json_encode($save);
        return;
    }

    public function listarResponsavel()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270 &&
            $this->session->userdata('perfil') != 271)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'listarResponsavel';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';

        $this->css[] = $this->minify->getCSS('cadastro_responsavel_lista.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));

        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        if ($this->session->userdata('escola')) {
            $data['escolaid'] = $this->session->userdata('escola');
            $data['lista'] = SaeDigital::make(BuscarDadosUsuariosNextAva::class)->handle($token, 3, $data['escolaid']);
        } else {
            $token = $this->session->userdata('token');
            $data['dadosEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle($token,'269');
        }

        $this->load->view('cadastro/listarResponsavel', $data);
    }

    public function buscaListaResponsaveis()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270 &&
            $this->session->userdata('perfil') != 271)
        {
            Redirect('/');
        }

        $this->layout = '';

        $escola = $this->input->post('escolaid', true);

        if(!$escola)
        {
            Redirect('/');
        }

        $token = $this->session->userdata('token');
        $responsaveis = SaeDigital::make(BuscarDadosUsuariosNextAva::class)->handle($token, 3, $escola);
        $table = '';

        if ($responsaveis)
        {
            foreach ($responsaveis as $v)
            {
                $situacao = $v->active == true ? 'Ativa' : 'Inativa';

                $table .= '<tr>';

                if($this->session->userdata('perfil') == 268){
                    $table .= '<td style="text-align:center;"><input onClick="mostrarBotaoApagar(\''.$v->personId.'\')" type="checkbox" class="excluir" name="excluir[]" value="'.$v->personId.'"/></td>';
                }

                $table.= '
                <td style="text-align:center;">'.((isset($v->name)) ? ($v->name) : '').'</td>
                <td style="text-align:center;">'.((isset($v->email)) ? ($v->email) : '').'</td>
                <td style="text-align:center;">'.((isset($v->login)) ? ($v->login) : '').'</td>
                <td style="text-align:center;">'. $situacao.'</td>
                <td style="text-align:center;">'.((isset($v->childName)) ? ($v->childName) : '').'</td>
                <td style="text-align:center;">'.((isset($v->childTeam)) ? ($v->childTeam) : '').'</td>
                <td style="text-align:center;">
                    <a id="btAtualizar" href="'. base_url().'cadastro/cadastrarResponsavel/'.$v->personId.'/'. $v->schoolId .'"><i class="glyphicon glyphicon-edit"></i></a>
                </td>
                </tr>';
            }
        }

        print($table);
        die;
    }

    public function cadastrarResponsavel($personId = null, $schoolId = null)
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270 &&
            $this->session->userdata('perfil') != 271)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'chosen';
        $this->css[] = $this->minify->getCSS('cadastro_responsavel.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'chosen.jquery.min';
        $this->benchmark->mark('code_end');

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);
        $data['edit'] = 0;

        if ($this->session->userdata('escola')) {
            $escolaid = $this->session->userdata('escola');

            if ($personId) {
                $data['edit'] = 1;    
                $data['dadosResp'] = SaeDigital::make(UsuarioNextAVA::class)->get($personId);
                $data['dadosAlunos'] = $this->montaComboAlunos($data['dadosResp']->schoolId, $personId);
                $data['schoolId'] = $data['dadosResp']->schoolId;
            } else {
                $data['dadosAlunos'] = $this->montaComboAlunos($escolaid, $personId);
                $data['schoolId'] = $escolaid;
            }
        } else {
            if($personId){
                $data['edit'] = 1;
                $data['dadosResp'] = SaeDigital::make(UsuarioNextAVA::class)->get($personId);
                $data['schoolId'] = $data['dadosResp']->schoolId;
                $data['dadosAlunos'] = $this->montaComboAlunos($data['dadosResp']->schoolId, $personId);
                $data['comboEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle();
            }else{
                $data['comboEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle();
            }
        }

        $this->load->view('cadastro/cadastrarResponsavel', $data);
    }

    public function salvarResponsavel()
    {
        $resultado = new stdClass();


        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270 &&
            $this->session->userdata('perfil') != 271)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post();

        if(!$post) {
            Redirect('/');
        }

        extract($post);

        $qntdadeAlunos = count($alunos);
        $alunosIds = [];

        for ($i = 0; $i < $qntdadeAlunos; $i++) {
            list($id, $ide, $desc) = explode('/', $alunos[$i]);
            $alunosIds[] = 1 * $id;
        }

        $fields['name'] = trim($name);
        $fields['login'] = strtolower(removeAcentos(trim($login)));
        $fields['password'] = $senha;
        $fields['email'] = trim($email);
        $fields['phone'] = trim($telefone);
        $fields['schoolId'] = 1 * $schoolId;
        $fields['personId'] = 1 * $personId;
        $fields['active'] = $situacao == 'A';
        $fields['type'] = 3;
        $fields['students'] = $alunosIds;

        $usuario = SaeDigital::make(UsuarioNextAVA::class);

        if ( $personId ){
            $save = $usuario->update($fields);
        } else {
            $fields['active'] = true;
            $save = $usuario->create($fields);
        }

        echo json_encode($save);
        return;
    }

    public function buscaListaProfessores()
    {
        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post);
        
        $token = $this->session->userdata('token'); 
        $escola = $this->input->post('escola');

        if(empty($escola)){
            $escola = $this->session->userdata('school')->id;
        }
        $professores = SaeDigital::make(BuscarDadosUsuariosNextAva::class)->handle($token, 2, $escola);

        $table = '';
        $turmas = '';

        if($professores){
            foreach ($professores as $v) {

                $situacao = $v->active == true ? 'Ativa' : 'Inativa';
                $turmas_list = $v->teams;
                foreach ($turmas_list as $turma) {
                    $turmas .= '<span class="badge" style="margin-right: 5px;">'.$turma->name." - ".$turma->year.'</span>';
                }
                $table .= '<tr>';
                if($this->session->userdata('perfil') == 268){
                    $table .= '<td style="text-align:center;"><input onClick="mostrarBotaoApagar(\''.$v->login.'\')" type="checkbox" class="excluir" name="excluir[]" value="'.$v->login.'"/></td>';
                }
                $table .= '<td style="text-align:center;">'.((isset($v->name)) ? ($v->name) : 'Nome não informado').'</td>
                <td style="text-align:center;">'.((isset($turmas)) ? ($turmas) : '' ).'</td>
                <td style="text-align:center;">'.((isset($v->email)) ? ($v->email) : '').'</td>
                <td style="text-align:center;">'.((isset($v->login)) ? ($v->login) : '').'</td>
                <td style="text-align:center;">'.((isset($v->schoolName)) ? ($v->schoolName) : '' ).'</td>
                <td style="text-align:center;">'. $situacao.'</td>
                <td style="text-align:center;">
                    <a id="btAtualizar" href="'. base_url() .'cadastro/cadastrarProfessor/'. $v->personId .'"><i class="glyphicon glyphicon-edit"></i></a>
                </td>
                </tr>';
                $turmas = '';
            }
        }

        print($table);
        die;
    }

    public function listarProfessor()
    {

        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270 &&
            $this->session->userdata('perfil') != 271)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';
        $this->js[] = 'listarProfessor';

        $this->css[] = $this->minify->getCSS('cadastro_professor_lista.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        //print_pre($this->session->userdata('escola'));die();
        if ($this->session->userdata('school')) {
            $data['escolaid'] = $this->session->userdata('school')->id;
        }else{
            $token = $this->session->userdata('token');
            $data['dadosEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle($token,'269');
        }
        $this->load->view('cadastro/listarProfessor', $data);
    }

    public function cadastrarProfessor($personId = null)
    {
        if($this->session->userdata('perfil') != 268 AND
            $this->session->userdata('perfil') != 269 AND
            $this->session->userdata('perfil') != 270 AND
            $this->session->userdata('perfil')!= 271)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';

        $this->css[] = $this->minify->getCSS('cadastro_professor.min', $this->cssMinify, ENVIRONMENT);


        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['edit'] = 0;
        // $data['dadosEscola'] = $this->cadastro->getDados(269, null, 'A');
        // $data['dadosEscola'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle();

        $data['turmas'] = array();
        $data['disciplinas'] = array();
        $data['schoolId'] = $data['escolaID'] = $this->session->userdata('school')->id;

        $data['dadosTurma'] = SaeDigital::make(BuscarTurmasNextAva::class)->get($this->session->userdata('school')->id);

        $return = '';
        $dados = $data['dadosTurma'];
        for ($i = 0; count($dados) > $i; $i++) {
            $return .= '<option value="' . $dados[$i]->id . '" '
                . 'data-desc="' . ($dados[$i]->name) . '" '
                . 'data-serie="' . ($dados[$i]->gradeId) . '" '
                . 'data-serieDesc="' . ($dados[$i]->gradeName) . '" '
                . 'data-vigencia="' . $dados[$i]->year . '">
                        ' . ($dados[$i]->name.' - '.$dados[$i]->year) . '</option>';
        }
        $return .= '</select>';
        $data['comboTurmas'] = $return;

        //print_pre($escola);die;
        $series = array();
        if ($personId) {

            //$data['dadosProfessor'] = $this->cadastro->getDados(272, null, null, null, $login);
            // $data['dadosProfessor'] = $this->cadastro->getDadosProfessor($login);
            $data['dadosProfessor'] = SaeDigital::make(UsuarioNextAVA::class)->get(1 * $personId);
            $data['schoolId'] = $data['escolaID'] = $data['dadosProfessor']->schoolId;
            $data['descEscola'] = $data['dadosProfessor']->schoolName;

            $escola = $this->session->userdata('school') ? $this->session->userdata('school')->id : $data['dadosProfessor']->schoolId;

            $data['dadosTurmas'] = SaeDigital::make(BuscarTurmasNextAva::class)->get($escola);

            $listaTurmas = [];
            $disciplinasTurmas = [];
            foreach($data['dadosProfessor']->subjectsTeams as $st){
                if ($st->active == true) {
                    $listaTurmas[] = $st->teamId;
                    $disciplinasTurmas[] = $st->teamId."-".$st->subjectId;
                }
            }

            $data['turmas'] = $listaTurmas;

            $return = '';
            $dados = $data['dadosTurmas'];
            for ($i = 0; count($dados) > $i; $i++) {
                $return .= '<option value="' . $dados[$i]->id . '" '
                    . (in_array($dados[$i]->id, $listaTurmas) ? 'selected ' : '')
                    . 'data-desc="' . ($dados[$i]->name) . '" '
                    . 'data-serie="' . ($dados[$i]->gradeId) . '" '
                    . 'data-serieDesc="' . ($dados[$i]->gradeName) . '" '
                    . 'data-vigencia="' . $dados[$i]->year . '">
                            ' . ($dados[$i]->name.' - '.$dados[$i]->year) . '</option>';
            }
            $return .= '</select>';
            $data['comboTurmas'] = $return;

            $countDadosProfessor = count($data['dadosProfessor']);
            //salva as tumas e categorias do coordenador
            
            $disciplinas = SaeDigital::make(ObterDisciplinasTurmasNextAVA::class)->handle($listaTurmas);

            $return = "";
            for ($i = 0; count($disciplinas) > $i; $i++) {
                $d = $disciplinas[$i];

                $return .= '<optgroup label="Disciplinas turma : ' . ($d->name) . '">';
                $lista = $d->subjects;
                for ($x = 0; $x < count($lista[0]) ; $x++) {
                    $dd = $lista[0][$x];
                    $discSelected = '';

                    $check = $d->id."-".$dd->subjectId;

                    $discSelected = "";
                    if ( in_array($check, $disciplinasTurmas ) )
                        $discSelected = " selected ";

                    $add = '<option value="' . $dd->subjectId.'" data-turma="'.$d->id.'" data-serie="' . ($dd->gradeId) . '" '.$discSelected.'>' . ($dd->subjectName . ' - ' . $d->name) . '</option>';
                    $return .= $add;
                }
                $return .= '</optgroup>';

            }
            $data['comboDisciplina'] = $return;

            $data['edit'] = 1;
        }

        if ($this->session->userdata('escola')) {
            // $data['escolaID'] = $this->session->userdata('escola');
            $data['livrodigital'] = $this->cadastro->getAcessoLD($this->session->userdata('escola'));
            $data['descEscola'] = $this->session->userdata('nomeEscola') ? $this->session->userdata('nomeEscola') : $this->session->userdata('nome');
            $data['dadosTurma'] = $this->cadastro->getDadosTurma($this->session->userdata('escola'), false, true, Date('Y'));
        }

        $this->load->view('cadastro/cadastrarProfessor', $data);
    }

    public function salvarProfessor()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 271 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post);

        $fields['name'] = $name;
        $fields['login'] = $login;
        $fields['email'] = $email;
        $fields['password'] = $password;
        $fields['schoolId'] = 1 * $schoolId;
        $fields['teams'] = $teams;
        $fields['type'] = 2;
        $fields['subjectsTeams'] = $subjectsTeams;
        $fields['personId'] = 1 * $personId;
        $fields['active'] = $situacao == 'A' || 1 * $personId == 0;

        $usuario = SaeDigital::make(UsuarioNextAVA::class);

        if ( $personId )
            $save = $usuario->update($fields);
        else
            $save = $usuario->create($fields);

        echo json_encode($save);
        return;

        exit;
    }

    public function cadastrarProfessorDemo()
    {    
        if($this->session->userdata('perfil') != 268 AND
            $this->session->userdata('perfil') != 269 AND
            $this->session->userdata('perfil') != 270 AND
            $this->session->userdata('perfil')!= 271)
        {
            Redirect('/');
        }

        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';

        $this->css[] = $this->minify->getCSS('cadastro_professor.min', $this->cssMinify, ENVIRONMENT);


        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $this->load->view('cadastro/cadastrarProfessorDemo');
    }    

    public function salvarProfessorDemo()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 271 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post);

        $ids = [];
        $obj = new stdClass();
        for ($i = 1; $i <= $quantidade; $i++) {
            $row = SaeDigital::make(CadastrarDemo::class)->handle($dias, 266383);

            $fields['name'] = "Professor Demonstrativo";
            $fields['login'] = "professor." . $row['code'];
            $fields['email'] = "";
            $fields['password'] = $row['code'];
            $fields['schoolId'] = 1 * 11876 ;
            $fields['teams'] = $teamId;
            $fields['type'] = 2;
            $fields['subjectsTeams'] = $subjectsTeams;
            $fields['personId'] = "";
            $fields['active'] = "A";
    
            $usuario = SaeDigital::make(UsuarioNextAVA::class);
                
            $obj->addProfessor = $usuario->create($fields);
            $ids[] = $row['id'];
        }       

        $obj->ids = implode(',', $ids);

        echo json_encode($obj);
        return;

        exit;
    }   

    public function cadastrarConfiguracoes()
    {
        $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['perfil'] = (int)$this->session->userdata('perfil');
        if (in_array($data['perfil'], [Perfil::ESCOLA, Perfil::DIRETOR])) {
            $data['idEscola'] = $this->session->userdata('escola');
        }

        $this->load->view('cadastro/configuracaoEscola', $data);
    }

    public function salvarConfiguracoes($cadastroEscola = false, $idEscola = null, $nomeEscola = null, $arrayPadrao = null, $arrayPadrao2 = null, $segmentos, $idProtheus = null)
    {

        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269 &&
            $this->session->userdata('perfil') != 270)
        {
            Redirect('/');
        }

        $this->layout = '';
        if(!$cadastroEscola){
            $post = $this->input->post(NULL, TRUE);
            extract($post);
        }

        $itemName = trim($idEscola);

        $fields['IdProtheus'] = $idProtheus;
        $fields['EscolaID'] = trim($idEscola);
        $fields['NomeEscola'] = trim($nomeEscola);
        $fields['AgendaProfessor'] = isset($agendaProfessor) ? trim($agendaProfessor) : 'N';
        $fields['AgendaCoordenador'] = isset($agendaCoordenador) ? trim($agendaCoordenador) : 'N';
        $fields['QuestaoProfessor'] = isset($questaoProfessor) ? trim($questaoProfessor) : 'N';
        $fields['QuestaoCoordenador'] = isset($questaoCoordenador) ? trim($questaoCoordenador) : 'N';
        $fields['DtFimProfessor'] = isset($dtFimProfessor) ? trim($dtFimProfessor) : 'N';
        $fields['DtFimCoordenador'] = isset($dtFimCoordenador) ? trim($dtFimCoordenador) : 'N';
        $fields['NotificacaoResponsavel'] = isset($notificacaoResponsavel) ? trim($notificacaoResponsavel) : 'N';
        $fields['NotiRespTarefaRealizada'] = isset($notiRespTarefaRealizada) ? trim($notiRespTarefaRealizada) : 'N';
        $fields['NotificacaoAluno'] = isset($notificacaoAluno) ? trim($notificacaoAluno) : 'N';
        $fields['RespostaFinalAgendamentoAluno'] = isset($respostafinalagendamentoAluno) ? trim($respostafinalagendamentoAluno) : 'N';
        $fields['MediaTurmaRelatorio'] = isset($mediaTurmaRelatorio) ? trim($mediaTurmaRelatorio) : 'S';
        $fields['AgendamentoDisciplinasLote'] = isset($agendamentoDisciplinasLote) ? trim($agendamentoDisciplinasLote) : 'N';
        $fields['itemName'] = $itemName;
        $fields['segmentos'] = is_array($segmentos) ? implode(',', $segmentos) : $segmentos;

        $fields['UsuarioCad'] = $this->session->userdata('pessoaid');
        $fields['UsuarioAlt'] = $this->session->userdata('pessoaid');
        $fields['DtCad'] = date('Y-m-d H:i:s');
        $fields['DtAlt'] = date('Y-m-d H:i:s');
        $fields['Tipo'] = 'G';
        $fields['AcessoLD'] = 'S';
        $fields['ExibeMenuLD'] = 'S';
        $fieldsSerie['ExibeMenuLD'] = 'S';

        if ($fields['NotificacaoResponsavel'] == 'S') {
            // Busca data anterior
            $dadosConfig = $this->cadastro->getConfiguracoes($fields['EscolaID']);

            $fields['DtNotificacaoResponsavel'] = date('Y-m-d H:i:s');

            //Salva logs de alterações opção notificação responsável, caso NotificacaoResponsavel seja igual S
            $fieldsLogs['EscolaID'] = $fields['EscolaID'];
            $fieldsLogs['DataNotificacaoAnterior'] = isset($dadosConfig[0]['DtNotificacaoResponsavel']) ? $dadosConfig[0]['DtNotificacaoResponsavel'] : 'N';
            $fieldsLogs['DataNotificacaoAtual'] = $fields['DtNotificacaoResponsavel'];
            $fieldsLogs['Tipo'] = 'responsavel';
            $this->cadastro->salvaDados('D029_Ava_Sae_LogNotificacoes', $this->iesdeuuid->getIdRandom(), $fieldsLogs, TRUE);
        }
        //salva os dados de configurações gerais do professor e coordenador

        if ( $cadastroEscola ){
            $resultado = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $itemName, $fields, TRUE);
        }else{
            $resultado = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $itemName, $fields, FALSE);
        }

        //salva um registro para cada serie
        $fieldsSerie['EscolaID'] = trim($idEscola);
        $fieldsSerie['NomeEscola'] = trim($nomeEscola);
        $fieldsSerie['UsuarioCad'] = $this->session->userdata('pessoaid');
        $fieldsSerie['UsuarioAlt'] = $this->session->userdata('pessoaid');
        $fieldsSerie['DtCad'] = date('Y-m-d H:i:s');
        $fieldsSerie['DtAlt'] = date('Y-m-d H:i:s');
        $fieldsSerie['Tipo'] = 'S';

        $arrayMetas = isset($meta) ? $meta : $arrayPadrao;

        for ($i = 0; count($arrayMetas) > $i; $i++) {
            $dados = explode('-', $arrayMetas[$i]);
            $met = isset($dados[1]) && $dados[1] != '' ? $dados[1] : 0;
            $itemNameSerie = trim($idEscola) . $dados[0];
            $fieldsSerie['Serie'] = $dados[0];
            $fieldsSerie['Meta'] = $met;
            $fieldsSerie['itemName'] = $itemNameSerie;

            if ( $cadastroEscola ){
                $resultado = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $itemNameSerie, $fieldsSerie, TRUE);
            }else{
                $resultado = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $itemNameSerie, $fieldsSerie, FALSE);
            }

            $this->cadastro->atualizaMetaQuestoes($idEscola, $fieldsSerie);
        }

        $arrayPercentual = isset($percentual) ? $percentual : $arrayPadrao2;

        for ($i = 0; count($arrayPercentual) > $i; $i++) {
            $dados = explode('-', $arrayPercentual[$i]);

            $perc = isset($dados[1]) && $dados[1] != '' ? (int) $dados[1] : (int) 0;

            $itemNameSerie = trim($idEscola) . $dados[0];
            $fieldsSerieUpdate['Serie'] = $dados[0];
            $fieldsSerieUpdate['Percentual'] = $perc;
            $fieldsSerieUpdate['itemName'] = $itemNameSerie;

            $resultado = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $itemNameSerie, $fieldsSerieUpdate, FALSE);
            $this->cadastro->atualizaMetaVideo($idEscola, $fieldsSerieUpdate);
        }

        print($resultado);
        die;
    }

    public function buscaConfiguracoesEscola()
    {
        if($this->session->userdata('perfil') != 268 &&
            $this->session->userdata('perfil') != 269)
        {
            Redirect('/');
        }

        $this->layout = '';

        $dados = new stdClass();

        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post);

        $configuracoes = $this->cadastro->getConfiguracoes($escola);
        if ($configuracoes) {
            $dados->QuestaoProfessor = isset($configuracoes[0]['QuestaoProfessor']) ? $configuracoes[0]['QuestaoProfessor'] : 'N';
            $dados->AgendaProfessor = isset($configuracoes[0]['AgendaProfessor']) ? $configuracoes[0]['AgendaProfessor'] : 'N';
            $dados->QuestaoCoordenador = isset($configuracoes[0]['QuestaoCoordenador']) ? $configuracoes[0]['QuestaoCoordenador'] : 'N';
            $dados->AgendaCoordenador = isset($configuracoes[0]['AgendaCoordenador']) ? $configuracoes[0]['AgendaCoordenador'] : 'N';
            $dados->DtFimProfessor = isset($configuracoes[0]['DtFimProfessor']) ? $configuracoes[0]['DtFimProfessor'] : 'N';
            $dados->DtFimCoordenador = isset($configuracoes[0]['DtFimCoordenador']) ? $configuracoes[0]['DtFimCoordenador'] : 'N';
            $dados->NotificacaoResponsavel = isset($configuracoes[0]['NotificacaoResponsavel']) ? $configuracoes[0]['NotificacaoResponsavel'] : NULL;
            $dados->NotificacaoAluno = isset($configuracoes[0]['NotificacaoAluno']) ? $configuracoes[0]['NotificacaoAluno'] : NULL;
            $dados->RespostaFinalAgendamentoAluno = isset($configuracoes[0]['RespostaFinalAgendamentoAluno']) ? $configuracoes[0]['RespostaFinalAgendamentoAluno'] : NULL;
            $dados->MediaTurmaRelatorio = isset($configuracoes[0]['MediaTurmaRelatorio']) ? $configuracoes[0]['MediaTurmaRelatorio'] : NULL;
            $dados->AgendamentoDisciplinasLote = isset($configuracoes[0]['AgendamentoDisciplinasLote']) ? $configuracoes[0]['AgendamentoDisciplinasLote'] : NULL;
            $dados->AcessoLD = isset($configuracoes[0]['AcessoLD']) ? $configuracoes[0]['AcessoLD'] : NULL;
            $dados->AcessoLD = isset($configuracoes[0]['AcessoLD']) ? $configuracoes[0]['AcessoLD'] : NULL;
            $dados->Porcentagem = isset($configuracoes[0]['Porcentagem']) ? $configuracoes[0]['Porcentagem'] : NULL;

            $metas = array();
            $percentual = array();
            for ($a = 1; count($configuracoes) > $a; $a++) {
                $metas[$configuracoes[$a]['Serie']] = $configuracoes[$a]['Meta'] != '-' ? $configuracoes[$a]['Meta'] : 0;
                $percentual[$configuracoes[$a]['Serie']] = (isset($configuracoes[$a]['Percentual']) && $configuracoes[$a]['Percentual'] != '-') ? $configuracoes[$a]['Percentual'] : 0;
            }
            //  $tipo = 1 para remover as series 1 a 5 ano e Infatil
            $tipo = 1;
            $serie = $this->cadastro->getSerie($tipo);

            $dadosSerie = array();
            for ($i = 0; count($serie) > $i; $i++) {

                $serie[$i]->Meta = '';
                $serie[$i]->Percentual = '';

                //adiciona a meta da serie no array
                if (array_key_exists($serie[$i]->SerieID, $metas)) {
                    $serie[$i]->Meta = $metas[$serie[$i]->SerieID];
                }

                if (array_key_exists($serie[$i]->SerieID, $percentual)) {
                    $serie[$i]->Percentual = $percentual[$serie[$i]->SerieID];
                }

                if (strpos($serie[$i]->Descricao, 'ano') !== false) {
                    $fundamental[] = $serie[$i];
                } else {
                    $medio[] = $serie[$i];
                }
            }

            $dados->fundamental = '';
            for ($i = 0; count($fundamental) > $i; $i++) {
                $dados->fundamental .= '<tr>
                            <td style="text-align: center;">' . $fundamental[$i]->Descricao . '</td>
                            <td style="text-align: center;"><input type="text" style="width: 50px;" name="meta" id="' . $fundamental[$i]->SerieID . '" value="' . $fundamental[$i]->Meta . '"> %</td>
                            <td style="text-align: center;"><input type="text" style="width: 50px;" name="percentual" id="' . $fundamental[$i]->SerieID . '" value="' . $fundamental[$i]->Percentual . '"> %</td>
               </tr>';
            }

            $dados->medio = '';
            for ($i = 0; count($medio) > $i; $i++) {
                $dados->medio .= '<tr>
                        <td style="text-align: center;">' . $medio[$i]->Descricao . '</td>
                        <td style="text-align: center;"><input type="text" style="width: 50px;" name="meta" id="' . $medio[$i]->SerieID . '" value="' . $medio[$i]->Meta . '"> %</td>
                        <td style="text-align: center;"><input type="text" style="width: 50px;" name="percentual" id="' . $medio[$i]->SerieID . '" value="' . $medio[$i]->Percentual . '"> %</td>
                </tr>';
            }
        } else {

            //seta como padrao das opções 'Sim'
            $dados->QuestaoProfessor = 'N';
            $dados->AgendaProfessor = 'N';
            $dados->QuestaoCoordenador = 'N';
            $dados->AgendaCoordenador = 'N';
            $dados->DtFimProfessor = 'N';
            $dados->DtFimCoordenador = 'N';
            $dados->NotificacaoResponsavel = 'N';
            $dados->NotificacaoAluno = 'N';
            $dados->NotificacaoAluno = 'N';
            $tipo = 1;
            $serie = $this->cadastro->getSerie($tipo);

            $dadosSerie = array();
            for ($i = 0; count($serie) > $i; $i++) {
                if (strpos($serie[$i]->Descricao, 'ano') !== false) {
                    $fundamental[] = $serie[$i];
                } else {
                    $medio[] = $serie[$i];
                }
            }

            $dados->fundamental = '';
            for ($i = 0; count($fundamental) > $i; $i++) {
                $dados->fundamental .= '<tr>
                        <td style="text-align: center;">' . $fundamental[$i]->Descricao . '</td>
                        <td style="text-align: center;"><input type="text" style="width: 50px;" name="meta" id="' . $fundamental[$i]->SerieID . '" value=""> %</td>
                        <td style="text-align: center;"><input type="text" style="width: 50px;" name="percentual" id="' . $fundamental[$i]->SerieID . '" value=""> %</td>
                </tr>';
            }
            $dados->medio = '';
            for ($i = 0; count($medio) > $i; $i++) {
                $dados->medio .= '<tr>
                        <td style="text-align: center;">' . $medio[$i]->Descricao . '</td>
                        <td style="text-align: center;"><input type="text" style="width: 50px;" name="meta" id="' . $medio[$i]->SerieID . '" value=""> %</td>
                        <td style="text-align: center;"><input type="text" style="width: 50px;" name="percentual" id="' . $medio[$i]->SerieID . '" value=""> %</td>
                </tr>';
            }
        }

        print(json_encode($dados));
        die;
    }

    public function buscaConfiguracoesEscolaLD()
    {
        $this->layout = '';

        $dados = new stdClass();

        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post);
        $configuracoes = $this->cadastro->getConfiguracoes($post['escola'],true);
        //p($post['escola']);die;
        if ($configuracoes) {

            $dados->AcessoLD = isset($configuracoes[0]['AcessoLD']) ? $configuracoes[0]['AcessoLD'] : NULL;
            $dados->SenhaAluno = isset($configuracoes[0]['SenhaAluno']) ? $configuracoes[0]['SenhaAluno'] : NULL;

            $acessoLD = array();

            for ($a = 1; count($configuracoes) > $a; $a++) {
                $acessoLD[$configuracoes[$a]['Serie']] = isset($configuracoes[$a]['ExibeMenuLD']) ? $configuracoes[$a]['ExibeMenuLD'] : '';
            }

            $serie = $this->cadastro->getSerie();
            $dadosSerie = array();
            for ($i = 0; count($serie) > $i; $i++) {

                if (isset($acessoLD[$serie[$i]->SerieID]) && $acessoLD[$serie[$i]->SerieID] != '') {
                    $serie[$i]->ExibeMenuLD = $acessoLD[$serie[$i]->SerieID];
                }

                if ($serie[$i]->CategoriaID == 1 || $serie[$i]->CategoriaID == 2) {
                    $fundamental[] = $serie[$i];
                }else if($serie[$i]->CategoriaID == 8) {
                    $infantil[] = $serie[$i];
                }else {
                    $medio[] = $serie[$i];
                }
            }

            $dados->infantil = '';
            $dados->fundamental = '';
            $dados->medio = '';
            for ($i = 0; count($infantil) > $i; $i++) {
                $dados->infantil .= '<tr>
											<td style="text-align: center;">' . ($infantil[$i]->Descricao) . '</td>
											<td style="text-align: center;"><input type="text" style="width: 50px;" name="acessoLD" id="' . $infantil[$i]->SerieID . '" value="' . $infantil[$i]->ExibeMenuLD . '"> </td>
									   </tr>';
            }
            for ($i = 0; count($fundamental) > $i; $i++) {
                $dados->fundamental .= '<tr>
											<td style="text-align: center;">' . ($fundamental[$i]->Descricao) . '</td>
											<td style="text-align: center;"><input type="text" style="width: 50px;" name="acessoLD" id="' . $fundamental[$i]->SerieID . '" value="' . $fundamental[$i]->ExibeMenuLD . '"> </td>
									   </tr>';
            }

            $dados->medio = '';
            for ($i = 0; count($medio) > $i; $i++) {
                $dados->medio .= '<tr>
									<td style="text-align: center;">' . ($medio[$i]->Descricao) . '</td>
									<td style="text-align: center;"><input type="text" style="width: 50px;" name="acessoLD" id="' . $medio[$i]->SerieID . '" value="' . $medio[$i]->ExibeMenuLD . '"> </td>
								</tr>';
            }
        } else {

            $serie = $this->cadastro->getSerie();

            $dadosSerie = array();
            for ($i = 0; count($serie) > $i; $i++) {

                if (isset($acessoLD[$serie[$i]->SerieID]) && $acessoLD[$serie[$i]->SerieID] != '') {
                    $serie[$i]->ExibeMenuLD = $acessoLD[$serie[$i]->SerieID];
                }

                if ($serie[$i]->CategoriaID == 1 || $serie[$i]->CategoriaID == 2) {
                    $fundamental[] = $serie[$i];
                }else if($serie[$i]->CategoriaID == 8) {
                    $infantil[] = $serie[$i];
                }else {
                    $medio[] = $serie[$i];
                }
            }

            $dados->infantil = '';
            $dados->fundamental = '';
            $dados->medio = '';
            for ($i = 0; count($infantil) > $i; $i++) {
                $dados->infantil .= '<tr>
											<td style="text-align: center;">' . ($infantil[$i]->Descricao) . '</td>
											<td style="text-align: center;"><input type="text" style="width: 50px;" name="acessoLD" id="' . $infantil[$i]->SerieID . '" value="' . $infantil[$i]->ExibeMenuLD . '"> </td>
									   </tr>';
            }
            for ($i = 0; count($fundamental) > $i; $i++) {
                $dados->fundamental .= '<tr>
											<td style="text-align: center;">' . ($fundamental[$i]->Descricao) . '</td>
											<td style="text-align: center;"><input type="text" style="width: 50px;" name="acessoLD" id="' . $fundamental[$i]->SerieID . '" value="' . $fundamental[$i]->ExibeMenuLD . '"> </td>
									   </tr>';
            }

            $dados->medio = '';
            for ($i = 0; count($medio) > $i; $i++) {
                $dados->medio .= '<tr>
									<td style="text-align: center;">' . ($medio[$i]->Descricao) . '</td>
									<td style="text-align: center;"><input type="text" style="width: 50px;" name="acessoLD" id="' . $medio[$i]->SerieID . '" value="' . $medio[$i]->ExibeMenuLD . '"> </td>
								</tr>';
            }
        }

        print(json_encode($dados));
        die;
    }

    public function cadDadosPrimeiroLogin() {

        $this->layout = 'new-ava';
        
        $login = $this->session->flashdata('login');

        $token = $this->session->token;
        $userData = SaeDigital::make(ObterUsuarioNextAva::class)->handle($token);
        $login = empty($login) ? $userData->login : $login;
        if (empty($login)) {
            redirect("login");
        }

        $this->load->model('cadastro_model', 'cadastro');

        $this->css[] = $this->minify->getCSS('cadastro_login.min', $this->cssMinify, ENVIRONMENT);
        
        $data['dados'] = $this->cadastro->getDados(null, null, 'A', null, $login);
        
        $data['liberarEdicaoNome'] = empty($data['dados'][0]['Nome']) && (int)$data['dados'][0]["Perfil"] !== Perfil::ALUNO;
        
        $data['edit'] = 1;

        $data['userData'] = $userData;
        
        $this->session->set_userdata("itemName" , $data['dados'][0]["itemName"]);

        $this->load->view('primeiro_login', $data);
    }

    public function salvarPrimeiroLogin()
    {
        try {
            if (!$this->input->post()) {
                throw new Exception('Requisição não permitida');
            }

            $data = [
                'nome' => trim($this->input->post('nome')),
                'novoLogin' => trim($this->input->post('login')),
                'senha' => trim($this->input->post('senha')),
                'email' => strtolower(trim($this->input->post('email'))) ?: null,
                'perfil' => $this->input->post('perfil'),
                'telefone' => $this->input->post('telefone'),
                'turma' => $this->input->post('turma'),
                'loginAntigo' => $this->input->post('loginAntigo')
            ];

            $id = $this->session->userdata("itemName");

            $liberar = SaeDigital::make(ValidarLoginPrimeiroLogin::class)->handle($data['novoLogin'], $id);
            if (!$liberar) {
                throw new Exception('Login informado já esta em uso.');
            }

            if ($data['email']) {
                $validacaoEmail = SaeDigital::make(ValidarDuplicidadeEmail::class)->handle($data['email'], $data['loginAntigo']);
                if (!$validacaoEmail) {
                    throw new Exception('Email informado já esta em uso');
                }
            }

            if (!SaeDigital::make(AtualizarDadosPrimeiroLogin::class)->handle($data)) {
                throw new Exception('Ocorreu um erro durante a atualização dos dados, tente novamente mais tarde');
            }

            SaeDigital::make(EnqueueDeletarUsuarioPortal::class)->handle($data['loginAntigo']);

            $usuario = SaeDigital::make(BuscarUsuarioPorItemName::class)->handle($id);

            $response = [
                'status' => 'success',
                'message' => 'Dados atualizados com sucesso!',
                'code' => 200,
                'redirecionar' => $usuario['Redirecionar']
            ];

        } catch (\Exception $e) {
            log_error($e->getMessage());

            $response = [
                'status' => 'error',
                'message' => $e->getMessage(),
                'code' => 500
            ];
        }

        return $this->responseJson($response, $response['code']);
    }

    /*
     * Seleção de Disciplina para vinculo das questões discursivas - Plataforma Literária
     */

    function questoes_discursivas() {

        $this->css[] = $this->minify->getCSS('questoes_discursivas.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'avasae';

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);
        $dados['tiposelecao'] = 'buscardisciplina';
        $this->load->view('cadastro/questoes_discursivas', $dados);
    }

    function buscarPacotes(){
        $this->layout = '';

        $tipobusca = $this->input->post('tipobusca');
        $tipobusca = utf8_decode($tipobusca);
        if(!$tipobusca)
        {
            Redirect('/');
        }

        $pacote = $this->cadastro->listarPacotes($tipobusca);
        if(empty($pacote)){
            $html = '<table>
                        <tr class="header">
                            <th width="90%">Nome do Pacote</th>
                            <th width="10%">A&ccedil;&atilde;o</th>
                        </tr>
                        <tr>
                            <td colspan="2" align="center" class="sempacotes">Nenhum pacote encontrado.</td>
                        </tr>
                    </table>';
        }else{
            $html = null;
        }
        $result = array("html" => $html, "encontrados" => count($pacote), "pacotes" => $pacote);
        header('Content-Type: application/json');
        exit(json_encode($result));
    }

    /**
     * questoes_discursivas_cadastro
     *
     * Cadastro de questões discursivas - Plataforma Literária
     *
     * @param string $Ancora determinanda qual ? a identificador da disciplina
     * @access	public
     * @return	void
     */
    function questoes_discursivas_cadastro($ancora = null) {

        $this->cssMinify = '';
        $this->cssMinify = array('bootstrap', '_reset', 'geral', 'messi', 'mensagem');
        $this->cssMinify[] = 'buscar';
        $this->cssMinify[] = 'curso';
        $this->css[] = $this->minify->getCSS('questoes_discursivas_cadastro.min', $this->cssMinify, ENVIRONMENT);

        $this->load->model('curso_model', 'curso');
        $this->load->model('plataformaliteraria_model', 'literaria');


        $perfil = $this->session->userdata('perfil');
        $dados['dados'] = montaMenu($perfil);
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $Ancora = $this->uri->segment(2);
        $grupoAula = $Ancora ? $this->home->verificaGrupoAulaAncora($Ancora) : '';

        if (!empty($grupoAula)) {
            $grupoaulaid = $grupoAula[0]['itemName'];
            $assuntosPL = $this->literaria->getQuestoesDiscursivasPorGrupoAula($grupoaulaid);
            $data['CursoNome'] = $grupoAula[0]['Descricao'];
            $data['GrupoAulaID'] = $grupoaulaid;
            $data['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];
            $data['meta'] = $this->session->userdata('meta');
            $data['assuntos'] = $assuntosPL;
            $array['Ancora'] = $Ancora;
            $array['grupoAulaID'] = $grupoaulaid;
            $array['DescricaoPacote'] = ($grupoAula[0]['Descricao']);
            $array['ClassificacaoID'] = $grupoAula[0]['ClassificacaoID'];
            $this->session->set_userdata($array);
            $this->session->set_userdata('GrupoAulaID', $grupoaulaid);
        }
        $data['perfil'] = $perfil;
        $this->load->view('cadastro/questoes_discursivas_cadastro', $data);
    }

    function questoes_discursivas_editar() {
        $this->css[] = $this->minify->getCSS('questoes_discursivas_editar.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'avasae';

        $dados['tiposelecao'] = 'buscardisciplina';
        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $this->load->model('curso_model', 'curso');
        $this->load->model('plataformaliteraria_model', 'literaria');

        //TODO: validar formato mais seguro
        $descricaoLiteraria = $this->session->userdata('DescricaoPacote');
        $grupoaulaid = $this->uri->segment(3);
        $assuntoid = $this->uri->segment(4);
        $aulaid = $this->uri->segment(5);
        $questaodiscursivaid = $this->uri->segment(6);
        $enunciado = $this->input->post('enunciado');
        $questaodiscursivaidPost = $this->input->post('questaoid');

        // Se existe conteudo grava questão discursiva.
        if ($enunciado && $questaodiscursivaidPost ) {
            $usuarioid = $this->session->userdata('pessoaid');
            $resultado = $this->literaria->salvarQuestoesDiscursivas($questaodiscursivaidPost, $enunciado, $grupoaulaid, $assuntoid, $aulaid, $usuarioid);
            exit(json_encode('1'));
        }

        $dados['enunciado'] = '';
        $dados['descricaoLiteraria'] = $descricaoLiteraria;
        if ($questaodiscursivaid) {
            $resultado = $this->literaria->getQuestaoDiscursivaPorID($questaodiscursivaid);
            $dados['questaodiscursivaid'] = $resultado->QuestaoDiscursivaID;
            $dados['grupoaulaid'] = $grupoaulaid;
            $dados['enunciado'] = utf8_decode($resultado->Enunciado);
        }
        $this->load->view('cadastro/questoes_discursivas_editar', $dados);
    }

    public function salvaQuestaoDiscursiva(){
        header('Content-Type: application/json');

        $questaodiscursivaid = $this->input->post('questaoid');
        $enunciado = $this->input->post('enunciado');
        $usuarioid = $this->session->userdata('pessoaid');

        if (isset($questaodiscursivaid, $enunciado, $usuarioid)) {
            $updated = $this->literaria->salvarQuestoesDiscursivas($questaodiscursivaid, $enunciado, null, null, null, $usuarioid);
            exit($usuarioid);
        }else{
            throw new Exception("Arguments is missing");
        }
    }

    function questoes_discursivas_lista() {
        $aulaid = $this->uri->segment(3);
        $grupoaulaid = $this->uri->segment(4);
        $assuntoid = $this->uri->segment(5);
        $perfilid = $this->session->userdata('perfil');

        $this->load->model('curso_model', 'curso');
        $this->load->model('plataformaliteraria_model', 'literaria');

        $this->css[] = $this->minify->getCSS('questoes_discursivas_editar.min', $this->cssMinify, ENVIRONMENT);
        $this->js[] = 'avasae';

        $aula = $this->literaria->getInfoAula($aulaid);
        $assuntoDescricao = null;
        if($aula){
            $assuntoDescricao = $aula[0]->Tema;
        }
        $resultado = $this->literaria->getQuestoesDiscursivas($grupoaulaid, null, $assuntoid);
        $dados['assuntoDescricao'] = $assuntoDescricao;
        $dados['discursivas'] = $resultado;
        $dados['disciplinaid'] = $grupoaulaid;
        $dados['assuntoid'] = $assuntoid;
        $dados['dados'] = montaMenu($perfilid);
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);
        $this->load->view('cadastro/questoes_discursivas_lista', $dados);
    }

    function plataformaliteraria() {
        $login = $this->session->userdata('login');
        $perfilid = $this->session->userdata('perfil');

        $this->load->model('curso_model', 'curso');
        $this->load->model('disciplina_model', 'disciplina');
        $this->load->model('plataformaliteraria_model', 'literaria');

        $this->js[] = 'avasae';
        $this->css[] = $this->minify->getCSS('questoes_discursivas_editar.min', $this->cssMinify, ENVIRONMENT);

        $data['dados'] = montaMenu($perfilid);
        $this->menu_vertical = $this->load->view('view_menu', $data, true);

        $turmaid = $this->input->post('turma') ? $this->input->post('turma', true) : null;
        $turmas = $this->literaria->getTurmasProfessorPorLogin($login, null, true);

        $teamsArray = array_unique($this->session->userdata('teams'), SORT_REGULAR);

        $seriesParaRemover = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];

        $output = [];
        array_walk($teamsArray, function($element) use ($seriesParaRemover, &$output) {
            $matches = true;
            foreach ($seriesParaRemover as $remover) {
                
                if ($remover == $element->grade_id) {
                    $matches = false;
                }
            }
            if ($matches) {
                $output[] = $element;
            }
        });

        $cboTurmas = array(NULL => 'Selecione uma Turma');

        foreach ($output as $key => $turma) {
            if (!in_array($turma->id, $cboTurmas)) {
                $cboTurmas[$turma->id] = $turma->name;
            }
        }       

        $extraTurma = array('id' => 'turma', 'class' => 'form-control', 'placehold' => 'Selecione uma turma');
        $data['comboTurma'] = form_dropdown('turma', $cboTurmas, $turmaid, $extraTurma);

        $assuntosAgendados = null;
        if($turmaid){
            $infoUsuario = $this->literaria->getSerieTurmaPorLogin($login, $turmaid);
        }

        if (isset($turmaid, $login, $perfilid, $infoUsuario)){
            // $serieid = $infoUsuario[0]->SerieID;

            $seriInfo = SaeDigital::make(ObterDisciplinasTurmasNextAVA::class)->handle($turmaid);
            
            $serieid = $seriInfo[0]->grade_id;

            $escolaId = $this->session->userdata('escola');

            $assuntos = $this->literaria->getAssuntosPlataformaLiterariaPorSerie($serieid, true, $escolaId);

            $disciplinas = SaeDigital::make(BuscarDisciplinasPorTurmaNextAva::class)->handle($turmaid, $serieid);

            foreach ($disciplinas as $disciplina) {
            if ((int)$disciplina['idClassificacao'] === 11) {
                    $idDisciplina = $disciplina;
                }
            }

            $assuntosAgendados = array();
            foreach ($assuntos as $key => $assunto){
                $aulaid = $assunto->AulaId;
                $disciplinaid = $idDisciplina['idDisciplina'];
                $frenteid = $assunto->CategoriaAulaID;
                $assuntoId = $assunto->AssuntoID;
                
                // $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $disciplinaid, $frenteid, null);
                
                $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $disciplinaid, $frenteid, $assuntoId);
                
                $assunto->AssuntoID = $assunto->SubCategoriaID;
                $assunto->AulaID = $aulaid;
                $assunto->FrenteID = $frenteid;
                if($agendamento){
                    $assunto->TurmaID =  $turmaid;
                    $assunto->SerieID =  $serieid;
                    $inicio = strtotime($agendamento[0]->DtInicio);
                    $fim = strtotime($agendamento[0]->DtFim);
                    $assunto->DataInicioAgendamento = date('d/m/Y',$inicio);
                    $assunto->DataFimAgendamento = date('d/m/Y',$fim);
                    array_push($assuntosAgendados, $assunto);
                }
            }
        }

        $data['assuntos'] = $assuntosAgendados;
        $data["turma_selecionada"] = $turmaid;
        $data["perfil"] = intval($perfilid);
        $data['postRelatorio'] = base_url().'cadastro/plataformaliteraria';
        $this->load->view('cadastro/listaPlataformaLiteraria', $data);
    }

    function buscaQuestaoDiscursivaPorTurma(){
        $frenteid = $this->input->post('frenteid');
        $aulaid = $this->input->post('aulaid');
        $grupoaulaid = $this->input->post('grupoaulaid');
        $assuntoid = $this->input->post('assuntoid');
        $turmaid = $this->input->post('turmaid');
        $usuarioid = $this->session->userdata('pessoaid');

        if (isset($turmaid, $aulaid, $frenteid, $grupoaulaid, $usuarioid)) {
            $alunos = array();
            $alunosTurma = SaeDigital::make(ObterUsuariosPorTurmaNextAva::class)->handle($turmaid);
            //            $respostasalunos = $this->literaria->getAlunoRespostasQuestoesDiscursivasPorTurma($turmaid, $grupoaulaid, $frenteid);
            
            usort($alunosTurma, function($a, $b) { return $a->person_id - $b->person_id; });

            foreach ($alunosTurma as $indexaluno => $aluno)
            {
                $alunotemp = new stdClass();
                $alunotemp->GrupoAulaID = $grupoaulaid;
                $alunotemp->AssuntoID = $assuntoid;
                $alunotemp->FrenteID = $frenteid;
                $alunotemp->AulaID = $aulaid;
                $alunotemp->AlunoID = $aluno->person_id;
                $alunotemp->Nome = $aluno->name;
                $alunotemp->Turma = $turmaid;
                array_push($alunos, $alunotemp);
            }
            $html = $this->getHtmlTBodyAulaProfesssor($alunos);
            print $html;
            die;
        }else{
            throw new Exception("Missing arguments");
        }
    }


    function getHtmlTBodyAulaProfesssor($alunos){
        $html = "";
        $path = "correcaoAtividades/";
        foreach ($alunos as $index => $aluno){
            $url = $path. $aluno->AulaID.'/'.$aluno->GrupoAulaID. '/'. $aluno->AssuntoID.'/'. $aluno->AlunoID.'/'.$aluno->Turma;
                $html .= "<tr>";
            $html .= "<td>" . $aluno->Nome ."</td>";
            $html .= "<td>" . $aluno->DescricaoAssunto ."</td>";
            $html .= "<td>
                        <a
                            data-grupo='".$aluno->GrupoAulaID."'
                            data-assunto='".$aluno->AssuntoID."'
                            data-frente='".$aluno->FrenteID."'
                            data-aula='".$aluno->AulaID."'
                            data-aluno='".$aluno->AlunoID."'
                            href='".$url."'>
                           Corrigir
                        </a>
                    </td>";
            $html .= "</tr>";
        }
        return $html;
    }



    function correcaoAtividades($aulaid, $grupoaulaid, $assuntoid, $alunoid, $turmaid) {

        $alunosTurma = SaeDigital::make(ObterUsuariosPorTurmaNextAva::class)->handle($turmaid);

        usort($alunosTurma, function($a, $b) { return $a->person_id - $b->person_id; });

        $num = count($alunosTurma);

        for ($i=0; $i < $num; $i++) { 
            if($alunosTurma[$i]->person_id == $alunoid){            
                $atual = $i;
            }
        }


        $prox =  $alunosTurma[$atual + 1]->person_id ;
        $ant =  $alunosTurma[$atual - 1]->person_id ;

        $this->css[] = $this->minify->getCSS('questoes_discursivas_editar.min', $this->cssMinify, ENVIRONMENT);

        $perfilid = $this->session->userdata('perfil');
        $dados['dados'] = montaMenu($perfilid);
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $urlProxAluno = '/cadastro/correcaoAtividades/'.$aulaid.'/'.$grupoaulaid.'/'.$assuntoid.'/'.$prox.'/'.$turmaid;
        $urlAntAluno = '/cadastro/correcaoAtividades/'.$aulaid.'/'.$grupoaulaid.'/'.$assuntoid.'/'.$ant.'/'.$turmaid;


        $discursivas = array();
        $assuntoFinalizado = false;
        $frenteid = null;
        $descricaoAssunto = null;
        $infoaluno = $this->cadastro->getDados(null, $alunoid, "A", null, null, null,null,null);
        if (isset($infoaluno)){
            // $turmaid = $infoaluno[0]['Turma'];
            $agendamento = $this->literaria->getTurmaAgendamentoAula($turmaid, $grupoaulaid, null, $assuntoid);
            if($agendamento){
                $frenteid = $agendamento[0]->FrenteID;
                $inicio = strtotime($agendamento[0]->DtInicio);
                $fim = strtotime($agendamento[0]->DtFim);
                $now = strtotime(date('d-m-Y'));
                if(isset($fim, $now, $inicio) && $now > $fim) {
                    $assuntoFinalizado = true;
                }
                $dados['DataInicioAgendamento'] = date('d-m-Y',$inicio);
                $dados['DataFimAgendamento'] = date('d-m-Y',$fim);
            }

            $questoes = $this->literaria->getQuestoesDiscursivas($grupoaulaid, $aulaid, $assuntoid);
            foreach ($questoes as $index => $questao){
                $respTemp = new stdClass();
                $resposta = $this->literaria->getRespostasDiscursivasPorAssunto($turmaid, $alunoid, $grupoaulaid,
                    $assuntoid, $questao->QuestaoDiscursivaID);
                $respTemp->QuestaoDiscursivaID = $questao->QuestaoDiscursivaID;
                $respTemp->GrupoAulaID = $questao->GrupoAulaID;
                $respTemp->AssuntoID = $questao->AssuntoID;
                $respTemp->AulaID = $questao->AulaID;
                if(!$descricaoAssunto){
                    $aula = $this->literaria->getInfoAula($questao->AulaID);
                    $descricaoAssunto = $aula[0]->Tema;
                }
                $respTemp->Enunciado = utf8_encode($this->removeTags($questao->Enunciado));
                $respTemp->TurmaID = $turmaid;
                $respTemp->RespostaID = null;
                $respTemp->Resposta = null;
                $respTemp->Nota = null;
                $respTemp->FrenteID = $frenteid;
                if ($resposta){
                    $respTemp->Resposta = isset($resposta[0]->Resposta)? $resposta[0]->Resposta: null;
                    $respTemp->RespostaID = $resposta[0]->RespostaID;
                    $respTemp->Nota = isset($resposta[0]->Nota)? $resposta[0]->Nota: null;
                    $respTemp->FrenteID = isset($resposta[0]->FrenteID)? $resposta[0]->FrenteID: null;
                }
                $respTemp->Resposta = utf8_encode($respTemp->Resposta);
                array_push($discursivas, $respTemp);
            }

            $dados['nomeAluno'] = $alunosTurma[$atual]->name;
        }
        $dados['questoes'] = $discursivas;
        $dados['alunoid'] = $alunoid;
        $dados['descricaoAssunto'] = $descricaoAssunto;
        $dados['urlVoltar'] = base_url() .'cadastro/plataformaliteraria';
        $dados['assuntofinalizado'] = $assuntoFinalizado;
        $dados['proximoAluno'] = $urlProxAluno;
        $dados['anteriorAluno'] = $urlAntAluno;
        $dados['atual']= $atual;
        $dados['num']= $num;
        $this->load->view('cadastro/salvaNotasDiscursivas', $dados);
    }

    public function salvaNotasQuestoesDiscursivas()
    {
        try {
            $this->load->model('disciplina_model', 'disciplina');
            $this->load->model('plataformaliteraria_model', 'literaria');

            $notas = $this->input->post('notas');

            if (isset($notas)) {
                $escolaid = $this->session->userdata('escola');
                foreach ($notas as $key => $nota) {
                    if (($nota['resposta'] == null || empty($nota['resposta'])) && (int)$nota['nota'] > 0 ) {
                        throw new \InvalidArgumentException("Professor, não é possível atribuir nota maior que zero para alunos que não preencheram o campo de resolução da atividade.");
                    }

                    $alunoid = $nota['alunoid'];
                    $turmaid = $nota['turmaid'];
                    $grupoaulaid = $nota['grupoaulaid'];
                    $assuntoid = $nota['assuntoid'];
                    $frenteid = $nota['frenteid'];
                    $questaoid = $nota['questaoid'];
                    $resposta = $nota['resposta'];
                    $respostaid = $nota['respostaid'] != '' ? $nota['respostaid'] : null;
                    $nota = $nota['nota'] != '' ? intval($nota['nota']) : null;
                    $result = $this->literaria->salvarRespostaQuestoesDiscursivas($respostaid, $questaoid,
                        $resposta, $alunoid, $frenteid, $turmaid,
                        $grupoaulaid, $assuntoid, $nota, null,
                        $escolaid, null, null, null, null, null);
                }
                $this->responseJson(['message' => 'Notas enviadas com sucesso!'], 200);
            }

        } catch (\InvalidArgumentException $ex) {
            $this->responseJson(['message' => $ex->getMessage()], 400);
        } catch (\Exception $ex) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição, tente novamente mais tarde'], 500);
        }
    }

    function cadastrarConfigLD() {
        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';

        $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $data['edit'] = 0;
        $data['dadosEscola'] = $this->cadastro->getDados(269, null, 'A');
        $this->load->view('cadastro/cadastrarConfigLD', $data);
    }

    public function salvarConfigLD()
    {
        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);

        if(!$post)
        {
            Redirect('/');
        }

        extract($post);

        $itemName = trim($idEscola);
        $fields['EscolaID'] = trim($idEscola);
        $fields['NomeEscola'] = trim($nomeEscola);
        $fields['AcessoLD'] = trim($acessoLD);
        $fields['SenhaAluno'] = trim($senhaAluno);
        $fields['UsuarioCad'] = $this->session->userdata('pessoaid');
        $fields['UsuarioAlt'] = $this->session->userdata('pessoaid');
        $fields['DtCad'] = date('Y-m-d H:i:s');
        $fields['DtAlt'] = date('Y-m-d H:i:s');
        $fields['Tipo'] = 'G';

        //salva os dados de configurações gerais do professor e coordenador
        $resultado = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $itemName, $fields, FALSE);
        if ($fields['AcessoLD'] == 'S') {
            for ($i = 0; count($acessoMenuLD) > $i; $i++) {
                $dados = explode('-', $acessoMenuLD[$i]);
                $acc = isset($dados[1]) && $dados[1] != '' ? $dados[1] : 0;

                $itemNameSerie = trim($idEscola) . $dados[0];
                $fieldsSerie['Serie'] = $dados[0];
                $fieldsSerie['EscolaID'] = $idEscola;
                $fieldsSerie['ExibeMenuLD'] = strtoupper($acc);
                //$fieldsSerie['UsuarioCad'] = $this->session->userdata('pessoaid');
                $fieldsSerie['UsuarioAlt'] = $this->session->userdata('pessoaid');
                $fieldsSerie['DtCad'] = date('Y-m-d H:i:s');
                $fieldsSerie['DtAlt'] = date('Y-m-d H:i:s');
                $fieldsSerie['Tipo'] = 'S';
                $fieldsSerie['NomeEscola'] = trim($nomeEscola);
                $resultado = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $itemNameSerie, $fieldsSerie, FALSE);
            }
        }
        print($resultado);
        die;
    }

    function excluirAlunos()
    {
        $items = $this->input->post('excluir', true);

        if(!$items)
        {
            Redirect('/');
        }

        foreach($items as $key => $value){
            $teste = $this->cadastro->excluirAlunos($value, true);
        }

        print base_url().'cadastro/listarAluno';
        die;
    }

    function excluirProfessores()
    {

        $items = $this->input->post('excluir', true);

        if(!$items)
        {
            Redirect('/');
        }

        foreach($items as $key => $value){
            $teste = $this->cadastro->excluirProfessores($value);
        }

        print base_url().'cadastro/listarProfessor';
        die;
    }

    function excluirResponsaveis()
    {

        $items = $this->input->post('excluir', true);

        if(!$items)
        {
            Redirect('/');
        }

        foreach($items as $key => $value)
        {
            $teste = $this->cadastro->excluirResponsaveis($value);
        }

        print base_url().'cadastro/listarResponsavel';
        die;
    }

    function excluirCoordenadores()
    {
        $items = $this->input->post('excluir', true);

        if(!$items)
        {
            Redirect('/');
        }

        foreach($items as $key => $value){
            $teste = $this->cadastro->excluirProfessores($value);
        }

        print base_url().'cadastro/listarCoordenador';
        die;
    }

    function excluirDiretores()
    {
        $items = $this->input->post('excluir', true);

        if(!$items)
        {
            Redirect('/');
        }

        foreach($items as $key => $value){
            $teste = $this->cadastro->excluirAlunos($value, false);
        }

        print base_url().'cadastro/listarDiretor';
        die;
    }

    function excluirTurmas()
    {
        $items = $this->input->post('excluir', true);
        $escolaid = $this->input->post('escolaid', true);
        $vigencia = $this->input->post('vigencia', true);

        if(!$items)
        {
            Redirect('/');
        }

        $turmasComAlunos = [];
        foreach($items as $key => $value){
            $alunos = SaeDigital::make(BuscarAlunosPorTurma::class)->handle($value, $escolaid, $vigencia);
            if (count($alunos) > 0) {
                $nomeTurma = $alunos[0]['DescricaoTurma'];
                $nomeSerie = $alunos[0]['DescricaoSerie'];
                $turmasComAlunos[] = [
                    'turma' => $nomeTurma,
                    'serie' => $nomeSerie
                ];
            }else{
                $this->cadastro->excluirTurmas($value);
            }
        }

        $this->responseJson($turmasComAlunos);
        /*
        print base_url().'cadastro/listarTurma';
        die;*/
    }


    function buscaSerieID($turmaid){
        $serieid = $this->cadastro->getDadosTurma(null, $turmaid);
        return $serieid[0]['SerieID'];
    }

    function disciplinaExclusiva(){
        $this->js[] = 'chosen.jquery.min';
        $this->cssMinify[] = 'chosen';
        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);
        $data['dadosDisciplinas'] = $this->cadastro->getDisciplinaExclusivas();
        $this->css[] = $this->minify->getCSS('disciplinaExclusiva.min', $this->cssMinify, ENVIRONMENT);
        $this->load->view('cadastro/disciplinaExclusiva', $data);
    }

    function verificaEscolasExclusivas(){
        $this->layout = '';
        $disciplina = $this->input->post('disciplina', true);
        $escolasVinculadas = $this->cadastro->getEscolasVinculadas($disciplina);
        $retorno['edit'] = 0;
        $vinculados = array();
        if (!empty($escolasVinculadas)) {
            foreach ($escolasVinculadas as $key) {
                $vinculados[] = $key['EscolaID'];
            }
            $retorno['edit'] = 1;
        }
        //print_pre($disciplinasVinculadas);die;
        $dadosEscolas = $this->cadastro->getEscolas();
        foreach ($dadosEscolas as $key) {
            $escolas[$key['itemName']] = $key['Nome'];
        }

        //print_pre($vinculados);die;
        //$extra['id'] = 'inputEscola';
        $extra = 'id="inputEscola"';
        $retorno['view'] = form_multiselect('inputEscola', $escolas, $vinculados, $extra);
        //$view = $this->load->view('selectEscola', $dados, true);
        print_r(json_encode($retorno));
        die;
    }

    function salvarDisciplina(){
        $disciplina = explode('/',$this->input->post('disciplina', true));
        $escolas = $this->input->post('escolas', true);
        $edit = $this->input->post('edit', true);
        $serieID = $this->cadastro->getSerieID($disciplina[0]);

        //print_pre($serieID[0]['SerieID']);die;
        $postEscola = array();
        if (!empty($escolas)) {

            foreach ($escolas as $escola) {
                $explodeEscola = explode('/', $escola);
                $arrayEscola[] = array(
                    'EscolaID' => $explodeEscola[0],
                    'DescricaoEscola' => $explodeEscola[1]);
                $postEscola[] = $explodeEscola[0];

            }
        }
        $fields['UsuarioAlt'] = $this->session->userdata('pessoaid');
        $fields['DtAlt'] = date('Y-m-d H:i:s');

        //print_pre($simpleDBEscolas);die;
        if ($edit == 1) {
            $escolasVinculadas = $this->cadastro->getEscolasVinculadas($disciplina[0]);
            $countEscolas = count($escolasVinculadas);

            if (!empty($escolas)) {
                //ativa ou inativa registros existentes
                for ($x = 0; $x < $countEscolas; $x++) {
                    $itemName = '';
                    $escolasVerificadas[] = $escolasVinculadas[$x]['EscolaID'];
                    //print($escolasVinculadas[$x]['EscolaID'] . '<br>');
                    if (in_array($escolasVinculadas[$x]['EscolaID'], $postEscola) && $escolasVinculadas[$x]['Situacao'] == 'A') {
                        $resultado = 1;
                    } else if (in_array($escolasVinculadas[$x]['EscolaID'], $postEscola) && $escolasVinculadas[$x]['Situacao'] == 'I') {
                        $itemName = $escolasVinculadas[$x]['itemName'];
                        $fields['Situacao'] = 'A';
                        $resultado = $this->cadastro->salvaDados('D034_Ava_Sae_DisciplinasExclusivas', $itemName, $fields, TRUE);
                    } else if (!in_array($escolasVinculadas[$x]['EscolaID'], $postEscola) && $escolasVinculadas[$x]['Situacao'] == 'A') {
                        $itemName = $escolasVinculadas[$x]['itemName'];

                        $fields['Situacao'] = 'I';
                        $resultado = $this->cadastro->salvaDados('D034_Ava_Sae_DisciplinasExclusivas', $itemName, $fields, TRUE);
                    }
                }
                for ($i = 0 ; $i < count($arrayEscola); $i++) {
                    $fields['SerieID'] = $serieID[0]['SerieID'];
                    $fields['DisciplinaID'] = $disciplina[0];
                    $fields['Descricao'] = $disciplina[1];
                    $fields['Situacao'] = 'A';
                    $fields['UsuarioCad'] = $this->session->userdata('pessoaid');
                    $fields['DtCad'] = date('Y-m-d H:i:s');
                    $fields['ClassificacaoID'] = $serieID[0]['ClassificacaoID'];
                    if (!in_array($arrayEscola[$i]['EscolaID'], $escolasVerificadas)) {
                        $itemName = $this->iesdeuuid->getIdRandom();
                        $fields['EscolaID'] = $arrayEscola[$i]['EscolaID'];
                        $resultado = $this->cadastro->salvaDados2('D034_Ava_Sae_DisciplinasExclusivas', $itemName, $fields, TRUE);
                    }
                }
            } else {
                //print_pre($escolasVinculadas);die;
                foreach ($escolasVinculadas as $key) {
                    $fields['Situacao'] = 'I';
                    $resultado = $this->cadastro->salvaDados('D034_Ava_Sae_DisciplinasExclusivas', $itemName, $fields, TRUE);
                }
            }
            for ($i = 0 ; $i < count($arrayEscola); $i++) {
                $fields['SerieID'] = $serieID[0]['SerieID'];
                $fields['DisciplinaID'] = $disciplina[0];
                $fields['Descricao'] = $disciplina[1];
                $fields['Situacao'] = 'A';
                $fields['UsuarioCad'] = $this->session->userdata('pessoaid');
                $fields['DtCad'] = date('Y-m-d H:i:s');
                $fields['ClassificacaoID'] = $serieID[0]['ClassificacaoID'];
                if (!in_array($arrayEscola[$i]['EscolaID'], $escolasVerificadas)) {
                    $itemName = $this->iesdeuuid->getIdRandom();
                    $fields['EscolaID'] = $arrayEscola[$i]['EscolaID'];

                    $resultado = $this->cadastro->salvaDados('D034_Ava_Sae_DisciplinasExclusivas', $itemName, $fields, TRUE);
                }
            }
        } else {
            //grava um novo registro para cada nova turma e disciplina escolhida
            $fields['SerieID'] = $serieID[0]['SerieID'];
            $fields['DisciplinaID'] = $disciplina[0];
            $fields['Descricao'] = $disciplina[1];
            $fields['Situacao'] = 'A';
            $fields['UsuarioCad'] = $this->session->userdata('pessoaid');
            $fields['DtCad'] = date('Y-m-d H:i:s');
            $fields['ClassificacaoID'] = $serieID[0]['ClassificacaoID'];
            for ($i = 0; $i < count($arrayEscola); $i++) {
                $itemName = $this->iesdeuuid->getIdRandom();
                $fields['EscolaID'] = $arrayEscola[$i]['EscolaID'];

                $resultado = $this->cadastro->salvaDados('D034_Ava_Sae_DisciplinasExclusivas', $itemName, $fields, TRUE);
            }
        }
        print_r($resultado);
        die;
    }


    function montaComboAlunos($escolaid = false, $personId = false){
        if (!$escolaid) {
            $this->layout = '';
            $escolaid = $this->input->post('escolaid', true);
        }
        $vinculados = array();

        if ($personId) {
            $filhos = SaeDigital::make(AlunosResponsavelNextAva::class)->handle($personId);
            if (!empty($filhos)) {
                foreach ($filhos as $key) {
                    $vinculados[] = $key->id.'/'.$key->school_id;
                }
            }
        }

        $dadosEscola = SaeDigital::make(BuscarDadosEscolaEspecificaNextAva::class)->handle($escolaid);
        $alunos = $dadosEscola->students;

        foreach ($alunos as $key) {
            if($key->active){
                $arrayAlunos[$key->person_id.'/'.$escolaid] = $key->full_name;
            }
        }

        //Caso não existam alunos, a variavel é preenchida com null para não apresentar erro na tela
        if(empty($arrayAlunos)) $arrayAlunos = null;

        $extra = 'id="inputAluno" data-placeholder="Selecione alunos"';
        $combo = form_multiselect('inputAluno', $arrayAlunos, $vinculados, $extra);

        if ($this->input->post('escolaid')) {
            print_r(json_encode($combo));
            die();
        } else {
            return $combo;
        }
    }

    function comboLimite()
    {
        // if($this->session->userdata('perfil') != 268 ||
        //     $this->session->userdata('perfil') != 269)
        // {
        //     Redirect('/');
        // }

        $escolaid = $this->input->post('escolaid', true);
        $itemName = $this->input->post('itemName', true);
        $livrodigital = $this->cadastro->getAcessoLD($escolaid);
        //$limita = $this->cadastro->getLimiteUsuario($itemName);
        if ($livrodigital) {
            $return['limite'] = '<label class="col-md-3 control-label" >Limitar dispositivos</label>
                                    <div class="col-md-3">
                                        <select class="form-control" id="inputLimite" >
                                            <option value="S">Sim</option>
                                            <option value="N">N&atilde;o</option>
                                        </select>
                                    </div>';
        } else {
            $return['limite'] = false;
        }
        print_r(json_encode($return));
        die;

    }

    function AlteracaoSenha()
    {
        $this->cssMinify[] = 'jquery-ui';
        $this->cssMinify[] = 'jquery.dataTables_themeroller';
        $this->cssMinify[] = 'glyphicon';

        $this->css[] = $this->minify->getCSS('cadastro_escola_lista.min', $this->cssMinify, ENVIRONMENT);

        $dados['dados'] = montaMenu($this->session->userdata('perfil'));
        $this->menu_vertical = $this->load->view('view_menu', $dados, true);

        $this->load->view('cadastro/alterarSenha');
    }


    function SalvarNovaSenha()
    {
        $this->layout = '';

        $post = $this->input->post(NULL, TRUE);
        extract($post);

        if ($login && $senha)
        {
            $fields['Login'] = trim($login);
            $fields['Senha'] = md5($senha);
        }

        $dados = $this->cadastro->verificaLogin($fields['Login']);

        if($dados)
        {
            $itemName = $dados[0]['itemName'];
            $resultado = $this->cadastro->salvaDados('D019_Ava_Sae', $itemName, $fields, FALSE);

            if($resultado)
            {
                $resultado = "Senha alterada com sucesso!";
            }
        }
        else
        {
            $resultado = "";
        }

        print($resultado);
        die;
    }

    function ExportarAlunosImportados()
    {
        $this->layout = '';
        $tipo_exportacao = $this->input->post('tipo_exportacao', true);
        $idTurma = $this->input->post('idTurma');

        if (!(count($idTurma) > 0)) {
            throw new NotFoundException('Turma informada não esta cadastrada ou não atende a vigência atual.');
        }

        $logins = SaeDigital::make(BuscarLoginsAlunosResponsaveisPorTurmaNextAva::class)->handle([$idTurma]);

        if($tipo_exportacao === 'xls'){
            $this->exportaAlunosXLS($logins, $idTurma);
        } else {
            $this->exportaAlunosCSV($logins, $idTurma);
        }

    }

    function exportaAlunosXLS($alunosImportados, $turmaid){
            $turma = null;

            $objPHPExcel = $this->phpexcel;
            // Define as propriedades do documento
            $objPHPExcel->getProperties()->setCreator("SAE Digital")->setLastModifiedBy("SAE Digital");
            $objPHPExcel->getProperties()->setCreator("SAE Digital")->setTitle("Cadastro de Alunos");
            $objPHPExcel->getProperties()->setCreator("SAE Digital")->setSubject("Cadastro de Alunos");
            $objPHPExcel->getProperties()->setCreator("SAE Digital")->setDescription("Cadastro de Alunos");
            $objPHPExcel->getProperties()->setCreator("SAE Digital")->setKeywords("Exportação Aluno");
            $objPHPExcel->getProperties()->setCreator("SAE Digital")->setCategory("Exportação");
            // Insere conteúdo no arquivo

            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'Nome Aluno');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B1', 'Login Aluno');
            // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', 'Senha Aluno');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', 'Responsável');
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D1', 'Login Responsável');
            $count_foreach = 2;
            foreach($alunosImportados as $aluno){
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$count_foreach, ($aluno->student_name ? $aluno->student_name : ''));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$count_foreach, ($aluno->student_login ? $aluno->student_login : ''));
                // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$count_foreach, $aluno['senhaAluno']);
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$count_foreach, ($aluno->responsible_name ? $aluno->responsible_name : ''));
                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$count_foreach, ($aluno->responsible_login ? $aluno->responsible_login : ''));
                $count_foreach ++;
            }

            // $turma_inf = $this->cadastro->buscaInformacaoTurmaExportar($turmaid);
            $turma_inf = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($turmaid);

            // Miscellaneous glyphs, UTF-8
            // Renomeia a worksheet
            $objPHPExcel->getActiveSheet()->setTitle('Exportação');
            // Define qual a worksheet estará ativa ao abrir o arquivo
            $objPHPExcel->setActiveSheetIndex(0);
            // Salva o arquivo no formato do Excel 2007 (.xlsx)
            // We'll be outputting an excel file
            header('Content-type: application/vnd.ms-excel');

            // It will be called file.xls
            $filename = $turma_inf[0]->schoolName."_".$turma_inf[0]->name."_".$turma_inf[0]->year;

            header('Content-Disposition: attachment; filename="'.$filename.'.xls"');
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
            $objWriter->save('php://output');
    }

    function exportaAlunosCSV($alunosImportados, $turmaid){

        $turma = null;
        $objPHPExcel = $this->phpexcel;
        // Insere conteúdo no arquivo

        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'Nome Aluno');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B1', 'Login Aluno');
        // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', 'Senha Aluno');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', 'Responsável');
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D1', 'Login Responsável');
        $count_foreach = 2;

        foreach($alunosImportados as $aluno){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$count_foreach, ($aluno->student_name ? $aluno->student_name : ''));
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$count_foreach, ($aluno->student_login ? $aluno->student_login : ''));
            // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$count_foreach, $aluno['senhaAluno']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$count_foreach, ($aluno->responsible_name ? $aluno->responsible_name : ''));
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$count_foreach, ($aluno->responsible_login ? $aluno->responsible_login : ''));

            $count_foreach ++;
        }


        // Miscellaneous glyphs, UTF-8
        // Renomeia a worksheet
        $turma_inf = SaeDigital::make(BuscaDadosTurmaNextAva::class)->handle($turmaid);

        $filename = $turma_inf[0]->schoolName."_".$turma_inf[0]->name."_".$turma_inf[0]->year;

        $objPHPExcel->getActiveSheet()->setTitle('Simple');
        // Define qual a worksheet estará ativa ao abrir o arquivo
        $objPHPExcel->setActiveSheetIndex(0);
        // Salva o arquivo no formato do Excel 2007 (.xlsx)
        // We'll be outputting an excel file
        header('Content-type: text/csv');
        header('Content-Disposition: attachment; filename="'.$filename.'.csv"');
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV');
        $objWriter->setDelimiter(";");
        $objWriter->setEnclosure(null);
        $objWriter->save('php://output');
    }

    public function cadastrarProvaIndex()
    {
        try {

            $this->allowProfile(Perfil::ADMIN);

            $this->js[] = 'chosen.jquery.min';
            $this->js[] = 'cadastrar-prova';
            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);

            $data = array();

            $data['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $data, true);

            $escolaridades = $this->cadastro->getScholarity();
            $escolaridades = array_reduce($escolaridades, function ($result, $item) {
                $result[$item['id']] = $item['nome'];
                return $result;
            }, array());
            $data["escolaridadesDropdown"] = form_dropdown('escolaridades', $escolaridades, '1', 'id="escolaridades"');

            $limit_per_page = 20;
            $start_index = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
            $total_records = $this->cadastro->getTestsTotal();

            if ($total_records > 0)
            {
                $data["results"] = $this->cadastro->getCurrentPageTests($limit_per_page, $start_index);

                $config['base_url'] = base_url() . 'cadastro/cadastrarProvaIndex';
                $config['total_rows'] = $total_records;
                $config['per_page'] = $limit_per_page;
                $config["uri_segment"] = 3;

                $this->pagination->initialize($config);

                $data["links"] = $this->pagination->create_links();
            }

            $this->load->view('cadastro/cadastrarProva', $data);

        } catch (Exception $e) {

            show_404();
        }
    }

    public function cadastrarProva ()
    {
        try {

            $this->allowProfile(Perfil::ADMIN);

            $post = $this->input->post();

            if (!$post['nome'] OR !$post['escolaridade']) {
                throw new \InvalidArgumentException("Você precisa preencher todos os campos", 400);
            }

            $post = $this->input->post();

            $newTest = $this->cadastro->createTest(
                $post['nome'],
                $post['escolaridade']
            );

            $response = [
                "success" => true,
                "message" => "Prova criada com sucesso!",
                "icon" => "success",
                "nova_prova" => $newTest
            ];

            return $this->responseJson($response, 200);

        } catch (\InvalidArgumentException $e) {

            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ];

            return $this->responseJson($response, $e->getCode());

        } catch (Exception $e) {

            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ];

            return $this->responseJson($response, $e->getCode());
        }

    }

    public function atualizaSituacaoProva()
    {
        try {
            $this->allowProfile(Perfil::ADMIN);

            $post = $this->input->post();

            $situacao = 'desativada';

            if ($post['situacao']) {
                $situacao = 'ativada';
            }

            $this->cadastro->atualizaSituacaoProva(
                $post['prova_id'],
                $post['situacao']
            );

            $response = [
                "success" => true,
                "message" => "Prova {$situacao} com sucesso!",
                "icon" => "success"
            ];

            return $this->responseJson($response, 200);

        } catch (Exception $e) {
            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ];

            return $this->responseJson($response, $e->getCode());
        }

    }

    public function consultaGruposQuestoes()
    {
        try {
            $this->allowProfile(Perfil::ADMIN);

            $post = $this->input->post();

            $data["grupos"] = $this->cadastro->getQuestionsGroups($post["provaid"]);

            $body = $this->load->view('cadastro/gruposQuestoes', $data, true);

            $response = [
                "success" => true,
                "body" => $body,
                "icon" => "success"
            ];

            return $this->responseJson($response, 200);

        } catch (Exception $e) {
            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ];

            return $this->responseJson($response, $e->getCode());
        }
    }


    public function atualizarQuestoesIndex()
    {
        try {
            $this->allowProfile(Perfil::ADMIN);

            $this->js = [];
            $this->js[] = 'jquery3.min';
            $this->js[] = 'atualizar-questoes';
            $this->js[] = 'trumbowyg';
            $this->css[] = 'trumbowyg/trumbowyg';
            $this->load->helper('url');

            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);

            $grupoId = (int) $this->uri->segment(3);

            $data = array();

            $data['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $data, true);

            $data['questoes'] = $this->questao->getGroupQuestions($grupoId);
            $data['grupoId'] = $grupoId;
            $data['questionGroup'] = true;

            $this->load->view('cadastro/atualizarQuestoes', $data);

        } catch (Exception $e) {

            show_404();
        }

    }

    private function validarEditarQuestoes($post)
    {
        collect($post['questoes'][0]['alternativas'])->map(function ($alternativa) {
            $img = !(strpos($alternativa['texto'], '<img') !== false);

            if (mb_strlen(strip_tags($alternativa['texto'])) === 0 && $img) {
                throw new InvalidArgumentException('Alternativa em branco, por favor verifique');
            }
        });

        $quantidadeAlternativas = collect($post['questoes'][0]['alternativas'])->groupBy(function ($alternativa) {
            $img = !(strpos($alternativa['texto'], '<img') !== false);
            return $img ? trim(strip_tags($alternativa['texto'])) : trim($alternativa['texto']);
        })->count();

        if ($quantidadeAlternativas < 5) {
            throw new InvalidArgumentException('Alternativas duplicadas, por favor verifique');
        }

        if (mb_strlen($post['questoes'][0]['enunciado']) === 0) {
            throw new InvalidArgumentException('Enunciado não informado, por favor verifique');
        }

        if (mb_strlen($post['questoes'][0]['alternativa_correta']) === 0) {
            throw new InvalidArgumentException('Alternativa correta não informada, por favor verifique');
        }
    }

    public function salvarQuestoes()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);
            $post = $_POST;

            $this->validarEditarQuestoes($post);

            SaeDigital::make(PDO::class)->beginTransaction();

            $idQuestao = (int) $post['questoes'][0]['questao_id'];

            $alteracaoGabarito = SaeDigital::make(ValidarAlteracaoDeGabarito::class)->handle(
                $idQuestao,
                (int) $post['questoes'][0]['alternativa_correta']
            );

            if (count($post) === 1  && $alteracaoGabarito) {
                SaeDigital::make(AlteraGabaritoQuestao::class)->handle(
                    (int)$post['questoes'][0]['questao_id'],
                    (int)$post['questoes'][0]['alternativa_correta']
                );

            }

            $this->questao->updateQuestions($post['questoes']);

            $response = [
                "success" => true,
                "title" => "Tudo certo!",
                "message" => 'Questões salvas com sucesso.',
                "icon" => "success"
            ];

            SaeDigital::make(PDO::class)->commit();

            return $this->responseJson($response, 200);
        } catch (InvalidArgumentException $e) {
            return $this->responseJson([
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ], 500);
        } catch (Exception $e) {
            SaeDigital::make(PDO::class)->rollBack();

            return $this->responseJson([
                "success" => false,
                "message" => 'Ocorreu um erro ao salvar a questão',
                "icon" => "error"
            ], $e->getCode());
        }
    }



    public function cadastrarQuestoesIndex()
    {
        try {

            $this->allowProfile(Perfil::ADMIN);

            $this->js[] = 'cadastrar-questoes';
            $this->js[] = 'chosen.jquery.min';
            $this->cssMinify[] = 'chosen';
            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);

            $data = array();

            $data['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $data, true);

            $scholarSubjects = $this->questao->getScholarSubjects();

            $data["scholarSubjects"] = form_dropdown('subjects', $scholarSubjects, '1', 'id="subjects"');

            $tests = $this->questao->getTests();

            $data["tests"] = form_dropdown('tests', $tests, '1', 'id="tests"');

            $this->load->view('cadastro/importarQuestoes', $data);

        } catch (Exception $e) {

            show_404();
        }

    }

    public function importQuestions()
    {
        try {
            $this->allowProfile(Perfil::ADMIN);

            SaeDigital::make(PDO::class)->beginTransaction();

            $post = $this->input->post();
            $file = $_FILES['media'];
            $file_parts = pathinfo($file['name']);

            if (!$post['subject_id'] OR !$post['topic_id'] OR !$post['test_id']) {
                throw new \InvalidArgumentException("Faltam alguns parâmetros.", 400);
            }

            if (!$file) {
                throw new \InvalidArgumentException("Você precisa selecionar um arquivo.", 400);
            }

            if ($file_parts['extension'] !== 'docx') {
                throw new \RuntimeException("O tipo do arquivo é inválido, utilize apenas docx.", 422);
            }

            $file = SaeDigital::make(UploadDocxService::class)->handle($file);
            $htmlFile = SaeDigital::make(Docx2Html::class)->handle($file);

            /** @var DocxQuestoesAggregate $aggregate */
            $aggregate = SaeDigital::make(Html2Object::class)->handle($htmlFile);

            SaeDigital::make(ValidateGroupQuestions::class)->handle($aggregate);

            SaeDigital::make(ImportarQuestoes::class)->handle(
                $aggregate,
                $post['test_id'],
                $post['topic_id'],
                $post['subject_id']
            );

            SaeDigital::make(PDO::class)->commit();

            $groupIds = $aggregate->getGroupOfQuestions()->map(
                function (GroupOfQuestionsEntity $groupOfQuestionsEntity) {
                    return (int) $groupOfQuestionsEntity->getId();
                }
            );

            $response = [
                "success" => true,
                "icon" => "success",
                "title" => "Questões importadas com sucesso!",
                "html" => $this->twig()->render('alert/questionsGroups.twig', ['groups' => $groupIds->toArray()])
            ];

            $statusCode = 201;

        } catch (Exception $e) {
            SaeDigital::make(PDO::class)->rollBack();

            $statusCode = ($e->getCode() > 500 OR $e->getCode() < 300 ) ? 500 : $e->getCode();

            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ];
        }

        return $this->responseJson($response, $statusCode);
    }

    public function getSubjectTopics()
    {
        try {

            $this->allowProfile(Perfil::ADMIN);

            $post = $this->input->post();

            if (!$post['subject_id']) {
                throw new \InvalidArgumentException("Alguns parâmetros estão faltando", 400);
            }

            $topics = $this->questao->getSubjectTopics($post['subject_id']);

            $response = [
                "success" => true,
                "topics" => $topics,
            ];

            return $this->responseJson($response, 200);

        } catch (\InvalidArgumentException $e) {

            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ];

            return $this->responseJson($response, $e->getCode());

        } catch (Exception $e) {

            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ];

            return $this->responseJson($response, $e->getCode());
        }

    }

    private function validarConfiguracoesSerieEscola($idEscola)
    {
        $versaoConteudoId = $this->session->userdata('versao_conteudo_id');

        $configuracoes = SaeDigital::make(BuscarConfiguracoesSeriePorEscola::class)->handle($idEscola, $versaoConteudoId);

        foreach ($configuracoes as $configuracao) {
            if (!is_null($configuracao['Serie'])) {
                continue;
            }

            $itemName = $idEscola . $configuracao['SerieID'];

            $config = SaeDigital::make(BuscarConfiguracao::class)->handle($itemName);
            if (is_null($config['EscolaID'])) {
                SaeDigital::make(RemoverConfiguracaoInvalida::class)->handle($itemName);
            }

            $data['itemName'] = $itemName;
            $data['AcessoLD'] = 'N';
            $data['DtAlt'] = date('Y-m-d H:i:s');
            $data['DtCad'] = date('Y-m-d H:i:s');
            $data['EscolaID'] = $idEscola;
            $data['ExibeMenuLD'] = 'N';
            $data['NomeEscola'] = $this->session->userdata('nome');
            $data['Serie'] = $configuracao['SerieID'];
            $data['Tipo'] = 'S';
            $data['UsuarioAlt'] = $this->session->userdata('pessoaid');
            $data['UsuarioCad'] = $this->session->userdata('pessoaid');

            $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $data['itemName'], $data, true);
        }
    }

    public function listarAlunosPorTurma()
    {
        try {
            $idTurma = $this->input->get('idTurma');
            $idEscola = $this->session->userdata('escola');
            $alunos = SaeDigital::make(BuscarAlunosPorTurma::class)->handle($idTurma, $idEscola);


            $listaAlunos = [];

            foreach ($alunos as $aluno) {
                $listaAlunos[] = [
                    'itemName' => $aluno['itemName'],
                    'nome' => trim(ucfirst(strtolower($aluno['Nome']))),
                    'acessoLD' => $aluno['acessoLD'] ? true : false
                ];
            }

            return $this->responseJson(['alunos' => $listaAlunos], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());

            return $this->responseJson([
                'message' => 'Ocorreu um problema com sua requisição, tente novamente mais tarde.'
            ], 500);
        }
    }

    public function listarTurmasPorSerie()
    {
        try {
            $idSerie = $this->input->get('idSerie');

            $turmas = SaeDigital::make(BuscarTurmasEscolaPorSerie::class)->handle(
                $this->session->userdata('escola'),
                $idSerie
            );

            $lista = [];

            foreach ($turmas as $turma) {
                $lista[] = [
                    'id' => $turma['itemName'],
                    'descricao' => $turma['Descricao']
                ];
            }

            return $this->responseJson(['turmas' => $lista], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());

            return $this->responseJson([
                'message' => 'Ocorreu um problema com sua requisição, tente novamente mais tarde'
            ], 500);
        }
    }

    public function ativarLivroDigitalIndex()
    {
        try {
            $this->js[] = 'chosen.jquery.min';
            $this->js[] = 'ativar-livro-digital';
            $this->cssMinify[] = 'chosen';
            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);
            $dados['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            if($this->session->userdata('perfil') != 268 &&
                $this->session->userdata('perfil') != 269 &&
                $this->session->userdata('perfil') != 270)
            {
                Redirect('/');
            }
            $seriesLD = [];
            $array_filtro = [
                Segmento::INFANTIL,
                Segmento::FUNDAMENTAL_I,
                Segmento::FUNDAMENTAL_II, 
                Segmento::ENSINO_MEDIO, 
                Segmento::EXTENSIVO, 
                Segmento::SEMIEXTENSIVO
            ]; 

            $this->validarConfiguracoesSerieEscola($this->session->userdata('escola'));

            $series = SaeDigital::make(BuscarSeriesNextAva::class)->handle($this->session->userdata('school')->id); 

            $configSeries = collect(SaeDigital::make(BuscarSeriesPorEscola::class)->handle(
                $this->session->userdata('school')->id
            ));

            foreach ($configSeries as $key => $v) {
                $j[] = $v['SerieID'];
                
            }

            foreach ($series as $k) {
                foreach ($k as $serie) {
           
                    if (in_array($serie->id, $j) && in_array($serie->segment, $array_filtro)) {
                        $tmpObjOld = $configSeries->where('SerieID', $serie->id)->first();
                        
                        $serie->ExibeMenuLD = "N";
                        
                        if(!empty($tmpObjOld)){
                            $serie->ExibeMenuLD = $tmpObjOld['ExibeMenuLD'];
                            $serie->configId = $tmpObjOld['id'];
                        }
                        
                        $seriesLD[] = $serie;
                    }                    
                }
            }

            $configGeral = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle(
                $this->session->userdata('escola')
            );

            $data['acessoEscolaLD'] = $configGeral['AcessoLD'];
            $data['series'] = $seriesLD;
        } catch (Exception $e) {
            print_r($e);exit;
            log_error($e->getMessage());

            $data['exception'] = 'Ops, ocorreu um problema, tente novamente mais tarde.';
        }

        $this->load->view('cadastro/ativarLivroDigital', $data);
    }

    public function ativarLivroDigital()
    {
        $post = $this->input->post();

        try {
            $escolaId = $this->session->userdata("escola");


            $this->cadastro->atualizaConfigLivroDigitalSerie(
                $post["configId"],
                $escolaId,
                (bool)$post["exibeMenuLD"]
            );

            if ((bool)$post["exibeMenuLD"]) {
                $situacao = 'ativado';
            } else {
                $situacao = 'desativado';
            }


            SaeDigital::make(AtualizarAcessoLivroDigitalPorConfigSerie::class)->handle(
                $escolaId,
                $post['configId'],
                Perfil::ALUNO,
                $post['exibeMenuLD']
            );


            $response = [
                "success" => true,
                "message" => "O livro digital foi {$situacao} para esta série.",
                "icon" => "success"
            ];

            $this->responseJson($response, 200);

        } catch (Exception $e) {

            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ];

            $this->responseJson($response, 500);
        }

    }

    public function ativarLivroDigitalEscola()
    {

        $post = $this->input->post();

        try {

            $escolaId = $this->session->userdata("escola");

            if ( (bool) $post["acessoLd"] ) {

                $situacao = 'ativado';
                $this->cadastro->atualizaConfigLivroDigitalEscola(
                    $escolaId,
                    (bool) $post["acessoLd"]
                );

            } else {

                $situacao = 'desativado';
                $this->cadastro->atualizaConfigLivroDigitalEscola(
                    $escolaId,
                    (bool) $post["acessoLd"]
                );

            }

            $response = [
                "success" => true,
                "message" => "O livro digital foi {$situacao}.",
                "icon" => "success"
            ];

            $this->responseJson($response, 200);

        } catch (Exception $e) {

            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "icon" => "error"
            ];

            $this->responseJson($response, 500);
        }

    }

    public function ativarLivroDigitalAluno()
    {
        try {
            $idAluno = $this->input->post('idAluno');
            $acessoLD = $this->input->post('acessoLD') === 'true' ? 1 : 0;

            $status = SaeDigital::make(AtualizarAcessoLivroDigitalUsuario::class)->handle(
                $idAluno, $acessoLD, Perfil::ALUNO
            );

            return $this->responseJson(['status' => $status], 200);
        } catch (Exception $e) {
            log_error($e->getMessage());

            return $this->responseJson([
                'message' => 'Ocorreu um problema e não foi possível atualizar o acesso'
            ], 500);
        }
    }

    public function listarOrganizacoes() {

        $client = $this->tickets->getClient();
        $organizations = [];
        $page = 1;

        while ($client->organizations()->findAll(["page" => $page, "per_page" => 400])->organizations) {

            $organizationsPage = $client->organizations()->findAll(
                [
                    "page" => $page,
                    "per_page" => 400
                ]
            )->organizations;

            foreach ($organizationsPage as $organization) {
                array_push($organizations, $organization);
            }

            $page++;
        }

        $this->makeOrganizationsReport($organizations, "xls");

    }

    private function makeOrganizationsReport($organizations, $formato) {

        $objPHPExcel = $this->phpexcel;

        $this->layout = false;
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setLastModifiedBy("SAE Digital");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setTitle("Relatório de organizações Zendesk");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setSubject("Relatório de organizações Zendesk");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setDescription("Relatório de organizações Zendesk");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setKeywords("Relatório organizações Zendesk");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setCategory("Relatório");



        if($organizations){

            $keys = array_keys(get_object_vars($organizations[0]->organization_fields));

            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'nome_organizacao');
            $objPHPExcel->setActiveSheetIndex(0)->fromArray($keys, null, 'B1');
            $count_lines = 2;

            foreach($organizations as $organization){

                $objPHPExcel->setActiveSheetIndex(0)->setCellValue(
                    "A{$count_lines}",
                    $organization->name
                );

                $row = get_object_vars($organization->organization_fields);
                $objPHPExcel->setActiveSheetIndex(0)->fromArray($row, null, "B{$count_lines}");
                $count_lines++;

            }

        }

        $data_geracao_relatorio = date("d-m-Y-H-i");
        $objPHPExcel->getActiveSheet()->setTitle('Relatório Zendesk');
        $objPHPExcel->setActiveSheetIndex(0);
        $filename = "{$data_geracao_relatorio}_relatorio_zd.{$formato}";
        header("Content-Disposition: attachment; filename='{$filename}'");

        if ($formato === "csv") {
            header('Content-type: text/csv');
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV');
        } else if ($formato === "xls" ) {
            header('Content-type: application/vnd.ms-excel');
            $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        }

        $objWriter->save('php://output');

    }

    public function migrarExportarTurmaIndex()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::ESCOLA, Perfil::DIRETOR, Perfil::COORDENADOR]);

            $this->js[] = 'migrar-exportar-turma';
            $this->js[] = 'chosen.jquery.min';

            $this->cssMinify[] = 'chosen';
            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);

            $dados['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            $data['vigencias'] = [Date('Y') - 1, Date('Y'), Date('Y') + 1, Date('Y') + 2];

            $data['turmasEscola'] = SaeDigital::make(BuscarTurmasNextAva::class)->get($this->session->userdata('school')->id);
            
            $data['turmasEscolaDestino'] =SaeDigital::make(BuscarTurmasNextAva::class)->get($this->session->userdata('school')->id, Date('Y'));

            $data['seriesDisponiveis'] = $this->cadastro->getSerie();

            $data['categoriasDisponiveis'] = $this->cadastro->getCategoriaEscola($this->session->userdata('escola'));

            $this->load->view('cadastro/migrarExportarTurma', $data);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function buscaAlunosTurma()
    {
        $this->layout = "";
        header('Content-Type: application/json');

        $post = $this->input->post();

        if (!$post["id_turma"]) {
            $response = array(
                "success" => False,
                "message" => "Nenhuma turma foi selecionada.",
                "status_icon" => "error",
            );

            $this->output->set_status_header(400);

            exit(json_encode($response));
        }

        try {

            $alunosTurma = SaeDigital::make(ObterUsuariosPorTurmaNextAva::class)->handle($post["id_turma"]);

            $arrayAlunos = [];

            foreach($alunosTurma as $aluno) {
                array_push($arrayAlunos, array(
                    'itemName' => $aluno->person_id,
                    'Nome'     => $aluno->name,
                    'Login'    => $aluno->login
                ));
            }
            
            $response = [
                "success" => True,
                "status_icon" => "success",
                "students" => $arrayAlunos,
            ];
            $this->output->set_status_header(200);

            exit(json_encode($response));

        } catch (Exception $e) {

            $response = [
                "success" => False,
                "message" => $e->getMessage(),
                "status_icon" => "error",
            ];

            $this->output->set_status_header(500);

            exit(json_encode($response));
        }

    }

    public function exportarTurma()
    {

        $this->layout = "";
        header('Content-Type: application/json');
        $post = $this->input->post();

        if (
            !$post["students_to_migrate"] OR
            !$post["class"] OR
            !$post["new_class_name"] OR
            !$post["new_class_category"] OR
            !$post["new_class_serie"] OR
            !$post["new_class_validity"]
        ) {

            $response = array(
                "success" => False,
                "message" => "Por favor, preencha todos os campos.",
                "status_icon" => "error",
            );
            $this->output->set_status_header(400);

            exit(json_encode($response));
        }


        try {

            $this->cadastro->getAvaMySQL()->trans_begin();

            $novaTurma = $this->cadastro->criaNovaTurma(
                $post["class"],
                $post["new_class_name"],
                $post["new_class_category"],
                $post["new_class_serie"],
                $post["new_class_validity"]
            );

            $this->cadastro->inativaTurmaAntiga($post["class"]);

            $alunosMigrados = $this->cadastro->migraAlunos($post["students_to_migrate"], $novaTurma);

            if ($this->cadastro->getAvaMySQL()->trans_status() === FALSE) {

                $this->cadastro->getAvaMySQL()->trans_rollback();

                $response = [
                    "success" => True,
                    "message" => "Algo deu errado na exportação... Mas não se preocupe, basta tentar novamente mais tarde",
                    "title" => "Ops...",
                    "status_icon" => "error",
                ];

                $this->output->set_status_header(500);

            } else {

                $this->cadastro->getAvaMySQL()->trans_commit();

                $response = [
                    "success" => True,
                    "message" => "A exportação da turma foi realizada com sucesso!",
                    "title" => "Tudo pronto!",
                    "status_icon" => "success",
                ];

                $this->output->set_status_header(200);

            }

            exit(json_encode($response));

        } catch (Exception $e) {

            $this->cadastro->getAvaMySQL()->trans_rollback();

            $response = [
                "success" => False,
                "message" => $e->getMessage(),
                "status_icon" => "error",
            ];

            $this->output->set_status_header(500);

            exit(json_encode($response));
        }

    }

    public function inativarAlunos()
    {
        try {
            if (!$this->input->post('estudantes') || count($this->input->post('estudantes')) === 0) {
                throw new \InvalidArgumentException("Não foram selecionados alunos para inativação.", 400);
            }

            $usuarioAlt = $this->session->userdata('pessoaid');
            $ids = $this->input->post('estudantes');

            if (SaeDigital::make(InativarUsuariosNextAVA::class)->handle($ids)) {
                $response = [
                    "success" => true,
                    "message" => "A inativação do(s) aluno(s) foi realizada com sucesso!",
                    "title" => "Tudo pronto!",
                    "status_icon" => "success",
                ];
                return $this->responseJson($response, 200);
            }

            $response = [
                "success" => false,
                "message" => "Ocorreu um problema com a inativação do(s) aluno(s)!",
                "title" => "Atenção!",
                "status_icon" => "warning",
            ];

            return $this->responseJson($response, 200);
        } catch (InvalidArgumentException $e) {
            return $this->responseJson([
                "success" => false,
                "message" => $e->getMessage(),
                "title" => "Atenção!",
                "status_icon" => "error",
            ], 200);
        } catch (Exception $e) {
            return $this->responseJson([
                "success" => false,
                "message" => "Ocorreu um problema com a inativação do(s) aluno(s)!",
                "title" => "Atenção!",
                "status_icon" => "error",
            ], 200);
        }
    }

    public function migrarAlunos()
    {
        try {

            $post = $this->input->post();

            if (!$post["students_to_migrate"] OR !$post["to_class"] OR !$post["from_class"]) {
                throw new \InvalidArgumentException("Você precisa preencher todos os campos.", 400);
            }


            if ($post["to_class"] === $post["from_class"]) {
                throw new Exception("Você não pode migrar os alunos para a mesma turma.", 400);
            }

            $result = SaeDigital::make(MigrarAlunosNextAVA::class)->handle($post["students_to_migrate"], $post["from_class"], $post["to_class"]);

            if ($result === FALSE) {
                throw new Exception("Algo deu errado na migração, tente novamente mais tarde", 500);
            }

            $response = [
                "success" => True,
                "message" => "A migração do(s) aluno(s) foi realizada com sucesso!",
                "title" => "Tudo pronto!",
                "status_icon" => "success",
            ];

            return $this->responseJson($response, 200);

        } catch (\InvalidArgumentException $e) {

            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "status_icon" => "error"
            ];

            return $this->responseJson($response, $e->getCode());

        } catch (Exception $e) {
            $response = [
                "success" => false,
                "message" => $e->getMessage(),
                "status_icon" => "error"
            ];

            return $this->responseJson($response, $e->getCode());
        }

    }

	public function editarQuestaoIndex()
    {
        try {

            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);

            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);
            $dados['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            $this->js[] = 'editar-questao';

            $this->load->view('cadastro/editarQuestaoIndex', []);

        } catch (Exception $e) {

            show_error(
                $e->getMessage(),
                $e->getCode(),
                $heading = 'An Error Was Encountered'
            );
        }
    }

    public function encurtador()
    {
        try {

            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);

            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);
            $dados['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            $this->js[] = 'encurtador';

            $this->load->view('cadastro/encurtador', []);

        } catch (Exception $e) {

            show_error(
                $e->getMessage(),
                $e->getCode(),
                $heading = 'An Error Was Encountered'
            );
        }
    }
    
    public function questao()
    {
        try {

            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);

            $this->js = [];
            $this->js[] = 'jquery3.min';
            $this->js[] = 'atualizar-questoes';
            $this->js[] = 'trumbowyg';
            $this->css[] = 'trumbowyg/trumbowyg';
            $this->load->helper('url');

            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);
            $dados['dados'] = montaMenu($this->session->userdata('perfil'));
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            $questionId = (int) $this->uri->segment(3);

            $data['questoes'] = $this->questao->getQuestion($questionId);

            if (!$data['questoes']) {
                show_404();
            }

            $data['groupId'] = $questionId;

            $data['questionGroup'] = false;

            $this->load->view('cadastro/atualizarQuestoes', $data);

        } catch (Exception $e) {

            show_error(
                $e->getMessage(),
                $e->getCode(),
                $heading = 'An Error Was Encountered'
            );
        }
    }

    public function buscarTurmasEscolaVigencia()
    {
        try {
            $itemNameEscola = $this->session->userdata('school')->id;
            $vigencia = $this->input->get('vigencia');

            $turmas = SaeDigital::make(BuscarTurmasNextAva::class)->get($itemNameEscola, (int) $vigencia);

            $listaTurmas = [];
            foreach ($turmas as $turma) {
                $listaTurmas[] = [
                    'itemName' => $turma->id,
                    'descricao' => $turma->name,
                    'migrada' => null,
                    'descricaoSerie' => $turma->grade,
                    'vigencia' => $turma->year
                ];
            }

            $response['listaTurmas'] = $listaTurmas;


            return $this->responseJson($response, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());

            return $this->responseJson([
                'message' => 'Ocorreu um problema com sua requisição, por favor tente novamente'
            ], 500);
        }
    }

    private function removeTags($string)
    {
        $string = str_replace(['<p>', '</p>'], '', $string);

        return $string;
    }

    public function listarEscolas()
    {
        $this->layout = false;
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $listaEscolas = SaeDigital::make(ListarEscolas::class)->handle();

            $response = [];
            foreach ($listaEscolas as $escola) {
                $response[] = [
                    'text' => ucwords(strtolower($escola['nome'])),
                    'id' => $escola['itemName']
                ];
            }

            return $this->responseJson($response, 200);
        } catch (Exception $e) {
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao carregar lista de escolas!'
            ], 400);
        }
    }

    public function buscarConfiguracoesEscola()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::ESCOLA, Perfil::DIRETOR]);

            $idEscola = $this->input->get('idEscola');

            $configuracaoGeral = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle($idEscola);
            $configuracaoSerie = SaeDigital::make(BuscarConfiguracaoSeriesPorEscola::class)->handle($idEscola);

            $response['configuracaoGeral'] = [
                'liberaAlteracaoSenha' => $configuracaoGeral['SenhaAluno'],
                'liberaAgendamentoProfessor' => $configuracaoGeral['AgendaProfessor'],
                'liberaAgendamentoCoordenador' => $configuracaoGeral['AgendaCoordenador'],
                'liberaVisualizacaoQuestoesProfessor' => $configuracaoGeral['QuestaoProfessor'],
                'liberaVisualizacaoQuestoesCoordenador' => $configuracaoGeral['QuestaoCoordenador'],
                'notificacaoResponsaveis' => $configuracaoGeral['NotificacaoResponsavel'],
                'notificarResponsavelPosPrazo' => $configuracaoGeral['NotiRespTarefaRealizada'],
                'notificacaoAlunos' => $configuracaoGeral['NotificacaoAluno'],
                'liberaResposta' => $configuracaoGeral['RespostaFinalAgendamentoAluno'],
                'liberaMediaTurma' => $configuracaoGeral['MediaTurmaRelatorio'],
                'agendamentoLote' => $configuracaoGeral['AgendamentoDisciplinasLote'],
                'porcentagem' => $configuracaoGeral['Porcentagem']
            ];

            foreach ($configuracaoSerie as $key => $config) {
                if (in_array($config['segmentoSerie'], [Segmento::INFANTIL, Segmento::DEMONSTRATIVO])
                    || in_array($config['SerieID'], [1, 2, 3, 12])) {
                    unset($configuracaoSerie[$key]);
                }
            }

            $response['configuracaoSerie'] = $configuracaoSerie;

            return $this->responseJson($response, 200);
        } catch (Exception $e) {
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao carregar lista de escolas!'
            ], 400);
        }
    }

    public function salvarConfiguracoesEscola()
    {
        $this->layout = false;
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::ESCOLA, Perfil::DIRETOR]);

            $idEscola = $this->input->post('idEscola');
            $configuracoesGerais = [
                'SenhaAluno' => $this->input->post('liberaAlteracaoSenha'),
                'AgendaProfessor' => $this->input->post('liberaAgendamentoProfessor'),
                'AgendaCoordenador' => $this->input->post('liberaAgendamentoCoordenador'),
                'QuestaoProfessor' => $this->input->post('liberaVisualizacaoQuestoesProfessor'),
                'QuestaoCoordenador' => $this->input->post('liberaVisualizacaoQuestoesCoordenador'),
                'NotificacaoAluno' => $this->input->post('notificacaoAlunos'),
                'RespostaFinalAgendamentoAluno' => $this->input->post('liberaResposta'),
                'MediaTurmaRelatorio' => $this->input->post('liberaMediaTurma'),
                'AgendamentoDisciplinasLote' => $this->input->post('agendamentoLote'),
                'NotificacaoResponsavel' => $this->input->post('notificacaoResponsaveis'),
                'NotiRespTarefaRealizada' => $this->input->post('notificarResponsavelPosPrazo'),
                'Porcentagem' => $this->input->post('porcentagem'),
                'EscolaID' => $idEscola,
                'Tipo' => 'G',
            ];

            $configuracaoSeries = json_decode($this->input->post('configuracoesSerie'));

            $temConfiguracaoGeral = SaeDigital::make(BuscarConfiguracaoGeralEscola::class)->handle($idEscola);

            if ( count($temConfiguracaoGeral) > 1 ) {
                $resultado = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $idEscola, $configuracoesGerais, FALSE);
            } else {
                $resultado = $this->cadastro->salvaDados('D023_Ava_Sae_Configuracoes', $idEscola, $configuracoesGerais, TRUE);
            }

            foreach ($configuracaoSeries->configuracoesSerie as $configuracao) {
                $data = ['Percentual' => $configuracao->metaVideo, 'Meta' => $configuracao->metaQuestoes];
                $condicoes = ['EscolaID' => $idEscola, 'Serie' => $configuracao->SerieID, 'Tipo' => 'S'];
                SaeDigital::make(AtualizarConfiguracaoSerie::class)->handle($data, $condicoes);
            }

            return $this->responseJson([
                'message' => 'Configurações atualizadas!'
            ], 200);
        } catch (Exception $e) {
            return $this->responseJson([
                'message' => 'Ocorreu um problema ao salvar as configurações, por favor tente novamente!'
            ], 400);
        }
    }

    public function cadastrarImagem(){

        try {

            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);
            $data = [];
            if (isset($_FILES['imagem'])) {
                if (in_array($this->getExtension($_FILES['imagem']['name']), ['jpeg', 'jpg', 'png', 'gif'])) {
                    $data['funcNum'] = $this->input->get('CKEditorFuncNum');
                    $fileName = 'upload_' . md5(microtime()) . '.' . $this->getExtension($_FILES['imagem']['name']);
                    try {
                        $file = SaeDigital::make(UploadImageS3::class)->handle(
                            AWS_DEFAULT_PATH_IMAGE_QUESTIONS . $fileName,
                            ',' . base64_encode(file_get_contents($_FILES['imagem']['tmp_name'])),
                            $_FILES['imagem']['type']
                        );
                        $data['imagem'] = $file->get('ObjectURL');
                    } catch (Exception $e) {
                        $data['message'] = 'Falha ao enviar arquivo: ' . $e->getMessage();
                    }

                } else {
                    $data['message'] = 'O formato do arquivo não é suportado';
                }
            }

            $data['csrf'] = [
                'name' => $this->security->get_csrf_token_name(),
                'hash' => $this->security->get_csrf_hash()
            ];

            $this->twigRender('cadastro/imagem.twig', $data);
        } catch (Exception $e) {
            show_404();
        }

        return $this;
    }

    public function gerenciarFaq()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);
            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);

            $dados['dados'] = montaMenu($this->session->userdata('perfil'));

            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            $this->load->view('faq/index.php');
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function editarFaq($id)
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);
            $this->css[] = $this->minify->getCSS('cadastro_configuracao.min', $this->cssMinify, ENVIRONMENT);
            $dados['dados'] = montaMenu($this->session->userdata('perfil'));

            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            $faq = SaeDigital::make(PegarFaqPorID::class)->handle($id);
            $faq['ativo'] = (int)$faq['ativo'] === 1 ? true : false;
            $categorias = SaeDigital::make(ListarCategorias::class)->handle();
            $categoriaFaq = SaeDigital::make(PegarCategoriasPorFaqId::class)->handle($id);


            $this->load->view('faq/editar', [
                'faq' => $faq,
                'categorias' => $categorias,
                'categoriaFaq' => $categoriaFaq]
            );
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function tokens()
    {
        try {
            $this->allowProfile(Perfil::ESCOLA);

            $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
            $perfilid = $this->session->userdata('perfil');
            $dados['dados'] = montaMenu($perfilid);
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            $this->load->view('api-auth-token/index');
        } catch (Exception $e) {

        }
    }

    public function escolaMovimento()
    {
        try {
            $this->allowProfile(Perfil::ESCOLA);

            $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
            $perfilid = $this->session->userdata('perfil');
            $dados['dados'] = montaMenu($perfilid);
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);

            $this->load->view('escola-em-movimento/index');
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function centralMarretaz()
    {
        try {
            $this->allowProfile(Perfil::ADMIN);
            $this->css[] = $this->minify->getCSS('cadastro_index.min', $this->cssMinify, ENVIRONMENT);
            $perfilid = $this->session->userdata('perfil');
            $dados['dados'] = montaMenu($perfilid);
            $this->menu_vertical = $this->load->view('view_menu', $dados, true);
            $this->load->view('cadastro/central-marretas');
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }
}
