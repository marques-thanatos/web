<?php
use Ava\App\Services\NextAVA\UsuarioNextAVA;
use Ava\App\Services\Escola\BuscarDadosEscolaNextAva;

class Student extends MY_Controller {
    public $layout = false;
    public $title = 'AVA SAE';
    public $description = 'Ambiente Virtual de Aprendizagem - AVA SAE';

    public function __construct() {
        parent::__construct();
    }


    public function index() {
        try {
          $idEscola = $this->session->userdata('school')->id;          
          
          
          if(!$idEscola){
            $data['idEscola'] = $this->input->get('schoolId');
            
            $data['alunos'] = $data['idEscola'] ? SaeDigital::make(UsuarioNextAVA::class)->listUsers(1, $data['idEscola']) : [];
            $data['escolas'] = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle();

          } else {
            $data['alunos'] = SaeDigital::make(UsuarioNextAVA::class)->listUsers(1, $idEscola);
            $data['escolas'] = [];
          }

          $this->load->view('cadastro/NextAVA/alunos', $data);
        } catch (\Exception $e) {
            log_error($e->getMessage());
        }
    }
}
