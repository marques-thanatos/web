<?php

use Ava\App\Services\Jarvis\JarvisApi;

/**
 * Class ModulesJarvis
 */
class ModulesJarvis extends MY_Controller
{
    /**
     * get modules
     */
    public function index()
    {
        try {
            $filters = $this->input->get('filters', []);
            $page = $this->input->get('page') ?: 1;
            $limit = $this->input->get('limit') ?: 500;
            $sort = $this->input->get('sort') ?: null;
            $desc = $this->input->get('desc');
            $this->allowProfile([\Ava\App\Support\Perfil::ADMIN]);
            $modules = SaeDigital::make(JarvisApi::class)->get('/modules', $filters, $page, $limit, $sort, $desc);
            $this->responseJson($modules);
        } catch (Exception $e) {
            $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }

    /**
     * @param $id
     */
    public function get($id)
    {
        try {
            $this->allowProfile([\Ava\App\Support\Perfil::ADMIN]);
            $module = SaeDigital::make(JarvisApi::class)->get('/modules', $id);
            $this->responseJson($module);
        } catch (Exception $e) {
            $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }
}
