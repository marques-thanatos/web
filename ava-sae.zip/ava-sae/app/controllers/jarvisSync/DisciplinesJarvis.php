<?php

use Ava\App\Services\Jarvis\JarvisApi;

/**
 * Class DisciplinesJarvis
 */
class DisciplinesJarvis extends MY_Controller
{

    /**
     * get disciplines
     */
    public function index()
    {
        try {
            $this->allowProfile([\Ava\App\Support\Perfil::ADMIN]);
            $modules = SaeDigital::make(JarvisApi::class)->get('/disciplines', [], 1, 500);
            return $this->responseJson($modules);
        } catch (Exception $e) {
            $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }

}
