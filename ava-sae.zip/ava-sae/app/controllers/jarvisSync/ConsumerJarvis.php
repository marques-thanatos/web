<?php

if (!defined('BASEPATH')) {
    die("No direct Script Access allowed");
}

/**
 * Class ConsumerJarvis
 */
class ConsumerJarvis extends CI_Controller
{
    /**
     * consumer moduleSync
     */
    public function moduleSync()
    {
        $this->layout = false;
        try {
            SaeDigital::make(Ava\App\Services\Enqueue\Enqueue::class)->consume(getenv('CI_ENV') . '_jarvis_module_sync',
                function ($msg) {
                    return SaeDigital::make(\Ava\App\Services\Assuntos\SyncAssunto::class)->handle($msg['module_id']);
                });

        } catch (\Exception $e) {
            echo $e->getMessage() . PHP_EOL;
        }
    }

    /**
     * consumer syncSeriesContent
     */
    public function syncSeriesContent()
    {
        $this->layout = false;
        try {
            SaeDigital::make(Ava\App\Services\Enqueue\Enqueue::class)->consume(getenv('CI_ENV') . '_platform_sync_series_content',
                function ($msg) {
                    return SaeDigital::make(Ava\App\Services\Jarvis\JarvisMigration::class)->syncSerieDiciplines($msg['serie']);
                });
        } catch (\Exception $e) {
            echo $e->getMessage() . PHP_EOL;
        }
    }
}
