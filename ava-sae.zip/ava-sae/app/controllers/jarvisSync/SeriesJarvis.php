<?php

use Ava\App\Services\Jarvis\JarvisApi;

/**
 * Class SeriesJarvis
 */
class SeriesJarvis extends MY_Controller
{
    /**
     *  get series
     */
    public function index()
    {
        try {
            $this->allowProfile([\Ava\App\Support\Perfil::ADMIN]);
            $modules = SaeDigital::make(JarvisApi::class)->get('/series', [], 1, 500);
            return $this->responseJson($modules);
        } catch (Exception $e) {
            $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }
}
