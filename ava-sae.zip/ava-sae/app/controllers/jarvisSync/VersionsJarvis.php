<?php

use Ava\App\Services\Jarvis\JarvisApi;

/**
 * Class ItemsJarvis
 */
class VersionsJarvis extends MY_Controller
{
    /**
     * @param $id
     */
    public function index()
    {
        try {
            $this->allowProfile([\Ava\App\Support\Perfil::ADMIN]);

            $versions = SaeDigital::make(JarvisApi::class)->get('/versions');
            $this->responseJson($versions);
        } catch (Exception $e) {
            $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }
}
