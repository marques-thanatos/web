<?php

use Ava\App\Services\Jarvis\JarvisApi;

/**
 * Class ItemsJarvis
 */
class ItemsJarvis extends MY_Controller
{
    /**
     * @param $id
     */
    public function index($id)
    {
        try {
            $module = SaeDigital::make(JarvisApi::class)->get('/versions');
            $this->responseJson($module);
        } catch (Exception $e) {
            $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }
}
