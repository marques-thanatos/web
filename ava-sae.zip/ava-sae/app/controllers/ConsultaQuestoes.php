<?php

//if (!defined('BASEPATH'))
//    exit('No direct script access allowed');
use Ava\App\Services\Assuntos\AssuntosPorBimestre;
use Ava\App\Services\Assuntos\DuplicarAssunto;
use Ava\App\Services\Assuntos\MoveAssuntoParaBimestre;
use Ava\App\Services\Assuntos\PegaAssuntoPeloId;
use Ava\App\Services\Assuntos\RelacionaAssuntoComBimestre;
use Ava\App\Services\Aulas\AulasPorAssunto;
use Ava\App\Services\Aulas\DuplicarAula;
use Ava\App\Services\Aulas\RelacionaAulaComAssunto;
use Ava\App\Services\Bimestres\BimestreDoAssunto;
use Ava\App\Services\Bimestres\BimestresDaDisciplina;
use Ava\App\Services\Bimestres\DuplicarBimestre;
use Ava\App\Services\Bimestres\RelacionaBimestreComDisciplina;
use Ava\App\Services\Disciplinas\CadastraDisciplina;
use Ava\App\Services\Disciplinas\CadastraDisciplinaIntegraDb;
use Ava\App\Services\Disciplinas\DisciplinasDaSerie;
use Ava\App\Services\Disciplinas\PegaDisciplinaDoAssunto;
use Ava\App\Services\Disciplinas\RelacionaDisciplinaComSerie;
use Ava\App\Services\Disciplinas\TodosAsDisciplinas;
use Ava\App\Services\Jarvis\JarvisApi;
use Ava\App\Services\Jarvis\JarvisMigration;
use Ava\App\Services\Questoes\DuplicaEstruturaQuestoes;
use Ava\App\Services\Questoes\DuplicaQuestao;
use Ava\App\Services\Questoes\EstruturaQuestoes;
use Ava\App\Services\Questoes\QuestoesDaEstrutura;
use Ava\App\Services\Series\ListasDeSeriesAtivas;
use Ava\App\Support\Perfil;
use Ava\App\Services\Enqueue\Enqueue;
use Ava\App\Services\Assuntos\CriaAssunto;

header('Content-Type: text/html; charset=utf-8');

/**
 * @property  output
 */
class ConsultaQuestoes extends MY_Controller
{
    public $js = array(
        'jquery.min',
        'bootstrap.min',
        'bootstrap-button.min',
        'messi.min',
        'jquery.maskedinput.min',
        'jquery.cookie',
        'jquery.dataTables',
        'consultaquestoes',
        'bootstrap-multiselect.min',
        'portalava_jarvis'
    );
    public $css = array('erro', 'bootstrap-multiselect.min');

    public function __construct()
    {
        try {
            parent::__construct();
            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);

            $this->load->model('cadastro_model', 'cadastro');
            $this->load->model('questao_model', 'questao');
            $this->cssMinify = array('bootstrap-new.min', 'bootstrap', '_reset', 'geral', 'messi');
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function getAvaMySQL()
    {
        if (!$this->_avaMySQL) {
            $this->_avaMySQL = $this->load->database('avaMySQL', true);
        }
        return $this->_avaMySQL;
    }

    public function getAvaMySQLQuestoes()
    {
        if (!$this->_avaMySQLQuestoes) {
            $this->_avaMySQLQuestoes = $this->load->database('avaMySQLQuestoes', true);
        }
        return $this->_avaMySQLQuestoes;
    }

    public function getGrupoAulasQuestoes($grupoAula = null, $classificacaoid = null)
    {
        $sql = "SELECT DISTINCT E358.GrupoAulaID
                FROM E093_GruposAulas AS E093
                INNER JOIN E358_EstruturaAulasQuestoes AS E358 ON E093.GrupoAulaID = E358.GrupoAulaID 
                WHERE 1=1 ";

        if ($grupoAula) {
            $sql .= " and  E093.GrupoAulaID = $grupoAula";
        }

        if ($classificacaoid != null) {
            $sql .= " and E093.classificacaoid in ($classificacaoid)";
        }

        $query = $this->getAvaMySQL()->query($sql);
        return $query->result_array();
    }

    public function getDadosAula($aulaid, $grupoaula, $pSubCat = null)
    {
        if ($pSubCat) {
            $sql = "select * FROM E358_EstruturaAulasQuestoes
                where AulaID in ($aulaid) and GrupoAulaID = " . $grupoaula . " and SubCategoriaID = " . $pSubCat;
        } else {
            $sql = "select * FROM E358_EstruturaAulasQuestoes
                where AulaID in ($aulaid) and GrupoAulaID = " . $grupoaula;
        }

        $query = $this->getAvaMySQL()->query($sql);
        return $query->result_array();
    }

    public function existeEstrutura($estruturaid, $questaoid, $pSubCat = null)
    {
        if ($pSubCat) {
            $sql = "select E358.EstruturaAulaID,E359.QuestaoID
				FROM E358_EstruturaAulasQuestoes as E358
				INNER JOIN E359_AulaQuestoes as E359 ON E358.EstruturaAulaID = E359.EstruturaAulaID
				WHERE E359.Situacao = 'A' 
				  and E359.EstruturaAulaID = $estruturaid
				  and E359.QuestaoID = $questaoid
				  and E358.SubCategoriaID = " . $pSubCat;
        } else {
            $sql = "select E358.EstruturaAulaID,E359.QuestaoID
				FROM E358_EstruturaAulasQuestoes as E358
				INNER JOIN E359_AulaQuestoes as E359 ON E358.EstruturaAulaID = E359.EstruturaAulaID
				WHERE E359.Situacao = 'A' 
				  and E359.EstruturaAulaID = $estruturaid
				  and E359.QuestaoID = $questaoid";
        }

        $query = $this->getAvaMySQL()->query($sql);
        return $query->row();
    }

    public function insertEstrutura($dados)
    {
        $result = $this->getAvaMySQL()->insert('E359_AulaQuestoes', $dados);

        return $result;
    }

    public function getDadosAulaQuestoes($questoes, $estruturaid, $tipo = '', $pSubCat = null)
    {
        if ($pSubCat) {
            $sql = "select E359.AulaQuestaoID,E358.EstruturaAulaID,E358.GrupoAulaID,E358.SubCategoriaID,E358.AulaID,
    			E359.QuestaoID,CONVERT(E358.DtCad, CHAR) as DtCad 
				FROM E358_EstruturaAulasQuestoes as E358
				INNER JOIN E359_AulaQuestoes as E359 ON E358.EstruturaAulaID = E359.EstruturaAulaID
				where E359.Situacao = 'A'
                                and E359.QuestaoID = $questoes
    				and E359.EstruturaAulaID = $estruturaid
    				and E358.SubCategoriaID = " . $pSubCat;
        } else {
            $sql = "select E359.AulaQuestaoID,E358.EstruturaAulaID,E358.GrupoAulaID,E358.SubCategoriaID,E358.AulaID,
    			E359.QuestaoID,CONVERT(E358.DtCad, CHAR) as DtCad 
				FROM E358_EstruturaAulasQuestoes as E358
				INNER JOIN E359_AulaQuestoes as E359 ON E358.EstruturaAulaID = E359.EstruturaAulaID
				where E359.Situacao = 'A'
                                and E359.QuestaoID = $questoes
    				and E359.EstruturaAulaID = $estruturaid";
        }

        $query = $this->getAvaMySQL()->query($sql);

        if ($tipo == 'Sae') // a estrutura do sae tem questões similares
        {
            return $query->result_array();
        } else {
            return $query->row();
        }
    }

    public function insereEstruturasSae2()
    {
        $pacote = $this->input->post('id', true);

        if ($this->input->post('txtaula', true)) {
            $pSubCat = $this->input->post('txtaula', true);
        } else {
            $pSubCat = false;
        }

        $this->load->model('api_model', 'api');
        echo '<h2>Iniciando importação da estrutura de questões...</h2>';
        $grupoAulas = $this->getGrupoAulasQuestoes($pacote, '10,11');


        if (!empty($grupoAulas)) {
            $erro = 0;
            foreach ($grupoAulas as $res) {
                $result = '';
                $aulas = '';
                $questoes = '';
                $qstArray = '';
                $array['curso'] = $res['GrupoAulaID'];

                $result = $this->api->ListarQuestoesSimilaridadeSae($array['curso'], $pSubCat);

                if (isset($result['success']) && $result['success'] == true) {
                    //percorre o array e salva as aulas que possuem questoes
                    foreach ($result['message']['disciplina'] as $pos) {
                        foreach ($pos['aula'] as $id => $al) {
                            $aulas .= $id . ',';
                            foreach ($al['questoes'] as $i => $qst) {

                                $cont = count($qst);

                                if ($cont > 1) {
                                    // questoes similares:
                                    foreach ($qst as $val) {
                                        $qstArray[$id][] = array('id' => $val, 'similar' => 'S', 'grupo' => $i);
                                        $questoes .= $val . ',';
                                    }
                                } else {
                                    if ($cont == 1 && $qst[0] != 0) {
                                        $qstArray[$id][] = array('id' => $qst[0], 'similar' => 'N');
                                        $questoes .= $qst[0] . ',';
                                    }
                                }
                            }
                        }
                    }

                    //retira a virgula do final da string
                    $aulas = trim($aulas, ',');

                } else {
                    echo "<br>Erro ao importar pacote " . $array['curso'];
                    continue;
                }

                $resultado = '';
                if (!empty($aulas)) {
                    $dados = $this->getDadosAula($aulas, $array['curso']);

                    if (!empty($dados)) {
                        $cont = 0;
                        $j = 0;
                        $insert = array();

                        for ($i = 0; count($dados) > $i; $i++) {
                            for ($x = 0; count($qstArray[$dados[$i]['AulaID']]) > $x; $x++) {
                                $dados[$i][$x]['QuestaoID'] = $qstArray[$dados[$i]['AulaID']][$x];

                                $insert[$j][$qstArray[$dados[$i]['AulaID']][$x]['id']] = array(
                                    'EstruturaAulaID' => $dados[$i]['EstruturaAulaID'],
                                    'QuestaoID' => $dados[$i][$x]['QuestaoID']['id'],
                                    'Situacao' => 'A',
                                    'DtCad' => date('Y-m-d H:i:s'),
                                    'DtAlt' => date('Y-m-d H:i:s'),
                                    'itemName' => $this->iesdeuuid->getIdRandom(),
                                    'Similar' => $dados[$i][$x]['QuestaoID']['similar']
                                );

                                if ($dados[$i][$x]['QuestaoID']['similar'] == 'S') {
                                    $insert[$j][$qstArray[$dados[$i]['AulaID']][$x]['id']]['GrupoSimilar'] = $dados[$i][$x]['QuestaoID']['grupo'];
                                }
                            }
                        }

                        $contq = 0;
                        foreach ($insert as $key => $item) {
                            foreach ($item as $key2 => $item2) {
                                if (!$this->VerificaSeExisteE359($item2['EstruturaAulaID'], $item2['QuestaoID'])) {
                                    $contq++;
                                    $this->insertEstrutura($item2);
                                }
                            }
                        }
                    }
                }
            }
        } else {
            print_pre('Nenhum dado a ser inserido');
            die;
        }

        echo 'Importação da estrutura realizada com sucesso!<br><br>Quantidade de questões inseridas: ' . $contq . '<br><br> Array Inserido: ';
        print_pre($insert);
        die;
    }

    public function VerificaSeExisteE359($estrutura, $questao)
    {
        $sql = "select count(*) as qtd
                from E359_AulaQuestoes e359
                where e359.EstruturaAulaID = " . $estrutura . "
                  and e359.QuestaoID = " . $questao;

        $ex = $this->getAvaMySQL()->query($sql)->result_array();

        if ($ex[0]['qtd'] > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function index()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $dados['logado'] = false;
            $this->load->view("view_consulta", $dados);

        } catch (Exception $e) {
            log_error($e->getMessage() . '--' . $this->session->userdata('pessoaid'));
            show_404();
        }
    }

    public function ValidaChave()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $chave = $_POST['chave'];
            $r001 = $_POST['r001'];

            if ($chave == "sae@085079#") {
                $_SESSION['logado_marreta'] = true;

                if ($r001 == 0) {
                    print("1");
                } else {
                    print("2");
                }

            } else {
                print("0");
            }
            die();
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function principal()
    {
        $dados['logado'] = true;
        $versoesConteudo = $this->cadastro->getContentVersions();

        $versoesConteudo = array_reduce($versoesConteudo, function ($result, $item) {
            $result[$item['id']] = $item['descricao'];
            return $result;
        }, array());

        $dados["form_versao_conteudo"] = form_dropdown('versao_conteudo', $versoesConteudo, '1',
            'id="versao_conteudo"');

        $this->load->view("view_consulta", $dados);
    }

    public function questao($prova_id, $assunto_id = null)
    {
        $sql = "SELECT a.questao_principal, 2, a.prova_nome, a.assunto_nome FROM aprovaquestoes.vw_sae_questao_agrupada a WHERE a.prova_id = " . $prova_id;
        $questoes = $this->getAvaMySQL()->query($sql)->result_array();

        echo "<table align=center>"
            . "     <tr><td style='width: 100px'>ID Grupo</td>"
            . "     <td style='width: 500px'>Segmento</td>"
            . "     <td style='width: 400px'>Assunto</td></tr>";

        $auxgrupo = 0;

        if ($questoes) {
            foreach ($questoes as $key => $row) {
                if ($auxgrupo != $row['questao_principal']) {
                  echo "<tr style='height: 2px; background-color: black;'><td></td><td></td><td></td></tr>";
                }

                echo "<tr><td>" . $row['questao_principal'] . "</td>"
                    . "<td>" . $row['prova_nome'] . "</td>"
                    . "<td>" . $row['assunto_nome'] . "</td></tr>";

                $auxgrupo = $row['questao_principal'];
            }

            echo "<tr style='height: 2px; background-color: black;'><td></td><td></td><td></td><td></td></tr>";
        }

        echo "</table>";
        die();

    }

    public function marreta()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $pGrupoAula = $this->input->post('id', true);
            $qr = Array();

            if ($this->input->post('subcat', true)) {
                $pSubCat = $this->input->post('subcat', true);

                $sql = "SELECT * FROM E358_EstruturaAulasQuestoes WHERE GrupoAulaID = " . $pGrupoAula . " AND SubCategoriaID = " . $pSubCat;
                $qr[] = $sql;
                $estrutura = $this->getAvaMySQL()->query($sql)->result_array();

                foreach ($estrutura as $item) {
                    $where2 = "EstruturaAulaID = " . $item['EstruturaAulaID'];
                    $this->getAvaMySQL()->delete("E359_AulaQuestoes", $where2);
                    $qr[] = $this->getAvaMySQL()->last_query();
                }
            } else {
                //Pega a estrutura
                $sql = "SELECT * FROM E358_EstruturaAulasQuestoes WHERE GrupoAulaID = " . $pGrupoAula;
                $qr[] = $sql;
                $estrutura = $this->getAvaMySQL()->query($sql)->result_array();

                foreach ($estrutura as $item) {
                    $where2 = "EstruturaAulaID = " . $item['EstruturaAulaID'];
                    $this->getAvaMySQL()->delete("E359_AulaQuestoes", $where2);
                    $qr[] = $this->getAvaMySQL()->last_query();
                }
            }

            echo "<span>Processo realizado com sucesso!</span><br/><br/><hr>";
            echo "<p>Log de Querys</p>";
            print_pre($qr);
            die();
        } catch (Exception $e) {
            log_error($e->getMessage() . '--' . $this->session->userdata('pessoaid'));
            echo $e->getMessage();
            die();
        }
    }

    function RelatorioUP()
    {
        $sql = "SELECT aluno.DescDisciplina
	, aluno.DescAssunto
	, aluno.NomeAluno
	, aluno.UsuarioID
	, aluno.AssuntoID
	, sum(aluno.Acertos) Acertos
	, sum(aluno.TotalQuestoesAula) TotalQuestoes
FROM (SELECT a.DescDisciplina
			, a.DescAssunto
			, a.TotalQuestoesAula
			, a.NomeAluno
			, a.UsuarioID
			, a.AssuntoID
			, a.VigenciaTurma
			, sum(CASE WHEN Tipo IN ('Q') AND respostacorreta = 'S' THEN 1 ELSE 0 END) Acertos
		FROM R001_RespostasQuestoes a
		WHERE a.EscolaID = '976de9cb2ed34e6162f720eb10d399aa'
		AND a.VigenciaTurma = '2017'
		AND a.Tipo IN ('Q')
		AND a.RespostaCorreta IS NOT NULL
		GROUP BY a.DescDisciplina
			, a.DescAssunto
			, a.NomeAluno
			, a.UsuarioID
			, a.AssuntoID
			, a.VigenciaTurma
			, a.TotalQuestoesAula

			UNION ALL

		SELECT a.DescDisciplina
			, a.DescAssunto
			, a.TotalQuestoesAula
			, a.NomeAluno
			, a.UsuarioID
			, a.AssuntoID
			, a.VigenciaTurma
			, sum(CASE WHEN Tipo IN ('R') AND respostacorreta = 'S' THEN 1 ELSE 0 END) Acertos
		FROM R001_RespostasQuestoes a
		WHERE a.EscolaID = '976de9cb2ed34e6162f720eb10d399aa'
		AND a.VigenciaTurma = '2017'
		AND a.Tipo IN ('R')
		AND a.RespostaCorreta IS NOT NULL
		GROUP BY a.DescDisciplina
			, a.DescAssunto
			, a.NomeAluno
			, a.UsuarioID
			, a.AssuntoID
			, a.VigenciaTurma
			, a.TotalQuestoesAula) aluno

GROUP BY aluno.DescDisciplina
	, aluno.DescAssunto
	, aluno.NomeAluno
	, aluno.UsuarioID
	, aluno.AssuntoID
	, aluno.VigenciaTurma";

        $resultado = $this->getAvaMySQL()->query($sql)->result();

        $html = "<table border=1>"
            . "<tr>"
            . "<td>Disciplina</td>"
            . "<td>Assunto</td>"
            . "<td>Nome</td>"
            . "<td>Acertos</td>"
            . "<td>Total de Questões</td></tr>";

        foreach ($resultado as $key => $value) {
            $html .= "<tr>";
            $html .= "<td>" . $value->DescDisciplina . "</td>";
            $html .= "<td>" . $value->DescAssunto . "</td>";
            $html .= "<td>" . $value->NomeAluno . "</td>";
            $html .= "<td>" . $value->Acertos . "</td>";
            $html .= "<td>" . $value->TotalQuestoes . "</td>";
            $html .= "</tr>";
        }

        $html .= "</table>";

        header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        header("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
        header("Cache-Control: no-cache, must-revalidate");
        header("Pragma: no-cache");
        header("Content-type: application/x-msexcel");
        header("Content-Disposition: attachment; filename=\"DadosDeAlunosAvaSae.xls\"");
        header("Content-Description: PHP Generated Data");

        echo $html;
        die();

    }

    public function RelacaoAula($pGrupoAula)
    {
        $sql = "SELECT E358.GrupoAulaID
                    , E088.Descricao AS desc_dis
                    , E089.Descricao AS desc_ass
                    , count(E359.QuestaoID) AS QtdQuestoes
                    , E068.Video
                    , E068.Duracao
                    , E0682.Tipo
                    FROM E358_EstruturaAulasQuestoes AS E358
                    left join E359_AulaQuestoes AS E359 on E358.EstruturaAulaID = E359.EstruturaAulaID
                    inner join T002_SeriesDisciplinas T002 on T002.DisciplinaID = E358.GrupoAulaID
                    inner join E090_CategoriasSubCategoriasAulas E090 on E090.SubCategoriaID = E358.SubCategoriaID
                    inner join  E089_SubCategoriasAulas E089 on E090.SubCategoriaID = E089.SubCategoriaAulaID
                    inner join E088_CategoriasAulas  E088 on E088.CategoriaAulaID = E090.CategoriaID
                    inner join E091_AulasSubCategorias E091 on E091.SubCategoriaID = E090.SubCategoriaID
                    inner join E068_Aulas E068 on E068.AulaID = E091.AulaId
                    inner join E068_Aulas E0682 on E0682.AulaID = E358.AulaID
                    inner join E094_GruposCategoriasAulas E094 on E094.CategoriaAulaID = E088.CategoriaAulaID
                    inner join E093_GruposAulas E093 on E093.GrupoAulaID = E094.GrupoAulaID

                    WHERE T002.SerieID = " . $pGrupoAula . "
                      AND E068.Tipo = 'N'
                      AND E068.Video IS NOT NULL
                      and E093.Situacao = 'A'
                      and E093.ClassificacaoID = 10
                    GROUP BY E358.GrupoAulaID
                           , E089.Descricao
                           , E358.AulaID
                           , E088.Descricao
                           , E068.Video
                           , E068.Duracao
                    ORDER BY E358.GrupoAulaID
                           , E088.Descricao
                           , E089.SubCategoriaAulaID";

        $ressql = $this->getAvaMySQL()->query($sql)->result_array();

        echo "<table border=1>"
            . "<tr style='background-color: lightgray; font-weight: bold'>"
            . "<td>ID da Disciplina</td>"
            . "<td>Disciplina</td>"
            . "<td>Assunto</td>"
            . "<td>Tipo</td>"
            . "<td>Qtd Questões</td>"
            . "<td>Vídeo</td>"
            . "<td>Duração</td></tr>";

        foreach ($ressql as $key => $value) {
            if ($value['QtdQuestoes'] != 20 && $value['QtdQuestoes'] != 15) {
                echo "<tr>"
                    . "<td>" . $value['GrupoAulaID'] . "</td>"
                    . "<td>" . $value['desc_dis'] . "</td>"
                    . "<td>" . $value['desc_ass'] . "</td>"
                    . "<td>" . $value['Tipo'] . "</td>"
                    . "<td>" . $value['QtdQuestoes'] . "</td>"
                    . "<td>" . $value['Video'] . "</td>"
                    . "<td>" . $value['Duracao'] . "</td></tr>";
            }
        }

        echo "</table><br><br>";


        echo "<table border=1>"
            . "<tr style='background-color: lightgray; font-weight: bold'>"
            . "<td>ID da Disciplina</td>"
            . "<td>Disciplina</td>"
            . "<td>Assunto</td>"
            . "<td>Tipo</td>"
            . "<td>Qtd Questões</td>"
            . "<td>Vídeo</td>"
            . "<td>Duração</td></tr>";

        foreach ($ressql as $key => $value) {
            echo "<tr>"
                . "<td>" . $value['GrupoAulaID'] . "</td>"
                . "<td>" . $value['desc_dis'] . "</td>"
                . "<td>" . $value['desc_ass'] . "</td>"
                . "<td>" . $value['Tipo'] . "</td>"
                . "<td>" . $value['QtdQuestoes'] . "</td>"
                . "<td>" . $value['Video'] . "</td>"
                . "<td>" . $value['Duracao'] . "</td></tr>";
        }

        echo "</table>";

        die();
    }

    public function InsereQRCode()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            echo "<h1 style=''>Cadastro de vídeos - QRCode</h1><hr>";
            echo "<form action='' method='POST'>";
            echo "<table><tr><td><b>Código:</b></td><td><input id='txtQrCode' type='text' size='26'/></td></tr>";
            echo "<tr><td><b>Vídeo:</b></td><td><input id='txtLink' type='text' size='150'/></td></tr></table>";
            echo "<tr><td><input id='btnInsereQrCode' type='button' value='Inserir' style='width:100px; height: 35px; font-size: 15px; font-weight: bold'/><img id='loadED' style='display:none;' src='../../../public/imagens/loading.gif' border='0' align='Absmiddle' /></td><td><input id='btnListaQRCode' type='button' value='Listar' style='width:100px; height: 35px; font-size: 15px; font-weight: bold'/></td></tr></table>";
            echo "</form><br/><br/>";
            echo "<div id='retornoQrCode' style='border-radius: 5px; display: none; background-color: lightgreen; width: 100%; height: 35px; padding: 10px; font-size: 25px; font-weight: bold'></div>";
            echo "<div id='retornoListaQrCodes' style='border-radius: 5px; width: 100%; padding: 10px'></div>";

        } catch (Exception $e) {
            log_error($e->getMessage() . '--' . $this->session->userdata('pessoaid'));
            show_404();
        }
    }

    public function ListaQRCode()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            echo "<style>tr:hover{ background-color: #d0e1e5; }</style>";
            echo "<input id='btnVoltaCadQRCode' type='button' value='Voltar' style='display:none; width:100px; height: 35px; font-size: 15px; font-weight: bold'/><br><br>";
            echo "<table border=1>"
                . "<tr style='background-color: lightgray; font-weight: bold'>"
                . "<td>QRCode</td>"
                . "<td>Link</td><td>Ação</td></tr>";

            $sql = "SELECT * FROM `D041_QRCodeVimeo` ORDER BY QRCode ASC";
            $result = $this->getAvaMySQL()->query($sql)->result_array();

            $tabela = '';

            if ($result) {
                foreach ($result as $value) {
                    $tabela .= "<tr><td>" . @utf8_encode($value['QRCode']) . "</td>"
                        . "<td><input id='vimeoid-" . trim($value['QRCode']) . "' size='100' type='text' value='" . @utf8_encode($value['VimeoID']) . "'/></td>"
                        . "<td><input type='button' id='btneditcode' value='Gravar' onclick=\"AlterarQRCode('" . trim($value['QRCode']) . "')\"/></td></tr>";
                }
            }

            print($tabela);
            die();
        } catch (Exception $e) {
            log_error($e->getMessage() . '--' . $this->session->userdata('pessoaid'));
            show_404();
        }
    }

    public function GravaQRCode()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            if ($this->input->post('tipo', true)) {
                $tipo = $this->input->post('tipo', true);
            } else {
                $tipo = 'insert';
            }

            if ($tipo == 'insert') {
                $itemName = $this->iesdeuuid->getIdRandom();

                $dados['QRCode'] = $this->input->post('qrcode', true);
                $dados['VimeoID'] = $this->input->post('link', true);

                $this->salvaDados('D041_QRCodeVimeo', $itemName, $dados, true);

                echo "V&iacute;deo inserido com sucesso!";
            } else {
                if ($tipo == 'update') {
                    $dados['QRCode'] = $this->input->post('qrcode', true);
                    $dados['VimeoID'] = $this->input->post('link', true);

                    $sql = "UPDATE D041_QRCodeVimeo set VimeoID = '" . $dados['VimeoID'] . "' where QRCode = '" . $dados['QRCode'] . "'";
                    $this->getAvaMySQL()->query($sql);

                    echo "V&iacute;deo alterado com sucesso!";
                }
            }

            die();
        } catch (Exception $e) {
            log_error($e->getMessage() . '--' . $this->session->userdata('pessoaid'));
            show_404();
        }
    }

    public function salvaDados($domain, $itemName = true, $dados, $replace = true)
    {
        $this->getAvaMySQL()->insert($domain, $dados);
    }

    public function portalava()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);

            $versoesConteudo = $this->cadastro->getContentVersions();

            $versoesConteudo = array_reduce($versoesConteudo, function ($result, $item) {
                $result[$item['id']] = $item['descricao'];
                return $result;
            }, array());

            $data["form_versao_conteudo"] = form_dropdown('versao_conteudo', $versoesConteudo, '1',
                'id="versao_conteudo"');

            $scholarSubjects = $this->questao->getScholarSubjects();

            $data["scholarSubjects"] = form_dropdown('subjects', $scholarSubjects, '1', 'id="subjects"');

            $this->load->view("view_portalava", $data);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function portalavaJarvis()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);

            $versoesConteudo = $this->cadastro->getContentVersions();

            $data["versoesConteudoJarvis"] = array_reduce($versoesConteudo, function ($result, $item) {
                $result[$item['id']] = [
                    'description' => $item['descricao'],
                    'jarvis_version_id' => (int) $item['jarvis_version_id']
                ];
                return $result;
            }, array());
            $data["versoesConteudoJarvis"] = json_encode($data["versoesConteudoJarvis"]);

            $versoesConteudo = array_reduce($versoesConteudo, function ($result, $item) {
                $result[$item['id']] = $item['descricao'];
                return $result;
            }, array());

            $data["form_versao_conteudo"] = form_dropdown('versao_conteudo', $versoesConteudo, '14',
                'id="versao_conteudo"');

            $scholarSubjects = $this->questao->getScholarSubjects();

            $data["versoesConteudo"] = json_encode($versoesConteudo);
            $data["scholarSubjects"] = form_dropdown('subjects', $scholarSubjects, '1', 'id="subjects"');

            $this->load->view("view_portalava_jarvis", $data);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function BuscaBimestres()
    {
        try {
            $this->allowProfile([Perfil::CONTEUDO, Perfil::ADMIN]);

            $grupoaula = $this->input->post("grupoaula", true);
            $view_marreta = $this->input->post("view_marreta", false);

            if (is_numeric($grupoaula)) {
                $sql = "SELECT DISTINCT E088.CategoriaAulaID
                             , E088.Descricao
                             , E094.Ordem
                FROM E093_GruposAulas E093
                   , E094_GruposCategoriasAulas E094
                   , E088_CategoriasAulas E088
                WHERE E093.GrupoAulaID = E094.GrupoAulaID
                AND E094.CategoriaAulaID = E088.CategoriaAulaID
                
                AND E093.GrupoAulaID = " . $grupoaula . " ORDER BY E094.Ordem";
            } else {
                $sql = "SELECT DISTINCT E088.CategoriaAulaID
                             , E088.Descricao
                             , E094.Ordem
                FROM E093_GruposAulas E093
                   , E094_GruposCategoriasAulas E094
                   , E088_CategoriasAulas E088
                WHERE E093.GrupoAulaID = E094.GrupoAulaID
                AND E094.CategoriaAulaID = E088.CategoriaAulaID
                
                AND lower(E093.Descricao) like '%" . strtolower($grupoaula) . "%' and E093.ClassificacaoID in(10,11,12)";
            }

            $res = $this->getAvaMySQL()->query($sql)->result_array();

            if ($view_marreta) {
                return $this->responseJson($res, 200);
            }

            echo "<table>";

            foreach ($res as $key => $value) {

                $disciplineName = str_replace([
                    'SAE:',
                    ':',
                    'SAE - ',
                    'Extensivo-Mega',
                    'Extensivo',
                    ' - EM',
                ], '', $value['Descricao']);

                //fix name
                $disciplineName = str_replace(["Espanhol", "Língua Língua Espanholaa"], 'Língua Espanhola',
                    $disciplineName);

                $disciplineName = explode('-', $disciplineName);

                $disciplineName = trim($disciplineName[0]);

                echo "<tr>";

                echo "<td style='padding-left: 10px; width: 450px'>
                    <a id='linkbim-" . $value['CategoriaAulaID'] . "' data-discipline ='" . $disciplineName . "' onclick='CarregaAssuntos_click(" . $value['CategoriaAulaID'] . ",\"" . $value['Descricao'] . "\",\"" . $disciplineName . "\");'>" . $value['CategoriaAulaID'] . " - " . $value['Descricao'] . "</a>
                        <input style='display: none; width: 460px' type='text' id='txtbim-" . $value['CategoriaAulaID'] . "' value='" . $value['Descricao'] . "'/>
                    </td>
                    <td style='width: 100px'>";
                echo "<input id='txtordembim-" . $value['CategoriaAulaID'] . "' type='text' style='width: 50px' value='" . $value['Ordem'] . "'/>";
                if ((int) $this->session->userdata('perfil') === Perfil::ADMIN) {
                    echo "</td>
                    <td style='width: 160px'>                                                
                        <a id='btnbim-save-" . $value['CategoriaAulaID'] . "' onclick='SalvaBim(" . $value['CategoriaAulaID'] . ")' class='glyphicon glyphicon-floppy-save' style='margin-right: 10px; display: none'></a>                         
                        <a id='btnbim-edit-" . $value['CategoriaAulaID'] . "' onclick='AtivaEditBim(" . $value['CategoriaAulaID'] . ")' class='glyphicon glyphicon-pencil' style='margin-right: 10px'></a>                         
                        <a id='btnbim-cancel-" . $value['CategoriaAulaID'] . "'  onclick='DesativaEditBim(" . $value['CategoriaAulaID'] . ")' class='glyphicon glyphicon-remove' style='display: none; margin-right: 10px'></a>                         
                        <a id='btnbim-remove-" . $value['CategoriaAulaID'] . "'  onclick='RemoveBim(" . $value['CategoriaAulaID'] . ")' class='glyphicon glyphicon-trash'></a>                         
                    </td>";
                }
                echo "</tr>";
            }

            echo "</table>";
            die();
        } catch (Exception $e) {
            log_error($e->getMessage() . ' - ' . $this->session->userdata('login'));
            show_404();
        }
    }

    public function BuscaAssuntos()
    {
        try {
            $bimestre = $this->input->post("bimestre", true);
            $view_marreta = $this->input->post("view_marreta", false);
            $desc = $this->input->post("descbi", true);

            $sql = "SELECT DISTINCT E089.SubCategoriaAulaID, E090.CategoriaSubCategoriaAulaID, E089.Descricao, E090.Ordem
                FROM E093_GruposAulas E093
                   , E094_GruposCategoriasAulas E094
                   , E088_CategoriasAulas E088
                   , E090_CategoriasSubCategoriasAulas E090
                   , E089_SubCategoriasAulas E089
                WHERE E093.GrupoAulaID = E094.GrupoAulaID
                AND E094.CategoriaAulaID = E088.CategoriaAulaID
                AND E088.CategoriaAulaID = E090.CategoriaID
                AND E089.SubCategoriaAulaID = E090.SubCategoriaID                
                AND E088.CategoriaAulaID = " . $bimestre . "
                ORDER BY E090.Ordem, E089.SubCategoriaAulaID ASC";

            $res = $this->getAvaMySQL()->query($sql)->result_array();

            if ($view_marreta) {
                return $this->responseJson($res, 200);
            }

            echo "<h2>" . $desc . "</h2>";

            echo "<table>";

            $subatual = 0;

            foreach ($res as $key => $value) {
                if ($value['SubCategoriaAulaID'] != $subatual) {

                    $sql9 = "select e068.AulaID
                        from E091_AulasSubCategorias e091
                        inner join E068_Aulas e068 on e068.AulaID = e091.AulaId
                        where e091.SubCategoriaID = " . $value['SubCategoriaAulaID'] . "
                        and e068.Tipo = 'N'";

                    $objAulaID = $this->getAvaMySQL()->query($sql9)->result_array();

                    echo "<tr>";
                    echo "<td style='padding-left: 10px; width: 350px'>
                        <a onclick='CarregaQuestoes(" . $value['SubCategoriaAulaID'] . ");' data-toggle='tooltip' title='" . $value['SubCategoriaAulaID'] . "' id='linkass-" . $value['SubCategoriaAulaID'] . "'>" . $value['SubCategoriaAulaID'] . " - " . $value['Descricao'] . "</a>
                        <input style='display: none; width: 460px' type='text' id='txtass-" . $value['SubCategoriaAulaID'] . "' value='" . $value['Descricao'] . "'/>
                        <input type='hidden' id='txtaulahd-" . $value['SubCategoriaAulaID'] . "' value='" . $objAulaID[0]['AulaID'] . "'/>                        
                    </td>";
                    if ((int) $this->session->userdata('perfil') === Perfil::ADMIN) {
                        echo "<td style='width: 100px'>
                    <input id='txtordemass-" . $value['SubCategoriaAulaID'] . "' type='text' style='width: 50px' value='" . $value['Ordem'] . "'/>                         
                    </td>
                    <td>
                        <a id='btnass-save-" . $value['SubCategoriaAulaID'] . "' onclick='SalvaAss(" . $value['SubCategoriaAulaID'] . ")' class='glyphicon glyphicon-floppy-save' style='margin-right: 10px; display: none'></a>                         
                        <a id='btnass-edit-" . $value['SubCategoriaAulaID'] . "' onclick='AtivaEditAss(" . $value['SubCategoriaAulaID'] . ")' class='glyphicon glyphicon-pencil' style='margin-right: 10px'></a>                         
                        <a id='btnass-cancel-" . $value['SubCategoriaAulaID'] . "'  onclick='DesativaEditAss(" . $value['SubCategoriaAulaID'] . ")' class='glyphicon glyphicon-remove' style='display: none'></a>
                        <a id='btnass-remove-" . $value['CategoriaAulaID'] . "'  onclick='RemoveAss(" . $value['CategoriaSubCategoriaAulaID'] . ")' class='glyphicon glyphicon-trash'></a>
                        <a id='btnass-moveBi-" . $value['CategoriaAulaID'] . "'  onclick='moveBimestre(" . $value['SubCategoriaAulaID'] . ")' title='Transferir assunto para outro bimestre' class='glyphicon glyphicon-transfer
'></a>
                    </td>";
                    }
                    echo "</tr><tr><td colspan='3'>
                    <div id='questoesaula-" . $value['SubCategoriaAulaID'] . "' style='width: 600px; display: none'>
                    </div>         
                    </td></tr>";
                }
                $subatual = $value['SubCategoriaAulaID'];
            }

            echo "</table>";
            die();
        } catch (Exception $e) {
            log_error($e->getMessage() . ' - ' . $this->session->userdata('login'));
            show_404();
        }
    }

    public function Similares()
    {
        $pacote = $this->input->post('id', true);

        $sql = "SELECT cd.id AS disciplina, c.id AS curso, ca.id AS aula, caq.questao_id AS questao  ,
        
                (	SELECT group_concat(qs.questao_similar_id  SEPARATOR ',') 
                	FROM aprovaquestoes.questao_similar qs 
                	WHERE qs.questao_id=caq.questao_id ) AS similar, 
                	
                (	SELECT group_concat(qs.questao_id  SEPARATOR ',') 
                	FROM aprovaquestoes.questao_similar qs 
                	WHERE qs.questao_similar_id=caq.questao_id ) AS similarInverso 
                	
                FROM aprovaquestoes.curso c 
                    JOIN aprovaquestoes.curso_categoria cc ON cc.curso_id = c.id
                    JOIN aprovaquestoes.curso_disciplina cd ON cd.id = cc.curso_disciplina_id
                    JOIN aprovaquestoes.curso_aula ca ON ca.curso_disciplina_id = cd.id
                    LEFT JOIN aprovaquestoes.curso_aula_questao caq ON caq.curso_aula_id = ca.id
                WHERE 1 = 1 ";

        if ($this->input->post('qstPai', true)) {
            $qstPai = $this->input->post('qstPai', true);
            $sql .= " and caq.questao_id = " . $qstPai;
        } else {
            if ($this->input->post('txtaula', true)) {
                $pSubCat = $this->input->post('txtaula', true);
                $sql .= " and c.id = " . $pacote . " and cd.id = " . $pSubCat;
            } else {
                $sql .= " and c.id = " . $pacote;
            }
        }

        $sql .= " order by cd.id, caq.questao_id";

        $res = $this->getAvaMySQL()->query($sql)->result_array();

        echo "<table>
                <tr>
                <td>
                    <b>SubCategoriaID</b>
                </td>
                <td>
                    <b>Questão Pai</b>
                </td>
                <td>
                    <b>Questões Filhas</b>
                </td>
                <td></td>
                </tr>";

        foreach ($res as $key => $value) {
            echo "<tr>";
            echo "<td style='padding-left: 10px; width: 150px'>
                   " . $value['disciplina'] . "
                    </td>
                    <td style='padding-left: 10px; width: 120px'>
                    " . $value['questao'] . "
                    </td>
                    <td>
                    " . $value['similar'] . "                            
                    </td>
                    <td>
                        <a onclick='RemoveQuestoesSimilares(" . $value['questao'] . ")' class='glyphicon glyphicon-remove' style='width: 25px; text-align: center'></a>
                    </td>";
            echo "</tr>";
        }

        echo "</table>";
        die();
    }

    public function Professores()
    {
        $this->load->view("view_pesq_professores");
    }

    public function ConsultaProf()
    {
        $aluno = $this->input->post('txtprof', true);

        $sql = "SELECT DISTINCT d019.Nome
                     , d019.Login
                     , d019.Serie
                FROM (SELECT d019.Turma
                FROM D019_Ava_Sae d019
                WHERE d019.Login = '" . $aluno . "') turmas
                , D019_Ava_Sae d019
                WHERE d019.Turma = turmas.Turma
                AND d019.Situacao = 'A'
                AND d019.DtCad >= '2017-01-01-'
                AND d019.Redirecionar = 'professor'
                ORDER BY d019.Serie";

        $res = $this->getAvaMySQL()->query($sql)->result_array();

        echo "<table>
                <tr>
                <td>
                    <b>Nome do Professor</b>
                </td>
                <td>
                    <b>Login do Professor</b>
                </td>
                <td>
                    <b>Disciplina</b>
                </td>
                </tr>";

        foreach ($res as $key => $value) {
            echo "<tr>";
            echo "<td style='padding-left: 10px; width: 420px'>
                   " . $value['Nome'] . "
                    </td>
                    <td style='padding-left: 10px; width: 260px'>
                    " . $value['Login'] . "
                    </td>
                    <td style='padding-left: 10px; width: 350px'>
                    " . $value['Serie'] . "                            
                    </td>";
            echo "</tr>";
        }

        echo "</table>";
        die();
    }

    public function RemoveQuestoesSimilares()
    {
        $questao = $this->input->post('questao', true);

        $where = "questao_id = " . $questao;
        $this->getAvaMySQL()->delete('aprovaquestoes.questao_similar', $where);

        die();
    }

    public function GravaEditBimestre()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $bimestre = $this->input->post("bimestre", true);
            $novo_nome = $this->input->post("novo_nome", true);
            $nova_ordem = $this->input->post("ordem", true);

            $dados['Descricao'] = $novo_nome;

            $this->getAvaMySQL()->where("CategoriaAulaID = " . $bimestre);
            $this->getAvaMySQL()->update("E088_CategoriasAulas", $dados);

            $dados94['Ordem'] = $nova_ordem;

            $this->getAvaMySQL()->where("CategoriaAulaID = " . $bimestre);
            $this->getAvaMySQL()->update("E094_GruposCategoriasAulas", $dados94);

            $dados014['OrdemCategoria'] = str_pad($nova_ordem, 5, "0", STR_PAD_LEFT);

            $this->getAvaMySQL()->where("CategoriaID = " . $bimestre);
            $this->getAvaMySQL()->update("D014_Categorias", $dados014);

            echo "Bimestre alterado com sucesso!";
            die();
        } catch (Exception $e) {
            log_error($e->getMessage() . ' - ' . $this->session->userdata('login'));
            echo "Não foi possível alterar bimestre!";
            die();
        }
    }

    public function RemoveBimestre()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);
            $bimestre = $this->input->post("bimestre", true);

            $this->getAvaMySQL()->where("CategoriaAulaID = " . $bimestre);
            $this->getAvaMySQL()->delete("E094_GruposCategoriasAulas");

            echo "Bimestre excluído com sucesso!";
            die();
        } catch (Exception $e) {
            echo "Bimestre excluído com sucesso!";
            die();
        }
    }

    public function RemoveAssunto()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $subCategoriaAulaId = $this->input->post("sub_categoria_aula_id", true);

            $this->getAvaMySQL()->where("CategoriaSubCategoriaAulaID = " . $subCategoriaAulaId);
            $this->getAvaMySQL()->delete("E090_CategoriasSubCategoriasAulas");

            echo "Assunto excluído com sucesso!";
            die();

        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }


    }

    public function GravaEditAssunto()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $assunto = $this->input->post("assunto", true);
            $novo_nome = $this->input->post("novo_nome", true);
            $ordem = $this->input->post("ordem", true);
            $aulaid = $this->input->post("aulaid", true);

            $dadosDesc['Descricao'] = $novo_nome;
            $dadosDescTema['Tema'] = $novo_nome;
            //$dadosOrd['Ordem'] = str_pad($ordem, 5, 0, STR_PAD_LEFT);
            $dadosOrd['Ordem'] = $ordem;

            $this->getAvaMySQL()->where("SubCategoriaAulaID = " . $assunto);
            $this->getAvaMySQL()->update("E089_SubCategoriasAulas", $dadosDesc);

            $this->getAvaMySQL()->where("SubCategoriaID = " . $assunto);
            $this->getAvaMySQL()->update("E090_CategoriasSubCategoriasAulas", $dadosOrd);

            $this->getAvaMySQL()->where("AulaID = " . $aulaid);
            $this->getAvaMySQL()->update("E068_Aulas", $dadosDescTema);

            echo "Assunto alterado com sucesso!";
            die();
        } catch (Exception $e) {
            log_error($e->getMessage() . ' - ' . $this->session->userdata('login'));
            echo "Não foi possível alterar assunto!";
            die();
        }
    }

    public function PesquisaNovoBim()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $nomebim = $this->input->post("nomebim", true);
            $grupoaula = $this->input->post("grupoaula", true);

            $sql = "select e088.CategoriaAulaID, e088.Descricao
                from E088_CategoriasAulas e088
                   left join E094_GruposCategoriasAulas e094 on e088.CategoriaAulaID = e094.CategoriaAulaID
                where lower(e088.Descricao) like lower('%" . $nomebim . "%')
                and ( (lower(e088.Descricao) like lower('sae%')) or (lower(e088.Descricao) like lower('plataforma%')))
                order by e088.Descricao";

            $res = $this->getAvaMySQL()->query($sql)->result_array();

            echo "<select id='lista_bimestres'>";

            foreach ($res as $key => $value) {
                echo " <option value='" . $value['CategoriaAulaID'] . "'>" . $value['Descricao'] . "</option>";
            }

            echo "</select>";
            die();
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function PesquisaNovoAss()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $nomeass = $this->input->post("nomeass", true);
            $grupoaula = $this->input->post("grupoaula", true);

            $sql = "select e089.Descricao as Tema, e089.SubCategoriaAulaID as SubCategoriaID
                from E089_SubCategoriasAulas e089
                where lower(e089.Descricao) like '%" . $nomeass . "%'";

            $res = $this->getAvaMySQL()->query($sql)->result_array();

            echo "<select id='lista_assuntos'>";

            foreach ($res as $key => $value) {
                echo " <option value='" . $value['SubCategoriaID'] . "'>" . $value['SubCategoriaID'] . " - " . $value['Tema'] . "</option>";
            }

            echo "</select>
            <input id='bimestre_selecionado' type='hidden' value=''/>
        ";
            die();
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function VinculaBimestre()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            if ($_SESSION['pessoaid']) {
                $novobim = $this->input->post("novobim", true);
                $grupoaula = $this->input->post("grupoaula", true);
                $nomebim = $this->input->post("nomebim", true);

                $sql1 = "SELECT max(e094.Ordem) AS ordemmax
                FROM E094_GruposCategoriasAulas e094
                WHERE e094.GrupoAulaID = " . $grupoaula;
                $res = $this->getAvaMySQL()->query($sql1)->result_array();

                $ordem = $res[0]['ordemmax'] + 1;

                $sql1 = "SELECT max(e094.GrupoCategoriaID) AS grupomax
                FROM E094_GruposCategoriasAulas e094;";
                $res = $this->getAvaMySQL()->query($sql1)->result_array();

                $grupocatid = $res[0]['grupomax'] + 1;

                $dados1['GrupoCategoriaID'] = $grupocatid;
                $dados1['GrupoAulaID'] = $grupoaula;
                $dados1['CategoriaAulaID'] = $novobim;
                $dados1['UsuarioID'] = $_SESSION['pessoaid'];
                $dados1['DtCad'] = date("Y-m-d H:i:s");
                $dados1['DtAlt'] = date("Y-m-d H:i:s");
                $dados1['Ordem'] = $ordem;

                $this->getAvaMySQL()->insert("E094_GruposCategoriasAulas", $dados1);

                die();
            }
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function VinculaAssunto()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            if ($_SESSION['pessoaid']) {
                $novoass = $this->input->post("novoass", true);
                $grupoaula = $this->input->post("grupoaula", true);
                $nomeass = $this->input->post("nomeass", true);
                $idbim = $this->input->post("idbim", true);

                $nomeexp = explode('-', $nomeass);

                $sql1 = "select max(e090.CategoriaSubCategoriaAulaID) as maxcat
                  from E090_CategoriasSubCategoriasAulas e090";
                $res = $this->getAvaMySQL()->query($sql1)->result_array();
                $catmax = $res[0]['maxcat'] + 1;

                $dados1['CategoriaSubCategoriaAulaID'] = $catmax;
                $dados1['CategoriaID'] = $idbim;
                $dados1['SubCategoriaID'] = $novoass;
                $dados1['UsuarioCad'] = $_SESSION['pessoaid'];
                $dados1['DtCad'] = date("Y-m-d H:i:s");
                $dados1['DtAlt'] = date("Y-m-d H:i:s");
                $dados1['UsuarioAlt'] = $_SESSION['pessoaid'];
                $this->getAvaMySQL()->insert('E090_CategoriasSubCategoriasAulas', $dados1);

                $dados4['itemName'] = str_pad($novoass, 7, 0, STR_PAD_LEFT) . str_pad($grupoaula, 7, 0, STR_PAD_LEFT);
                $dados4['CategoriaID'] = $idbim;
                $dados4['Descricao'] = trim($nomeexp[1]);
                $dados4['DisciplinaID'] = $novoass;
                $dados4['DtInicio'] = date("Y-m-d H:i:s");
                $dados4['GrupoAulaID'] = $grupoaula;
                $dados4['OrdemDisciplina'] = '00001';
                $dados4['Situacao'] = 'A';
                $this->getAvaMySQL()->insert('D004_Disciplinas', $dados4);

                die();
            }
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function VinculaAssuntoJarvis()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            if ($_SESSION['pessoaid']) {
                $grupoaula = $this->input->post("grupoaula", true);
                $idbim = $this->input->post("idbim", true);

                $modules = $this->input->post("modules", true);

                foreach ($modules as $moduleId) {
                    //get module information from jarvis
                    $module = SaeDigital::make(JarvisApi::class)->get(
                        '/modules/' . $moduleId,
                        [],
                        1,
                        1,
                        'module,module.id,module.name'
                    );

                    //create module
                    $assunto_id = SaeDigital::make(CriaAssunto::class)->handle($module['name'], $module['id']);
                    //relate module with period
                    SaeDigital::make(RelacionaAssuntoComBimestre::class)->handle($assunto_id, $idbim,
                        $_SESSION['pessoaid']);
                    //notify consumer with legacy id
                    SaeDigital::make(Enqueue::class)->sendMessage([
                        //'assunto_id' => $assunto_id,
                        'module_id' => $moduleId
                    ], getenv('CI_ENV') . '_jarvis_module_sync');
                }
            }

            $this->responseJson(['message' => 'Módulos vínculados com sucesso'], 200);
        } catch (Exception $e) {
            $this->responseJson(['message' => $e->getMessage()], 500);
        }
    }

    public function CriaBimestre()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $grupoaula = $this->input->post("grupoaula", true);
            $nomebimestrenovo = $this->input->post("nomebimestrenovo", true);

            $sql1 = "select max(e088.CategoriaAulaID) as maxcataula
                  from E088_CategoriasAulas e088";
            $res = $this->getAvaMySQL()->query($sql1)->result_array();
            $maxcataula = $res[0]['maxcataula'] + 1;

            $dados88['CategoriaAulaID'] = $maxcataula;
            $dados88['Descricao'] = $nomebimestrenovo;
            $dados88['UsuarioCad'] = $_SESSION['pessoaid'];
            $dados88['DtCad'] = Date('Y-m-d h:i:s');
            $dados88['UsuarioAlt'] = $_SESSION['pessoaid'];
            $dados88['DtAlt'] = Date('Y-m-d h:i:s');

            $this->getAvaMySQL()->insert('E088_CategoriasAulas', $dados88);

            $sql1 = "select max(e094.GrupoCategoriaID) as maxgrupocat
                  from E094_GruposCategoriasAulas e094";
            $res = $this->getAvaMySQL()->query($sql1)->result_array();
            $grupocatmax = $res[0]['maxgrupocat'] + 1;

            $sql2 = "select max(e094.Ordem) as ordem
                from E094_GruposCategoriasAulas e094
                where e094.GrupoAulaID = " . $grupoaula;
            $res2 = $this->getAvaMySQL()->query($sql2)->result_array();
            $proxordem = $res2[0]['ordem'] + 1;

            $dados94['GrupoCategoriaID'] = $grupocatmax;
            $dados94['GrupoAulaID'] = $grupoaula;
            $dados94['CategoriaAulaID'] = $maxcataula;
            $dados94['UsuarioID'] = $_SESSION['pessoaid'];;
            $dados94['DtCad'] = date("Y-m-d H:i:s");
            $dados94['DtAlt'] = date("Y-m-d H:i:s");
            $dados94['Ordem'] = $proxordem;
            $this->getAvaMySQL()->insert('E094_GruposCategoriasAulas', $dados94);

            die();
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function CriaAssunto()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $grupoaula = $this->input->post("grupoaula", true);
            $nomeassuntonovo = $this->input->post("nomeassuntonovo", true);
            $linkVideo = $this->input->post("videoassuntonovo", true);
            $tempoVideo = $this->input->post("tempovideoassuntonovo", true);
            $idbim = $this->input->post("idbim", true);
            $disciplinaQuestoes = $this->input->post("disciplina_questoes", true);
            $aulaTypes = $this->input->post("types", []);

            $sql1 = "select max(e089.SubCategoriaAulaID) as maxsubcat
                  from E089_SubCategoriasAulas e089;";
            $res = $this->getAvaMySQL()->query($sql1)->result_array();
            $subcatmax = $res[0]['maxsubcat'] + 1;

            $dados89['SubCategoriaAulaID'] = $subcatmax;
            $dados89['Descricao'] = $nomeassuntonovo;
            $dados89['UsuarioCad'] = $_SESSION['pessoaid'];
            $dados89['DtCad'] = Date('Y-m-d h:i:s');
            $dados89['UsuarioAlt'] = $_SESSION['pessoaid'];
            $dados89['DtAlt'] = Date('Y-m-d h:i:s');
            $dados89['DtInicio'] = Date('Y-m-d h:i:s');
            $dados89['Autor'] = '880';
            $dados89['Situacao'] = 'A';
            $this->getAvaMySQL()->insert('E089_SubCategoriasAulas', $dados89);

            $sql1 = "select max(e090.CategoriaSubCategoriaAulaID) as maxcat
                  from E090_CategoriasSubCategoriasAulas e090";
            $res2 = $this->getAvaMySQL()->query($sql1)->result_array();
            $catmax = $res2[0]['maxcat'] + 1;

            $dados90['CategoriaSubCategoriaAulaID'] = $catmax;
            $dados90['CategoriaID'] = $idbim;
            $dados90['SubCategoriaID'] = $subcatmax;
            $dados90['UsuarioCad'] = $_SESSION['pessoaid'];
            $dados90['DtCad'] = Date('Y-m-d h:i:s');
            $dados90['UsuarioAlt'] = $_SESSION['pessoaid'];
            $dados90['DtAlt'] = Date('Y-m-d h:i:s');
            $dados90['Ordem'] = 1;
            $this->getAvaMySQL()->insert('E090_CategoriasSubCategoriasAulas', $dados90);

            $assuntoQuestoes = [
                "nome" => $nomeassuntonovo,
                "status" => 1,
                "disciplina_id" => $disciplinaQuestoes
            ];

            $this->getAvaMySQLQuestoes()->insert('assunto', $assuntoQuestoes);


            $aulaDefault = [
                'DtCad' => date('Y-m-d H:i:s'),
                'DtAlt' => date('Y-m-d H:i:s'),
                'UsuarioCad' => $this->session->userdata('pessoaid'),
                'UsuarioAlt' => $this->session->userdata('pessoaid'),
                'SistemaID' => 25,
                'Importou' => 'S',
                'Situacao' => 'A',
            ];

            $aulas = [];
            foreach ($aulaTypes as $aulaType) {
                $aula = [
                    'Tipo' => $aulaType,
                ];

                switch ($aulaType) {
                    case 'Q':
                        $aula['Tema'] = 'Questão';
                        break;
                    case 'R':
                        $aula['Tema'] = 'Revisão';
                        break;
                    case 'D':
                        $aula['Tema'] = $nomeassuntonovo;
                        break;
                    case 'N':
                        $aula['pdf'] = $linkVideo;
                        $aula['Video'] = $linkVideo;
                        $aula['Duracao'] = $tempoVideo;
                        $aula['Tema'] = $nomeassuntonovo;
                        break;
                }
                $aulas[] = array_merge($aulaDefault, $aula);
            }

            $aulasInseridas = [];
            foreach ($aulas as $aula) {
                $this->getAvaMySQL()->insert('E068_Aulas', $aula);
                $aulaId = $this->getAvaMySQL()->insert_id();
                array_push($aulasInseridas, $aulaId);


                if (in_array($aula['Tipo'], ['Q', 'R'])) {

                    $estruturaQuestoesAula = [
                        'GrupoAulaID' => $grupoaula,
                        'SubCategoriaID' => $dados90['SubCategoriaID'],
                        'AulaID' => $aulaId,
                        'Situacao' => 'A',
                        'DtCad' => date('Y-m-d H:i:s'),
                        'DtAlt' => date('Y-m-d H:i:s'),
                        'ExisteQuestao' => 1
                    ];

                    $this->getAvaMySQL()->insert('E358_EstruturaAulasQuestoes', $estruturaQuestoesAula);

                }
            }

            foreach ($aulasInseridas as $aulaInserida) {
                $subCategoria = [
                    'AulaId' => $aulaInserida,
                    'SubCategoriaID' => $dados89['SubCategoriaAulaID'],
                    'UsuarioCad' => $this->session->userdata('pessoaid'),
                    'UsuarioAlt' => $this->session->userdata('pessoaid'),
                    'DtAlt' => date('Y-m-d H:i:s'),
                    'DtCad' => date('Y-m-d H:i:s')
                ];
                $this->getAvaMySQL()->insert('E091_AulasSubCategorias', $subCategoria);
            }

            $dados = $this->getDadosQuestoes($grupoaula, $dados89['SubCategoriaAulaID']);

            foreach ($dados as $key => $res) {
                if ($res->SITUACAO == 'A') {
                    $aulaid_api[] = $res->Aula;
                    $prof_api[] = $res->email;
                    $array['cursos'][$res->Curso]['nome'] = $res->Desc_Curso;
                    $array['cursos'][$res->Curso]['disciplinas'][$res->Subcategoria_aula]['nome'] = $res->Desc_Subcategoria_aula;
                    $array['cursos'][$res->Curso]['disciplinas'][$res->Subcategoria_aula]['aulas'][$res->Aula]['nome'] = $res->Tema;
                    $array['cursos'][$res->Curso]['disciplinas'][$res->Subcategoria_aula]['aulas'][$res->Aula]['usuario'] = $res->email;
                    $array['cursos'][$res->Curso]['disciplinas'][$res->Subcategoria_aula]['aulas'][$res->Aula]['tipo'] = $res->Tipo;
                } else {
                    $array['cursos'][$res->Curso]['nome'] = $res->Desc_Curso;
                    $array['cursos'][$res->Curso]['disciplinas'][$res->Subcategoria_aula]['nome'] = $res->Desc_Subcategoria_aula;
                    $array['cursos'][$res->Curso]['disciplinas'][$res->Subcategoria_aula]['aulas'][$res->Aula]['delete'] = 'true';
                }
            }

            $grpAulaID = $res->Curso;

            foreach ($dados as $key => $res) {
                $resposta = $this->api_definir_estrutura($grpAulaID, $res->Subcategoria_aula, $aulaid_api);
            }

            if ($resposta['success'] == 1) {
                $dadosResposta['bar'] = "50%";
                $dadosResposta['tituloDialog'] = 'Criando estrutura...';
                print_r(json_encode($dadosResposta));
            } else {
                print_r(json_encode(""));
            }

            die();
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function RelatorioQuestaoAssunto($assunto)
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);
            $sql = "select distinct a.nome as Assunto, q.questao_id as Questao
                from aprovaquestoes.questao_similar q
                inner join aprovaquestoes.questao_assunto qa on qa.questao_id = q.questao_id
                inner join aprovaquestoes.assunto a on a.id = qa.assunto_id
                where a.id = " . $assunto;
            $res = $this->getAvaMySQL()->query($sql)->result_array();

            echo "<table border=1>"
                . "<tr style='background-color: lightgray; font-weight: bold'>"
                . "<td style=''>Assunto</td>"
                . "<td>Questão</td></tr>";

            foreach ($res as $key => $value) {
                echo "<tr>"
                    . "<td>" . $value['Assunto'] . "</td>"
                    . "<td>" . $value['Questao'] . "</td>"
                    . "</tr>";
            }

            echo "</table>";

            die();
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function BuscaQuestoes()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);
            $subcategoria = $this->input->post("subcategoria", true);
            $grupoAulaId = $this->input->post("grupoAulaId", true);

            echo " <div id='modal_questoes-" . $subcategoria . "' style='display:none;'>
                    <p id='lblEnun-" . $subcategoria . "' style='margin-bottom: 20px'><b>Enunciado</b></p>      
                    <hr>          
                    <span id='questaoenun-" . $subcategoria . "' style='width: 600px; height: 150px'></span>                    
                    <p style='margin-top: 30px'><b id='opalta-" . $subcategoria . "'>a.</b> <span id='alta-" . $subcategoria . "' style='width: 600px; height: 50px'></span></p>
                    <p><b id='opaltb-" . $subcategoria . "'>b.</b> <span id='altb-" . $subcategoria . "' style='width: 600px; height: 50px;'></span></p>
                    <p><b id='opaltc-" . $subcategoria . "'>c.</b> <span id='altc-" . $subcategoria . "' style='width: 600px; height: 50px;'></span></p>
                    <p><b id='opaltd-" . $subcategoria . "'>d.</b> <span id='altd-" . $subcategoria . "' style='width: 600px; height: 50px;'></span></p>
                    <p><b id='opalte-" . $subcategoria . "'>e.</b> <span id='alte-" . $subcategoria . "' style='width: 600px; height: 50px;'></span></p>                                                        
            </div>";

            $sql = "select *
                from E358_EstruturaAulasQuestoes e358
                  inner join E359_AulaQuestoes e359 on e358.EstruturaAulaID = e359.EstruturaAulaID
                  inner join E068_Aulas E068 ON E068.Aulaid = e358.aulaid
                where e358.SubCategoriaID = " . $subcategoria . "
                and e358.GrupoAulaID = ".$grupoAulaId."
                
                order by E068.Tipo, e359.GrupoSimilar";

            $res = $this->getAvaMySQL()->query($sql)->result_array();

            echo "<table style='margin-left: 20px'><tr>";

            $similar = -1;
            $cont = 1;
            $contgrupo = 1;
            foreach ($res as $key => $value) {
                if ($similar != $value['GrupoSimilar']) {
                    echo "</tr><tr>
                <td colspan='3'>Grupo " . $cont . "</td>";
                    $cont++;
                }

                if ($contgrupo % 5 == 0) {
                    echo "<td style='padding-left: 15px;' class='tdquestoes'>
                        <a style='background-color: #d1f2f5; color: black' onclick='" . ($value['JarvisItemID'] ? "CarregaInfoQuestaoJarvis(" . $value['JarvisItemID'] . ")" : "CarregaInfoQuestao(" . $value['QuestaoID'] . ")") . "' data-toggle='tooltip' title='" . $value['QuestaoID'] . "' id='linkqst-" . $value['QuestaoID'] . "'>" . $value['QuestaoID'] . "</a>                                          
                    </td>";
                } else {
                    echo "<td style='padding-left: 15px;' class='tdquestoes'>
                        <a onclick='" . ($value['JarvisItemID'] ? "CarregaInfoQuestaoJarvis(" . $value['JarvisItemID'] . ")" : "CarregaInfoQuestao(" . $value['QuestaoID'] . ")") . "' data-toggle='tooltip' title='" . $value['QuestaoID'] . "' id='linkqst-" . $value['QuestaoID'] . "'>" . $value['QuestaoID'] . "</a>                                          
                    </td>";
                }

                $similar = $value['GrupoSimilar'];
                $contgrupo++;
            }

            echo "</table>";
            die();
        } catch (Exception $e) {
            log_error($e->getMessage() . ' - ' . $this->session->userdata('login'));
            show_404();
        }
    }

    public function CarregaInfoQuestoes()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);

            $questao = $this->input->post("questao", true);
            $this->layout = '';
            $sql = "select q.enunciado
                     , qor.opcao_correta
                     , qor.valor_opcao
                     , qor.opcao
                from aprovaquestoes.questao q
                  inner join aprovaquestoes.questao_opcao_resposta qor on qor.questao_id = q.id
                where q.id = " . $questao . "
                order by qor.valor_opcao";

            $data['questao'] = $this->getAvaMySQL()->query($sql)->result_array();

            $this->load->view('portalava/questao_view', $data);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function CarregaInfoQuestoesJarvis()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);

            $this->layout = '';
            $itemId = $this->input->post("itemId", true);
            $item = SaeDigital::make(JarvisApi::class)->get('/items/' . $itemId);

            $correct = reset(array_filter($item['attributes'], function ($attribute) {
                return ($attribute['attribute']['id'] == JarvisApi::ALTERNATIVA_CORRETA ? true : false);
            }));
            $question = [
                'title' => $item['title'],
                'options' => array_map(function ($attr) use ($correct) {
                    $attr['is_correct'] = ($attr['attribute']['id'] == $correct['value'] ? true : false);
                    return $attr;
                }, array_filter($item['attributes'], function ($attribute) {
                    return (in_array($attribute['attribute']['id'], [
                        JarvisApi::ALTERNATIVA_1,
                        JarvisApi::ALTERNATIVA_2,
                        JarvisApi::ALTERNATIVA_3,
                        JarvisApi::ALTERNATIVA_4,
                        JarvisApi::ALTERNATIVA_5
                    ]) ? true : false);
                }))
            ];
            return $this->load->view('portalava/questao_view_jarvis', ['question' => $question]);
        } catch (Exception $e) {
            log_error($e->getMessage());
            show_404();
        }
    }

    public function relatorioExclusivoColegioUP()
    {
        $this->layout = 'relatorio';
        $this->cssMinify = array('style_avasae_bootstrap3', 'botao_imprimir', 'mensagem');
        $this->css[] = $this->minify->getCSS('relatorio_exclusivo.min', $this->cssMinify, ENVIRONMENT);
        $this->load->view('relatorios/relatorioExclusivoColegioUP', array());
    }

    public function exportarRelatorioExclusivoColegioUP()
    {
        $resultado = $this->ExecRelatorioUP();

        $html = '';
        foreach ($resultado as $key => $value) {
            $html .= "<tr>";
            $html .= "<td>" . $value->DescDisciplina . "</td>";
            $html .= "<td>" . $value->DescAssunto . "</td>";
            $html .= "<td>" . $value->NomeAluno . "</td>";
            $html .= "<td>" . $value->Acertos . "</td>";
            $html .= "<td>" . $value->TotalQuestoes . "</td>";
            $html .= "</tr>";
        }
        print $html;
        die;
    }

    public function gerarXLSExclusivo()
    {
        $data['excelGerando'] = true;
        $this->layout = 'relatorio';
        $this->load->view('relatorios/relatorioExclusivoColegioUP', $data);

        $resultado = $this->ExecRelatorioUP();

        $this->load->library('PHPExcel');
        $objPHPExcel = $this->phpexcel;
        $title = "Relatório Exclusivo Colegio UP";
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setLastModifiedBy("SAE Digital");
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setTitle($title);
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setSubject($title);
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setDescription($title);
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setKeywords($title);
        $objPHPExcel->getProperties()->setCreator("SAE Digital")->setCategory($title);

        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', "Disciplina");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B1', "Assunto");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C1', "Nome");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D1', "Acertos");
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E1', "Total de Questões");

        $count_lines = 1;
        foreach ($resultado as $key => $value) {
            $count_lines += 1;
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A' . $count_lines, $value->DescDisciplina);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B' . $count_lines, $value->DescAssunto);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C' . $count_lines, $value->NomeAluno);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D' . $count_lines, $value->Acertos);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E' . $count_lines, $value->TotalQuestoes);
        }

        $data_geracao_relatorio = date("d-m-Y-H-i");
        $objPHPExcel->getActiveSheet()->setTitle($title);
        $objPHPExcel->setActiveSheetIndex(0);
        $filename = $data_geracao_relatorio . "_relatorio_exclusivo_up.xls";
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-type: application/vnd.ms-excel');
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save('php://output');
    }

    public function ExecRelatorioUP()
    {
        $sql = "SELECT aluno.DescDisciplina
                    , aluno.DescAssunto
                    , aluno.NomeAluno
                    , aluno.UsuarioID
                    , aluno.AssuntoID
                    , sum(aluno.Acertos) Acertos
                    , sum(aluno.TotalQuestoesAula) TotalQuestoes
                FROM (SELECT a.DescDisciplina
                            , a.DescAssunto
                            , a.TotalQuestoesAula
                            , a.NomeAluno
                            , a.UsuarioID
                            , a.AssuntoID
                            , a.VigenciaTurma
                            , sum(CASE WHEN Tipo IN ('Q') AND respostacorreta = 'S' THEN 1 ELSE 0 END) Acertos
                        FROM R001_RespostasQuestoes a
                        WHERE a.EscolaID = '976de9cb2ed34e6162f720eb10d399aa'
                        AND a.VigenciaTurma = '2017'
                        AND a.Tipo IN ('Q')
                        and month(a.DtCad) = month(now())
                        AND a.RespostaCorreta IS NOT NULL
                        GROUP BY a.DescDisciplina
                            , a.DescAssunto
                            , a.NomeAluno
                            , a.UsuarioID
                            , a.AssuntoID
                            , a.VigenciaTurma
                            , a.TotalQuestoesAula
                
                            UNION ALL
                
                        SELECT a.DescDisciplina
                            , a.DescAssunto
                            , a.TotalQuestoesAula
                            , a.NomeAluno
                            , a.UsuarioID
                            , a.AssuntoID
                            , a.VigenciaTurma
                            , sum(CASE WHEN Tipo IN ('R') AND respostacorreta = 'S' THEN 1 ELSE 0 END) Acertos
                        FROM R001_RespostasQuestoes a
                        WHERE a.EscolaID = '976de9cb2ed34e6162f720eb10d399aa'
                        AND a.VigenciaTurma = '2017'
                        AND a.Tipo IN ('R')
                        and month(a.DtCad) = month(now())
                        AND a.RespostaCorreta IS NOT NULL
                        GROUP BY a.DescDisciplina
                            , a.DescAssunto
                            , a.NomeAluno
                            , a.UsuarioID
                            , a.AssuntoID
                            , a.VigenciaTurma
                            , a.TotalQuestoesAula) aluno
                
                GROUP BY aluno.DescDisciplina
                    , aluno.DescAssunto
                    , aluno.NomeAluno
                    , aluno.UsuarioID
                    , aluno.AssuntoID
                    , aluno.VigenciaTurma";
        $resultado = $this->getAvaMySQL()->query($sql)->result();
        return $resultado;
    }

    public function getDisciplinas()
    {
        $dados = SaeDigital::make(TodosAsDisciplinas::class)->handle();
        $this->twigRender('disciplinas/lista.twig', ['dados' => $dados]);
    }

    public function novaDisciplina()
    {
        $series = SaeDigital::make(ListasDeSeriesAtivas::class)->handle();

        $this->twigRender('disciplinas/cadastrar.twig', ['series' => $series]);
    }

    /**
     * Salvamos a nova disciplina e efetuamos o relacionamento entra a disciplina e a aula.
     *
     * @throws Exception
     */
    public function salvarDisciplina()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            throw new Exception('method not allowed.', 405);
        }

        try {
            $this->allowProfile([Perfil::ADMIN]);

            $idsAssuntos = [];
            $idsAulas = [];

            SaeDigital::make(PDO::class)->beginTransaction();

            /** @var CadastraDisciplina $service */
            $service = SaeDigital::make(CadastraDisciplina::class);
            $userId = (int) $this->session->userdata('id');
            $record = $service->handle($this->input->post(), $userId);

            SaeDigital::make(RelacionaDisciplinaComSerie::class)->handle(
                $this->input->post('serie'),
                $record['GrupoAulaID'],
                $userId
            );

            /* Cadastrando no integraDB */
            SaeDigital::make(CadastraDisciplinaIntegraDb::class)->handle($record);

            if (!empty($this->input->post('disciplina_base'))) {

                $bimestres = SaeDigital::make(BimestresDaDisciplina::class)->handle(
                    $this->input->post('disciplina_base')
                );

                $novosBimestres = SaeDigital::make(DuplicarBimestre::class)->handle($bimestres, $userId);

                SaeDigital::make(RelacionaBimestreComDisciplina::class)->handle(
                    $novosBimestres,
                    $record['GrupoAulaID'],
                    $userId
                );

                foreach ($novosBimestres as $bimestre) {
                    $assuntos = SaeDigital::make(AssuntosPorBimestre::class)->handle($bimestre['reference']);
                    $idsAssuntos = SaeDigital::make(DuplicarAssunto::class)->handle($assuntos, $userId);

                    SaeDigital::make(RelacionaAssuntoComBimestre::class)->handle(
                        $idsAssuntos,
                        $bimestre['new'],
                        $userId
                    );

                    foreach ($idsAssuntos as $assunto) {
                        $listaAulas = SaeDigital::make(AulasPorAssunto::class)->handle($assunto['reference']);

                        $idsAulas = SaeDigital::make(DuplicarAula::class)->handle($listaAulas, $userId);

                        SaeDigital::make(RelacionaAulaComAssunto::class)->handle($idsAulas, $assunto['new'], $userId);

                        foreach ($idsAulas as $aula) {
                            $estrutura = SaeDigital::make(EstruturaQuestoes::class)->handle($aula['reference']);

                            if (!empty($estrutura)) {

                                $idEstruturas = SaeDigital::make(DuplicaEstruturaQuestoes::class)->handle(
                                    $estrutura,
                                    $aula['new'],
                                    $record['GrupoAulaID']
                                );

                                $questoes = SaeDigital::make(QuestoesDaEstrutura::class)->handle(
                                    $idEstruturas['reference']
                                );

                                SaeDigital::make(DuplicaQuestao::class)->handle($questoes, $idEstruturas['new']);
                            }
                        }

                    }
                }
            }

            SaeDigital::make(PDO::class)->commit();

            $statusCode = 201;
            $msg = &$this->input->post('disciplina');


        } catch (\Exception $e) {
            SaeDigital::make(PDO::class)->rollBack();

            $statusCode = 500;
            $msg = $e->getMessage() . ' :: ' . $e->getFile() . ' :: ' . $e->getLine();
        }

        $this->responseJson(['msg' => $msg], $statusCode);
    }

    public function pegaDisciplinasSerie()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $id = (int) $this->input->get('id');
            $result = [];

            try {
                $statusCode = 200;
                $dados = SaeDigital::make(DisciplinasDaSerie::class)->handle($id);

            } catch (\Exception $e) {
                $statusCode = 500;
                $dados = ['msg' => $e->getMessage()];
            }

            $this->responseJson($dados, $statusCode);
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    /**
     * Exibe a tela que a a opção de mover o assunto entre bimestres.
     */
    public function moverAssuntoPorBimestre()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $assuntoId = (int) $this->input->get('id');

            $bimestreAtual = SaeDigital::make(BimestreDoAssunto::class)->handle($assuntoId);
            $disciplina = SaeDigital::make(PegaDisciplinaDoAssunto::class)->handle($assuntoId);
            $bimestres = SaeDigital::make(BimestresDaDisciplina::class)->handle($disciplina['GrupoAulaID']);
            $assunto = SaeDigital::make(PegaAssuntoPeloId::class)->handle($assuntoId);
            $csrf = ['name' => $this->security->get_csrf_token_name(), 'hash' => $this->security->get_csrf_hash()];

            $this->twigRender('bimestres/moveAssuntoPorBimestre.twig', [
                'assunto' => $assunto,
                'bimestreAtual' => $bimestreAtual,
                'bimestres' => $bimestres,
                'csrf' => $csrf
            ]);
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function moverAssuntoPorBimestreUpdate()
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('method not allowed.', 405);
            }

            $assunto_id = (int) $this->input->post('assunto_id');
            $bimestre_new = (int) $this->input->post('bimestre_new');
            $bimestre_old = (int) $this->input->post('bimestre_old');

            try {
                $statusCode = 200;
                SaeDigital::make(MoveAssuntoParaBimestre::class)->handle($assunto_id, $bimestre_new, $bimestre_old);
                $dados = ['msg' => 'Dados atualizados com sucesso.'];

            } catch (\Exception $e) {
                $statusCode = 500;
                $dados = ['msg' => $e->getMessage()];
            }

            $this->responseJson($dados, $statusCode);
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }


    }

    // Abaixo funções importadas do integradb
    private function getDadosQuestoes($grupoAulaID = 0, $SubCategoriaAulaID = "")
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $sql = "SELECT 
                        E093.GrupoAulaID as Curso,
                        E093.Descricao as Desc_Curso, 
                        E089.SubCategoriaAulaID as Subcategoria_aula,
                        E089.Descricao  as Desc_Subcategoria_aula,
                        E068.AulaID as Aula,
                        E068.Tema,
                        E211.Autor,
                        E211.email,
                        E068.SITUACAO,
                        E068.Tipo
                    FROM E093_GruposAulas E093
                    JOIN E094_GruposCategoriasAulas E094
                        ON (E094.GrupoAulaID = E093.GrupoAulaID)
                    JOIN E090_CategoriasSubCategoriasAulas E090
                        ON (E090.CategoriaID = E094.CategoriaAulaID)
                    JOIN E089_SubCategoriasAulas E089
                        ON (E089.SubcategoriaAulaId = E090.SubcategoriaId)
                    INNER JOIN E091_AulasSubCategorias E091
                        ON (E091.SubcategoriaId = E090.SubcategoriaId)
                    INNER JOIN E068_Aulas E068
                        ON (E068.AulaID = E091.AulaID)
                    LEFT JOIN  E211_Autores E211 on  E211.AutorID = E089.Autor
                    WHERE  E093.GrupoAulaID IN (" . $this->getAvaMySQL()->escape_str($grupoAulaID) . " )";
            if ($SubCategoriaAulaID) {
                $sql .= "AND E089.SubCategoriaAulaID in (" . $this->getAvaMySQL()->escape_str($SubCategoriaAulaID) . ")";
            }
            $sql .= " AND E068.Tipo in('Q','R')
                    GROUP BY E093.GrupoAulaID, E093.Descricao ,E089.SubCategoriaAulaID,E089.Descricao,
                        E068.AulaID,E211.Autor, E068.Tema,E211.email,E068.Situacao,E068.Tipo
                    ORDER BY E093.GrupoAulaID";

            $query = $this->getAvaMySQL()->query($sql);

            return $query->result();
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    private function api_definir_estrutura($grupoAulaID, $subCat, $aulaID)
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $sql = "select *
                from E093_GruposAulas E093
                   , E094_GruposCategoriasAulas E094
                   , E088_CategoriasAulas E088
                   , E090_CategoriasSubCategoriasAulas E090
                   , E091_AulasSubCategorias E091
                   , E068_Aulas E068
                   , E089_SubCategoriasAulas E089
                where E093.GrupoAulaID = E094.GrupoAulaID
                and E094.CategoriaAulaID = E088.CategoriaAulaID
                and E088.CategoriaAulaID = E090.CategoriaID
                and E090.SubCategoriaID = E091.SubCategoriaID
                and E091.AulaId = E068.AulaID
                and E089.SubCategoriaAulaID = E090.SubCategoriaID

                and E093.GrupoAulaID = " . $grupoAulaID . "
                and E091.SubCategoriaID = " . $subCat . "
                and E068.Tipo in ('Q','R')
                and E068.AulaID in ('" . implode("','", $aulaID) . "')";
            $lastquer[] = $sql;
            $query = $this->getAvaMySQL()->query($sql)->result_array();

            foreach ($query as $key => $value) {
                $a = $this->VerificaInsertUpdateCursoDisciplina($subCat);
                if ($a) {
                    $sql = "insert into aprovaquestoes.curso_disciplina(id, nome, professor_avisado)  
                        values(" . $subCat . ", '" . str_replace("'", "\\'", $value['Descricao']) . "',0);";
                    $lastquer[] = $sql;
                    $this->getAvaMySQL()->query($sql);
                } else {
                    $dados2['Nome'] = $value['Descricao'];

                    $this->getAvaMySQL()->where("id = " . $subCat);
                    $this->getAvaMySQL()->update("aprovaquestoes.curso_disciplina", $dados2);
                }

                if ($this->VerificaInsertUpdateCursoCategoria($value['SubCategoriaAulaID'], $grupoAulaID)) {
                    $sql = "INSERT INTO aprovaquestoes.curso_categoria (curso_id,
                                                                    curso_disciplina_id)
                        VALUES
                        (" . $grupoAulaID . ",
                        " . $subCat . ")";
                    $lastquer[] = $sql;
                    $this->getAvaMySQL()->query($sql);
                }

                if ($this->VerificaInsertUpdateCA($value['AulaID'])) {
                    $sql = "INSERT INTO aprovaquestoes.curso_aula( id
                                              , nome
                                              , curso_disciplina_id
                                              , usuario_id
                                              , status
                                              , data_alteracao
                                              , tag_assunto
                                              , sem_questoes)
                        VALUES ( " . $value['AulaID'] . "
                               , '" . $value['Tema'] . "'
                               , " . $subCat . "
                               , 1
                               , 1
                               , NULL
                               , " . $value['SubCategoriaAulaID'] . "
                               , 0)";
                    $lastquer[] = $sql;
                    $this->getAvaMySQL()->query($sql);
                } else {
                }
            }

            $retorno['success'] = 1;
            $retorno['message'] = "Estrutura criada com sucesso!";
            $retorno['querys'] = $lastquer;

            return $retorno;
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    private function VerificaInsertUpdateCursoDisciplina($SubCategoriaAulaID)
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $sql = "select count(*) as qtd
                from aprovaquestoes.curso_disciplina ca 
              where ca.id = " . $SubCategoriaAulaID;

            $res = $this->getAvaMySQL()->query($sql)->result_array();

            return $res[0]['qtd'] == 0;
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }

    }

    private function VerificaInsertUpdateCursoCategoria($SubCategoriaAulaID, $grupoAulaId)
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);
            $sql = "select count(*) as qtd from aprovaquestoes.curso_categoria ca 
                where ca.curso_disciplina_id = " . $SubCategoriaAulaID . "
                and ca.curso_id = " . $grupoAulaId;
            $res = $this->getAvaMySQL()->query($sql)->result_array();

            return $res[0]['qtd'] == 0;
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }

    }

    private function VerificaInsertUpdateCA($AulaID)
    {
        try {
            $this->allowProfile([Perfil::ADMIN]);

            $sql = "select count(*) as qtd from aprovaquestoes.curso_aula where id = " . $AulaID;
            $res = $this->getAvaMySQL()->query($sql)->result_array();

            return $res[0]['qtd'] == 0;
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function getSeriesVersao()
    {
        try {
            $this->allowProfile([Perfil::ADMIN, Perfil::CONTEUDO]);

            $this->layout = false;
            $versao_conteudo = $this->input->post("versao_conteudo");
            $series = $this->cadastro->getSerie(null, $versao_conteudo);

            // json_encode($series);
            $this->responseJson($series, 200);
        } catch (Exception $e) {
            log_error($e->getMessage());
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function getDisciplinasSerie()
    {
        try {
            $this->allowProfile([Perfil::CONTEUDO, Perfil::ADMIN]);

            $this->layout = false;
            $versao_conteudo = $this->input->post("versao_conteudo");
            $serie = $this->input->post("serie");

            $disciplinas = $this->cadastro->getDadosDisciplina($serie, $versao_conteudo);

            $this->responseJson($disciplinas, 200);
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function createLogMarreta()
    {
        try {
            $data = [
                "created_date" => date("Y-m-d H:i:s"),
                "GrupoAulaID" => $this->input->post("grupoaula"),
                "CategoriaAulaID" => $this->input->post("bimestres"),
                "SubCategoriaAulaID" => $this->input->post("assuntos"),
                "Login" => $this->session->userdata('login')
            ];

            $this->getAvaMySQL()->insert("log_marreta", $data);

            $this->responseJson([], 200);
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    public function getLogMarreta()
    {
        try {
            $sql = "SELECT 
                        Log.created_date,
                        Log.Login,
                        E093.Descricao AS Disciplina,
                        E088.Descricao AS Bimestre,
                        E089.Descricao AS Assunto
                    FROM
                        avasae.log_marreta Log
                            LEFT JOIN
                        E093_GruposAulas E093 ON (Log.GrupoAulaID = E093.GrupoAulaID)
                            LEFT JOIN
                        E088_CategoriasAulas E088 ON (Log.CategoriaAulaID = E088.CategoriaAulaID)
                            LEFT JOIN
                        E089_SubCategoriasAulas E089 ON (Log.SubCategoriaAulaID = E089.SubCategoriaAulaID)
                    ORDER BY Log.id DESC
                    LIMIT 4";
            $data = $this->getAvaMySQL()->query($sql)->result_array();

            $this->responseJson(["data" => $data], 200);
        } catch (Exception $e) {
            $this->responseJson(['message' => 'Ocorreu um problema com sua requisição!'], 500);
        }
    }

    /**
     * getStructureForJarvis
     */
    public function getStructureForJarvis()
    {
        try {
            $versaoConteudoId = $this->input->get('versao_conteudo_id');

            if (empty($versaoConteudoId)) {
                throw new Exception('Versão de conteúdo não informada.');
            }

            $data = SaeDigital::make(JarvisMigration::class)->buildStructure($versaoConteudoId);

            $this->responseJson($data, 200);
        } catch (Exception $e) {
            $this->responseJson(['message' => $e->getMessage()], 400);
        }

    }

    /**
     * startFullContentVersionImport
     */
    public function startFullContentVersionImport()
    {
        try {
            $versaoConteudoId = $this->input->get('versao_conteudo_id');

            if (empty($versaoConteudoId)) {
                throw new Exception('Versão de conteúdo não informada.');
            }

            $data = SaeDigital::make(JarvisMigration::class)->handle($versaoConteudoId);

            $this->responseJson($data, 200);
        } catch (Exception $e) {
            $this->responseJson(['message' => $e->getMessage()], 400);
        }

    }
}
