<?php

use Ava\App\Services\Demonstrativo\CadastrarDemo;
use Ava\App\Services\Demonstrativo\CadastrarProfessorDemo;
use Ava\App\Services\Demonstrativo\ContasExpiradas;
use Ava\App\Services\Demonstrativo\DeletaContaDemonstrativo;
use Ava\App\Services\Demonstrativo\ExportaDemostrativos;
use Ava\App\Services\Demonstrativo\GetAll;
use Ava\App\Services\Demonstrativo\PegaDemonstrativosPorId;
use Ava\App\Support\Perfil;

/**
 * Controller responsável por gerenciar  todos os usuários demonstrativos da aplicação.
 */
class Demonstrativo extends MY_Controller
{
    public function indexAction()
    {
        $this->allowProfile(Perfil::ADMIN);

        $this->twigRender('demonstrativo/index.html.twig', [
            'contas' => SaeDigital::make(GetAll::class)->handle()
        ]);
    }

    public function newAction()
    {
        $this->allowProfile(Perfil::ADMIN);

        $this->twigRender('demonstrativo/new.html.twig', [
            'csrf' => [
                'name' => $this->security->get_csrf_token_name(),
                'hash' => $this->security->get_csrf_hash()
            ]
        ]);
    }

    public function storeAction()
    {
        $this->allowProfile(Perfil::ADMIN);
        $this->layout = false;

        $quantidade = (int) filter_input(INPUT_POST, 'quantidade', FILTER_SANITIZE_NUMBER_INT);
        $dia = (int) filter_input(INPUT_POST, 'dias', FILTER_SANITIZE_NUMBER_INT);
        $responsavel = (int) $this->session->userdata('pessoaid');

        try {
            SaeDigital::make(PDO::class)->beginTransaction();

            $ids = [];
            for ($i = 1; $i <= $quantidade; $i++) {
                $row = SaeDigital::make(CadastrarDemo::class)->handle($dia, $responsavel);
                SaeDigital::make(CadastrarProfessorDemo::class)->handle($row);
                //SaeDigital::make(CadastrarAlunoDemo::class)->handle($row);

                $ids[] = $row['id'];
            }

            SaeDigital::make(PDO::class)->commit();

            $this->redirect('/demonstravio/usuarios/preview?id=' . implode(',', $ids));

        } catch (PDOException $e) {
            SaeDigital::make(PDO::class)->rollBack();

        }
    }

    public function previewAction()
    {
        $this->allowProfile(Perfil::ADMIN);
        $this->layout = false;

        $ids = $this->input->get('id', true);

        $this->twigRender('demonstrativo/preview.html.twig', [
            'contas' => SaeDigital::make(PegaDemonstrativosPorId::class)->handle(explode(',', $ids)),
            'ids' => $ids
        ]);
    }

    public function exportAction()
    {
        $this->allowProfile(Perfil::ADMIN);
        $this->layout = false;

        $ids = $this->input->get('id', true);
        $date = (new DateTime())->format('dmY_His');

        $records = SaeDigital::make(PegaDemonstrativosPorId::class)->handle(explode(',', $ids));

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        //header("Content-type: application/octet-stream");
        header('Content-Disposition: attachment;filename="Contas_demonstrativas_'.$date.'.xlsx"');
        header('Cache-Control: max-age=0');

        echo SaeDigital::make(ExportaDemostrativos::class)->handle($records);

    }

    public function deleteAction()
    {
        $this->layout = false;

        try {
            $this->allowAuthorization('E384396387575D5578F09EA81C47A8DB544E46D76289E2412B1B125BAAB8D0AE');

            SaeDigital::make(PDO::class)->beginTransaction();

            $day = (new DateTime())->sub(new DateInterval('P1D'))->format('Y-m-d');
            $expirados = SaeDigital::make(ContasExpiradas::class)->handle($day);

            foreach ($expirados as $conta) {
                SaeDigital::make(DeletaContaDemonstrativo::class)->handle($conta);
            }

            SaeDigital::make(PDO::class)->commit();
            $this->responseJson(['msg' => 'Contas demostrativas deletas com sucesso', 'total' => count($expirados)]);

        } catch (\Exception $e) {
            SaeDigital::make(PDO::class)->rollBack();
            $this->responseJson(['msg' => $e->getMessage(), 'code' => $e->getCode()], $e->getCode());
        }
    }
}
