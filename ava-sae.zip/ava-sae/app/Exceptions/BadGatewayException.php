<?php

namespace Ava\App\Exceptions;

use Throwable;

class BadGatewayException extends \Exception
{
    const BAD_GATEWAY_CODE = 502;

    public function __construct($message = "", $code = 502, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
