<?php

namespace Ava\App\Exceptions;

use Exception;
use Throwable;

/**
 * Class StudentAnswerUpdateException
 * @package Ava\App\Exceptions
 */
class StudentAnswerUpdateException extends Exception
{
    /**
     * StudentAnswerUpdateException constructor.
     * @param string $message
     * @param int $code
     * @param Throwable|null $previous
     */
    public function __construct($message = "", $code = 0, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}