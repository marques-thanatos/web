<?php

namespace Ava\App\Exceptions;

use Exception;
use Throwable;

/**
 * Class FileNotFoundException
 *
 * @package Ava\App\Exceptions
 * @author Ronaldo Matos Rodrigues <ronaldo@whera.com.br>
 */
class FileNotFoundException extends Exception
{
    /**
     * @param string $path
     * @param int $code
     * @param Throwable $previous
     */
    public function __construct($path, $code = 400, Throwable $previous = null)
    {
        $message = sprintf("File '%s' not found", $path);

        parent::__construct($message, $code, $previous);
    }
}
