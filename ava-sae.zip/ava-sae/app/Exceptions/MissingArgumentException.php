<?php

namespace Ava\App\Exceptions;

use Exception;
use Throwable;

/**
 * Class MissingArgumentException
 * @package Ava\App\Exceptions
 */
class MissingArgumentException extends Exception
{
    /**
     * MissingArgumentException constructor.
     * @param string $message
     * @param int $code
     * @param Throwable|null $previous
     */
    public function __construct($message = "", $code = 0, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}