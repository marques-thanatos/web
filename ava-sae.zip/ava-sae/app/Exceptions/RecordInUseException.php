<?php

namespace Ava\App\Exceptions;

use RuntimeException;
use Throwable;

/**
 * Class RecordInUseException
 *
 * @package Ava\App\Exceptions
 */
class RecordInUseException extends RuntimeException
{
    /**
     * @param string $message
     * @param int $code
     * @param Throwable|null $previous
     */
    public function __construct($message = 'Record being used by other tables', $code = 400, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
