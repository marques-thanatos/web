<?php

namespace Ava\App\Aggregates;

/**
 * Class AbstractAggregate
 *
 * @package Ava\App\Aggregates
 */
abstract class AbstractAggregate
{

}
