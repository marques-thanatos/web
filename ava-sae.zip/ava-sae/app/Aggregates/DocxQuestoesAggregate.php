<?php

namespace Ava\App\Aggregates;

use Ava\App\Collections\GroupOfQuestionsCollection;
use DateTime;

/**
 * Class DocxQuestoesAggregate
 *
 * @package Ava\App\Aggregates
 */
class DocxQuestoesAggregate extends AbstractAggregate
{
    /**
     * @var string
     */
    private $editor;

    /**
     * @var DateTime
     */
    private $createdAt;

    /**
     * @var string
     */
    private $discipline;

    /**
     * @var string
     */
    private $courseware;

    /**
     * @var string
     */
    private $twoMonths;

    /**
     * @var string
     */
    private $subject;

    /**
     * @var GroupOfQuestionsCollection
     */
    private $groupOfQuestions;

    /**
     * @return string
     */
    public function getEditor()
    {
        return $this->editor;
    }

    /**
     * @param string $editor
     *
     * @return $this
     */
    public function setEditor($editor)
    {
        $this->editor = $editor;

        return $this;
    }

    /**
     * @return DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @param DateTime $createdAt
     *
     * @return $this
     */
    public function setCreatedAt(\DateTime $createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * @return string
     */
    public function getDiscipline()
    {
        return $this->discipline;
    }

    /**
     * @param string $discipline
     *
     * @return $this
     */
    public function setDiscipline($discipline)
    {
        $this->discipline = $discipline;

        return $this;
    }

    /**
     * @return string
     */
    public function getCourseware()
    {
        return $this->courseware;
    }

    /**
     * @param string $courseware
     *
     * @return $this
     */
    public function setCourseware($courseware)
    {
        $this->courseware = $courseware;

        return $this;
    }

    /**
     * @return string
     */
    public function getTwoMonths()
    {
        return $this->twoMonths;
    }

    /**
     * @param string $twoMonths
     *
     * @return $this
     */
    public function setTwoMonths($twoMonths)
    {
        $this->twoMonths = $twoMonths;

        return $this;
    }

    /**
     * @return string
     */
    public function getSubject()
    {
        return $this->subject;
    }

    /**
     * @param string $subject
     *
     * @return $this
     */
    public function setSubject($subject)
    {
        $this->subject = $subject;

        return $this;
    }


    /**
     * @return GroupOfQuestionsCollection
     */
    public function getGroupOfQuestions()
    {
        return $this->groupOfQuestions;
    }


    /**
     * @param GroupOfQuestionsCollection $groupOfQuestions
     *
     * @return $this
     */
    public function setGroupOfQuestions(GroupOfQuestionsCollection $groupOfQuestions)
    {
        $this->groupOfQuestions = $groupOfQuestions;

        return $this;
    }
}
