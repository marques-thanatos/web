<?php

namespace Ava\App\Objects\Requests;

use Swagger\Annotations as SWG;

/**
 * Class SchedulesUpdateRequest
 * @package Ava\App\ValueObjects\Requests
 *
 * @SWG\Definition(
 *     required={"dtInicio", "dtFim"},
 *     type="object",
 *     @SWG\Xml(name="SchedulesUpdateRequest"),
 * )
 */
class SchedulesUpdateRequest
{
    /**
     * @SWG\Property(type="string", required=true)
     * @var string
     */
    public $dtInicio;

    /**
     * @SWG\Property(type="string", required=true)
     * @var string
     */
    public $dtFim;

}
