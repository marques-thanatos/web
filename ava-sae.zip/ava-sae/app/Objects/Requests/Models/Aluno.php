<?php

namespace Ava\App\Objects\Requests\Models;

use Swagger\Annotations as SWG;

/**
 * @SWG\Definition(
 *     required={"idAluno"},
 *     type="object",
 *     @SWG\Xml(name="Aluno")
 * )
 */
class Aluno
{
    /**
     * @SWG\Property(
     *     type="string",
     *     required=true,
     * )
     * @var string
     */
    public $idAluno;

    /**
     * @SWG\Property(
     *     type="string",
     *     required=true,
     * )
     * @var string
     */
    public $idTurma;

}
