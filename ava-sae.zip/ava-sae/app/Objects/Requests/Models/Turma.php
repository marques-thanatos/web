<?php

namespace Ava\App\Objects\Requests\Models;

use Swagger\Annotations as SWG;

/**
 * @SWG\Definition(
 *     required={"idTurma"},
 *     type="object",
 *     @SWG\Xml(name="Turma")
 * )
 */
class Turma
{

    /**
     * @SWG\Property(
     *     type="string",
     *     required=true
     * )
     * @var string
     */
    public $idTurma;

}
