<?php

namespace Ava\App\Objects\Requests\Models;

use Swagger\Annotations as SWG;

/**
 * @SWG\Definition(
 *     required={"idAssunto"},
 *     type="object",
 *     @SWG\Xml(name="modulo")
 * )
 */
class Modulo
{

    /**
     * @SWG\Property(
     *     type="string",
     *     required=true,
     * )
     * @var string
     */
    public $idAssunto;

}
