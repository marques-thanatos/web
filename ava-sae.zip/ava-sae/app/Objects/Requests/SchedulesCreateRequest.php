<?php

namespace Ava\App\Objects\Requests;

use Swagger\Annotations as SWG;

/**
 * Class SchedulesCreateRequest
 * @package Ava\App\ValueObjects\Requests
 *
 * @SWG\Definition(
 *     required={"turmas", "alunos", "dtInicio", "dtFim", "modulos", "idSerie", "$idComponenteCurricular"},
 *     type="object",
 *     @SWG\Xml(name="SchedulesCreateRequest"),
 * )
 */
class SchedulesCreateRequest
{
    /**
     * @SWG\Property(type="string", required=true)
     * @var string
     */
    public $dtInicio;

    /**
     * @SWG\Property(type="string", required=true)
     * @var string
     */
    public $dtFim;

    /**
     * @SWG\Property(type="integer", required=true)
     * @var int
     */
    public $idSerie;

    /**
     * @SWG\Property(type="integer", required=true)
     * @var int
     */
    public $idComponenteCurricular;

    /**
     * @SWG\Property(
     *     type="array",
     *     @SWG\Xml(name="Alunos", wrapped=true),
     *     @SWG\Items(ref="#/definitions/Aluno")
     * )
     *
     * @var array
     */
    public $alunos;

    /**
     * @SWG\Property(
     *     type="array",
     *     required=false,
     *     @SWG\Xml(name="Turmas", wrapped=true),
     *     @SWG\Items(ref="#/definitions/Turma")
     * )
     *
     * @var array
     */
    public $turmas;

    /**
     * @SWG\Property(
     *     type="array",
     *     @SWG\Xml(name="Modulos", wrapped=true),
     *     @SWG\Items(ref="#/definitions/Modulo")
     * )
     *
     * @var array
     */
    public $modulos;

    /**
     * @SWG\Property(type="boolean")
     *
     * @var boolean
     */
    public $videoaula;

    /**
     * @SWG\Property(type="boolean")
     *
     * @var boolean
     */
    public $review;

}
