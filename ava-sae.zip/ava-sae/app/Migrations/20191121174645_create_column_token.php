<?php

use Phinx\Migration\AbstractMigration;

class CreateColumnToken extends AbstractMigration
{
    public function up()
    {
        $this->table('D023_Ava_Sae_Configuracoes')->addColumn('tokenEscolaMov', 'string', ['default'=>null])
            ->save();
    }
    public function down()
    {
        $this->table('D023_Ava_Sae_Configuracoes')->removeColumn('tokenEscolaMov');
    }
}