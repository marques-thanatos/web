<?php


use Phinx\Migration\AbstractMigration;

class AddColumnJarvisVersionIdToVersaoConteudo extends AbstractMigration
{
    public function up()
    {
        $this->table('versao_conteudo')
            ->addColumn('jarvis_version_id', 'integer', ['null' => true, 'default' => null])
            ->save();
    }

    public function down()
    {
        $this->table('versao_conteudo')->removeColumn('jarvis_version_id');
    }
}

