<?php


use Phinx\Migration\AbstractMigration;

class CreateColumnAmbienteEscola extends AbstractMigration
{
    public function up()
    {
        $this->table('D023_Ava_Sae_Configuracoes')->addColumn('AmbienteEEM', 'string', ['limit' => 255,'default'=>null])
            ->save();
    }
    public function down()
    {
        $this->table('D023_Ava_Sae_Configuracoes')->removeColumn('AmbienteEEM');
    }
}
