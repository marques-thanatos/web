<?php

use Phinx\Migration\AbstractMigration;

class CreateTableFaqCategoriasFaqs extends AbstractMigration
{
    public function up()
    {
        $this->table('faqCategorias_faqs')
            ->addColumn('faqCategoria_id', 'integer')
            ->addColumn('faq_id', 'integer')
            ->addForeignKey('faqCategoria_id', 'faqCategorias', 'id')
            ->addForeignKey('faq_id', 'faqs', 'id')
            ->create();
    }

    public function down()
    {
        $this->dropTable('faqCategorias_faqs');
    }
}
