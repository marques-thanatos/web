<?php

use Phinx\Migration\AbstractMigration;

class CreateTableFaqs extends AbstractMigration
{
    public function up()
    {
        $this->table('faqs')
            ->addColumn('pergunta','string')
            ->addColumn('resposta','text')
            ->addColumn('criado_em','datetime')
            ->addColumn('ordem', 'integer', ['default' => 1])
            ->addColumn('ativo', 'boolean', ['default' => 1])
            ->addColumn('responsavel_id', 'integer')
            ->create();
    }

    public function down()
    {
        $this->dropTable('faqs');
    }
}
