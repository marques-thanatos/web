<?php


use Phinx\Migration\AbstractMigration;

class CreateNotificacoesTable extends AbstractMigration
{
    public function up()
    {
        $this->table('notificacoes')
            ->addColumn('login','string')
            ->addColumn('escola_id','string', ['null' => true, 'default' => null])
            ->addColumn('tipo_notificacao_id','integer')
            ->addColumn('json','text', ['null' => true, 'default' => null])
            ->addColumn('data_inicio','datetime')
            ->addColumn('data_fim','datetime')
            ->addColumn('lido', 'datetime', ['null' => true, 'default' => null])
            ->addForeignKey('tipo_notificacao_id', 'tipo_notificacoes', 'id')
            ->save();
    }
}
