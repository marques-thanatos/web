<?php


use Phinx\Migration\AbstractMigration;

class LinkDigitalBook extends AbstractMigration
{
    public function up()
    {
        $this->table('link_livro_digital')
            ->addColumn('descricao', 'string')
            ->addColumn('link', 'string')
            ->addColumn('sistema_operacional', 'string')
            ->addColumn('arquitetura', 'string')
            ->addColumn('criado_em','datetime')
            ->create();
    }

    public function down()
    {
        $this->dropTable('link_livro_digital');
    }
}
