<?php


use Phinx\Migration\AbstractMigration;

class UpdateColumnIdProtheusFromIntToString extends AbstractMigration
{
    /**
     * Migrate Up.
     */
    public function up()
    {
        $this->table('D023_Ava_Sae_Configuracoes')
            ->changeColumn('IdProtheus', 'string', ['limit' => 255, 'default' => null])
            ->save();
    }

    /**
     * Migrate Down.
     */
    public function down()
    {
        $this->table('D023_Ava_Sae_Configuracoes')
            ->changeColumn('IdProtheus', 'integer', ['default' => 0])
            ->save();
    }
}
