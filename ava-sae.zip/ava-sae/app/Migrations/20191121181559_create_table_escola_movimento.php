<?php


use Phinx\Migration\AbstractMigration;

class CreateTableEscolaMovimento extends AbstractMigration
{
    public function up()
    {
        $this->table('EscolaMovimento')
            ->addColumn('alunoid','string')
            ->addColumn('alunora','string')
            ->addColumn('turma','string')
            ->addColumn('escolaid', 'string', ['default' => 1])
            ->addColumn('ativo', 'boolean', ['default' => 1])
            ->create();
    }

    public function down()
    {
        $this->dropTable('EscolaMovimento');
    }
}

