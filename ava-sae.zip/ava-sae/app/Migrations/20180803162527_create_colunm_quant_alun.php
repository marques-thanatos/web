<?php


use Phinx\Migration\AbstractMigration;

class CreateColunmQuantAlun extends AbstractMigration
{
    public function up()
    {
         $this->table('D019_Ava_Sae')->addColumn('QuantAlunos', 'integer', ['default'=>0])
            ->save();
    }
    public function down()
    {
        $this->table('D019_Ava_Sae')->removeColumn('QuantAlunos');
    }
}
