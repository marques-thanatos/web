<?php


use Phinx\Migration\AbstractMigration;

class CreateColumnPorcentagem extends AbstractMigration
{
    public function up()
    {
        $this->table('D023_Ava_Sae_Configuracoes')->addColumn('Porcentagem', 'float', ['default'=>0])
            ->save();
    }
    public function down()
    {
        $this->table('D023_Ava_Sae_Configuracoes')->removeColumn('Porcentagem');
    }
}

