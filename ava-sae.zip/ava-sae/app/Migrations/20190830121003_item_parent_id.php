<?php


use Phinx\Migration\AbstractMigration;

class ItemParentId extends AbstractMigration
{
    public function up()
    {
        $this->table('E359_AulaQuestoes')->addColumn('is_parent', 'boolean')->save();
    }
}
