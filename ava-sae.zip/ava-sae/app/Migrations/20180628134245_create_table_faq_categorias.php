<?php


use Phinx\Migration\AbstractMigration;

class CreateTableFaqCategorias extends AbstractMigration
{
    public function up()
    {
        $this->table('faqCategorias')
            ->addColumn('codigo','string')
            ->addColumn('nome','string')
            ->addColumn('criado_em','datetime')
            ->addColumn('responsavel_id', 'integer')
            ->addColumn('ativo', 'boolean', ['default' => 1])
            ->create();
    }

    public function down()
    {
        $this->dropTable('faqCategorias');
    }
}
