<?php

use Phinx\Migration\AbstractMigration;

class CreateDemonstrativoTable extends AbstractMigration
{
    public function up()
    {
        $this->table('demonstrativos')
            ->addColumn('codigo','string')
            ->addColumn('criado_em','datetime')
            ->addColumn('expira_em','date')
            ->addColumn('responsavel_id', 'integer')
            ->save();
    }
    public function down()
    {
        $this->dropTable('demonstrativos');
    }
}
