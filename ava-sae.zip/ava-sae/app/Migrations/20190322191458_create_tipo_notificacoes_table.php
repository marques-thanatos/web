<?php


use Phinx\Migration\AbstractMigration;

class CreateTipoNotificacoesTable extends AbstractMigration
{
    public function up()
    {
        $this->table('tipo_notificacoes')
            ->addColumn('descricao','string')
            ->addColumn('template','text')
            ->addColumn('status', 'boolean', ['default' => 1])
            ->addColumn('criado_em', 'datetime')
            ->save();
    }

    public function down()
    {
        $this->dropTable('tipo_notificacoes');
    }
}
