<?php


use Phinx\Migration\AbstractMigration;

class CreateLogMarreta extends AbstractMigration
{
    public function up()
    {
        $this->table('log_marreta')
            ->addColumn('created_date','datetime')
            ->addColumn('GrupoAulaID','integer')
            ->addColumn('CategoriaAulaID','integer')
            ->addColumn('SubCategoriaAulaID', 'integer')
            ->addColumn('Login', 'string')
            ->save();
    }
    public function down()
    {
        $this->dropTable('log_marreta');
    }
}