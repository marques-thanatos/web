<?php

// Padrao do CI para não acessar a Classe direto pelo Browser
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Layout Class
 *
 * @package hooks
 * @description Implementa as views do tipo layout no framework.
 */
class Layout {

    public $base_url;
    public $base_urlCSS;
    public $base_urlJS;

    /**
     * Metodo que executa as implementacoes.
     * Este metodo e chamado atraves do arquivo hooks.php
     * na pasta config.
     *
     * @return
     */
    public function init() {
        // Instancia do CI.
        $CI = & get_instance();

        // Definindo o base_url.        
        $this->base_url = $CI->config->slash_item('base_url');
        $this->base_urlJS  = 'http://js.iesde.com.br/ava.aprovaconcursos.com.br/';
        
        // Pegando a saida que o CI gera normalmente.
        $output = $CI->output->get_output();

        // Pegando o valor de title, se definido no controller.
        $title = (isset($CI->title)) ? $this->createTitle($CI->title) : '';

        // Descriptions for SEO.
        $description = (isset($CI->description)) ? $this->createDescription($CI->description) : '';

        // Keywords for SEO.
        $keywords = (isset($CI->keywords)) ? $this->createKeywords($CI->keywords) : '';

        // Analytics
        $analytics = (isset($CI->analytics)) ? $CI->analytics : '';

        $header = (isset($CI->header)) ? $CI->header : '';
        $menu_vertical = (isset($CI->menu_vertical)) ? $CI->menu_vertical : '';
        $footer = (isset($CI->footer)) ? $CI->footer : '';

        // Links CSS definidos no controlador.
        $css = (isset($CI->css)) ? $this->createCSSLinks($CI->css) : '';
        // antes geral $cssGeral = (isset($CI->cssGeral)) ? $this->createCSSLinks($CI->cssGeral, PATH_CSS_GERAL) : $css;

        // Links JS definidos no controlador.
        $js = (isset($CI->js)) ? $this->createJSLinks($CI->js) : '';

        // Se layout estiver definido e a regexp nao bater.
        if (isset($CI->layout) && !preg_match('/(.+).php$/', $CI->layout)) {
            $CI->layout .= '.php';
        } else {
            $CI->layout = 'default.php';
        }

        // Definindo caminho completo do layout.
        $layout = LAYOUTPATH . $CI->layout;

        // Se o layout for diferente do default, e o arquivo nao existir.
        if ($CI->layout !== 'default.php' && !file_exists($layout)) {
        // Exibe a mensagem, se o layout for diferente de '.php'.
            if ($CI->layout != '.php')
                show_error("You have specified a invalid layout: " . $CI->layout);
        }

        // Se o arquivo layout existir.
        if (file_exists($layout)) {
            // Carrega o conteudo do  arquivo.
            $layout = $CI->load->file($layout, true);

            // Substitui o texto {content_for_layout} pelo valor de output em layout.
            $view = str_replace('{content_for_layout}', $output, $layout);
            
            //configurando conte�dos 
            $view = str_replace('{menu_vertical_for_layout}', $menu_vertical, $view);
            $view = str_replace('{header_for_layout}', $header, $view);

            // Substitui o texto {title_for_layout} pelo valor de title em view.
            $view = str_replace('{title_for_layout}', $title, $view);

            $view = str_replace('{descriptions_for_layout}', $description, $view);

            // Keywords SEO.
            $view = str_replace('{keywords_for_layout}', $keywords, $view);

            $view = str_replace('{analytics_for_layout}', $analytics, $view);

            //configurando conte�dos     
            $view = str_replace('{header_for_layout}', $header, $view);
            $view = str_replace('{footer_for_layout}', $footer, $view);

            // Links CSS.
            $view = str_replace('{css_for_layout}', $css, $view);
			// antes geral $view = str_replace('{css_for_layout}', $css.$cssGeral, $view);

            // Links JS.
            $view = str_replace('{js_for_layout}', $js, $view);
        } else {
            $view = $output;
        }
        
        echo $view;
    }

    /**
     * Gera os links CSS utilizados no layout.
     *
     * @return void
     */
	//antes geral private function createCSSLinks($links, $path = PATH_CSS_SITE) {
    private function createCSSLinks($links) {
       
        $html = "";

        for ($i = 0; $i < count($links); $i++) {
            $html .= "<link rel='stylesheet' type='text/css' href='" . PATH_CSS_SITE . '' . $links[$i] . ".css?".VERSIONCSSCDN."' media='all' />";
            // antes geral $html .= "<link rel='stylesheet' type='text/css' href='". $path . $links[$i] . ".css' media='screen' />";
                
        }

        return $html;
    }

    /**
     * Gera os links JS utilizados no layout.
     *
     * @return void
     */
    private function createJSLinks($links) {
        $html = "";

        for ($i = 0; $i < count($links); $i++) {
            $html .= "<script type='text/javascript' sync='false' src='" . PATH_JS_SITE . '' . $links[$i] . ".js?".VERSIONJSCDN."'></script>";
        }

        return $html;
    }
    
    /**
     * Gera meta tag contendo a descrição do titulo.
     * 
     * @return void
     */
    private function createTitle($title) {
        $html = '<meta name="title" content="' . $title . '" />';
        $html .= '<title>' . $title . '</title>';

        return $html;
    }

    /**
     * Gera a meta tag Description para SEO.
     * 
     * @return void
     */
    private function createDescription($desc) {
        $html = '<meta name="description" content="';

        $html .= $desc;

        $html .= '" />';

        return $html;
    }

    /**
     *  Gera a meta tag keywords para SEO.
     * 
     * @return void
     */
    private function createKeywords($words) {
        $html = '<meta name="keywords" content="';

        for ($i = 0; $i < count($words); $i++) {
            if ($i > 0) {
                $html .= ', ';
            }

            $html .= $words[$i];
        }

        $html .= '" />';

        return $html;
    }

}
