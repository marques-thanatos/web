<?php

namespace Ava\App\Domain\Controllers;

use Ava\App\Exceptions\NotAllowedException;
use Ava\App\Exceptions\NotImplementedException;
use Ava\App\Services\Monitoramento\Sentry;
use Ava\App\Support\Perfil;
use Illuminate\Contracts\Cache\Store;
use CI_Controller;
use CI_Input;
use CI_Loader;
use CI_Output;
use CI_Session;
use Raven_ErrorHandler;
use SaeDigital;

/**
 * @property CI_Session session
 * @property CI_Input input
 * @property CI_Output output
 * @property CI_Loader load
 */
class BaseController extends CI_Controller
{
    /**
     * @var bool
     */
    public $layout = false;

    /**
     * @var bool
     */
    public $loginRequired = true;

    /**
     * BaseController constructor.
     */
    public function __construct()
    {
        parent::__construct();

        $sentryClient = SaeDigital::make(Sentry::class)->handle();

        $error_handler = new Raven_ErrorHandler($sentryClient);
        $error_handler->registerExceptionHandler();
        $error_handler->registerErrorHandler();

        $this->load->helper('log_helper');

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            log_system_action("Requisição AJAX em {$this->uri->uri_string}");
        } else {
            log_user_action("Entrou na página {$this->uri->uri_string}");
        }

        if ($this->loginRequired) {
            $this->checkForLogin();
        }
    }

    /**
     * @param array $body
     * @param int $statusCode
     * @return CI_Output
     */
    protected function responseJson(array $body, $statusCode = 200)
    {
        return $this->output
            ->set_content_type('application/json')
            ->set_status_header($statusCode)
            ->set_output(\GuzzleHttp\json_encode($body));
    }

    /**
     * Checks if user is logged using jwt token or session.
     */
    private function checkForLogin()
    {
        try {
            $jwtToken = $this->input->get_request_header('Authorization') ?: $this->input->get('token');

            if ($jwtToken) {
                $valid = $this->validateJwtAuthorization($jwtToken);

                if (!$valid) {
                    throw new \Exception('Não autorizado.');
                }
            }

            if (!$this->session->userdata('logado')) {
                throw new \Exception('Não autorizado.');
            }
        } catch (NotImplementedException $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        } catch (\Exception $e) {
            return $this->responseJson([
                'success' => false,
                'message' => $e->getMessage()
            ], 401);
        }
    }

    /**
     * @param string $jwtToken
     * @throws NotImplementedException
     */
    private function validateJwtAuthorization($jwtToken)
    {
        throw new NotImplementedException('Login via JWT não implementado.');
    }

    /**
     * @param int|array $profiles
     * @return bool
     * @throws NotAllowedException
     */
    protected function allowProfile($profiles)
    {
        if (!is_array($profiles)) {
            $profiles = (array)$profiles;
        }

        $myProfile = $this->session->userdata('perfil');

        if (!in_array($myProfile, $profiles)) {
            if ($myProfile == Perfil::ALUNO) {
                $this->redirect('/aluno');
                die;
            } else if ($myProfile == Perfil::RESPONSAVEL) {
                $this->redirect('/responsavel');
                die;
            } else if ($myProfile == Perfil::PROFESSOR) {
                $this->redirect('/professor');
                die;
            } else if ($myProfile == Perfil::COORDENADOR) {
                $this->redirect('/coordenador');
                die;
            } else {
                throw new NotAllowedException("Access denied for this page", 403);
            }
        }

        return true;
    }

    /**
     * Loads cache instance from container.
     * @return Store
     */
    protected function cache()
    {
        return SaeDigital::make('cache');
    }
}
