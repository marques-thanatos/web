INSERT INTO versao_conteudo (descricao, status, responsavel, criado_em, atualizado_em, jarvis_version_id)
VALUES (:descricao, :status, :responsavel, NOW(), NOW(), :jarvis_version_id);
