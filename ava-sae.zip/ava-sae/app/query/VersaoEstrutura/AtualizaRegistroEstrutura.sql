UPDATE versao_conteudo
SET descricao=:descricao, status=:status, responsavel=:responsavel, atualizado_em=NOW()
WHERE id=:id
LIMIT 1
