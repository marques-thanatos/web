SELECT
    E093.*
FROM
    E093_GruposAulas AS E093
        INNER JOIN
    T002_SeriesDisciplinas AS T002 ON (T002.DisciplinaID = E093.GrupoAulaID)
        INNER JOIN
    T001_Series AS T001 ON (T001.SerieID = T002.SerieID)
WHERE
    T002.versao_conteudo_id = :estrutura
        AND T001.ID = :serie_id
        AND E093.Situacao = :situacao
        AND E093.GrupoAulaID <> 30791