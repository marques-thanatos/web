SELECT
    VersaoConteudo.id,
    VersaoConteudo.descricao,
    VersaoConteudo.status,
    Usuario.Nome AS responsavel,
    VersaoConteudo.criado_em,
    VersaoConteudo.atualizado_em
FROM
    versao_conteudo VersaoConteudo
        INNER JOIN
    D019_Ava_Sae Usuario ON (Usuario.id = VersaoConteudo.responsavel)