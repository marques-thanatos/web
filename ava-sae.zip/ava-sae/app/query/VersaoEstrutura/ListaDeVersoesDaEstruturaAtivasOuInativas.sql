SELECT
    *
FROM
    versao_conteudo
WHERE
    status = :status
