SELECT
    COUNT(id)
FROM
    D019_Ava_Sae
WHERE
    Perfil = :perfil AND versao_conteudo_id = :versao
        AND Situacao = :situacao