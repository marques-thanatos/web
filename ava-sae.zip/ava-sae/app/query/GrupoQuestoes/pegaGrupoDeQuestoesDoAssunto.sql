SELECT
  MIN(e359.QuestaoID) AS grupo_id,
  e068.Tipo
FROM E358_EstruturaAulasQuestoes e358
  INNER JOIN E359_AulaQuestoes e359 ON e358.EstruturaAulaID = e359.EstruturaAulaID
  INNER JOIN E068_Aulas e068 ON e068.AulaID = e358.AulaID
WHERE e358.SubCategoriaID = :assunto_id AND e068.Tipo = :tipo
GROUP BY e359.GrupoSimilar