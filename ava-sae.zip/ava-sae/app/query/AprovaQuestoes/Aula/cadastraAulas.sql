INSERT INTO aprovaquestoes.curso_aula (id, nome,curso_disciplina_id,usuario_id,status,tag_assunto,sem_questoes)
VALUES (:id, :nome, :assunto_id, 1, 1, :tag, 0);
