INSERT INTO `aprovaquestoes`.`curso_disciplina` (`id`, `nome`, `professor_avisado`, `status`, `assunto_id`)
VALUES (:id, :nome, :professor_avisado, :status, :assunto_id)