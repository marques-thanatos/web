INSERT INTO `aprovaquestoes`.`curso_categoria` (`curso_id`, `curso_disciplina_id`) VALUES (:disciplina_id, :assunto_id)
