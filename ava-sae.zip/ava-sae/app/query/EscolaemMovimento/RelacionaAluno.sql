INSERT INTO EscolaMovimento (
    alunoid,
    alunora,
    turma,
    escolaid,
    ativo
)
VALUES (
    :alunoid,
    :alunora,
    :turma,
    :escolaid,
    1
)