SELECT UsuarioID, DisciplinaID
FROM
    R001_RespostasQuestoes respostas 
    WHERE
  ( YEAR(respostas.DtCad) = 2020 OR YEAR(respostas.DtCad) = 2021 )
