SELECT
    SUM(DISTINCT IF(agenda.AlunoID IS NOT NULL, 1, 0)) as agendamentoAluno,
    SUM(DISTINCT IF(agenda.TurmaID IS NOT NULL AND agenda.AlunoID IS NULL, 1, 0)) as agendamentoTurma,
    schedule.DisciplinaID idDisciplina,
    CASE
        WHEN POSITION('Extensivo' IN discipline.Descricao) > 0 THEN TRIM(SUBSTRING_INDEX(discipline.Descricao, ':', -1))
        ELSE TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(REPLACE(REPLACE(discipline.Descricao, 'SAE - ', ''), ' - EM', ''), ':', 1), ' -', 1))
        END descDisciplina,
    schedule.FrenteID idBimestre,
    TRIM(SUBSTRING_INDEX(period.Descricao, ':', -1)) descBimestre,
    schedule.AssuntoID idAssunto,
    module.Descricao descAssunto,
    schedule.AlunoID idAluno,
    IF(COUNT(answer.RespostaQuestaoReforcoID) = SUM(IF(answer.Resposta IS NOT NULL, 1, 0)) AND COUNT(answer.RespostaQuestaoReforcoID) > 0, 1, 0) fezAtividade,
    CASE
        WHEN
                (COUNT(answer.RespostaQuestaoReforcoID) = SUM(IF(answer.Resposta IS NOT NULL, 1, 0))) AND COUNT(answer.RespostaQuestaoReforcoID) > 0
            THEN
                ROUND((SUM(IF(answer.Resposta IS NOT NULL AND answer.RespostaCorreta = 'S', 1, 0)) / SUM(IF(answer.Resposta IS NOT NULL, 1, 0))), 3) * 100
        ELSE 0
    END desempenho,
    config.Porcentagem porcentagem
FROM
    D024_Ava_Sae_Agenda schedule
        INNER JOIN E089_SubCategoriasAulas module ON schedule.AssuntoID = module.SubCategoriaAulaID
        INNER JOIN D023_Ava_Sae_Configuracoes config ON (schedule.EscolaID = config.EscolaID AND config.Tipo = 'G')
        INNER JOIN E090_CategoriasSubCategoriasAulas module_period ON module.SubCategoriaAulaID = module_period.SubCategoriaID
        INNER JOIN E088_CategoriasAulas period ON module_period.CategoriaID = period.CategoriaAulaID
        INNER JOIN E094_GruposCategoriasAulas period_discipline ON period.CategoriaAulaID = period_discipline.CategoriaAulaID
        INNER JOIN E093_GruposAulas discipline ON period_discipline.GrupoAulaID = discipline.GrupoAulaID
        LEFT JOIN R002_RespostasQuestoesReforco answer ON (
                module.SubCategoriaAulaID = answer.AssuntoID
                AND period.CategoriaAulaID = answer.FrenteID
                AND discipline.GrupoAulaID = answer.DisciplinaID
                AND schedule.AlunoID = answer.UsuarioID
                AND YEAR(answer.DtCad) = YEAR(NOW())
        )
WHERE
    schedule.AlunoID IS NOT NULL
      AND ( YEAR(schedule.DtCad) = 2020 OR YEAR(schedule.DtCad) = 2021 )
      AND schedule.DisciplinaID = :idDisciplina
      AND discipline.ClassificacaoID = :idClassificacao