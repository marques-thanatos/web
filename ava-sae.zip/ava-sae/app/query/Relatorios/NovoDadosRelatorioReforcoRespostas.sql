SELECT
    answer.AssuntoID idAssunto,
    answer.UsuarioID idAluno,
    IF(COUNT(answer.RespostaQuestaoReforcoID) = SUM(IF(answer.Resposta IS NOT NULL, 1, 0)) AND COUNT(answer.RespostaQuestaoReforcoID) > 0, 1, 0) fezAtividade,
    CASE
        WHEN
                (COUNT(answer.RespostaQuestaoReforcoID) = SUM(IF(answer.Resposta IS NOT NULL, 1, 0))) AND COUNT(answer.RespostaQuestaoReforcoID) > 0
            THEN
                ROUND((SUM(IF(answer.Resposta IS NOT NULL AND answer.RespostaCorreta = 'S', 1, 0)) / SUM(IF(answer.Resposta IS NOT NULL, 1, 0))), 3) * 100
        ELSE 0
    END desempenho,
    config.Porcentagem porcentagem
FROM R002_RespostasQuestoesReforco answer 
    LEFT JOIN D023_Ava_Sae_Configuracoes config ON (answer.EscolaID = config.EscolaID AND config.Tipo = 'G')
WHERE
    ( YEAR(answer.DtCad) = 2020 OR YEAR(answer.DtCad) = 2021 )