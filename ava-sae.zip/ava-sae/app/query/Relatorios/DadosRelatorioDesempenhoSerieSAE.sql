SELECT
	agenda.DisciplinaID idDisciplina,
	agenda.FrenteID idBimestre,
  agenda.AssuntoID idAssunto,
  aluno.itemName idAluno,
  turma.itemName idTurma,
  turma.Descricao descTurma,
  turma.EscolaID idEscola,
	agenda.DtInicio dataInicio,
	agenda.DtFim dataFim,
	(
	  SELECT
      mediaRelatorioTotalAlunos
    FROM
        D023_Ava_Sae_Configuracoes
    WHERE
        EscolaID = :idEscolaConfig AND Tipo = 'G'
  ) mediaRelatorioTotalAlunos,
  COALESCE(
		GREATEST(
			CASE
				WHEN
					SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'Q', 1, 0))
				THEN
					ROUND(SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)) * 100, 1)
				ELSE 0
			END,
			CASE
				WHEN
					SUM(IF(respostas.Tipo = 'R' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'R', 1, 0))
				THEN
					ROUND(SUM(IF(respostas.Tipo = 'R' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'R', 1, 0)) * 100, 1)
				ELSE 0
			END
		),
	0) desempenho,
  CASE
    WHEN
      SUM(IF(respostas.Tipo = 'Q', 1, 0)) > 0
    THEN
      SUM(IF(respostas.Tipo = 'Q', 1, 0)) = SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0))
    ELSE 0
  END fezAtividade
FROM
    D024_Ava_Sae_Agenda agenda
		INNER JOIN D021_Ava_Sae_Turmas turma ON (agenda.TurmaID = turma.itemName AND turma.Situacao = :ativo AND (turma.Vigencia = 2020 OR turma.Vigencia = 2021))
		INNER JOIN D019_Ava_Sae aluno ON (turma.itemName = aluno.Turma AND aluno.Perfil = :perfilAluno AND aluno.Situacao = :ativo)
    INNER JOIN E093_GruposAulas disciplina ON (agenda.DisciplinaID = disciplina.GrupoAulaID AND disciplina.ClassificacaoID = :idClassificacao)
    INNER JOIN T002_SeriesDisciplinas disciplina_serie ON (
        disciplina.GrupoAulaID = disciplina_serie.DisciplinaID
          AND disciplina_serie.versao_conteudo_id = aluno.versao_conteudo_id
    )
    LEFT JOIN R001_RespostasQuestoes respostas ON (
			agenda.EscolaID = respostas.EscolaID
				AND agenda.DisciplinaID = respostas.DisciplinaID
				AND agenda.AssuntoID = respostas.AssuntoID
				AND agenda.FrenteID = respostas.FrenteID
				AND turma.SerieID = respostas.SerieID
				AND turma.itemName = respostas.TurmaID
        AND aluno.Escola = respostas.EscolaID
				AND aluno.itemName = respostas.UsuarioID
				AND respostas.Situacao = :ativo
		)
WHERE
	agenda.DtFim IS NOT NULL
    AND agenda.DtFim <> ''
    AND agenda.DtInicio IS NOT NULL
    AND agenda.DtInicio <> ''
    AND turma.SerieID = :idSerie
    AND agenda.DisciplinaID = :idDisciplina
    AND ( YEAR(agenda.DtInicio) = 2020 OR YEAR(agenda.DtInicio) = 2021 )
GROUP BY turma.SerieID, agenda.DisciplinaID, agenda.FrenteID, agenda.AssuntoID, aluno.itemName
