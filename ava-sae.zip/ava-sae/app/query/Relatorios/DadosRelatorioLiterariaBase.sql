SELECT
	agenda.DisciplinaID idDisciplina,
  TRIM(disciplina.Descricao) descDisciplina,
	agenda.FrenteID idBimestre,
  TRIM(bimestre.Descricao) descBimestre,
  agenda.AssuntoID idAssunto,
  TRIM(assunto.Descricao) descAssunto,
  aluno.itemName idAluno,
  TRIM(aluno.Nome) nomeAluno,
  turma.itemName idTurma,
  turma.Descricao descTurma,
  turma.EscolaID idEscola,
	agenda.DtInicio dataInicio,
	agenda.DtFim dataFim,
	config.mediaRelatorioTotalAlunos,
	CASE
    WHEN LOCATE('quiz 1', assunto.Descricao) > 0 THEN 'Q1'
    WHEN LOCATE('quiz 2', assunto.Descricao) > 0 THEN 'Q2'
    WHEN LOCATE('quiz 3', assunto.Descricao) > 0 THEN 'Q3'
    WHEN LOCATE('discursiva', assunto.Descricao) > 0 THEN 'D1'
    WHEN LOCATE('aluno 1', assunto.Descricao) > 0 THEN 'V1'
    WHEN LOCATE('produção de texto', assunto.Descricao) > 0 THEN 'V2'
	END tipo,
	COALESCE(config.Meta, 75) metaQuestoes,
  COALESCE(
    CASE
      WHEN
        SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'Q', 1, 0))
      THEN
        ROUND(SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)) * 100, 1)
      ELSE 0
    END, 0
	) desempenho,
	COALESCE(
    CASE
      WHEN
        SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'Q', 1, 0))
      THEN
        ROUND(SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)) * 100, 1)
      ELSE 0
    END, 0
	) mediaQuestoes,
  CASE
    WHEN
      SUM(IF(respostas.Tipo = 'Q', 1, 0)) > 0
    THEN
      SUM(IF(respostas.Tipo = 'Q', 1, 0)) = SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0))
    ELSE 0
  END fezAtividade,

	SUM(IF(respostas.Tipo = 'Q', 1, 0)) totalQuestoes,
	SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) totalQuestoesRespondidas,
	SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) totalQuestoesAcertos,

  SUM(IF(discursivas.Resposta IS NOT NULL AND discursivas.Resposta <> '', 1, 0)) > 0 fezAtividadeDiscursiva,
  SUM(COALESCE(discursivas.Nota, 0)) / SUM(IF(discursivas.RespostaID IS NOT NULL, 1, 0)) desempenhoDiscursiva,
  SUM(IF(discursivas.Nota IS NOT NULL, 1, 0)) > 0 discursivaCorrigida,

	SUM(IF(respostas.Tipo = 'N', 1, 0)) totalVideos,
	SUM(IF(respostas.Tipo = 'N', respostas.PercentualVideo, 0)) percentualVideo,
	CASE
    WHEN
      SUM(IF(respostas.Tipo = 'N', respostas.PercentualVideo, 0)) =
      COALESCE(ROUND(SUM(IF(respostas.Tipo = 'N', respostas.Meta, 0)) / SUM(IF(respostas.Tipo = 'N', 1, 0)), 0), 100)
    THEN 1
    ELSE 0
  END videoAssistido,
	COALESCE(ROUND(SUM(IF(respostas.Tipo = 'N', respostas.Meta, 0)) / SUM(IF(respostas.Tipo = 'N', 1, 0)), 0), 100) metaVideo,
	COALESCE(ROUND(SUM(IF(respostas.Tipo = 'Q', respostas.Meta, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)), 0), 75) metaQuestao
FROM
    D024_Ava_Sae_Agenda agenda
		INNER JOIN D021_Ava_Sae_Turmas turma ON (agenda.TurmaID = turma.itemName AND turma.Situacao = :ativo AND (turma.Vigencia = 2020 OR turma.Vigencia = 2021))
		INNER JOIN D019_Ava_Sae aluno ON (turma.itemName = aluno.Turma AND aluno.Perfil = :perfilAluno AND aluno.Situacao = :ativo)
    INNER JOIN E093_GruposAulas disciplina ON (agenda.DisciplinaID = disciplina.GrupoAulaID AND disciplina.ClassificacaoID = :idClassificacao)
    INNER JOIN E089_SubCategoriasAulas assunto ON agenda.AssuntoID = assunto.SubCategoriaAulaID
		INNER JOIN D023_Ava_Sae_Configuracoes config ON (turma.EscolaID = config.EscolaID AND config.Tipo = 'G')
		INNER JOIN E088_CategoriasAulas bimestre ON agenda.FrenteID = bimestre.CategoriaAulaID
		LEFT JOIN SAE_Respostas_Questoes_Discursivas discursivas ON (
			aluno.itemName = discursivas.AlunoID
				AND turma.itemName = discursivas.TurmaID
        AND assunto.SubCategoriaAulaID = discursivas.AssuntoID
        AND disciplina.GrupoAulaID = discursivas.GrupoAulaID
        AND discursivas.Situacao = 'A'
		)
    LEFT JOIN R001_RespostasQuestoes respostas ON (
			agenda.EscolaID = respostas.EscolaID
				AND agenda.DisciplinaID = respostas.DisciplinaID
				AND agenda.AssuntoID = respostas.AssuntoID
				AND agenda.FrenteID = respostas.FrenteID
				AND turma.SerieID = respostas.SerieID
				AND turma.itemName = respostas.TurmaID
        AND aluno.Escola = respostas.EscolaID
				AND aluno.itemName = respostas.UsuarioID
				AND respostas.Situacao = :ativo
		)
WHERE
	agenda.DtFim IS NOT NULL
    AND agenda.DtFim <> ''
    AND agenda.DtInicio IS NOT NULL
    AND agenda.DtInicio <> ''
    AND turma.itemName = :itemNameTurma
    AND turma.EscolaID = :itemNameEscola
    AND agenda.DisciplinaID = :idDisciplina
    AND ( YEAR(agenda.DtInicio) = 2020 OR YEAR(agenda.DtInicio) = 2021 )