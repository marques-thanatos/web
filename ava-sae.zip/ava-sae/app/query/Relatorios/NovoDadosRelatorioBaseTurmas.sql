-- QueryID: 96ec671a-0e3b-415f-8708-34620ccaf71b
SELECT
       agenda.tipo_agendamento,
    SUM(DISTINCT IF(agenda.AlunoID IS NOT NULL, 1, 0)) as agendamentoAluno,
    SUM(DISTINCT IF(agenda.TurmaID IS NOT NULL AND agenda.AlunoID IS NULL, 1, 0)) as agendamentoTurma,
 agenda.DisciplinaID idDisciplina,
  TRIM(disciplina.Descricao) descDisciplina,
 agenda.FrenteID idBimestre,
  TRIM(bimestre.Descricao) descBimestre,
  agenda.AssuntoID idAssunto,
  TRIM(assunto.Descricao) descAssunto,
  agenda.AlunoID idAlunoAgenda,
  respostas.UsuarioID idAluno,
  agenda.TurmaID idTurma,
  agenda.EscolaID idEscola,
 agenda.DtInicio dataInicio,
 agenda.DtFim dataFim,
  COALESCE(
  GREATEST(
   CASE
       WHEN (bimestre.Descricao LIKE '%videoaula%' OR bimestre.Descricao LIKE '%video aula%') = 1
                    THEN SUM(IF(respostas.Tipo = 'N', respostas.PercentualVideo, 0))
    WHEN
     SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'Q', 1, 0))
    THEN
     ROUND(SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)) * 100, 1)
    ELSE 0
   END,
   CASE
       WHEN (bimestre.Descricao LIKE '%videoaula%' OR bimestre.Descricao LIKE '%video aula%') = 1
                    THEN SUM(IF(respostas.Tipo = 'N', respostas.PercentualVideo, 0))
    WHEN
     SUM(IF(respostas.Tipo = 'R' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'R', 1, 0))
    THEN
     ROUND(SUM(IF(respostas.Tipo = 'R' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'R', 1, 0)) * 100, 1)
    ELSE 0
   END
  ),
 0) desempenho,
 COALESCE(
 CASE
    WHEN
      SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'Q', 1, 0))
    THEN
      ROUND(SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)) * 100, 1)
    ELSE 0
  END, 0
 ) mediaQuestoes,
  COALESCE(
  CASE
    WHEN
      SUM(IF(respostas.Tipo = 'R' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'R', 1, 0))
    THEN
      ROUND(SUM(IF(respostas.Tipo = 'R' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'R', 1, 0)) * 100, 1)
    ELSE 0
  END, 0
  ) mediaRevisoes,

  CASE
    WHEN
      (bimestre.Descricao LIKE '%videoaula%' OR bimestre.Descricao LIKE '%video aula%') = 1
    THEN
      SUM(IF(respostas.Tipo = 'N', respostas.PercentualVideo, 0)) > 1
    WHEN
      SUM(IF(respostas.Tipo = 'Q', 1, 0)) > 0
    THEN
      SUM(IF(respostas.Tipo = 'Q', 1, 0)) = SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0))
    ELSE 0
  END fezAtividade,

  CASE
    WHEN
      SUM(IF(respostas.Tipo = 'R', 1, 0)) > 0
    THEN
      SUM(IF(respostas.Tipo = 'R', 1, 0)) = SUM(IF(respostas.Tipo = 'R' AND respostas.Resposta IS NOT NULL, 1, 0))
    ELSE 0
  END fezRevisoes,

 SUM(IF(respostas.Tipo = 'Q', 1, 0)) totalQuestoes,
 SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) totalQuestoesRespondidas,
 SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) totalQuestoesAcertos,

 SUM(IF(respostas.Tipo = 'R', 1, 0)) totalRevisoes,
 SUM(IF(respostas.Tipo = 'R' AND respostas.Resposta IS NOT NULL, 1, 0)) totalRevisoesRespondidas,
 SUM(IF(respostas.Tipo = 'R' AND respostas.RespostaCorreta = 'S', 1, 0)) totalRevisoesAcertos,

 SUM(IF(respostas.Tipo = 'N', 1, 0)) totalVideos,
 SUM(IF(respostas.Tipo = 'N', respostas.PercentualVideo, 0)) percentualVideo,
    (bimestre.Descricao LIKE '%videoaula%' OR bimestre.Descricao LIKE '%video aula%') = 1 videoAula,
 CASE
    WHEN
      SUM(IF(respostas.Tipo = 'N', respostas.PercentualVideo, 0)) =
      COALESCE(ROUND(SUM(IF(respostas.Tipo = 'N', respostas.Meta, 0)) / SUM(IF(respostas.Tipo = 'N', 1, 0)), 0), 100)
    THEN 1
    ELSE 0
  END videoAssistido,
 COALESCE(ROUND(SUM(IF(respostas.Tipo = 'N', respostas.Meta, 0)) / SUM(IF(respostas.Tipo = 'N', 1, 0)), 0), 100) metaVideo,
 COALESCE(ROUND(SUM(IF(respostas.Tipo = 'Q', respostas.Meta, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)), 0), 75) metaQuestao
FROM
    D024_Ava_Sae_Agenda agenda
    INNER JOIN E093_GruposAulas disciplina ON (agenda.DisciplinaID = disciplina.GrupoAulaID AND disciplina.ClassificacaoID = 10)
    INNER JOIN E089_SubCategoriasAulas assunto ON agenda.AssuntoID = assunto.SubCategoriaAulaID
  INNER JOIN E088_CategoriasAulas bimestre ON agenda.FrenteID = bimestre.CategoriaAulaID
    LEFT JOIN R001_RespostasQuestoes respostas ON (
   agenda.DisciplinaID = respostas.DisciplinaID
    AND agenda.AssuntoID = respostas.AssuntoID
    AND agenda.FrenteID = respostas.FrenteID
    AND agenda.TurmaID = respostas.TurmaID
    AND respostas.Situacao = :ativo
  )
WHERE
 agenda.DtFim IS NOT NULL
    AND agenda.DtFim <> ''
    AND agenda.DtInicio IS NOT NULL
    AND agenda.DtInicio <> ''
    AND ( YEAR(agenda.DtInicio) = 2020 OR YEAR(agenda.DtInicio) = 2021 )
    AND agenda.AlunoID IS NULL