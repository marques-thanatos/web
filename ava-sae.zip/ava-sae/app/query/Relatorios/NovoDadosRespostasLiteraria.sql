SELECT
  respostas.UsuarioID idAluno,
  respostas.AssuntoID idAssunto,
  respostas.TurmaID,
  config.mediaRelatorioTotalAlunos,

CASE
    WHEN LOCATE('quiz 1', assunto.Descricao) > 0 THEN 'Q1'
    WHEN LOCATE('quiz 2', assunto.Descricao) > 0 THEN 'Q2'
    WHEN LOCATE('quiz 3', assunto.Descricao) > 0 THEN 'Q3'
    WHEN LOCATE('discursiva', assunto.Descricao) > 0 THEN 'D1'
    WHEN LOCATE('aluno 1', assunto.Descricao) > 0 THEN 'V1'
    WHEN LOCATE('produção de texto', assunto.Descricao) > 0 THEN 'V2'
	END tipo,
	COALESCE(config.Meta, 75) metaQuestoes,
  COALESCE(
    CASE
      WHEN
        SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'Q', 1, 0))
      THEN
        ROUND(SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)) * 100, 1)
      ELSE 0
    END, 0
	) desempenho,
	COALESCE(
    CASE
      WHEN
        SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) = SUM(IF(respostas.Tipo = 'Q', 1, 0))
      THEN
        ROUND(SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)) * 100, 1)
      ELSE 0
    END, 0
	) mediaQuestoes,
  CASE
    WHEN
      SUM(IF(respostas.Tipo = 'Q', 1, 0)) > 0
    THEN
      SUM(IF(respostas.Tipo = 'Q', 1, 0)) = SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0))
    ELSE 0
  END fezAtividade,

	SUM(IF(respostas.Tipo = 'Q', 1, 0)) totalQuestoes,
	SUM(IF(respostas.Tipo = 'Q' AND respostas.Resposta IS NOT NULL, 1, 0)) totalQuestoesRespondidas,
	SUM(IF(respostas.Tipo = 'Q' AND respostas.RespostaCorreta = 'S', 1, 0)) totalQuestoesAcertos,

	SUM(IF(respostas.Tipo = 'N', 1, 0)) totalVideos,
	SUM(IF(respostas.Tipo = 'N', respostas.PercentualVideo, 0)) percentualVideo,
	CASE
    WHEN
      SUM(IF(respostas.Tipo = 'N', respostas.PercentualVideo, 0)) =
      COALESCE(ROUND(SUM(IF(respostas.Tipo = 'N', respostas.Meta, 0)) / SUM(IF(respostas.Tipo = 'N', 1, 0)), 0), 100)
    THEN 1
    ELSE 0
  END videoAssistido,
	COALESCE(ROUND(SUM(IF(respostas.Tipo = 'N', respostas.Meta, 0)) / SUM(IF(respostas.Tipo = 'N', 1, 0)), 0), 100) metaVideo,
	COALESCE(ROUND(SUM(IF(respostas.Tipo = 'Q', respostas.Meta, 0)) / SUM(IF(respostas.Tipo = 'Q', 1, 0)), 0), 75) metaQuestao

FROM
    R001_RespostasQuestoes respostas 
    INNER JOIN D023_Ava_Sae_Configuracoes config ON (respostas.EscolaID = config.EscolaID AND config.Tipo = 'G')
    INNER JOIN E093_GruposAulas disciplina ON (respostas.DisciplinaID = disciplina.GrupoAulaID AND disciplina.ClassificacaoID = 11)
    INNER JOIN E089_SubCategoriasAulas assunto ON respostas.AssuntoID = assunto.SubCategoriaAulaID
    INNER JOIN E088_CategoriasAulas bimestre ON respostas.FrenteID = bimestre.CategoriaAulaID
WHERE
  ( YEAR(respostas.DtCad) = 2020 OR YEAR(respostas.DtCad) = 2021 )
