SELECT
discursivas.AlunoID idAluno, discursivas.AssuntoID idAssunto, discursivas.TurmaID, config.mediaRelatorioTotalAlunos, 'D1' AS tipo,

  SUM(IF(discursivas.Resposta IS NOT NULL AND discursivas.Resposta <> '', 1, 0)) > 0 fezAtividadeDiscursiva,
  AVG(discursivas.Nota) desempenhoDiscursiva,
  SUM(IF(discursivas.Nota IS NOT NULL, 1, 0)) > 0 discursivaCorrigida

FROM 
   SAE_Respostas_Questoes_Discursivas discursivas
   INNER JOIN D023_Ava_Sae_Configuracoes config ON (discursivas.EscolaID = config.EscolaID AND config.Tipo = 'G')
		
WHERE

discursivas.TurmaID = :itemNameTurma

GROUP BY discursivas.AlunoID, discursivas.AssuntoID