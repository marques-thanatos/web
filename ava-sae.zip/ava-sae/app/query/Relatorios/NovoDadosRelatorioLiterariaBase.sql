  SELECT
      agenda.tipo_agendamento,
      SUM(DISTINCT IF(agenda.AlunoID IS NOT NULL, 1, 0)) as agendamentoAluno,
      SUM(DISTINCT IF(agenda.TurmaID IS NOT NULL AND agenda.AlunoID IS NULL, 1, 0)) as agendamentoTurma,
      agenda.DisciplinaID idDisciplina,
      TRIM(disciplina.Descricao) descDisciplina,
      agenda.FrenteID idBimestre,
      TRIM(bimestre.Descricao) descBimestre,
      agenda.AssuntoID idAssunto,
      TRIM(assunto.Descricao) descAssunto,
      agenda.FrenteID frenteID,
      agenda.AlunoID idAlunoAgenda,
      agenda.TurmaID idTurma,
      agenda.EscolaID idEscola,
      agenda.DtInicio dataInicio,
      agenda.DtFim dataFim,
      disciplina.SerieID,

    CASE
    WHEN LOCATE('quiz 1', assunto.Descricao) > 0 THEN 'Q1'
    WHEN LOCATE('quiz 2', assunto.Descricao) > 0 THEN 'Q2'
    WHEN LOCATE('quiz 3', assunto.Descricao) > 0 THEN 'Q3'
    WHEN LOCATE('discursiva', assunto.Descricao) > 0 THEN 'D1'
    WHEN LOCATE('aluno 1', assunto.Descricao) > 0 THEN 'V1'
    WHEN LOCATE('produção de texto', assunto.Descricao) > 0 THEN 'V2'
	END tipo 

  FROM
      D024_Ava_Sae_Agenda agenda  
      INNER JOIN E093_GruposAulas disciplina ON (agenda.DisciplinaID = disciplina.GrupoAulaID AND disciplina.ClassificacaoID = 11)
      INNER JOIN E089_SubCategoriasAulas assunto ON agenda.AssuntoID = assunto.SubCategoriaAulaID
      INNER JOIN D023_Ava_Sae_Configuracoes config ON (config.Tipo = 'G')
      INNER JOIN E088_CategoriasAulas bimestre ON agenda.FrenteID = bimestre.CategoriaAulaID
  WHERE
      agenda.DtFim IS NOT NULL
      AND agenda.DtFim <> ''
      AND agenda.DtInicio IS NOT NULL
      AND agenda.DtInicio <> ''
      AND ( YEAR(agenda.DtInicio) = 2020 OR YEAR(agenda.DtInicio) = 2021 )
