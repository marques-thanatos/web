INSERT INTO E090_CategoriasSubCategoriasAulas (
    CategoriaSubCategoriaAulaID,
    CategoriaID,
    SubCategoriaID,
    UsuarioCad,
    DtCad,
    UsuarioAlt,
    DtAlt,
    EscolaID,
    Ordem
)
VALUES (
    :newId,
    :bimestre,
    :assunto,
    :UsuarioCad,
    NOW(),
    :UsuarioAlt,
    NOW(),
    :escola_id,
    :ordem
)