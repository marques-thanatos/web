SELECT
    E089.*
FROM
    E089_SubCategoriasAulas E089
WHERE
    E089.jarvisModuleID = :jarvisModuleID
