SELECT
    E089.*, E090.Ordem
FROM
    E090_CategoriasSubCategoriasAulas E090
        INNER JOIN
    E089_SubCategoriasAulas E089 ON (E089.SubCategoriaAulaID = E090.SubCategoriaID)
WHERE
    E090.CategoriaID = :bimestre