UPDATE E089_SubCategoriasAulas
SET
  Descricao = :Descricao,
  DtAlt = NOW()
WHERE
  SubCategoriaAulaID = :SubCategoriaAulaID
