SELECT
    e068.*
FROM
    E091_AulasSubCategorias e091
        INNER JOIN
    E068_Aulas e068 ON (e068.AulaID = e091.AulaId)
WHERE
    e091.SubCategoriaID = :assunto
ORDER BY e068.AulaID ASC