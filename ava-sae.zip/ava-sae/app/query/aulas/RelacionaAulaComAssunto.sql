INSERT INTO E091_AulasSubCategorias (
	AulaSubCategoriaID,
    AulaId,
    SubCategoriaID,
    UsuarioCad,
    DtCad,
    UsuarioAlt,
    DtAlt
)
VALUES (
	  :newId,
    :AulaId,
    :AssuntoId,
    :UsuarioCad,
    NOW(),
    :UsuarioAlt,
    NOW()
)