SELECT
    COUNT(e093.GrupoAulaID) aulaPertenceSerie
FROM
    E093_GruposAulas e093
		INNER JOIN E094_GruposCategoriasAulas e094 ON e093.GrupoAulaID = e094.GrupoAulaID
		INNER JOIN E088_CategoriasAulas e088 ON e088.CategoriaAulaID = e094.CategoriaAulaID
		INNER JOIN E090_CategoriasSubCategoriasAulas e090 ON e088.CategoriaAulaID = e090.CategoriaID
		INNER JOIN E091_AulasSubCategorias e091 ON e090.SubCategoriaID = e091.SubCategoriaID
WHERE
	e091.AulaId = :idAula
		AND e093.ClassificacaoID = 12
		AND e093.Situacao = 'A'
		AND (e093.SerieID = :idSerie OR e093.SerieID LIKE :idSerie2 OR e093.SerieID LIKE :idSerie3 OR e093.SerieID LIKE :idSerie4);