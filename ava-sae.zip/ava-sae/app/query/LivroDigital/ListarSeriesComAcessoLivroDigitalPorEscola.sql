SELECT
    configEscola.id, serie.Descricao, configEscola.ExibeMenuLD
FROM
    D021_Ava_Sae_Turmas turma
    INNER JOIN D023_Ava_Sae_Configuracoes configEscola ON (turma.EscolaID = configEscola.EscolaID AND turma.SerieID = configEscola.Serie)
    INNER JOIN T001_Series serie ON turma.SerieID = serie.SerieID
WHERE
	turma.EscolaID = :idEscola
    AND (turma.Vigencia = 2020 OR turma.Vigencia = 2021)
    AND serie.CategoriaID IN (1, 2, 8)
    AND serie.versao_conteudo_id = :idVersaoConteudo
    AND turma.Situacao = 'A'
GROUP BY serie.SerieID
ORDER BY turma.DescricaoCategoriaTurma, turma.DescricaoSerie;