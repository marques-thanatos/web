SELECT
    turma.itemName turma, turma.SerieID, config.id, config.itemName, config.Serie, config.Meta
FROM
    D021_Ava_Sae_Turmas turma
        INNER JOIN T001_Series serie ON serie.SerieID = turma.SerieID
        LEFT JOIN D023_Ava_Sae_Configuracoes config ON (turma.EscolaID = config.EscolaID AND turma.SerieID = config.Serie)
WHERE
    turma.EscolaID = :idEscola
        AND (turma.Vigencia = 2020 OR turma.Vigencia = 2021)
        AND serie.CategoriaID IN (1 , 2, 8)
        AND serie.versao_conteudo_id = :idVersaoConteudo
        AND turma.Situacao = 'A'
GROUP BY turma.SerieID;
