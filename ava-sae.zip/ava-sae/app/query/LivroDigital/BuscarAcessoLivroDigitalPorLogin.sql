SELECT
   SUM(CASE
        WHEN
            config.perfil = :perfilAluno
        THEN
            (config.acessoGeral = 'S' AND config.exibeGeral = 'S' AND config.exibeSerie = 'S' AND config.acessoAluno = 1)
       ELSE
            config.acessoGeral = 'S' AND config.exibeGeral = 'S'
    END) > 0 acessoLD
FROM
   (SELECT
        usuario.Perfil perfil, configGeral.AcessoLD acessoGeral, configGeral.ExibeMenuLD exibeGeral, configSerie.ExibeMenuLD exibeSerie, usuario.acessoLD acessoAluno
    FROM
        D019_Ava_Sae usuario
        INNER JOIN D021_Ava_Sae_Turmas turma ON (usuario.Turma = turma.itemName AND (turma.Vigencia = 2020 OR turma.Vigencia = 2021) AND turma.Situacao = :situacao)
        INNER JOIN T001_Series serie ON (turma.SerieID = serie.SerieID AND serie.CategoriaID IN (1, 2, 3, 4, 8) AND serie.versao_conteudo_id = usuario.versao_conteudo_id)
        INNER JOIN D023_Ava_Sae_Configuracoes configGeral ON (usuario.Escola = configGeral.EscolaID AND configGeral.Tipo = 'G')
        INNER JOIN D023_Ava_Sae_Configuracoes configSerie ON (turma.EscolaID = configSerie.EscolaID AND configSerie.tipo = 'S' AND configSerie.Serie = turma.SerieID)
    WHERE
        usuario.Login = :login
        AND usuario.Situacao = :situacao
        AND usuario.Perfil <> :perfilResponsavel
        AND usuario.Perfil = :perfilUsuario
    UNION ALL
    SELECT
        usuario.Perfil perfil, configGeral.AcessoLD acessoGeral, configGeral.ExibeMenuLD exibeGeral, configSerie.ExibeMenuLD exibeSerie, usuario.acessoLD acessoAluno
    FROM
        D019_Ava_Sae usuario
        INNER JOIN D021_Ava_Sae_Turmas turma ON (usuario.Categoria = turma.CategoriaTurmaID AND (turma.Vigencia = 2020 OR turma.Vigencia = 2021) AND turma.Situacao = :situacao)
        INNER JOIN T001_Series serie ON (turma.SerieID = serie.SerieID AND serie.CategoriaID IN (1, 2, 3, 4, 8) AND serie.versao_conteudo_id = usuario.versao_conteudo_id)
        INNER JOIN D023_Ava_Sae_Configuracoes configGeral ON (usuario.Escola = configGeral.EscolaID AND configGeral.Tipo = 'G')
        INNER JOIN D023_Ava_Sae_Configuracoes configSerie ON (turma.EscolaID = configSerie.EscolaID AND configSerie.tipo = 'S' AND configSerie.Serie = turma.SerieID)
    WHERE
        usuario.Login = :login
        AND usuario.Situacao = :situacao
        AND usuario.Perfil <> :perfilResponsavel
        AND usuario.Perfil = :perfilUsuario) config