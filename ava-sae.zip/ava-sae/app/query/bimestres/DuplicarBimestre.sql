INSERT INTO E088_CategoriasAulas (
  CategoriaAulaID,
  Descricao,
  UsuarioCad,
  DtCad,
  UsuarioAlt,
  DtAlt,
  ClassificacaoID,
  CMS )
  SELECT
    :newId, Descricao,:UsuarioCad, NOW(), :UsuarioAlt, NOW(), ClassificacaoID, CMS FROM E088_CategoriasAulas
  WHERE CategoriaAulaID = :bimestre_id LIMIT 1