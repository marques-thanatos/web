SELECT
    E088.*, E094.Ordem
FROM
    E094_GruposCategoriasAulas E094
        INNER JOIN
    E088_CategoriasAulas E088 ON (E088.CategoriaAulaID = E094.CategoriaAulaID)
WHERE
    E094.GrupoAulaID = :disciplina