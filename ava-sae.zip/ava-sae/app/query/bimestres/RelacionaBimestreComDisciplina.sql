INSERT INTO E094_GruposCategoriasAulas (
          GrupoCategoriaID, GrupoAulaID, CategoriaAulaID, UsuarioID, DtCad, DtAlt, Ordem) 
          VALUE (:GrupoCategoriaID, :GrupoAulaID, :CategoriaAulaID, :UsuarioID, NOW(), NOW(), :Ordem)