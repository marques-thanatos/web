SELECT
    e088.*
FROM
    E088_CategoriasAulas e088
        INNER JOIN
    E090_CategoriasSubCategoriasAulas e090 ON (e090.CategoriaID = e088.CategoriaAulaID)
WHERE
    e090.SubCategoriaID = :assunto_id;