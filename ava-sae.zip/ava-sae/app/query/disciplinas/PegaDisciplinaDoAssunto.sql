SELECT
    e093.*
FROM
    E088_CategoriasAulas e088
        INNER JOIN
    E090_CategoriasSubCategoriasAulas e090 ON (e090.CategoriaID = e088.CategoriaAulaID)
        INNER JOIN
    E094_GruposCategoriasAulas e094 ON (e094.CategoriaAulaID = e088.CategoriaAulaID)
        INNER JOIN
    E093_GruposAulas e093 ON (e093.GrupoAulaID = e094.GrupoAulaID)
WHERE
    e090.SubCategoriaID = :assunto_id;
