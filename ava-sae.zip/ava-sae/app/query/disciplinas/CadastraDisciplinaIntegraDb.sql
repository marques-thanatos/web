INSERT INTO aprovaquestoes.curso (id, nome, data_alteracao, data_cadastro, curso_status_id)
values (:id, :nome, NOW(), NOW(), :status)