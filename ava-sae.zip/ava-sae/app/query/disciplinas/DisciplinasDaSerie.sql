SELECT
    E093.*
FROM
    T002_SeriesDisciplinas T002
        INNER JOIN
    E093_GruposAulas E093 ON (E093.GrupoAulaID = T002.DisciplinaID)
WHERE
    T002.SerieID = :serie
        AND E093.ClassificacaoID IN (10 , 11, 12)
        AND E093.Situacao = 'A'
        AND NOW() BETWEEN E093.Dtinicio AND E093.DtFim
