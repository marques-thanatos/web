SELECT
    *
FROM
    E358_EstruturaAulasQuestoes
WHERE
    AulaID = :AulaID;