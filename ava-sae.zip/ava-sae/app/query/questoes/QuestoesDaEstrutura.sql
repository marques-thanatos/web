SELECT
    *
FROM
    E359_AulaQuestoes
WHERE
    EstruturaAulaID = :EstruturaAulaID;