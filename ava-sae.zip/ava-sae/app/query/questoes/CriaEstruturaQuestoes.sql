INSERT INTO E358_EstruturaAulasQuestoes (
    EstruturaAulaID,
    GrupoAulaID,
    SubCategoriaID,
    AulaID,
    Situacao,
    DtCad,
    DtAlt,
    ExisteQuestao
)
VALUES (
    :newId,
    :GrupoAulaID,
    :SubCategoriaID,
    :AulaID,
    :Situacao,
    NOW(),
    NOW(),
    1
)