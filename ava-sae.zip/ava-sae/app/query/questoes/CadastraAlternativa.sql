INSERT INTO aprovaquestoes.questao_opcao_resposta (opcao, valor_opcao, opcao_correta, status, questao_id)
VALUES (:opcao, :valor_opcao, :opcao_correta, :status, :questao_id)