INSERT INTO E359_AulaQuestoes (
    AulaQuestaoID,
    EstruturaAulaID,
    QuestaoID,
    Situacao,
    DtCad,
    DtAlt,
    itemName,
    Similar,
    GrupoSimilar
)
SELECT
    :newId,
    :estruturaId,
    QuestaoID,
    Situacao,
    NOW(),
    NOW(),
    itemName,
    Similar,
    GrupoSimilar
FROM
    E359_AulaQuestoes
WHERE
    AulaQuestaoID = :questaoId
