INSERT INTO E358_EstruturaAulasQuestoes (
    EstruturaAulaID,
    GrupoAulaID,
    SubCategoriaID,
    AulaID,
    Situacao,
    DtCad,
    DtAlt
)
VALUES (
    :EstruturaAulaID,
    :GrupoAulaID,
    :SubCategoriaID,
    :AulaID,
    :Situacao,
    NOW(),
    NOW()
)