SELECT
    *
FROM
    D023_Ava_Sae_Configuracoes
WHERE
    itemName = :itemName;