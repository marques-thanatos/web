SELECT
    *
FROM
    T001_Series
WHERE
    versao_conteudo_id = :estrutura_id
        AND Situacao = :situacao