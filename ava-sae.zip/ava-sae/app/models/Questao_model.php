<?php

class questao_model extends MY_Model {

    function __construct() {

        parent::__construct();

    }

    public function getGroupQuestions($groupId) 
    {
        $sql = "SELECT
                  qst.id,
                  qst.enunciado,
                  qst.data_cadastro
                FROM aprovaquestoes.questao qst
                  INNER JOIN aprovaquestoes.questao_similar qsts ON qsts.questao_similar_id = qst.id
                WHERE qsts.questao_id = :id1
                UNION ALL
                SELECT
                  qst.id,
                  qst.enunciado,
                  qst.data_cadastro
                FROM aprovaquestoes.questao qst
                WHERE qst.id = :id2
                ORDER BY id";

        $query = SaeDigital::make(PDO::class)->prepare($sql);
        $query->bindParam(':id1', $groupId, PDO::PARAM_INT);
        $query->bindParam(':id2', $groupId, PDO::PARAM_INT);
        $query->execute();
        
        $questions = $query->fetchAll(PDO::FETCH_ASSOC);

        $this->getQuestionAlternatives($questions);

        return $questions;
    }

    public function getQuestionAlternatives(&$questions) 
    {
        $sql = "SELECT *
                FROM aprovaquestoes.questao_opcao_resposta
                WHERE questao_id = :id";

        $query = SaeDigital::make(PDO::class)->prepare($sql);

        foreach ($questions as &$question) {
            $query->bindParam(':id', $question['id'], PDO::PARAM_INT);
            $query->execute();
            $question['alternativas'] = $query->fetchAll(PDO::FETCH_ASSOC);

        }
        
    }

    public function updateQuestions($questions)
    {

        foreach ($questions as $question) {
            
            $this->updateQuestion($question);
            $this->updateAlternatives($question['alternativas']);
        
        }
    }

    public function updateQuestion($question)
    {
        $sql = "UPDATE aprovaquestoes.questao
                SET enunciado = :enunciado
                WHERE id = :id";

        $query = SaeDigital::make(PDO::class)->prepare($sql);
        $query->bindParam(':id', $question['questao_id'], PDO::PARAM_INT);
        $query->bindParam(':enunciado', $question['enunciado'], PDO::PARAM_STR);
        
        return $query->execute();
        
    }

    public function updateAlternatives($alternatives)
    {
        foreach ($alternatives as $alternative) {
            
            $this->updateAlternative($alternative);
        
        }
    }

    public function updateAlternative($alternative)
    {
        $sql = "UPDATE aprovaquestoes.questao_opcao_resposta
                SET opcao = :opcao,
                opcao_correta = :opcao_correta
                WHERE id = :id";

        $query = SaeDigital::make(PDO::class)->prepare($sql);
        $query->bindParam(':id', $alternative['alternativa_id'], PDO::PARAM_INT);
        $query->bindParam(':opcao_correta', $alternative['alternativa_correta'], PDO::PARAM_BOOL);
        $query->bindParam(':opcao', $alternative['texto'], PDO::PARAM_STR);
        
        return $query->execute();
    }

    public function getScholarSubjects()
    {

        $sql = "SELECT *
               FROM aprovaquestoes.disciplina
               WHERE nome LIKE '%SAE%'";
        
        $query = SaeDigital::make(PDO::class)->prepare($sql);
        $query->execute();
        $subjects = $query->fetchAll(PDO::FETCH_UNIQUE|PDO::FETCH_COLUMN);

        return $subjects;
    }

    public function getSubjectTopics($subjectId)
    {

        $sql = "SELECT *
               FROM aprovaquestoes.assunto
               WHERE disciplina_id = :curso_id";

        $query = SaeDigital::make(PDO::class)->prepare($sql);
        $query->bindParam(':curso_id', $subjectId, PDO::PARAM_INT);
        $query->execute();
        $topics = $query->fetchAll(PDO::FETCH_ASSOC);

        return $topics;
    }

    public function getTests()
    {

        $sql = "SELECT pr.*
                FROM aprovaquestoes.prova pr
                  INNER JOIN aprovaquestoes.concurso con ON con.id = pr.concurso_id
                  INNER JOIN aprovaquestoes.instituicao inst ON inst.id = con.instituicao_id
                WHERE inst.id = 7720 AND pr.status = 1";

        /** @var PDOStatement $query */
        $query = SaeDigital::make(PDO::class)->prepare($sql);
        $query->execute();
        $tests = $query->fetchAll(PDO::FETCH_UNIQUE|PDO::FETCH_COLUMN);

        return $tests;
    }

    public function getQuestion($questionId)
    {
        $sql = "SELECT *
                FROM aprovaquestoes.questao
                WHERE id = :questao_id";

        /** @var PDOStatement $query */
        $query = SaeDigital::make(PDO::class)->prepare($sql);
        $query->bindParam(':questao_id', $questionId, PDO::PARAM_INT);
        $query->execute();

        $question = $query->fetchAll(PDO::FETCH_ASSOC);

        $this->getQuestionAlternatives($question);

        return $question;
    }

}
