﻿<?php

class Notificacoes_model extends MY_Model {

    function __construct()
    {
        parent::__construct();
        
    }

    /**
     * lista todos os agendamentos não processados com vencimento hoje
     */
    function getAgendamentosConcluidos()
    {
        $selectExpression = "select * from D024_Ava_Sae_Agenda where EnvioProcessado is null and DtFim < '" . date('Y-m-d') . "'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();

    }

    /**
     * lista todos os alunos ativos de uma turma, ou um aluno específico
     * @param unknown $escolaid
     * @param unknown $turmaid
     * @param string $alunoid
     */
    function getAlunos($escolaid, $turmaid, $alunoid = null)
    {
        $sqlExpression = "select *
                          from D019_Ava_Sae
                          where Perfil = '273' and Situacao = 'A'
                              and Escola = '$escolaid'
                              and Turma = '$turmaid'";
        if ($alunoid){
            $sqlExpression .= " and id = '$alunoid'";
        }
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($sqlExpression);
        return $result->result_array();

    }

    /**
     * lista os alunos de uma turma contando as tarefas que foram pelo menos iniciadas e se o aluno tem agendamento individual
     * @param unknown $escolaid
     * @param unknown $turmaid
     * @param unknown $disciplinaid
     * @param unknown $assuntoid
     * @param unknown $frenteid
     * @param string $alunoid -> se informado, traz dados somente do aluno
     */
    function getRelatorioAlunos($escolaid, $turmaid, $disciplinaid, $assuntoid, $frenteid, $alunoid = null, $dtnotificacaoresponsavel)
    {
        $sql = "select UsuarioID, DisciplinaID, count(DtConclusao) as Concluido,
                    case when (DtAgendaFim > getdate()) then 'S' else 'N' end as TemPrazo
                from AVASAE.R001_RespostasQuestoes
                where Situacao = 'A' and EscolaID = '$escolaid'
                	and TurmaID = '$turmaid'
                	and AssuntoID = '$assuntoid'
                	and DisciplinaID = '$disciplinaid'
                	and FrenteID = '$frenteid'";

        if ($alunoid)
            $sql .= " and UsuarioID = '$alunoid'";

            $sql .="AND NOT EXISTS (SELECT TOP 1* FROM
                       avasae.T004_EnviosEmailsSms
                       WHERE  TurmaID = '$turmaid'
                       AND EscolaID = '$escolaid'
                       AND DisciplinaID = '$disciplinaid'
                       AND Situacao = 'A') ";

        if (!empty($dtnotificacaoresponsavel)) {
             $sql .= " and DtAgendaFim >= '$dtnotificacaoresponsavel'";
        }

        $sql .= " group by UsuarioID, DtAgendaFim, DisciplinaID";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    /**
     * lista dados de agendamento individual
     * @param unknown $escolaid
     * @param unknown $turmaid
     * @param unknown $assuntoid
     * @param unknown $disciplinaid
     * @param unknown $alunoid
     */
    function getAgendaAluno($escolaid, $turmaid, $assuntoid, $disciplinaid, $alunoid)
    {
        $selectExpression = "select * from D024_Ava_Sae_Agenda
                             where EnvioProcessado is null
                                 and EscolaID = '$escolaid'
                                 and TurmaID = '$turmaid'
                	             and AssuntoID = '$assuntoid'
                	             and DisciplinaID = '$disciplinaid'
                                 and AlunoID = '$alunoid' and NotificacaoResponsavel == 'S'";
        // TODO: FDD-429 - UNSAFE QUERY
       $result = $this->getAvaMySQL()->query($selectExpression);
       return $result->result_array();
    }

    /**
     * verifica se o aluno tem dados cadastrados para o relatório
     * @param unknown $alunoid
     * @param unknown $escolaid
     * @param unknown $turmaid
     */
    function existeRelatorioAluno($alunoid, $escolaid, $turmaid)
    {
        $sql = "select count(*) as Existe
                from R001_RespostasQuestoes
                where Situacao = 'A' and UsuarioID = '$alunoid'
                	and EscolaID = '$escolaid'
                	and TurmaID = '$turmaid'";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->row();
    }

    /**
     * lista os agendamentos que estão iniciando hoje:
     */
    function getAgendamentosIniciados()
    {
        $selectExpression = "select * from D024_Ava_Sae_Agenda where DtInicio = '" . date('Y-m-d') . "'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function getConfiguracoes($escolaid)
    {
        $selectExpression = "select * from D023_Ava_Sae_Configuracoes where NotificacaoResponsavel = 'S' and EscolaID = '$escolaid'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }
}
