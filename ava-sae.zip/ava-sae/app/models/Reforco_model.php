<?php

class Reforco_model extends MY_Model {

    function __construct() {
        parent::__construct();
    }

    function tratamentoQuestoes($GrupoAulaID, $disciplinaID){

        $sql = "select e359.QuestaoID
                     , e359.Similar
                     , e359.GrupoSimilar
                     , e359.JarvisItemID
                from E359_AulaQuestoes e359
                inner join E358_EstruturaAulasQuestoes e358 on e358.EstruturaAulaID = e359.EstruturaAulaID
                where e358.SubCategoriaID = {$disciplinaID}
                  and e359.is_parent = 0
                  and e358.GrupoAulaID = {$GrupoAulaID}
                  GROUP BY e359.EstruturaAulaID, e359.GrupoSimilar";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        $result = $query->result_array();

        if ($result){
          return $result;
        }
        return false;
    }

    function gravaRespostaAlunoReforco($dados, $where) {

        $id = $where['UsuarioID'];
        $grupoaulaID = $where['DisciplinaID'];
        $aulaId = $where['AulaID'];
        $disciplinaId = $where['AssuntoID'];
        $questaoId = $where['QuestaoID'];

        $sql = '';

        if ($aulaId) {
            $sql .= " and AulaID = '$aulaId' ";
        }

        if ($disciplinaId) {
            $sql .= " and AssuntoID = '$disciplinaId' ";
        }

        if ($questaoId) {
            $sql .= " and QuestaoID = '$questaoId' ";
        }

        $selectExpression = "select * from R002_RespostasQuestoesReforco where UsuarioID = '$id' and DisciplinaID = $grupoaulaID " . $sql . 'order by SequenciaResposta Desc limit 1';
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($selectExpression);
        // TODO: FDD-429 - REVER, ISSO APARENTEMENTE NAO ESTA FAZENDO NADA
        $resultSequencia =  $query->row();

        //return $resultSequencia->SequenciaResposta;
        //$dados['SequenciaResposta'] = $resultSequencia->SequenciaResposta + 1;
        // buscar ve se existe gravado caso não tenha sequencia, a sequencia é 1,  e se existir é a ultima +1  so que insere um novo registro.
       // if ($resultSequencia->SequenciaResposta == null) {
            //return 'atualiza o registro existente apenas como primeira sequencia';

        $this->getAvaMySQL()->update('R002_RespostasQuestoesReforco', $dados, $where);
        if($this->getAvaMySQL()->affected_rows()) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * getQuestoesAlunoReforco
     *
     * @access	public
     * @return	array        dados
     */
    function getQuestoesAlunoReforco($id, $grupoAula, $assunto, $aula, $questaoID = null) {

        $sql = '';

        if ($questaoID) {
            $sql = " and QuestaoID = $questaoID";
        }

        $selectExpression = "select * from R002_RespostasQuestoesReforco
                where UsuarioID = '$id' and DisciplinaID = $grupoAula
                and AssuntoID = $assunto and (SequenciaResposta = 1 OR SequenciaResposta IS NULL) and AulaID = $aula" . $sql;
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($selectExpression);
        return $query->result();
    }

    /**
     * Busca resposta correta consultando pelo ID da questão
     *
     * @access	public
     * @return	array dados
     */
    function buscaRespostaCorreta($questaoId) {
        $this->getAvaMySQLQuestoes()->select(
            'questao_opcao_resposta.id, questao_opcao_resposta.valor_opcao'
        );    
        $this->getAvaMySQLQuestoes()->from('questao');
        $this->getAvaMySQLQuestoes()->join('questao_opcao_resposta', 
            'questao_opcao_resposta.questao_id = questao.id'
        );
        $this->getAvaMySQLQuestoes()->where('questao.id', $questaoId);
        $this->getAvaMySQLQuestoes()->where(
            'questao_opcao_resposta.opcao_correta', 1
        );
        $query = $this->getAvaMySQLQuestoes()->get();
        return $query->result_array()[0];
    }

 
    /**
     * @param $alunoId
     * @param $assuntoId
     *
     * @return mixed
     */
    public function buscarAgendamentoReforco($alunoId, $assuntoId, $turmaId = null)
    {
        $tipoReforco = \Ava\App\Support\TipoAgendamento::REFORCO; 
        $turmaStr = '';
        if($turmaId != null)
            $turmaStr = " OR (TurmaID = '$turmaId' AND `AssuntoID` = '$assuntoId' AND `tipo_agendamento` = '$tipoReforco')"; 

        $sql = "SELECT * FROM `D024_Ava_Sae_Agenda` WHERE (`AlunoID` = '$alunoId' AND `AssuntoID` = '$assuntoId' AND `tipo_agendamento` = '$tipoReforco') {$turmaStr} ORDER BY DtAlt DESC LIMIT 1";

        $query = $this->getAvaMySQL()->query($sql);
        return $query->result_array();
    }

}
