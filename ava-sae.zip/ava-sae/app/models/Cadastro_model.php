<?php

use Ava\App\Services\Escola\BuscarDadosEscola;
use Ava\App\Services\Escola\BuscarDadosEscolaNextAva;
use Ava\App\Support\Senha;
use Ava\App\Providers\PdoServiceProvider;

class cadastro_model extends MY_Model {


    function __construct() {
        parent::__construct();
    }

    public function verificaLogin($login, $email = null) {

    	$sql = '';

    	if($email){
    		$sql .= " and Email != '".$email."'";
    	}

    	// TODO: FDD-429 - UNSAFE QUERY
    	$selectExpression = "select itemName,id, Login, Nome, Senha, Turma, Escola, Aluno, Situacao from D019_Ava_Sae where Login = '{$login}'".$sql;
      $result = $this->getAvaMySQL()->query($selectExpression);
      return $result->result_array();

    }

    public function verificaEmail($email, $login = null) {

    	$sql = '';

    	if($login){
    		$sql .= " and Login = '{$login}'";
    	}

    	// TODO: FDD-429 - UNSAFE QUERY
    	$selectExpression = "select id, itemName, Login, Senha, Turma, Escola, Aluno, Situacao from D019_Ava_Sae where Email = '".$email."'".$sql;

      $result = $this->getAvaMySQL()->query($selectExpression);
      return $result->result_array();

    }

    function verificaEmailDuplicado($email) {
        $this->getAvaMySQL()->select('Email as email, Login as login_dono_email');
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->where('Email', $email);
        $this->getAvaMySQL()->order_by('DtCad', "asc");

        $query = $this->getAvaMySQL()->get();
        return (count($query->result_array()) > 0) ? $query->result_array()[0] : Null;
    }

     function salvaDados($domain,$id,$dados,$replace=TRUE){
        if ( $replace ){
            $dados['itemName']=$id;
            return $this->getAvaMySQL()->insert($domain, $dados);
        }else{
            $this->getAvaMySQL()->where('itemName',$id);
            return $this->getAvaMySQL()->update($domain, $dados);
        }
    }

    function salvaDados2($domain,$dados,$replace=TRUE)
    {
      $insert= $this->getAvaMySQL()->insert($domain, $dados);
      return $insert;
    }

    public function getDados($perfil = null, $id = null, $situacao = null, $escolaid = null, $login = null, $email = null, $turma = null, $vigencia = null) {

        return [];

        //     $selectExpression = "select * from D019_Ava_Sae  as ava Where Situacao in ('A', 'I') ". $sql ." order by Situacao";
        //     if($this->session->userdata('perfil') == 268 && $perfil == 269){
        //       $selectExpression = "select ava.*, config.IdProtheus from D019_Ava_Sae as ava INNER JOIN D023_Ava_Sae_Configuracoes as config ON (config.itemName = ava.itemName AND config.TIpo='G')  Where ava.Situacao in ('A', 'I') ". $sql ." order by ava.Situacao";
        //     }
        //     $result = $this->getAvaMySQL()->query($selectExpression);
        //     return $result->result_array();
    }

    public function getDadosAlunosResp($perfil = null, $id = null, $situacao = null, $escolaid = null, $login = null, $email = null, $turma = null) {

    	$sql = '';

    	if($id){
    		$sql .= " and itemName = '".$id."'";
    	}


    	if($login){
    		$sql .= " and Login = '".$login."'";
    	}

    	if($email){
    		$sql .= " and ( Email = '".$email."' OR Login = '".$email."' )";
    	}

    	if(!$situacao){
            $situacao = 'A';
    	}

    	if($escolaid){
    		$sql .= " and Escola = '".$escolaid."'";
    	}

        if($perfil){
            $sql .= " and Perfil = '".$perfil."'";
            if($perfil == 269 ){
                 $sql .= ' and Nome is not null order by Nome asc';
            }
    	}

    	if($turma){
    		$sql .= " and Turma in ('".$turma."')";
    	}

    	//$selectExpression = "select * from D019_Ava_Sae Where Situacao = '".$situacao."'  ". $sql . "";
      $selectExpression = "select * from D019_Ava_Sae Where Situacao = '". $situacao ."' ". $sql;
    	// TODO: FDD-429 - UNSAFE QUERY
    	$result = $this->getAvaMySQL()->query($selectExpression);
      return $result->result_array();
    }

    public function getDadosUsuario($id = null) {

    	$selectExpression = "select id, itemName, Matricula, Nome, Login, Senha, Serie, Email, Escola, NomeEscola, Turma, DescricaoTurma, Telefone, "
                . "LimiteDispositivo, Situacao, LinkCadastro from D019_Ava_Sae where itemName = '".$id."'";

    	// TODO: FDD-429 - UNSAFE QUERY
    	$result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function getAlunos($escolaid = '', $alunosNaoExcluidos = false) {
    	$selectExpression = "select id, itemName, Nome, Escola, NomeEscola, Turma, DescricaoTurma, Situacao from D019_Ava_Sae where Perfil = '273' and Nome is not null";

    	if ( $escolaid != '') {
    	    $selectExpression .= " and Escola = '$escolaid'";
        }
        if ( $alunosNaoExcluidos) {
            $selectExpression .= " and Situacao in ('A','I')";
        }
        // TODO: FDD-429 - UNSAFE QUERY
    	$result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function getDadosTurma($escolaid = null,$id = null, $param = false, $vigencia = null) {

    	$sql = '';
    	//param para remover os inativos do cadastro de alunos.
        if ($param) {
            $sql .= " and Situacao != 'I'";
        }

    	if($escolaid){
    		$sql .= " and EscolaID = '".$escolaid."'";
    	}

    	if($id){
    		$sql .= " and itemName = '".$id."'";
    	}

        if ($vigencia) {
            $sql .= " and Vigencia = '$vigencia'";
        }

    	$selectExpression = "select id, itemName, Descricao,SerieID,DescricaoSerie,Vigencia,CategoriaTurmaID,DescricaoCategoriaTurma,EscolaID,NomeEscola,Situacao
    									from D021_Ava_Sae_Turmas where Situacao != 'E' ".$sql . "ORDER BY SerieID, Descricao";
    	//print_pre($selectExpression);die;
        // TODO: FDD-429 - UNSAFE QUERY
    	$result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function getListaTurma($escolaid = null,$id = null) {

    	$sql = '';

    	if($escolaid){
    		$sql .= " and EscolaID = '".$escolaid."'";
    	}

    	$selectExpression = "select id,itemName, Descricao,SerieID,DescricaoSerie,Vigencia,CategoriaTurmaID,DescricaoCategoriaTurma,EscolaID,NomeEscola,Situacao
    									from D021_Ava_Sae_Turmas where itemName in ('".$id."') ".$sql;
    	// TODO: FDD-429 - UNSAFE QUERY
    	$result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function getCategoriaEscola($escolaid = null,$id = null) {

    	$sql = '';

    	if($id){
    		$sql = " and itemName = '".$id."'";
    	}

    	if($escolaid){
    		$sql .= " and Escola = '".$escolaid."'";
    	}

    	$selectExpression = "select id, itemName, ItemName, Descricao,Escola from D022_Ava_Sae_CategoriaTurma where Situacao = 'A'".$sql;

    	// TODO: FDD-429 - UNSAFE QUERY
    	$result = $this->getAvaMySQL()->query($selectExpression);

      return $result->result_array();
    }

    function getSerie($tipo = null, $versaoConteudo = null, $segmentos = null)
    {
        $versao_conteudo_id = $this->session->userdata('versao_conteudo_id');

        if ($versaoConteudo) {

            $versao_conteudo_id = $versaoConteudo;

        }


        $andSegmentos = '';
        if (!empty($segmentos)) {
            $andSegmentos = " AND CategoriaID IN ($segmentos)";
        }

        $and = "";
        if($tipo == 1){
            $and = 'and SerieID not in (1,2,3,15,16,17,18,19)';
        }

    	$sql = "select SerieID,Descricao,Situacao,ExibeMenuLD,CategoriaID, versao_conteudo_id from T001_Series where Situacao = 'A' and versao_conteudo_id = $versao_conteudo_id and SerieID <> 12 ". $and . $andSegmentos;
        $query = $this->getAvaMySQL()->query($sql);

    	return $query->result();
    }

    public function getListaCoordenador( $escolaid = null ,$login = null,$situacao = null) {

        return []; 
    	// $sql = '';

    	// if($escolaid){
    	// 	$sql .= " and Escola = '".$escolaid."'";
    	// }

    	// if($login){
    	// 	$sql .= " and Login = '".$login."'";
    	// }

    	// if($situacao){
    	// 	$sql .= " and Situacao = '".$situacao."'";
    	// }

        // $anoAtual = date('Y');

    	// $selectExpression = "select id, itemName, ItemName, Situacao,Login,Nome,Senha,Email,Escola,NomeEscola,Turma, DescricaoTurma,Categoria, DescricaoCategoria, LimiteDispositivo
    	// 								from D019_Ava_Sae where DtCad like '". $anoAtual ."%' and Situacao != 'E' and Perfil = '271'"  . $sql . ' order by Situacao asc';
        // // TODO: FDD-429 - UNSAFE QUERY
        // $result = $this->getAvaMySQL()->query($selectExpression);
        // return $result->result_array();
    }

    function getDadosDisciplina($serie, $versaoConteudo = null)
    {
        $versao_conteudo_id =
            ($versaoConteudo !== null) ?
            $versaoConteudo :
            $this->session->userdata('versao_conteudo_id');

    	$sql = "select distinct t002.DisciplinaID, e093.Descricao,t002.SerieID
                from T002_SeriesDisciplinas as t002
                inner join E093_GruposAulas as e093 on e093.GrupoAulaID = t002.DisciplinaID
                inner join T001_Series as t001 on t001.SerieID = t002.SerieID
                where t002.SerieID in (".$serie.") and e093.Situacao = 'A'
                    and t002.Situacao = 'A' and e093.ClassificacaoID <> 12 and e093.AvaSaeDisciplinaEspecifica = 'N'
                    and t002.versao_conteudo_id = $versao_conteudo_id
                    and t001.versao_conteudo_id = $versao_conteudo_id
                order by t002.SerieID";

    	// TODO: FDD-429 - UNSAFE QUERY
    	$query = $this->getAvaMySQL()->query($sql);

    	return $query->result();
    }



    public function getConfiguracoes($escolaid,$traz_permissao_senha = null) {
        if($traz_permissao_senha)
            $traz_permissao_senha = ",SenhaAluno";
        $selectExpression = "select itemName, id, EscolaID,Serie,Meta,Percentual,QuestaoProfessor,AgendaProfessor,QuestaoCoordenador,AgendaCoordenador,DtFimProfessor,DtFimCoordenador,
                            Tipo,NotificacaoResponsavel,NotificacaoAluno,DtNotificacaoResponsavel, RespostaFinalAgendamentoAluno, AgendamentoDisciplinasLote, AcessoLD, ExibeMenuLD, NotiRespTarefaRealizada,  MediaTurmaRelatorio, mediaRelatorioTotalAlunos".$traz_permissao_senha."
    						 from D023_Ava_Sae_Configuracoes where EscolaID = '".$escolaid."'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
    	return $result->result_array();
    }

	public function verificaMeta($serie,$escolaID){
            $selectExpression = "select id, Meta, Percentual from D023_Ava_Sae_Configuracoes where Tipo = 'S' and Serie = '$serie' and EscolaID = '$escolaID'";
            // TODO: FDD-429 - UNSAFE QUERY
            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
	}

	public function verificaDisciplina($serieID, $dtInicio) {

            $selectExpression = "select e093.GrupoAulaID as itemName
                                      , e093.Descricao
                                from E093_GruposAulas e093
                                where e093.SerieID = '". $serieID ."'
                                        and e093.DtInicio >= '". $dtInicio ."-01-01'
                                        and (e093.Situacao is null or e093.Situacao = 'A')
                                and ClassificacaoID in (10,11)";


            // TODO: FDD-429 - UNSAFE QUERY
            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
	}

	public function verificaFrente($DisciplinaID) {

		$selectExpression = "select concat(LPAD(e088.CategoriaAulaID,7,'0'),LPAD(e094.GrupoAulaID,7,'0')) as itemName
                                 , e088.Descricao
                                 , e088.CategoriaAulaID as CategoriaID
                            from E088_CategoriasAulas e088
                            inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                            where e094.GrupoAulaID = ". $DisciplinaID ."
                            and e094.Ordem is not null
                            order by e094.Ordem ASC";

		// TODO: FDD-429 - UNSAFE QUERY
		$return = $result = $this->getAvaMySQL()->query($selectExpression)->result_array();
		return $return;
	}

	// TODO: FDD-429 - VERIFICAR SE ISSO FUNCIONA, JÁ QUE GrupoAulaID NAO É PASSADO
	public function verificaAssuntos($DisciplinaID ,$FrenteID) {
        $select_expression = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                    , e089.Descricao
                                     , e094.GrupoAulaID
                                     , e089.SubCategoriaAulaID as DisciplinaID
                                     , e089.DtInicio as DtInicio
                                     , e088.CategoriaAulaID as CategoriaID
                                     , '' as TemMensagem
                                from E089_SubCategoriasAulas e089
                                inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                where e094.GrupoAulaID = " . $DisciplinaID . "
                                  and e088.CategoriaAulaID = '" . $FrenteID . "'
                                  and e089.Descricao != ''
                                order by e089.Descricao ASC";
        // TODO: FDD-429 - UNSAFE QUERY
        $return = $result = $this->getAvaMySQL()->query($select_expression)->result_array();
        return $return;
    }


    //Agendamento turma
    function getAgendamento($escola, $disciplina, $frente, $assunto, $turma, $alunoid = null)
    {
        $selectExpression = "select id, EscolaID, DisciplinaID,FrenteID, AssuntoID, DtInicio, DtFim from D024_Ava_Sae_Agenda
                                                     where EscolaID = '" . $escola . "' and DisciplinaID = '" . $disciplina . "' and FrenteID = '" . $frente . "'
                                                     and AssuntoID = '" . $assunto . "' and TurmaID = '" . $turma . "'";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    //Agendamento aluno
    function getAgendamentoAluno($escola, $disciplina, $frente, $assunto, $turma, $alunoid)
    {
        $selectExpression = "select id, EscolaID, DisciplinaID,FrenteID, AssuntoID, DtInicio, DtFim from D024_Ava_Sae_Agenda
                                                     where EscolaID = '" . $escola . "' and DisciplinaID = '" . $disciplina . "' and FrenteID = '" . $frente . "'
                                                     and AssuntoID = '" . $assunto . "' and TurmaID = '" . $turma . "'  and AlunoID = '" . $alunoid . "' ";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getAulas($disciplina, $tipo = null)
    {

        $sql = '';
        if ($tipo) {
            $sql = " and e068.Tipo = '" . $tipo . "' ";
        }

        $selectExpression = "select '' as id
                                 , e068.AulaID
                                 , e091.SubCategoriaID as DisciplinaID
                                 , e068.Tema
                                 , LPAD(e091.Ordem,4,0) as Ordem
                                 , e068.Video
                                 , e068.Duracao
                                 , e068.DtCad
                                 , e068.Tipo
                                 , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName

                            from E068_Aulas e068
                            inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                            where e091.SubCategoriaID = " . $disciplina . "
                            " . $sql . "
                            order by e091.Ordem ASC";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);

        return $result->result_array();
    }

	function getQuestoesAula($grupoAulaID,$aulaID){

            $selectExpression = "select e358.AulaID
                                     , e359.QuestaoID
                                     , e358.GrupoAulaID
                                     , e358.EstruturaAulaID
                                     , e359.Similar
                                     , e359.GrupoSimilar
                                     , e359.JarvisItemID
                                from E359_AulaQuestoes e359
                                inner join E358_EstruturaAulasQuestoes e358 on e358.EstruturaAulaID = e359.EstruturaAulaID
                                where e358.AulaID = ". $aulaID ."
                                  and e358.GrupoAulaID = ". $grupoAulaID;
            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
	}

	function gravaDadosRelatorio($dados){
            return $this->getAvaMySQL()->insert('R001_RespostasQuestoes', $dados);
	}

    function listarPacotes($tipobusca){
        try{
            if (is_numeric($tipobusca)){
                $where = " and GrupoAulaID = " . $this->getAvaMySQL()->escape_str($tipobusca);
            }else{
                $where = " and Descricao LIKE '%" . $this->getAvaMySQL()->escape_str($tipobusca) . "%'";
            }
            $sql = "SELECT GrupoAulaID, Descricao FROM E093_GruposAulas WHERE ClassificacaoID in (10,11) and Situacao = 'A' ";
            $sql .= $where;
            $sql .= " ORDER BY DtCad DESC, Descricao";
            $query = $this->getAvaMySQL()->query($sql);
            $result = $query->result();
            return $result;
        }catch (Exception $exception){
            $acao = 1; //cadastro
            $message = "Nao foi possivel listar o pacote por tipobusca = ".$tipobusca;
            $error = $exception->getMessage();
            //TODO: logar erro
        }
    }

    function verificaExisteQuestao($usuarioid) {
        $sql = "select COUNT(*) as Existe
                from R001_RespostasQuestoes
                where Situacao = 'A' and UsuarioID = '{$usuarioid}'";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->row();
    }


    function getAcessoLD($escolaid){
        $selectExpression = "select id, AcessoLD from D023_Ava_Sae_Configuracoes where EscolaID = '$escolaid' and Tipo = 'G' and AcessoLD is not null";

        // TODO: FDD-429 - UNSAFE QUERY
        $resultado = $this->getAvaMySQL()->query($selectExpression)->result_array();
        if(isset($resultado[0]['AcessoLD']) && $resultado[0]['AcessoLD'] == 'S'){
            return true;
        }else{
            return false;
        }
    }

    public function getListaTurmaVigencia($escolaid = null,$vigencia = null, $param = false) {

		$sql = '';

		if($vigencia){
			$sql .= 'and Vigencia in ("'.$vigencia.'") ';
		}

                if ($param) {
                    $sql .= "and Situacao = 'A' ";
                }

    	$selectExpression = "select id, itemName, ItemName, Descricao,SerieID,DescricaoSerie,Vigencia,CategoriaTurmaID,DescricaoCategoriaTurma,EscolaID,NomeEscola,Situacao
    									from D021_Ava_Sae_Turmas where EscolaID in ('".$escolaid."') " . $sql;

		// TODO: FDD-429 - UNSAFE QUERY
    	$result = $this->getAvaMySQL()->query($selectExpression);
      return $result->result_array();
    }

    function getDadosProfessor($login){
        $selectExpression = "select id, itemName, Nome, Login, Senha, Email, Situacao, Escola,NomeEscola, Turma, Disciplina, LimiteDispositivo from D019_Ava_Sae where Login = '$login' and Perfil = '272' and Situacao is not null AND Situacao <> 'E' order by Situacao asc";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getListaProfessor($escolaid = null ){
        $this->getAvaMySQL()->select("
            itemName,
            id,
            Nome,
            Email,
            Login,
            NomeEscola,
            IF(SUM(Situacao = 'A') > 0, 'A', 'I') Situacao"
        );

        $this->getAvaMySQL()->from('D019_Ava_Sae');

        $this->getAvaMySQL()->where_in('Situacao', array("A", "I"));
        $this->getAvaMySQL()->where('Perfil', 272);

        if($escolaid)
        {
            $this->getAvaMySQL()->where('Escola', $escolaid);
        }

        if($this->session->userdata('perfil') != 268)
        {
            $anoAtual = date('Y');
            $this->getAvaMySQL()->like('DtCad', $anoAtual);
        }

        $this->getAvaMySQL()->group_by('Login');

        $query = $this->getAvaMySQL()->get();
        return $query->result_array();
    }

    function getTurmasProfessor($professorLogin){
        $this->getAvaMySQL()->select("d021.descricao, d021.Vigencia");
        $this->getAvaMySQL()->from('D019_Ava_Sae d019');
        $this->getAvaMySQL()->join(
            "D021_Ava_Sae_Turmas d021",
            "d021.itemName = d019.Turma"
        );
        $this->getAvaMySQL()->where("d019.Login", $professorLogin);
        $this->getAvaMySQL()->where("d019.Situacao", 'A');
        $this->getAvaMySQL()->where("d021.Situacao", 'A');
        $this->getAvaMySQL()->group_by("d021.Descricao");
        $this->getAvaMySQL()->order_by("d021.Descricao", "ASC");
        $query = $this->getAvaMySQL()->get();
        return $query->result_array();
    }

	function excluirAlunos($itemName, $isAluno = null)
    {
		$domain = 'D019_Ava_Sae';
		$dados = ['Situacao' => 'E'];
        $this->getAvaMySQL()->where('itemName', $itemName);
        $checkinsert = $this->getAvaMySQL()->update($domain, $dados);

		if($isAluno){
			$sql = "update R001_RespostasQuestoes set Situacao = 'E' where UsuarioID = '{$itemName}'";
			$this->getAvaMySQL()->set('Situacao', 'E');
			$this->getAvaMySQL()->where('UsuarioID', $itemName);
			$this->getAvaMySQL()->update('R001_RespostasQuestoes');
		}

        return $checkinsert;
	}

	function excluirProfessores($login){

		$sql = "select id FROM D019_Ava_Sae WHERE Login = '".$login."'";
		// TODO: FDD-429 - UNSAFE QUERY
		$ids = $this->getAvaMySQL()->query($sql);
        $ids = $ids->result_array();
		$domain = 'D019_Ava_Sae';
		$dados = array(
			'Situacao' => 'E'
		);

		foreach($ids as $key => $value) {
          $this->getAvaMySQL()->where('id',$value['id']);
          $checkinsert = $this->getAvaMySQL()->update($domain,$dados);

		}

		return $checkinsert;
	}

    function excluirResponsaveis ( $itemname )
    {
        $this->getAvaMySQL()->where('itemname', $itemname);
            return $this->getAvaMySQL()->update('D019_Ava_Sae', array( 'Situacao' => 'E'));
	}

    function excluirTurmas($itemName)
    {
        $domain = 'D021_Ava_Sae_Turmas';
        $dados = array(
            'Situacao' => 'E'
        );
        $this->getAvaMySQL()->where('itemName',$itemName);
        $checkinsert = $this->getAvaMySQL()->update($domain,$dados);

        return $checkinsert;
    }

    function getSeries($versaoConteudoId = null){
        $this->getAvaMySQL()->select('SerieID');
        $this->getAvaMySQL()->where('Situacao =', 'A');
        $this->getAvaMySQL()->group_by('SerieID');
        if (!is_null($versaoConteudoId)) {
            $this->getAvaMySQL()->where('versao_conteudo_id', $versaoConteudoId);
        }
        $query = $this->getAvaMySQL()->get('T001_Series');
        return $query->result_array();
    }

    function getDisciplinaExclusivas()
    {
        $selectExpression = "select e093.GrupoAulaID as itemName
                                     , e093.Descricao
                                from E093_GruposAulas e093
                                where e093.Situacao = 'A'
                                and e093.AvaSaeDisciplinaEspecifica = 'S'";

        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getEscolasVinculadas($disciplina = false)
    {
        $sql = '';
        if ($disciplina) {
            $sql = " where DisciplinaID = '$disciplina'";
        }
        // TODO: FDD-429 - UNSAFE QUERY
        $selectExpression = "select id, itemName, ItemName, EscolaID, Descricao, Situacao from D034_Ava_Sae_DisciplinasExclusivas" . $sql;
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getEscolas()
    {

        $token = $this->session->userdata('token');
        $result = SaeDigital::make(BuscarDadosEscolaNextAva::class)->handle($token,'269');

        return $result;
    }

    function getSerieID($disciplina)
    {
        $selectExpression = "select e093.GrupoAulaID as itemName
                                     , e093.SerieID
                                     , e093.ClassificacaoID
                                from E093_GruposAulas e093
                                where e093.GrupoAulaID = " . $disciplina . "
                                and e093.Situacao = 'A'";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getDisciplinasExclusivas($escolaid, $serieid)
    {
        $selectExpression = "select id, itemName, ItemName, DisciplinaID, SerieID, Descricao from D034_Ava_Sae_DisciplinasExclusivas where EscolaID = '$escolaid' and SerieID = '$serieid' and Situacao = 'A'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getListaResponsavel($escolaid)
    {
        return [];

        // if($this->session->userdata('perfil') != 268)
        // {
        //     $anoAtual = date('Y');
        //     $selectExpression = "select id, itemName, Nome, Login, Email, Situacao from D019_Ava_Sae where DtCad like '". $anoAtual ."%' and Perfil = '274' and Escola = '$escolaid' and Situacao in ('A', 'I') order by Situacao";
        // }
        // else
        // {
        //     $selectExpression = "select id, itemName, Nome, Login, Email, Situacao from D019_Ava_Sae where Perfil = '274' and Escola = '$escolaid' and Situacao in ('A', 'I') order by Situacao";
        // }

        // // TODO: FDD-429 - UNSAFE QUERY
        // $result = $this->getAvaMySQL()->query($selectExpression);
        // return $result->result_array();
    }

    function getTurmasSerie($escolaID, $serieID){
        $selectExpression = "select id, itemName, ItemName, Descricao from D021_Ava_Sae_Turmas where EscolaID = '$escolaID' and SerieID = '$serieID' and Situacao = 'A'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function atualizaQuestoes($usuarioid, $dadosTurma){
        $update = array(
            'TurmaID' => $dadosTurma['itemName'],
            'DescTurma' => $dadosTurma['Descricao'],
            'DtAlt' => date('Y-m-d H:i:s')
            //'UsuarioAlt' => $this->session->userdata('pessoaid')
        );
        $this->getAvaMySQL()->where('UsuarioID', $usuarioid);
        $this->getAvaMySQL()->update('R001_RespostasQuestoes', $update);
        $this->getAvaMySQL()->update('R002_RespostasQuestoesReforco', $update);
    }


    function atualizaMetaQuestoes($escolaid, $dadosTurma){
        $where = array(
            'SerieID' => $dadosTurma['Serie'],
            'EscolaID' => $escolaid,
        );

        $whereIn = ["Q", "R"];

        $updateMeta = array(
            'Meta' => $dadosTurma['Meta']
        );

        $this->getAvaMySQL()->trans_begin();
        $this->getAvaMySQL()->where( $where );
        $this->getAvaMySQL()->where_in("Tipo", $whereIn );
        $this->getAvaMySQL()->update('R001_RespostasQuestoes', $updateMeta);

        if ( $this->getAvaMySQL()->trans_status() === TRUE ){
            $this->getAvaMySQL()->trans_commit();
        }else{
            $this->getAvaMySQL()->trans_rollback();
        }
    }

    function atualizaMetaVideo($escolaid, $dadosTurma){
        $where = array(
            'SerieID' => $dadosTurma['Serie'],
            'EscolaID' => $escolaid,
        );

        $whereIn = ["N"];

        $updateMeta = array(
            'Meta' => $dadosTurma['Percentual']
        );

        $this->getAvaMySQL()->trans_begin();
        $this->getAvaMySQL()->where( $where );
        $this->getAvaMySQL()->where_in("Tipo", $whereIn );
        $this->getAvaMySQL()->update('R001_RespostasQuestoes', $updateMeta);

        if ( $this->getAvaMySQL()->trans_status() === TRUE ){
            $this->getAvaMySQL()->trans_commit();
        }else{
            $this->getAvaMySQL()->trans_rollback();
        }
    }

    /**
     * Realiza busca no SimpleDB e executa atualização dos registros encontrados
     *
     * @param $domain dominio/tabela no SimpleDB
     * @param $findKey atributo para realizar busca (where $findKey = $findValue)
     * @param $findValue valor do atributo para busca (where $findKey = $findValue)
     * @param $arrDataToUpdate array contendo os os dados a serem atualizados nos registros encontrados
     */
    function atualizaRegistrosTabelaRelacionada($domain, $findKey, $findValue, $arrDataToUpdate){
        $sql = "select itemName FROM $domain WHERE $findKey = '".$findValue."'";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        $ids = $query->result_array();
        $replace = true;
        foreach($ids as $key => $value){
            $this->getAvaMySQL()->where('itemName',$value['itemName']);
            $this->getAvaMySQL()->update($domain,$arrDataToUpdate);
        }
    }
    function excluirArquivo($id){
        $domain = "D038_Materiais_Adicionais_Upload";
        $dados = array(
                'Situacao' => 'E'
        );

        $this->getAvaMySQL()->where('id',$id);
        $checkinsert = $this->getAvaMySQL()->update($domain,$dados);
        return $checkinsert;
	}

    public function getCadastroItemNameById($id) {

        $selectExpression = "select itemName from D019_Ava_Sae where id = ".$id;

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array()[0]['itemName'];
    }

    public function updateNomeAlunoRespostaQuestoes($itemName,$nomeAluno){
        $sql = "update R001_RespostasQuestoes set NomeAluno = '$nomeAluno'
                    where UsuarioID = '$itemName'";
        // TODO: FDD-429 - UNSAFE QUERY
        $this->getAvaMySQL()->query($sql);
    }

    public function buscaAlunosParaExportar($turma){
        $selectExpression = "select  d019.itemName,d019.Login, d019.Nome, d019.Senha, d019.email, d019.nomeEscola,
        d021.descricao as Turma
        from D019_Ava_Sae d019
        inner join D021_Ava_Sae_Turmas as d021 on d019.turma = d021.itemname
        where Turma = '{$turma}'
        and Perfil = 273";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }


    public function buscaAlunosParaExportarCSV($turma){
        $selectExpression = "select aluno.nome, group_concat(resp.email separator '/') as responsavel
        FROM avasae.D019_Ava_Sae as aluno
        inner join avasae.D019_Ava_Sae as resp on aluno.itemname = resp.aluno
        where aluno.Turma = '{$turma}'
        and aluno.Perfil = 273
        group by aluno.nome";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }


    public function buscaInformacaoTurmaExportar($turma){
        $selectExpression = "select NomeEscola,Descricao,Dtcad,vigencia
        FROM avasae.D021_Ava_Sae_Turmas
        where itemname = '{$turma}'";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    // public function ativaZendeskEscola($escolaid, $iderp, $situacao){
    //     $data = [
    //         'id_erp' => $iderp,
    //         'onZendesk' => (int) $situacao,
    //         'DtAlt' => date('Y-m-d H:i:s'),
    //     ];
    //     // $this->getAvaMySQL()->where("Escola", $escolaid);
    //     $this->getAvaMySQL()->where(
    //         "(Escola = '$escolaid' OR itemName = '$escolaid')"
    //     );
    //     $result = $this->getAvaMySQL()->update("D019_Ava_Sae", $data);
    //     return $result;
    // }

    public function escolasAtivasZendesk() {
        $this->getAvaMySQL()->select('Nome, Login, id_erp');
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->where('onZendesk', 1);
        $this->getAvaMySQL()->where('perfil', 269);
        $this->getAvaMySQL()->order_by('DtAlt', "asc");
        $result = $this->getAvaMySQL()->get();
        return $result->result_array();
    }

    public function removeTurmasCoordenador($login) {
        $selectExpression = "update
                              D019_Ava_Sae
                            set
                              Situacao = 'I'
                            where
                              itemName in (
                                select * from (
                                  select
                                    itemName
                                  from D019_Ava_Sae
                                  where
                                    login = '{$login}'
                                  and
                                    turma is NOT null
                                ) as x
                              )";
        // TODO: FDD-429 - UNSAFE QUERY
        $this->getAvaMySQL()->query($selectExpression);
    }

    public function dadosTurma($turmaid)
    {
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('D021_Ava_Sae_Turmas');
        $this->getAvaMySQL()->where('itemName', $turmaid);
        $query = $this->getAvaMySQL()->get();

        return $query->row();
    }

    public function getConfiguracoesSerie($escola, $serieId)
    {
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('D023_Ava_Sae_Configuracoes');
        $this->getAvaMySQL()->where('EscolaID', $escola);
        $this->getAvaMySQL()->where('Serie', $serieId);
        $query = $this->getAvaMySQL()->get();

        return $query->row();
    }

    public function getContentVersions()
    {
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('versao_conteudo');
        $this->getAvaMySQL()->where('status', 1);
        $query = $this->getAvaMySQL()->get();

        return $query->result_array();
    }

    public function getContentVersionData($contentVersionId)
    {
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('versao_conteudo');
        $this->getAvaMySQL()->where('id', $contentVersionId);
        $this->getAvaMySQL()->where('status', 1);
        $query = $this->getAvaMySQL()->get();

        return $query->result_array();
    }

    public function getTestsTotal()
    {
        $concurso_id = 4417;
        $this->getAvaMySQLQuestoes()->select('count(*) as total');
        $this->getAvaMySQLQuestoes()->from('prova');
        $this->getAvaMySQLQuestoes()->where("concurso_id", $concurso_id);
        $this->getAvaMySQLQuestoes()->where("status", 1);
        $query = $this->getAvaMySQLQuestoes()->get();

        return $query->row()->total;
    }

    public function getCurrentPageTests($limit, $start)
    {
        $concurso_id = 4417;
        $this->getAvaMySQLQuestoes()->limit($limit, $start);
        $this->getAvaMySQLQuestoes()->order_by("id", "desc");
        $this->getAvaMySQLQuestoes()->where("status", 1);
        $this->getAvaMySQLQuestoes()->where("concurso_id", $concurso_id);
        $query = $this->getAvaMySQLQuestoes()->get("prova");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
    }


    public function getScholarity()
    {
        $this->getAvaMySQLQuestoes()->select('*');
        $this->getAvaMySQLQuestoes()->from('escolaridade');
        $query = $this->getAvaMySQLQuestoes()->get();

        return $query->result_array();

    }

    public function createTest($name, $scholarity)
    {
        // Tem que ser hardcoded =/
        $cargo_id = 16073;
        $prova_area_formacao_id = 265;
        $prova_area_atuacao_id = 6;
        $concurso_id = 4417;

        $data = array(
            'nome' => $name,
            'status' => 1,
            'escolaridade_id' => $scholarity,
            'concurso_id' => $concurso_id,
            'prova_area_formacao_id' => $prova_area_formacao_id,
            'prova_area_atuacao_id' => $prova_area_atuacao_id,
            'data_aplicacao' => date('m/Y'),
            'cargo_id' => $cargo_id,
            'slug' => $this->slugify($name),
            'data_cadastro' => date('Y-m-d H:i:s'),
        );

        $this->getAvaMySQLQuestoes()->insert('prova', $data);

        $newTest = $this->getAvaMySQLQuestoes()->insert_id();
        $this->getAvaMySQLQuestoes()->select('id, nome, status');
        $this->getAvaMySQLQuestoes()->from('prova');
        $this->getAvaMySQLQuestoes()->where('id', $newTest);
        $query = $this->getAvaMySQLQuestoes()->get();

        return $query->row();

    }

    public function atualizaSituacaoProva($provaId, $situacao)
    {
        $data = [
            "status" => $situacao
        ];

        $this->getAvaMySQLQuestoes()->where('id', $provaId);
        $this->getAvaMySQLQuestoes()->update('prova', $data);
    }

    public function slugify($text)
    {
        // replace non letter or digits by -
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);

        // transliterate
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

        // remove unwanted characters
        $text = preg_replace('~[^-\w]+~', '', $text);

        // trim
        $text = trim($text, '-');

        // remove duplicate -
        $text = preg_replace('~-+~', '-', $text);

        // lowercase
        $text = strtolower($text);

        if (empty($text)) {
            return 'n-a';
        }

        $microtime = (int) microtime(true);

        return "{$text}-{$microtime}";
    }

    public function getSchoolContentVersion($escolaId)
    {
        $this->getAvaMySQL()->select('versao_conteudo_id');
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->where('itemName', $escolaId);
        $query = $this->getAvaMySQL()->get();

        return $query->row()->versao_conteudo_id;

    }

    public function getQuestionsGroups($testId)
    {
        $this->getAvaMySQLQuestoes()->select('*');
        $this->getAvaMySQLQuestoes()->from('vw_sae_questao_agrupada');
        $this->getAvaMySQLQuestoes()->where('prova_id', $testId);
        $this->getAvaMySQLQuestoes()->order_by("questao_principal", "desc");
        $query = $this->getAvaMySQLQuestoes()->get();

        return $query->result_array();

    }

    public function getConfiguracoesSeries($escola)
    {
        $this->getAvaMySQL()->select('d023.id, t001.Descricao, d023.ExibeMenuLD');
        $this->getAvaMySQL()->from('D023_Ava_Sae_Configuracoes d023');
        $this->getAvaMySQL()->join('T001_Series t001', 't001.SerieID = d023.Serie');
        $this->getAvaMySQL()->where('EscolaID', $escola);
        $this->getAvaMySQL()->where('Tipo', 'S');
        $query = $this->getAvaMySQL()->get();

        return $query->result_array();
    }


    public function atualizaConfigLivroDigitalSerie($idConfig, $escola, $situacao)
    {
        $domain = 'D023_Ava_Sae_Configuracoes';

        if ($situacao) {

            $exibeMenuLd = 'S';

        } else {

            $exibeMenuLd = 'N';

        }

        $dados = array(
            'ExibeMenuLD' => $exibeMenuLd
        );

        $this->getAvaMySQL()->where('id', $idConfig);
        $this->getAvaMySQL()->where('EscolaID', $escola);
        $checkinsert = $this->getAvaMySQL()->update($domain,$dados);

        return $checkinsert;
    }

    public function getConfiguracaoGeralEscola($escola)
    {
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('D023_Ava_Sae_Configuracoes');
        $this->getAvaMySQL()->where('EscolaID', $escola);
        $this->getAvaMySQL()->where('Tipo', 'G');
        $query = $this->getAvaMySQL()->get();

        return $query->row();
    }

    public function atualizaConfigLivroDigitalEscola($escola, $situacao)
    {
        $domain = 'D023_Ava_Sae_Configuracoes';

        if ($situacao) {

            $acessoLD = 'S';

        } else {

            $acessoLD = 'N';

        }

        $dados = array(
            'AcessoLD' => $acessoLD
        );

        $this->getAvaMySQL()->where('Tipo', 'G');
        $this->getAvaMySQL()->where('EscolaID', $escola);
        $checkinsert = $this->getAvaMySQL()->update($domain,$dados);

        return $checkinsert;
    }

    public function getTurmasEscola($escolaId, $anoVigencia = null){
        if (is_null($anoVigencia)) {
            $anoVigencia = (int)date("Y") - 1;
        }

        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('D021_Ava_Sae_Turmas');
        $this->getAvaMySQL()->where('EscolaID', $escolaId);
        $this->getAvaMySQL()->where('Vigencia =', $anoVigencia);
        $this->getAvaMySQL()->where_in('Situacao', ["A"]);
        $this->getAvaMySQL()->order_by('');
        $query = $this->getAvaMySQL()->get();

        return $query->result_array();

    }

    public function getAlunosTurma($turmaId){

        $this->getAvaMySQL()->select('itemName, Login, Nome');
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->where('Turma', $turmaId);
        $this->getAvaMySQL()->where('Perfil', 273);
        $this->getAvaMySQL()->where('Situacao', "A");
        $query = $this->getAvaMySQL()->get();

        return $query->result_array();

    }

    public function getCategoriaTurma($categoriaId)
    {
        $tableCategorias = "D022_Ava_Sae_CategoriaTurma";
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from($tableCategorias);
        $this->getAvaMySQL()->where('itemName', $categoriaId);
        $query = $this->getAvaMySQL()->get();

        return $query->row();
    }

    public function getSerieDetails($serieId)
    {
        $tableSeries = "T001_Series";
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from($tableSeries);
        $this->getAvaMySQL()->where('SerieID', $serieId);
        $query = $this->getAvaMySQL()->get();

        return $query->row();
    }

    public function criaNovaTurma(
        $turmaId,
        $novoNomeTurma,
        $novaCategoriaTurma,
        $novaSerieTurma,
        $novaVigenciaTurma
    ) {

        $tableTurmas = 'D021_Ava_Sae_Turmas';
        $novoItemName = md5(uniqid(rand(), true));
        $hoje = date('Y-m-d H:i:s');
        $UsuarioAlt = $this->session->userdata("pessoaid");
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from($tableTurmas);
        $this->getAvaMySQL()->where('itemName', $turmaId);
        $query = $this->getAvaMySQL()->get();
        $turma = $query->row();
        unset($turma->id);

        $categoria = $this->getCategoriaTurma($novaCategoriaTurma);

        $serie = $this->getSerieDetails($novaSerieTurma);

        $turma->itemName = $novoItemName;
        $turma->CategoriaTurmaID = $novaCategoriaTurma;
        $turma->Descricao = $novoNomeTurma;
        $turma->SerieID = $novaSerieTurma;
        $turma->UsuarioAlt = $UsuarioAlt;
        $turma->UsuarioCad = $UsuarioAlt;
        $turma->Vigencia = $novaVigenciaTurma;
        $turma->DtCad = $hoje;
        $turma->DtAlt = $hoje;
        $turma->Migrada = 0;
        $turma->Situacao = 'A';
        $turma->DtAlt = $hoje;
        $turma->CategoriaTurmaID = $categoria->itemName;
        $turma->DescricaoCategoriaTurma = $categoria->Descricao;
        $turma->DescricaoSerie = $serie->Descricao;
        $turma->SerieID = $serie->SerieID;

        $this->getAvaMySQL()->insert($tableTurmas, $turma);

        $lastInsert = $this->getAvaMySQL()->insert_id();
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from($tableTurmas);
        $this->getAvaMySQL()->where('id', $lastInsert);
        $query = $this->getAvaMySQL()->get();

        return $query->row();


    }

    public function inativaTurmaAntiga($turmaId)
    {

        $tableTurmas = 'D021_Ava_Sae_Turmas';
        $update = [
            "Situacao" => "I",
            "Migrada" => 1
        ];
        $this->getAvaMySQL()->where('itemName', $turmaId);
        $this->getAvaMySQL()->update($tableTurmas, $update);

    }

    public function getAluno($alunoId)
    {

        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->where('itemName', $alunoId);
        $this->getAvaMySQL()->where('Perfil', 273);
        $this->getAvaMySQL()->where('Situacao', "A");
        $query = $this->getAvaMySQL()->get();

        return $query->row();

    }

    public function softDeleteAluno($alunoId)
    {
        $update = [
            "Situacao" => "E",
            'Email' => null
        ];
        $this->getAvaMySQL()->where('itemName', $alunoId);
        $this->getAvaMySQL()->update("D019_Ava_Sae", $update);

    }

    public function atualizaResponsavel($aluno)
    {
        $itemNameAntigo = $aluno->MigradoDe;
        $itemNameNovo = $aluno->itemName;

        $update = [
            'Aluno' => $itemNameNovo,
            'Senha' => md5(Senha::RESPONSAVEL),
            'PrimeiroLogin' => 'S',
            'DtCad' => (new DateTime())->format('Y-m-d H:i:s'),
            'DtAlt' => (new DateTime())->format('Y-m-d H:i:s')
        ];

        $this->getAvaMySQL()->where('perfil', 274);
        $this->getAvaMySQL()->where('Aluno', $itemNameAntigo);
        $this->getAvaMySQL()->update("D019_Ava_Sae", $update);

    }

    public function getClass($classId)
    {
        $schoolId = $this->session->userdata("escola");

        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('D021_Ava_Sae_Turmas');
        $this->getAvaMySQL()->where('itemName', $classId);
        $this->getAvaMySQL()->where('EscolaID', $schoolId);
        $query = $this->getAvaMySQL()->get();

        return $query->row();
    }

    public function canChangeStudent($studentId)
    {
        $schoolId = $this->session->userdata("escola");

        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->where('itemName', $studentId);
        $this->getAvaMySQL()->where('Escola', $schoolId);
        $this->getAvaMySQL()->where('Perfil', 273);
        $query = $this->getAvaMySQL()->get();

        return ($query->num_rows() > 0) ? true : false;
    }

    public function migraAlunos($alunos, $turma)
    {
        $novosAlunos = [];

        $UsuarioAlt = $this->session->userdata("pessoaid");

        $vigencia = $turma->Vigencia;

        /*
            TODO: Após arrumar o login, colocar $hoje com a data atual
            Colocamos assim pois até o momento o login é liberado com
            base na datacad. Se o ano for igual ao atual ele faz login.
            O login deveria ser liberado com base na vigência
        */
        $hoje = date("{$vigencia}-m-d H:i:s");

        $escola = SaeDigital::make(BuscarDadosEscola::class)->handle(
            $this->session->userdata("escola")
        );

        foreach ($alunos as $alunoAntigo) {

            /*
                Para não ser possível alterar um aluno
                que não seja da escola atual
            */
            if (!$this->canChangeStudent($alunoAntigo)) {
                continue;
            }

            $novoItemName = md5(uniqid(rand(), true));

            $alunoParaMigrar = $this->getAluno($alunoAntigo);
            $this->softDeleteAluno($alunoAntigo);

            unset($alunoParaMigrar->id);

            $alunoParaMigrar->itemName = $novoItemName;
            // TODO: permir que alunos com primeiro login sejam migrados
            /*
                Primeiro login = N pois um aluno migrado
                não consegue passar da tela de primeiro login
                pois será mostrada a mesagem "este login já existe".
                Isso ocorre pois ele tenta atualizar as infos do aluno salvando um novo registro
                Seria interessante ver como modificar isso para permitir que um aluno
                seja migrado mesmo que ele nunca tenha acessado a plataforma
                na turma que ele estava.
                Coloquei um filtro na função que pega os alunos para serem migrados ($this->getAlunosTurma()),
                ela só retorna alunos que já acessaram a plataforma.
            */
            $alunoParaMigrar->PrimeiroLogin = "S";
            $alunoParaMigrar->Senha = md5(Senha::ALUNO);
            $alunoParaMigrar->Turma = $turma->itemName;
            $alunoParaMigrar->VigenciaTurma = $turma->Vigencia;
            $alunoParaMigrar->DescricaoTurma = $turma->Descricao;
            $alunoParaMigrar->DescricaoSerie = $turma->DescricaoSerie;
            $alunoParaMigrar->Serie = $turma->SerieID;
            $alunoParaMigrar->versao_conteudo_id = $escola['versao_conteudo_id'];

            $alunoParaMigrar->DtAlt = $hoje;
            $alunoParaMigrar->DtCad = $hoje;

            $alunoParaMigrar->UsuarioAlt = $UsuarioAlt;
            $alunoParaMigrar->UsuarioCad = $UsuarioAlt;
            $alunoParaMigrar->MigradoDe = $alunoAntigo;

            array_push($novosAlunos, $alunoParaMigrar);
        }

        $this->getAvaMySQL()->insert_batch('D019_Ava_Sae', $novosAlunos);

        foreach ($novosAlunos as $aluno) {
            $this->atualizaResponsavel($aluno);
        }

        return $novosAlunos;
    }

    /**
     *  Busca a versão de conteúdo da escola através do itemname da mesma.
     *
     * @param string $escolaid
     *
     * @return integer
     */
    public function versaoEscola($escolaid)
    {
        /** @var \PDO $pdo */
        $pdo = SaeDigital::make(PDO::class);

        $sql = "SELECT
                    versao_conteudo_id
                FROM
                    D019_Ava_Sae
                WHERE
                    Perfil = 269
                    AND Situacao = 'A'
                    AND itemName = :escola";

        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':escola', $escolaid, PDO::PARAM_INT);
        $stmt->execute();

        $versao = $stmt->fetchColumn();

        return (int) ($versao !== 0 ? $versao : null);
    }

    public function professorPlataformaLiteraria($disciplinas)
    {
        foreach ($disciplinas as $disciplina) {
            if (strpos(strtolower($disciplina['Descricao']), 'plataforma') !== false) {
                return true;
            }
            continue;
        }

        return false;
    }

    /**
     * @param string $itemName
     * @return array
     */
    public function verifyToken($itemName)
    {
        $this->getAvaMySQL()->select('tokenEscolaMov');
        $this->getAvaMySQL()->select('AmbienteEEM');
        $this->getAvaMySQL()->from('D023_Ava_Sae_Configuracoes');
        $this->getAvaMySQL()->where('itemName', $itemName);
        $query = $this->getAvaMySQL()->get();

        return $query->row();
    }

    public function verificaAlunoEM($alunoid)
    {
        try {
            $this->getAvaMySQL()->select('*');
            $this->getAvaMySQL()->from('EscolaMovimento');
            $this->getAvaMySQL()->where('alunoid', $alunoid);
            $query = $this->getAvaMySQL()->get();
            return $query->result_array();

        } catch (Exception $e) {
            log_error($e->getMessage());
            return false;
        }
    }

    public function salvaAlunoEEM($dados, $replace = true)
    {
        try {
            if ( $replace ){
                return $this->getAvaMySQL()->insert('EscolaMovimento', $dados);
            }else{
                $id = $dados['alunoid'];
                $this->getAvaMySQL()->where('alunoid',$id);
                return $this->getAvaMySQL()->update('EscolaMovimento', $dados);
            }
        } catch (Exception $e) {
            log_error($e->getMessage());
            return false;
        }
    }

    public function alunosPturma($turma){
        $this->getAvaMySQL()->select('d019.Nome');
        $this->getAvaMySQL()->select('d019.Login');
        $this->getAvaMySQL()->select('d019.itemName');
        $this->getAvaMySQL()->select('d019.Turma');
        $this->getAvaMySQL()->select('d019.Escola');
        $this->getAvaMySQL()->select('eem.alunora');
        $this->getAvaMySQL()->from('D019_Ava_Sae d019');
        $this->getAvaMySQL()->join(
            "EscolaMovimento eem",
            "d019.itemName = eem.alunoid",
            "LEFT"
        );
        $this->getAvaMySQL()->where('d019.Turma', $turma);
        $this->getAvaMySQL()->where('d019.Perfil', 273);
        $this->getAvaMySQL()->where('d019.Situacao', "A");
        $query = $this->getAvaMySQL()->get();

        return $query->result_array();
    }
}
