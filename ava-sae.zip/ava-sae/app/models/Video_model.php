<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

// TODO: FDD-429 - REVER, NAO ESTAMOS MAIS USANDO DYNAMO DB
class Video_model extends MY_Model {
        
    function getPlayerLogs($param = null) {

        $client = $this->iesdesdk2aws->get_service('DynamoDb','','us-east-1');
        
        // filtros:
        $item['turmaid']['ComparisonOperator'] = 'EQ';
        $item['turmaid']['AttributeValueList'] = array(array('S' => isset($param['turmaid']) ? $param['turmaid'] : (string) $this->session->userdata('TurmaID') ));
        $item['datacadastro']['ComparisonOperator'] = 'GE';
        $item['datacadastro']['AttributeValueList'] = array(array('S' => '2015-07-17 16:50:00'));
        $item['disciplinaid']['ComparisonOperator'] = 'EQ';
        $item['disciplinaid']['AttributeValueList'] = array(array('S' => (string) $param['disciplinaid'] ));
        
        $select = array(
            'TableName' => 'DY015_EventosPlayer',
            'ConsistentRead' => false,
            'IndexName' => 'pessoaid-index',            
            'KeyConditions' => array(
                'pessoaid' => array(
                    'AttributeValueList' => array(
                            array('S' => isset($param['alunoid']) ? $param['alunoid'] :$this->session->userdata('pessoaid')),
                    ), 
                    'ComparisonOperator' => 'EQ',
                ),
            ),
            'QueryFilter' => $item,
            'ReturnConsumedCapacity' => 'TOTAL'
        );
        
        $result = $client->Query($select);        
        return $this->formatarDadosDynamo($result);
    }

    // Formata resultado dos dados consultados no servico dynamodb
    // TODO: FDD-429 - REVER, NAO ESTAMOS MAIS USANDO DYNAMO DB
    function formatarDadosDynamo($result, $format = 'array') {
    
        $return = array();
        $i = 0;
        foreach ($result['Items'] as $key => $value) {
            foreach ($value as $type => $attr) {
                $return[$key][$type] = current($attr);
            }
            $i++;
        }
    
        if (!empty($return)) {
            //$return['Count'] = $result['Count'];
            switch ($format) {
                case 'json':
                    return json_encode($return);
                    break;
                default:
                    return $return;
                    break;
            }
        } else {
            return array();
        }
    }
    
}
