<?php


class Acesso_model extends MY_Model
{
    public $sdb;

    function __construct()
    {
        parent::__construct();

    }


    /* NAO ESTÁ SENDO USADA!!!!  */
    public function verificaControleAcessos($id) {

        $selectExpression ="select * from D020_Controle_Acessos_Sae where id = '$id' and Situacao = 'A'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }


    /* NAO ESTÁ SENDO USADA!!! */
    function verificaSituacaoSessaoIP($dados) {
        $id = $dados['id'];

        $selectExpression = "select * from D020_Controle_Acessos_Sae where id = '$id'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

     /*function verificaSituacao($dados) {

        $pessoaPerfilID = $dados['PessoaPerfilID'];

        $response = $this->sdb->select("select * from D006_Controle_Acessos where PessoaPerfilID = '$pessoaPerfilID' and Situacao = 'A'");

        $return = '';
        if (@$response->body->SelectResult->Item->Attribute) {
            $return = formataArraydeObjetos($response->body->SelectResult);
        }

        return $return;

    }*/

    public function novoControleAcessos($dados) {

        $fields = array(
            'DtAcesso' => utf8_encode($dados['DtAcesso']),
            'Situacao' => utf8_encode($dados['Situacao']),
            'IP' => utf8_encode($dados['IP']),
            'SubIP' => utf8_encode($dados['SubIP']),
            'SiteID' => utf8_encode($dados['SiteID']),
            'manterconectado' => utf8_encode($dados['manterconectado']),
            'itemName' => $dados['ItemName']
        );
        $insert= $this->getAvaMySQL()->insert('D020_Controle_Acessos_Sae', $fields);
        return $insert;

    }

    // TODO: VERIFICAR O QUE ISSO FAZ, SE É QUE FAZ ALGUMA COISA
      public function atualizaControleAcesso($dados) {

          $fields = array(
          'Situacao' => utf8_encode($dados['Situacao'])
          );

          $insert= $this->getAvaMySQL()->insert('D020_Controle_Acessos_Sae', $data);
          return $insert;


    }

    public function logoutControleAcesso($dados)
    {

        $fields = array(
            'Situacao' => utf8_encode($dados['Situacao'])
        );

        $insert= $this->getAvaMySQL()->insert('D020_Controle_Acessos_Sae', $fields);

        return $insert;

    }

    public function countInactiveSessions() {

        $countSessionsSql = "SELECT count(*) as sessions from ci_sessions WHERE timestamp < (unix_timestamp() - 3600)";
        $result = $this->getAvaMySQL()->query($countSessionsSql);
        
        return $result->row()->sessions;
    }

    public function deleteInactiveSessions() {

        $countSessionsSql = "DELETE from ci_sessions WHERE timestamp < (unix_timestamp() - 3600)";
        $result = $this->getAvaMySQL()->query($countSessionsSql);
        
        return $result;
    }


}
