<?php

use Ava\App\Services\Escola\BuscarDadosEscolaEspecificaNextAva;
use Zendesk\API\HttpClient as ZendeskAPI;
use GuzzleHttp\Client as Guzzle;

/**
 * Class Ticket_model
 */
class Ticket_model extends MY_Model
{
    /**
     * @var
     */
    private $_zendesk_client;

    /**
     * @var string
     */
    private $zendeskUsername;


    /**
     * Ticket_model constructor.
     */
    function __construct()
    {
        $this->zendeskUsername = $zendeskUsername = base64_encode(getenv('ZENDESK_EMAIL') . '/token:' . getenv('ZENDESK_TOKEN'));
        parent::__construct();
    }

    /**
     * @return mixed
     * @throws \Zendesk\API\Exceptions\AuthException
     * @throws \Zendesk\API\Exceptions\MissingParametersException
     * @throws \Zendesk\API\Exceptions\RouteException
     */
    public function TicketsNaoLidosUsuario()
    {
        $client  = $this->getClient();
        $search = $client->search()->find('requester:'.$this->tickets->getRequesterEmail() . ' tags:nao_lido');
        return $search->count;
    }

    /**
     * @param $escola_id
     * @return mixed
     */
    public function getEscola($escola_id)
    {
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->where('itemName', $escola_id);
        $escola = $this->getAvaMySQL()->get();

        if ( $escola->num_rows() > 0 ) {
            return $escola->row_array();
        }
    }

    /**
     * @return string
     */
    public function getRequesterEmail()
    {
        $escola_id = $this->session->userdata('escola');
        $escola = SaeDigital::make(BuscarDadosEscolaEspecificaNextAva::class)->handle($escola_id);
        $login = removeAcentos($escola->login);
        $pattern = '/[^a-zA-Z0-9]]/i';
        $replacement = '.';
        $dominio =  preg_replace($pattern, $replacement, $login);
        $usuario_id = $this->session->userdata("pessoaid");


        $requester = $usuario_id . '@' . $dominio . '.com';
        return $requester;

    }

    /**
     * @return ZendeskAPI
     * @throws \Zendesk\API\Exceptions\AuthException
     */
    public function getClient()
    {
        if(!$this->_zendesk_client){
            $this->_zendesk_client = new ZendeskAPI(getenv('ZENDESK_SUBDOMAIN'));
            $this->_zendesk_client->setAuth('basic', ['username' => getenv('ZENDESK_EMAIL'), 'token' => getenv('ZENDESK_TOKEN')]);
        }

        return $this->_zendesk_client;
    }

    /**
     * @return array
     */
    public function getRequester()
    {
        return array(
            'locale_id' => '1',
            'name' => ($this->session->userdata('nome')) ? $this->session->userdata('nome') : "Nome não informado",
            'email' => $this->getRequesterEmail(),
        );
    }

    /**
     * @return Guzzle
     */
    public function getGuzzleClient()
    {
        return new Guzzle([
            'base_uri' => getenv('ZENDESK_URL'),
            'timeout'  => 30,
        ]);
    }

    /**
     * @param int $formId
     * @return array
     * @throws Exception
     */
    public function getForm($formId)
    {
        $guzzleClient = $this->getGuzzleClient();
        $form = $guzzleClient->get('/api/v2/ticket_forms/' . $formId, ['headers' => [
            'Authorization' => 'Basic ' . $this->zendeskUsername, 'Content-Type' => 'application/json ']
        ]);

        if (!in_array($form->getStatusCode(), array(200, 201, 205))) {
            throw new \Exception('Erro ao buscar as informações, tente novamente mais tarde.');
        }

        return json_decode($form->getBody(), true);
    }

    /**
     * @return array
     * @throws Exception
     */
    public function getFields()
    {
        $guzzleClient = $this->getGuzzleClient();
        $form = $guzzleClient->get('/api/v2/ticket_fields', [
            'headers' => ['Authorization' => 'Basic ' . $this->zendeskUsername, 'Content-Type' => 'application/json ']
        ]);

        if (!in_array($form->getStatusCode(), array(200, 201, 205))) {
            throw new \Exception('Erro ao buscar as informações, tente novamente mais tarde.');
        }

        $fields = json_decode($form->getBody(), true);

        return ($fields['ticket_fields'] ? $fields['ticket_fields'] : []);
    }
}
