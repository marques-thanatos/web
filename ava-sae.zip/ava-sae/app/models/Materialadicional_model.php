<?php

class Materialadicional_Model extends MY_Model{
    function __construct(){
        parent::__construct();
        

    }
    public $file;

    public function gerarNomeDeArquivo()
    {
        $selectExpression = "select id from D038_Materiais_Adicionais_Upload Where id is not null order by id DESC limit 1";
        $result = $this->getAvaMySQL()->query($selectExpression);
        $find = $result->result_array();
        $fileName = empty($find) ? md5('1') . date('Y_m_d_h_m_i') : md5($find[0]['id']) . '_' . date('Y_m_d_h_m_i');
        return $fileName;
    }

    protected function generateConditions($params){
        $sql = array();
        foreach ($params as $key => $value)
            $sql[] = $key .' = '. "'$value'";
        return implode(' and ',$sql);
    }

    public function geraid (){
        $selectExpression = "select id from D038_Materiais_Adicionais_Upload Where id is not null order by id DESC limit 1";
        $result = $this->getAvaMySQL()->query($selectExpression);
        $find = $result->result_array();

        return $find[0]['id']+1;
    }

    public function findById($idMaterial)
    {
        try {
            /** @var \PDO $pdo */
            $pdo = SaeDigital::make(PDO::class);
            $sql = "SELECT 
                        *
                    FROM
                        D038_Materiais_Adicionais_Upload arquivo
                    WHERE
                        arquivo.id = :idMaterial
                    LIMIT 1;";

            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':idMaterial', $idMaterial, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {

        } catch (\Exception $e) {

        }
    }

    public function buscaMaterialAdicional($idDisciplina, $idEscola, $idTurma){
        try {
            /** @var \PDO $pdo */
            $pdo = SaeDigital::make(PDO::class);

            $sql = "SELECT 
                    id, NomeGerado, concat(nomeOriginal,'.', Extensao) NomeOriginal, Extensao, DtCad
                FROM
                    D038_Materiais_Adicionais_Upload
                WHERE
                    Situacao = 'A'
                        AND DisciplinaID = :idDisciplina
                        AND EscolaID = :idEscola
                        AND TurmaID = :idTurma;";

            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':idDisciplina', $idDisciplina, PDO::PARAM_INT);
            $stmt->bindValue(':idEscola', $idEscola, PDO::PARAM_STR);
            $stmt->bindValue(':idTurma', $idTurma, PDO::PARAM_STR);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            return false;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function listaAlunoDisciplinas($idTurma, $idVersaoConteudo = 1){
        try {
            /** @var \PDO $pdo */
            $pdo = SaeDigital::make(PDO::class);
            $sql = "SELECT 
                    E093.GrupoAulaID AS itemName, E093.Descricao, MAX(D038.DtCad) AS maxDtCad
                FROM
                    D021_Ava_Sae_Turmas D021
                      INNER JOIN E093_GruposAulas E093 ON D021.SerieID = E093.SerieID
                      INNER JOIN T002_SeriesDisciplinas T002 ON E093.GrupoAulaID = T002.DisciplinaID
                      INNER JOIN D038_Materiais_Adicionais_Upload D038 ON T002.DisciplinaID = D038.DisciplinaID 
                      AND D021.itemName = D038.TurmaID 
                WHERE
                    D021.Situacao = 'A'
                        AND E093.ClassificacaoID = 10
                        AND T002.versao_conteudo_id = :idVersaoConteudo
                        AND D021.itemName = :idTurma;";

            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':idTurma', $idTurma, PDO::PARAM_STR);
            $stmt->bindValue(':idVersaoConteudo', $idVersaoConteudo, PDO::PARAM_INT);
            $stmt->execute();

            $disciplinas = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $idEscola = $this->session->userdata('escola');

            $listaDisciplinas = [];
            foreach ($disciplinas as $key => $disciplina) {
                $arquivo = $this->buscaMaterialAdicional($disciplina['itemName'], $idEscola, $idTurma);
                $listaDisciplinas[] = [
                    'descricao' => $disciplina['Descricao'],
                    'files' => $arquivo,
                    'maxDtCad' => $disciplina['maxDtCad']
                ];
            }
            return $listaDisciplinas;
        } catch (\PDOException $e) {
            return false;
        } catch (\Exception $e) {
            return false;
        }
    }

}
