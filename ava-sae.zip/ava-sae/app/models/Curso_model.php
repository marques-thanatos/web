<?php

use Ava\App\Exceptions\BadGatewayException;
use Ava\App\Exceptions\NotFoundException;
use Ava\App\Services\Assuntos\PegaAssuntoPeloId;
use Ava\App\Services\Jarvis\JarvisApi;
use Ava\App\Services\Questoes\BuscarEstruturaQuestao;
use Ava\App\Services\Aluno\ObterAlunoPorIdNextAva;
use Ava\App\Support\ClassificacaoConteudo;
use Ava\App\Support\TipoAgendamento;

class Curso_model extends MY_Model {
    public $pessoaid;
    protected $trigger = array(
        "NomeAluno" => "",
        "DescDisciplina" => "",
        "DescFrente" => "",
        "DescAssunto" => "",
        "NomeEscola" => "",
        "DescTurma" => "",
        "FrenteID" => "",
        "EscolaID" => "",
        "SerieID" => "",
        "UsuarioID" => "",
        "DisciplinaID" => "",
        "TurmaID" => "",
        "AssuntoID" => "",
        "TotalQuestoes" => 0,
        "TotalAcertoQuestoes" => 0,
        "TotalVideos" => 0,
        "TotalQuestoesRevisao" => 0,
        "TotalAcertosQuestoesRevisao" => 0,
        "MetaQuestoes" => 0,
        "MetaVideos" => 0,
        "DtAgendaInicio" => "",
        "DtAgendaFim" => "",
        "Tipo" => "");
    function __construct() {
        parent::__construct();

        $this->pessoaid = $this->session->userdata('pessoaid');
    }

    /**
     * Verifica Categorias com Ordem definida
     *
     *
     * @access	public
     * @param	int           dado GrupoAulaID.
     * @return	array         com conteúdo / vazio
     */
    public function verificaCategoriaOrdem($GrupoAulaID = null, $categoriaID = null) {
        $sql = '';
        if ($GrupoAulaID) {

            if ($categoriaID) {
                $sql = " and e088.CategoriaAulaID = '" . $categoriaID . "' ";
            }

            $selectExpression = "select concat(LPAD(e088.CategoriaAulaID,7,'0'),LPAD(e094.GrupoAulaID,7,'0')) as ItemName
                                     , e088.Descricao
                                     , e088.CategoriaAulaID as CategoriaID
                                     , e094.Ordem as OrdemCategoria
                                from E088_CategoriasAulas e088
                                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                where e094.GrupoAulaID = ". $GrupoAulaID ."
                                and e094.Ordem is not null 
                                ". $sql ."
                                order by ABS(e094.Ordem) ASC";

            // TODO: FDD-429 - UNSAFE QUERY
            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
        }

        return '';
    }

    /**
     * Verifica Disciplinas com Ordem definida
     *
     * Recebe os parâmetros de GrupoAulaID via URL.
     *
     * @access	public
     * @param	int           dado GrupoAulaID.
     * @return	array         com conteúdo / vazio
     */
    public function verificaDisciplinasOrdem($GrupoAulaID = null, $DisciplinaID = FALSE, $CategoriaID = FALSE) {
        if ($GrupoAulaID) {

            $Disciplina = '';
            if ($DisciplinaID) {
                $Disciplina = " and e089.SubCategoriaAulaID = '$DisciplinaID' ";
            }
            $Categoria = '';
            if ($CategoriaID) {
                $Categoria = " and e088.CategoriaAulaID = '$CategoriaID' ";
            }

            $selectExpression = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                     , e089.Descricao
                                     , e094.GrupoAulaID
                                     , e089.SubCategoriaAulaID as DisciplinaID
                                     , e089.DtInicio
                                     , e088.CategoriaAulaID as CategoriaID
                                     , '' as TemMensagem
                                     , null as SemQuestoes
                                from E089_SubCategoriasAulas e089
                                inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                where e094.GrupoAulaID = ". $GrupoAulaID ."
                                  and e089.Descricao != '' 
                                  ". $Categoria ."
                                  ". $Disciplina ." 
                                  and (e089.Situacao is null or e089.Situacao = 'A') 
                                order by ABS(e090.Ordem) ASC";
            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
        }

        return '';
    }

    /**
     * Verifica Disciplinas sem Ordem definida
     *
     * Recebe os parâmetros de GrupoAulaID via URL.
     *
     * @access	public
     * @param	int           dado GrupoAulaID.
     * @return	array         com conteúdo / vazio
     */
    public function verificaDisciplinas($GrupoAulaID = null, $DisciplinaID = FALSE, $CategoriaID = FALSE) {

        $return = '';
        if ($GrupoAulaID) {

            $Disciplina = '';
            if ($DisciplinaID) {
                $Disciplina = " and e089.SubCategoriaAulaID = '$DisciplinaID' ";
            }

            $Categoria = '';
            if ($CategoriaID) {
                $Categoria = " and e088.CategoriaAulaID = '$CategoriaID' ";
            }

            $select_expression = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                     , e089.Descricao
                                     , e094.GrupoAulaID
                                     , e089.SubCategoriaAulaID as DisciplinaID
                                     , e089.DtInicio as DtInicio
                                     , e088.CategoriaAulaID as CategoriaID
                                     , '' as TemMensagem
                                     , null as SemQuestoes,
                                     e090.Ordem
                                from E089_SubCategoriasAulas e089
                                inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                where e094.GrupoAulaID = ". $GrupoAulaID ."
                                  ". $Disciplina ."
                                  ". $Categoria ."
                                  and e089.Descricao != '' 
                                  and (e089.Situacao is null or e089.Situacao = 'A') 
                                order by ABS(e090.Ordem) asc";

            // TODO: FDD-429 - UNSAFE QUERY
            $result = $this->getAvaMySQL()->query($select_expression);
            $return =  $result->result_array();
        }

        return $return;
    }



    // TODO: FDD-429 - VERIFICAR SE ISSO AINDA FUNCIONA, POIS AINDA ESTÁ NO FORMATO DO SIMPLEDB
    public function verificaDisciplinasMensagem($GrupoAulaID = null) {

        $return = '';
        if ($GrupoAulaID) {

            $select_expression = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                        , e089.Descricao
                                         , e094.GrupoAulaID
                                         , e089.SubCategoriaAulaID as DisciplinaID
                                         , e089.DtInicio as DtInicio
                                         , e088.CategoriaAulaID as CategoriaID
                                         , '' as TemMensagem
                                    from E089_SubCategoriasAulas e089
                                    inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                    inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                    inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                    where e094.GrupoAulaID = ". $GrupoAulaID ."
                                      and e089.Descricao != ''
                                    order by e089.Descricao ASC";

            $disc = array();

            $next_token = null;
            do {
                if ($next_token) {
                    $response = $this->sdb->select($select_expression, array(
                        'NextToken' => $next_token,
                    ));

                    $disc = array_merge($disc, formataArraydeObjetos($response->body->SelectResult));
                } else {

                    $response = $this->sdb->select($select_expression);
                    $disc = array_merge($disc, formataArraydeObjetos($response->body->SelectResult));
                }

                $next_token = isset($response->body->SelectResult->NextToken) ? (string) $response->body->SelectResult->NextToken : null;
            } while ($next_token);
            $return = $disc;
        }

        return $return;
    }

    /**
     * Verifica Vídeos Aulas Disciplinas Video
     *
     * Recebe o parâmetro de GrupoAulaID e retorno o array de dados.
     *
     * @access	public
     * @param	int           dado GrupoAulaID.
     * @return	array         com conteúdo / vazio
     */
    public function verificaVideoAulasDisciplinaVideo($GrupoAulaID, $DisciplinaID, $tipo = null, $questao = true) {

        $dados = $this->verificaDisciplinas($GrupoAulaID, $DisciplinaID);

        $videoaulas = array();

        if (empty($dados))
            return $videoaulas;

        $sql = '';
        if ($tipo) {
            $sql = " and e068.Tipo = '" . $tipo . "' ";
        } else if($questao) {
            $sql .= "and e091.Ordem != ''";
        }

        $tmp = '';
        foreach ($dados as $key => $value) {


            $selectExpression = "select e068.AulaID
                                     , e091.SubCategoriaID as DisciplinaID
                                     , e068.Tema
                                     , LPAD(e091.Ordem,4,0) as Ordem
                                     , e068.Video
                                     , e068.Duracao
                                     , e068.DtCad
                                     , e068.Tipo
                                     , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                                     
                                from E068_Aulas e068
                                inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                where e091.SubCategoriaID = ". $value['DisciplinaID'] ."
                                ". $sql ."
                                order by ABS(e091.Ordem) ASC";

            $dtInicio = isset($value['DtInicio']) ? $value['DtInicio'] : '-';
            $videoaulas[$value['Descricao']]['info'] = array('DtInicio' => $dtInicio);
            $videoaulas[$value['Descricao']]['aulas'] = array();

            // TODO: FDD-429 - UNSAFE QUERY
            $result = $this->getAvaMySQL()->query($selectExpression);
            $videoaulas[$value['Descricao']]['aulas'] = $result->result_array();
        }

        return $videoaulas;
    }

    public function corrigeAgendamentos($escola, $assuntoId, $turmaid, $disciplinaId, $frenteId){
        $updateAgendamento = "update R001_RespostasQuestoes, (
            select DtInicio, DtFim from D024_Ava_Sae_Agenda where 
            EscolaID = ?  and
            AssuntoID = ? and
            TurmaID = ? and
            DisciplinaID =  ? and
            FrenteID = ? and 
            AlunoID is null
        ) as t set DtAgendaInicio = t.DtInicio, DtAgendaFim = t.DtFim
        where EscolaID = ?  and
            AssuntoID = ? and
            TurmaID = ? and
            DisciplinaID =  ? and
            FrenteID = ? and 
            Situacao = 'A'"
        ;

        $this->getAvaMySQL()->query($updateAgendamento, array($escola, $assuntoId, $turmaid, $disciplinaId, $frenteId
        , $escola, $assuntoId, $turmaid, $disciplinaId, $frenteId));
    }

    public function corrigeAgendamentosPlataformaLiteraria($turmaid, $assuntoid, $disciplinaid){
        try{
            
            $updateAgendamento = "update R001_RespostasQuestoes, (
                select DtInicio, DtFim from D024_Ava_Sae_Agenda where 
                AssuntoID = ? and
                TurmaID = ? and
                DisciplinaID =  ? and
                AlunoID is null
            ) as t set DtAgendaInicio = t.DtInicio, DtAgendaFim = t.DtFim
            where
                AssuntoID = ? and
                TurmaID = ? and
                DisciplinaID =  ? and
                Situacao = 'A'";
            $this->getAvaMySQL()->query($updateAgendamento, array($assuntoid, $turmaid, $disciplinaid, $assuntoid, $turmaid, $disciplinaid));
        }catch (Exception $e){
            //FIXME: Salvar no log de agendamento erro quando nao foi possivel corrigir
            $acao = "Tentou corrigir agendamento plataforma literaria e falhou.Turma ID=".$turmaid; //agendamento
            $acao .= " Assunto ID = ".$assuntoid. "DisciplinaID = ".$disciplinaid;
            $this->salvaLogAgendamento($acao);
            exit;
        }
    }

    function salvaLogAgendamento($acao){
        try{
            $codigo = 5;  //agendamento
            $log['loginid'] = $this->session->userdata['pessoaid'];
            $log['login'] = $this->session->userdata['login'];
            $log['acao'] = ($acao);
            $log['nomeescola'] = ($this->session->userdata['nomeEscola']);
            $log['escola'] = ($this->session->userdata['escola']);
            $log['codigo'] = $codigo;

            $this->load->model('Log_model','logacesso');
            $this->logacesso->GravaLog($log);

        }catch (Exception $e){
            // TODO: FDD-429 - VERIFICAR! CAPTURAR ESTE ERRO E NAO TRATAR FAZ ELE NAO BATER NO SENTRY
            exit;
        }
    }

    /**
     * Verifica Vídeos Aulas Disciplinas
     *
     * Recebe o parâmetro de GrupoAulaID e retorno o array de dados.
     *
     * @access	public
     * @param	int           dado GrupoAulaID.
     * @return	array         com conteúdo / vazio
     */
    public function verificaVideoAulasDisciplina($GrupoAulaID, $categoriaid = null) {
        $videoaulas = '';

        if (empty($videoaulas)) {
            $cat = $this->verificaCategoriaOrdem($GrupoAulaID, $categoriaid);
            if ($cat) {
                $a = 0;
                foreach ($cat as $key => $categoria) {
                    $dis = $this->verificaDisciplinas($GrupoAulaID, False, $categoria['CategoriaID']);
                    if ($dis) {
                        foreach ($dis as $key2 => $subcategoria) {
                            $dados[$a]['DtFimAluno'] = '';
                            $dados[$a]['DtInicio'] = $subcategoria['DtInicio'];
                            $dados[$a]['Descricao'] = $subcategoria['Descricao'];
                            $dados[$a]['GrupoAulaID'] = $subcategoria['GrupoAulaID'];
                            $dados[$a]['DisciplinaID'] = $subcategoria['DisciplinaID'];
                            $dados[$a]['DescricaoCategoria'] = $categoria['Descricao'];
                            $dados[$a]['CategoriaID'] = $categoria['CategoriaID'];
                            $dados[$a]['itemName'] = $subcategoria['itemName'];
                            $dados[$a]['SemQuestoes'] = isset($subcategoria['SemQuestoes']) ? $subcategoria['SemQuestoes'] : 'N';
                            $dados[$a]['TemMensagem'] = isset($subcategoria['TemMensagem']) ? $subcategoria['TemMensagem'] : '';
                            $a++;
                        }
                    }
                }
            }

            $videoaulas = array();

            if (empty($dados))
                return $videoaulas;

            $tmp = '';
            foreach ($dados as $key => $value) {
                $select = "select count(e068.AulaID) as Count                                     
                                from E068_Aulas e068
                                inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                where e091.SubCategoriaID = ". $value['DisciplinaID'] ."
                                and e068.Tipo = 'N'
                                and e091.Ordem != ''
                                and (e068.Situacao is null or e068.Situacao = 'A')";
                // TODO: FDD-429 - UNSAFE QUERY
                $result = $this->getAvaMySQL()->query($select);
                $response = $result->result_array();
                $qtdVideos = $response[0]['Count'];

                $videos = $this->buscaQuestoesAluno($this->session->userdata('pessoaid'), $GrupoAulaID, null, false, true, 'N', null, $value['DisciplinaID']);

                $qtdVideosAssistidos = $videos ? count($videos) : 0;

                $videoaulas[@$value['CategoriaID']]['DescricaoCategoria'] = @$value['DescricaoCategoria'];
                $dtInicio = isset($value['DtInicio']) ? $value['DtInicio'] : '-';
                $videoaulas[@$value['CategoriaID']][$value['Descricao']]['info'] = array(
                    'DisciplinaID' => $value['DisciplinaID'],
                    'TemMensagem' => $value['TemMensagem'],
                    'SemQuestoes' => $value['SemQuestoes'],
                    'QtdVideos' => $qtdVideos,
                    'QtdVideosAssistidos' => $qtdVideosAssistidos
                );

                $agendamento = null;
                // verifica agendamento específico para o aluno:
                if ($this->session->userdata('perfil') == PERFIL_ALUNO) {                                                                                                                            // , $this->session->userdata('pessoaid')
                    $agendamento = $this->getAgendamento($this->session->userdata('escola'), $value['GrupoAulaID'], $value['CategoriaID'], $value['DisciplinaID'], $this->session->userdata('TurmaID'), $this->session->userdata('pessoaid'));
                    if ($agendamento) {
                        $videoaulas[@$value['CategoriaID']][$value['Descricao']]['info']['DtInicio'] = $agendamento[0]['DtInicio'];
                        $videoaulas[@$value['CategoriaID']][$value['Descricao']]['info']['DtFimAluno'] = isset($agendamento[1]['DtFim']) ? $agendamento[1]['DtFim'] : '';
                    }
                }

                if (!$agendamento) {
                    $agendamento = $this->getAgendamento($this->session->userdata('escola'), $value['GrupoAulaID'], $value['CategoriaID'], $value['DisciplinaID'], $this->session->userdata('TurmaID'));
                    if ($agendamento) {
                        $videoaulas[@$value['CategoriaID']][$value['Descricao']]['info']['DtInicio'] = $agendamento[0]['DtInicio'];
                        $videoaulas[@$value['CategoriaID']][$value['Descricao']]['info']['DtFim'] = $agendamento[0]['DtFim'];
                    }
                }

                $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'] = array();

                // TODO: FDD-429 - ESTA SOBRANDO ?
                $select_expression = "DisciplinaID = " . "'" . $value['DisciplinaID'] . "'" . " AND Ordem != '' and (Situacao is null or Situacao = 'A') Order by Ordem asc ";

                $select_expression = "select e068.AulaID
                                         , e091.SubCategoriaID as DisciplinaID
                                         , e068.Tema
                                         , LPAD(e091.Ordem,4,0) as Ordem
                                         , e068.Video
                                         , e068.Duracao
                                         , e068.DtCad
                                         , e068.Tipo
                                         , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                                         
                                    from E068_Aulas e068
                                    inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                    where e091.SubCategoriaID = ". $value['DisciplinaID'] ."
                                    and (Situacao is null or Situacao = 'A')
                                    and e091.Ordem != ''
                                    order by ABS(e091.Ordem) ASC";

                $result = $this->getAvaMySQL()->query($select_expression);
                $response = $result->result_array();
                if ($response != '') {
                    $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'] = array_merge($videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'], $response);

                    // calcula duração das videoaulas em segundos:
                    $duracaoTotal = 0;
                    foreach ($response as $k => $v) {
                        if ($v['Duracao'] && $v['Duracao'] != '') {
                            $duracao = $v['Duracao'];

                            // tempo em segundos:
                            $array = explode(':', $duracao);

                            if (count($array) == 2) {
                                $h = 0;
                                $m = (isset($array[1])) ? $array[1] : 0;
                                $s = (isset($array[2])) ? $array[2] : 0;
                            } else if (count($array) == 3) {

                                $h = (isset($array[0])) ? $array[0] : 0;
                                $m = (isset($array[1])) ? $array[1] : 0;
                                $s = (isset($array[2])) ? $array[2] : 0;
                            }

                            // duração do vídeo em segundos
                            $tempoTotal = $h * 60 * 60 + $m * 60 + $s;
                            $duracaoTotal += $tempoTotal;
                        }
                    }

                    $videoaulas[@$value['CategoriaID']][$value['Descricao']]['info']['TempoTotalVideos'] = $duracaoTotal;
                }

                /* BEGIN - QUESTÕES DISCURSIVAS */
                $select_qd = "select e091.SubCategoriaID as DisciplinaID
                                     , LPAD(e091.Ordem,4,0) as Ordem
                                     , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                                     , e068.*                                                                          
                                from E068_Aulas e068
                                inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                where e091.SubCategoriaID = ". $value['DisciplinaID'] ."
                                and e068.Tipo = 'D'
                                and e091.Ordem != ''
                                and (e068.Situacao is null or e068.Situacao = 'A')";

                // TODO: FDD-429 - UNSAFE QUERY
                $result = $this->getAvaMySQL()->query($select_qd);
                $response_qd = $result->result_array();

                if (is_array($response_qd)) {
                    foreach ($response_qd as $key_qd => $value_qd) {

                        $aulaidD = $value_qd['AulaID'];
                        $disciplinaidD = $value_qd['DisciplinaID'];

//                        $item = array();
//                        // filtros:
//                        $item['disciplinaid']['ComparisonOperator'] = 'EQ';
//                        $item['disciplinaid']['AttributeValueList'] = array(array('N' => $GrupoAulaID));
//                        $item['aulaid']['ComparisonOperator'] = 'EQ';
//                        $item['aulaid']['AttributeValueList'] = array(array('N' => $value_qd['AulaID']));
//
//                        $select = array(
//                            'TableName' => 'DY001_AvaSae_QuestoesDiscursivas',
//                            'ConsistentRead' => false,
//                            'IndexName' => 'assuntoid-index',
//                            'KeyConditions' => array(
//                                'assuntoid' => array(
//                                    'AttributeValueList' => array(
//                                        array('N' => $value_qd['DisciplinaID'])
//                                    ),
//                                    'ComparisonOperator' => 'EQ',
//                                ),
//                            ),
//                            'QueryFilter' => $item,
//                            'ReturnConsumedCapacity' => 'TOTAL'
//                        );
//                        // TODO: FDD-429 - VERIFICAR SE ISSO AINDA FUNCIONA, NAO USAMOS MAIS DYNAMO DB
//                        $result = $this->dynamodb->Query($select);
//
                        $questoesDiscursivas =  $this->getQuestoesDiscursivas($disciplinaidD, $aulaidD, null);

                        $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'] = $response_qd;
                        $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'][$key_qd]['questoes-discursivas'] = array();
                        if (count($questoesDiscursivas) >= 1) {
                            $videoaulas[@$value['CategoriaID']][$value['Descricao']]['info']['totalQuestoesDiscursivas'] = count ($questoesDiscursivas);
                            $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'][$key_qd]['questoes-discursivas'] = $questoesDiscursivas;
                        }
                    }
                }
                /* END - QUESTÕES DISCURSIVAS */

                $tmp = '';
                $ultAulaQuestao = 0;

                //adiciona no array a quantidade de questoes da aula
                for ($i = 0; count($videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas']) > $i; $i++) {
                    $aula = $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'][$i]['AulaID'];

                    // tratamento para as questões similares:
                    $select_questoes = "select e359.QuestaoID
                                             , e359.Similar
                                             , e359.GrupoSimilar
                                        from E359_AulaQuestoes e359
                                        inner join E358_EstruturaAulasQuestoes e358 on e358.EstruturaAulaID = e359.EstruturaAulaID
                                        where e358.AulaID = ". $aula ."
                                          and e358.GrupoAulaID = ". $GrupoAulaID;
                    // TODO: FDD-429 - UNSAFE QUERY
                    $result = $this->getAvaMySQL()->query($select_questoes);
                    $questoesSDB = $result->result_array();


                    if (!empty($questoesSDB) && $this->session->userdata('perfil') == PERFIL_ALUNO) {
                        $grupo = -1;
                        $cont = 0;
                        foreach ($questoesSDB as $val) {
                            if (!isset($val['Similar']) || $val['Similar'] == 'N') {
                                $cont++;
                            } else { // similar = 'S'
                                if ($grupo != $val['GrupoSimilar']) {
                                    $cont++;
                                    $grupo = $val['GrupoSimilar'];
                                }
                            }
                        }

                        $questoesSDB = array('0' => array('Count' => $cont));
                    }else{

                        $cont = empty($questoesSDB) ? 0 : count($questoesSDB);
                        $questoesSDB = array('0' => array('Count' => $cont));
                    }

                    $questoes = $this->buscaQuestoesAluno($this->session->userdata('pessoaid'), $GrupoAulaID, $aula);

                    if ($questoes != '') {

                        if (count($questoes) != 0) {

                            $questoesRespondidas = $this->buscaQuestoesAluno($this->session->userdata('pessoaid'), $GrupoAulaID, $aula, true);
                            $questoesCorretas = $this->buscaQuestoesAluno($this->session->userdata('pessoaid'), $GrupoAulaID, $aula, true, null, null, true);

                            //grava a ultima aula que possui questao
                            $ultAulaQuestao = ($i + 1);

                            $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'][$i]['QtdQuestoes'] = isset($questoesSDB[0]['Count']) ? $questoesSDB[0]['Count'] : 0;
                            $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'][$i]['QtdQuestoesRespondidas'] = count($questoesRespondidas);
                            $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'][$i]['QtdRespostaCorretas'] = count($questoesCorretas);
                        } else {
                            $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'][$i]['QtdQuestoes'] = isset($questoesSDB[0]['Count']) ? $questoesSDB[0]['Count'] : 0;
                            $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'][$i]['QtdQuestoesRespondidas'] = 0;
                            $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'][$i]['QtdRespostaCorretas'] = 0;
                        }
                    }
                }
                /*
                 * Verifica Questões de Reforço - Retorna array pronto
                 */
                $dadosReforco = $videoaulas[@$value['CategoriaID']][$value['Descricao']]['aulas'];
                if (count($dadosReforco) === 0) {
                    continue;
                }

                $questoesReforco = $this->questoesReforco($dadosReforco, $GrupoAulaID);

                if ($questoesReforco != FALSE) {
                    $videoaulas[@$value['CategoriaID']][$value['Descricao']]['reforco']['TotalReforco'] = count($questoesReforco);
                }

            }

        }

        return $videoaulas;
    }

    public function getQuestoesDiscursivas($grupoaulaid, $aulaid=null, $assuntoid=null){
        $this->getAvaMySQL()->select('QuestaoDiscursivaID, Enunciado, AulaID, AssuntoID, GrupoAulaID');
        $this->getAvaMySQL()->where('GrupoAulaID', $grupoaulaid); //disciplinaid
        $this->getAvaMySQL()->where('Situacao', 'A');

        if($aulaid)
            $this->getAvaMySQL()->where('AulaID', $aulaid);
        if ($assuntoid)
            $this->getAvaMySQL()->where('AssuntoID', $assuntoid);

        $query = $this->getAvaMySQL()->get('SAE_Questoes_Discursivas');
        $result = $query->result();
        return $result;
    }


    function questoesReforco($params, $GrupoAulaID) {

        $disciplinaID =  $params[0]['DisciplinaID'];
        // tratamento para as questões similares:
        $select_questoes = "select e359.QuestaoID
                                 , e359.Similar
                                 , e359.GrupoSimilar
                            from E359_AulaQuestoes e359
                            inner join E358_EstruturaAulasQuestoes e358 on e358.EstruturaAulaID = e359.EstruturaAulaID
                            where e358.SubCategoriaID = ". $disciplinaID ."
                              and e358.GrupoAulaID = ". $GrupoAulaID;
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($select_questoes);
        $questoesSDB = $result->result_array();

        if (!empty($questoesSDB)) {
            // format response questões com a questãoid como chave array
            foreach ($questoesSDB as $key => $value) {
                $questoesSDBFormat[$value['QuestaoID']] = $value;
            }

            for ($i = 0; count($params) > $i; $i++) {

                if ($params[$i]['Tipo'] === 'R' || $params[$i]['Tipo'] === 'Q') {
                    $result = $this->buscaQuestoesAluno($this->session->userdata('pessoaid'), $GrupoAulaID, $params[$i]['AulaID']);
                    if (count($result) >= 1) {
                        foreach ($result as $key => $value) {
                            // remove questões reservadas
                            unset($questoesSDBFormat[$result[$key]->QuestaoID]);
                        }
                    }
                }
            }
        } else {
            return false;
        }

        return array_values($questoesSDBFormat);
    }

    /**
     * getQuestoesAula
     *
     * Retorna as questoes relacionadas a aula
     *
     * @access    public
     * @param $grupoAulaID
     * @param $aulaID
     * @param int $classificacaoID
     * @return    array        dados
     */
    function getQuestoesAula($grupoAulaID, $aulaID)
    {
        $order = "";
        if ((int)$this->session->userdata('perfil') === \Ava\App\Support\Perfil::ALUNO) {
            $order = "ORDER BY RAND()";
        }

        $selectExpression = "SELECT 
                                e358.AulaID,
                                e359.QuestaoID,
                                e358.GrupoAulaID,
                                e358.EstruturaAulaID,
                                e359.Similar,
                                e359.GrupoSimilar,
                                e359.JarvisItemID,
                                e359.is_parent
                            FROM
                                E359_AulaQuestoes e359
                                    INNER JOIN E358_EstruturaAulasQuestoes e358 ON e358.EstruturaAulaID = e359.EstruturaAulaID
                                    INNER JOIN E090_CategoriasSubCategoriasAulas assunto_livro ON e358.SubCategoriaID = assunto_livro.SubCategoriaID
                                    INNER JOIN E088_CategoriasAulas livro ON assunto_livro.CategoriaID = livro.CategoriaAulaID
                            WHERE
                                e358.AulaID = {$aulaID}
                                    AND IF(e359.JarvisItemID IS NOT NULL, e359.is_parent = 1, e359.is_parent IN (0, 1))
                                    AND e358.GrupoAulaID = {$grupoAulaID}
                            GROUP BY e359.QuestaoID {$order};";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }


    function getQuestoesPlataformaLiteraria($grupoAulaID, $aulaID)
    {
        $order = "";
        if ((int)$this->session->userdata('perfil') === \Ava\App\Support\Perfil::ALUNO) {
            $order = "ORDER BY RAND()";
        }

        $selectExpression = "SELECT 
                                e358.EstruturaAulaID
                            FROM
                                E358_EstruturaAulasQuestoes e358
                            WHERE
                                e358.AulaID = {$aulaID}
                                AND e358.GrupoAulaID = {$grupoAulaID}";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        $estruturaAulaId = collect($result->result_array())->first()['EstruturaAulaID'];
        $selectExpression = "SELECT
        e358.AulaID,
        e359.QuestaoID,
        e358.GrupoAulaID,
        e358.EstruturaAulaID,
        e359.Similar,
        e359.GrupoSimilar,
        e359.JarvisItemID,
        e359.is_parent
    FROM
        E359_AulaQuestoes e359
            INNER JOIN E358_EstruturaAulasQuestoes e358 ON e358.EstruturaAulaID = e359.EstruturaAulaID
    WHERE
        e359.EstruturaAulaID = {$estruturaAulaId}
    GROUP BY e359.QuestaoID;";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        

        return $result->result_array();
    }

    /**
     * getQuestoesAluno
     *
     * @access	public
     * @return	array        dados
     */
    function getQuestoesAluno($id, $grupoAula, $assunto, $aula, $questaoID = null) {

        $sql = '';

        if ($questaoID) {
            $sql = " and r001.QuestaoID = $questaoID";
        }

        $selectExpression = "select distinct r001.RespostaQuestaoID, r001.UsuarioID, r001.QuestaoID, r001.Resposta, r001.RespostaCorreta, r001.TurmaID,
                                    r001.EscolaID,r001.NomeEscola,r001.DescTurma ,r001.AulaID,r001.AssuntoID,r001.DisciplinaID,r001.SerieID,r001.DescSerie,
                                    r001.VigenciaTurma,r001.TotalQuestoesAula,r001.DescAssunto,r001.FrenteID,r001.DescFrente,r001.Tipo,r001.Meta,
                                    r001.DescAula,r001.Gabarito,r001.DescDisciplina,r001.DtCad,r001.DtAlt,r001.DtConclusao,r001.VideoAulaAssistida,
                                    r001.NomeAluno,r001.TipoQuestaoID,r001.Situacao
                                    , d024.DtInicio as DtAgendaInicio, d024.DtFim as DtAgendaFim
                from R001_RespostasQuestoes r001
                   , D024_Ava_Sae_Agenda d024
                where r001.Situacao = 'A' and r001.UsuarioID = '$id' and r001.DisciplinaID = $grupoAula
                
                and d024.AssuntoID = r001.AssuntoID
                and d024.EscolaID = r001.EscolaID
                and d024.TurmaID = r001.TurmaID
                and d024.DisciplinaID = r001.DisciplinaID
                and d024.id = (select max(d024_2.id) from D024_Ava_Sae_Agenda as d024_2
                    where d024.AssuntoID = d024_2.AssuntoID
                        and d024.EscolaID = d024_2.EscolaID
                        and d024.TurmaID = d024_2.TurmaID
                        and d024.DisciplinaID = d024_2.DisciplinaID)
                and r001.AssuntoID = $assunto and r001.AulaID = $aula" . $sql;
		// TODO: FDD-429 - UNSAFE QUERY

        $selectExpression = "select
            r001.QuestaoID,
            r001.Resposta, 
            r001.RespostaCorreta,
            r001.TurmaID,
            r001.AssuntoID,
            r001.DisciplinaID, 
            r001.Tipo,
            r001.DtConclusao  
        from 
            R001_RespostasQuestoes r001
        where 
            r001.Situacao = 'A' 
            and r001.UsuarioID = '$id' 
            and r001.DisciplinaID = $grupoAula 
            and r001.AssuntoID = $assunto 
            and r001.AulaID = $aula" . $sql;
        
        // dump($selectExpression);
        // die;

        $query = $this->getAvaMySQL()->query($selectExpression);
        return $query->result();
    }

    /**
     * studentQuestions
     *
     * @access	public
     * @return	array        dados
     */
    function studentQuestions($id, $tipo, $assunto) {
        $sql = '';
        if ($tipo) {
            $sql = "AND Tipo='$tipo'";
        }

		$selectExpression = 
			"SELECT count(AulaID)>0 as questoesGeradas
				FROM R001_RespostasQuestoes
				WHERE 
					AssuntoID = $assunto
                    AND UsuarioID='$id'" . $sql;

        $query = $this->getAvaMySQL()->query($selectExpression);
        return $query->result();
    }


    /**
     * verificaVideoAula
     *
     * Retorna o titulo da disciplina esta para assistir .
     *
     * @access	public
     * @return	array        dados
     */
    function verificaVideoAula($param = 4) {
        try{

            $aux = str_split($this->uri->segment($param), 7);

            $selectExpression = "select  e091.SubCategoriaID as DisciplinaID
                                         , LPAD(e091.Ordem,4,0) as Ordem
                                         , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                                         , e068.*
                                         
                                    from E068_Aulas e068
                                    inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                    where e091.SubCategoriaID = ". intval($aux[0]) ."
                                      and e068.AulaID = ". intval($aux[1]);
            // TODO: FDD-429 - NAO TA UNSAFE... MAS NAO TA IDEAL....
            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
        } catch (Exception $e){
            return array();
        }
    }

    function dadosGerais($subcategoria, $aulaid) {
        try{
            $selectExpression = "select  e091.SubCategoriaID as DisciplinaID
                                         , LPAD(e091.Ordem,4,0) as Ordem
                                         , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                                         , e068.*
                                         
                                    from E068_Aulas e068
                                    inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                    where e091.SubCategoriaID = ".$subcategoria ."
                                      and e068.AulaID = ". $aulaid;

            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
        } catch (Exception $e){
            return array();
        }

    }

    /**
     * verificaDisciplina
     *
     * Retorna o titulo da disciplina esta para assistir .
     *
     * @access	public
     * @param   int $DisciplinaID identificador da disciplina
     * @param   int $GrupoAulaID grupo que pertence a disciplina
     * @return	array  dados
     */
    function verificaDisciplina($DisciplinaID, $GrupoAulaID) {

        $selectExpression = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                    , e089.Descricao
                                     , e094.GrupoAulaID
                                     , e089.SubCategoriaAulaID as DisciplinaID
                                     , e089.DtInicio as DtInicio
                                     , e088.CategoriaAulaID as CategoriaID
                                     , '' as TemMensagem
                                     , null as SemQuestoes
                                     , e093.ClassificacaoID
                                from E089_SubCategoriasAulas e089
                                inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                inner join E093_GruposAulas e093 on e093.GrupoAulaID = $GrupoAulaID
                                where e094.GrupoAulaID = ". $GrupoAulaID ."
                                  and e089.SubCategoriaAulaID = ". $DisciplinaID;
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getDisciplina($disciplinaID) {
        $sql = "select e093.*
                from E093_GruposAulas e093
                where e093.GrupoAulaID = ". $disciplinaID;
        $result = $this->getAvaMySQL()->query($sql)->result_array();
        return $result;
    }

    // TODO: FDD-429 - VERIFICAR SE ISSO AINDA FAZ SENTIDO, NAO USAMOS ANOTACOES NO SAE
    function verificaVideoAssistidos_Anotacoes() {
        $select_expression = "select * from D017_VideoAulasAcoes_" . $this->configuracoes[0]['Base'] . " where PessoaID = '" . $this->pessoaid . "'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($select_expression);
        $dados =  $result->result_array();

        if ($dados) {

            for ($i = 0; count($dados) > $i; $i++) {
                // TODO: FDD-429 - NUNCA FOI USADO
                $select_expression2 = "select * from D018_Anotacoes_" . $this->configuracoes[0]['Base'] . " where VideoAulaAcaoID = '" . $dados[$i]['id'] . "'";
                // TODO: FDD-429 - UNSAFE QUERY
                $result = $this->getAvaMySQL()->query($select_expression);
                $data =  $result->result_array();

                if (count($data) > 0) {
                    $dados[$i]['Anotacao'] = 'S';
                } else {
                    $dados[$i]['Anotacao'] = 'N';
                }
            }
        }

        return $dados;
    }

    function verificaAcaoVideoAula($AulaID)
    {

        $selectExpression = "select * from D017_VideoAulasAcoes_" . $this->configuracoes[0]['Base'] . " where PessoaID = '" . $this->pessoaid . "' and AulaID = '" . $AulaID . "'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        $dados = $result->result_array();

        if ($dados) {
            $dados[0]['VideoAulaAcaoID'] = $dados[0]['id'];
        }

        return $dados;

    }

    // TODO: FDD-429 - VERIFICAR SE ISSO AINDA FAZ SENTIDO, NAO USAMOS ANOTACOES NO SAE
    function verifica_quantidadeAnotacoes($grupoAulaID, $videosAssistidos = null) {

        if ($this->configuracoes[0]['SqlServer'] != 'N') {

            $select_expression = "SELECT E301.VideoAulaAcaoID,E301.AulaID,E089.Descricao,COUNT(E302.VideoAulaAcaoID) Qtd
								FROM E094_GruposCategoriasAulas E094 (NOLOCK)
								INNER JOIN E090_CategoriasSubCategoriasAulas E090 (nolock)ON (E090.CategoriaID = E094.CategoriaAulaID)
								INNER JOIN E089_SubCategoriasAulas E089 (nolock)ON (E089.SubcategoriaAulaId = E090.SubcategoriaId)
								INNER JOIN E091_AulasSubCategorias E091 (nolock)ON (E091.SubcategoriaId = E090.SubcategoriaId)
								INNER JOIN E068_Aulas E068 (nolock)ON (E068.AulaID = E091.AulaID)
								INNER JOIN E301_VideoAulasAcoes E301 (nolock)  ON (E301.AulaID = E068.AulaID)
								INNER JOIN E302_AnotacoesVideoAulas E302 (nolock) ON (E302.VideoAulaAcaoID = E301.VideoAulaAcaoID )
								WHERE  E094.GrupoAulaID = '" . $grupoAulaID . "' AND E301.PessoaID = '" . $this->pessoaid . "' AND E302.Situacao = 'A'
								GROUP BY E301.VideoAulaAcaoID,E301.AulaID,E089.Descricao";


            // TODO: FDD-429 - UNSAFE QUERY
            $query = $this->getAvaMySQL()->query($select_expression);
            // TODO: FDD-429 - NUNCA FOI USADO
            $result = $query->result_array();

            return $query->result();
        } else {

            $data = array();
            for ($i = 0; count($videosAssistidos) > $i; $i++) {
                //busca dados apenas para aulas com anotacoes
                if ($videosAssistidos[$i]['Anotacao'] == 'S') {

                    //busca quantidade de anotacoes
                    $select_expression = "select count(*) from D018_Anotacoes_" . $this->configuracoes[0]['Base'] . " where VideoAulaAcaoID = '" . $videosAssistidos[$i]['id'] . "' and Situacao = 'A'";
                    // TODO: FDD-429 - UNSAFE QUERY
                    $result = $this->getAvaMySQL()->query($select_expression);
                    $dados = $result->result_array();

                    //busca disciplinaid
                    $select_expression2 = "select e091.SubCategoriaID as DisciplinaID                                                 
                                                 , LPAD(e091.Ordem,4,0) as Ordem
                                                 , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                                                 , e068.*
                                                 
                                            from E068_Aulas e068
                                            inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                            where e068.AulaID = ". $videosAssistidos[$i]['AulaID'];
                    // TODO: FDD-429 - UNSAFE QUERY
                    $response2 = $this->getAvaMySQL()->query($select_expression2);
                    $dados2 = $response2->result_array();

                    $select_expression3 = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                                , e089.Descricao
                                                 , e094.GrupoAulaID
                                                 , e089.SubCategoriaAulaID as DisciplinaID
                                                 , e089.DtInicio as DtInicio
                                                 , e088.CategoriaAulaID as CategoriaID
                                                 , '' as TemMensagem
                                                 , null as SemQuestoes
                                            from E089_SubCategoriasAulas e089
                                            inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                            inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                            inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                            where e094.GrupoAulaID = ". $grupoAulaID ."
                                              and e089.SubCategoriaAulaID = ". $dados2[0]->DisciplinaID;
                    // TODO: FDD-429 - UNSAFE QUERY
                    $response3 = $this->getAvaMySQL()->query($select_expression3);
                    $dados3 = $response3->result_array();

                    $obj = new stdClass();

                    $obj->VideoAulaAcaoID = $videosAssistidos[$i]['id'];
                    $obj->AulaID = $videosAssistidos[$i]['AulaID'];
                    $obj->Descricao = $dados3[0]->Descricao;
                    $obj->Qtd = $dados[0]->Count;

                    $data[] = $obj;
                }
            }

            return $data;
        }
    }

    // TODO: FDD-429 - VERIFICAR SE AINDA FAZ SENTIDO, NAO USAMOS ANOTACOES NO SAE
    function exporta_AnotacoesVideoAula($fields) {

        if ($this->configuracoes[0]['SqlServer'] != 'N') {

            if ($fields['Disciplina'] == $fields['Curso'])
                $fields['Disciplina'] = "";
            else
                $fields['Disciplina'] = " and E301.VideoAulaAcaoID IN ('" . $fields['Disciplina'] . "')";

            $select_expression = 'set language brazilian';
            $query = $this->getAvaMySQL()->query($select_expression);

            $select_expression = "SELECT E089.SubcategoriaAulaId,E089.Descricao,E301.AulaID,E068.Tema,E302.Anotacoes,
								convert(varchar(02),DatePart(day,e302.DtAnotacao)) + ' de ' + DateName(Month,e302.DtAnotacao) + ' de ' + convert(varchar(04),DatePart(Year,e302.DtAnotacao)) as [DtAnotacao]
								FROM E094_GruposCategoriasAulas E094 (NOLOCK)
								INNER JOIN E090_CategoriasSubCategoriasAulas E090 (nolock)ON (E090.CategoriaID = E094.CategoriaAulaID)
								INNER JOIN E089_SubCategoriasAulas E089 (nolock)ON (E089.SubcategoriaAulaId = E090.SubcategoriaId)
								INNER JOIN E091_AulasSubCategorias E091 (nolock)ON (E091.SubcategoriaId = E090.SubcategoriaId)
 								INNER JOIN E068_Aulas E068 (nolock)ON (E068.AulaID = E091.AulaID)
 								INNER JOIN E301_VideoAulasAcoes E301 (nolock)  ON (E301.AulaID = E068.AulaID)
 								INNER JOIN E302_AnotacoesVideoAulas E302 ON (E302.VideoAulaAcaoID = E301.VideoAulaAcaoID )
 								WHERE E302.Situacao = 'A' AND E094.GrupoAulaID = '" . $fields['GrupoAulaID'] . "'
								AND E301.PessoaID = '" . $this->pessoaid . "'" . $fields['Disciplina'] . "
								ORDER BY E089.Descricao, E301.AulaID, E302.DtAnotacao";


            // TODO: FDD-429 - UNSAFE QUERY
            $query = $this->getAvaMySQL()->query($select_expression);
            $result = $query->result_array();

            return $query->result();
        }else {

            $result = array();

            //busca as anotaçoes de todas as aulas do pacote
            if ($fields['Disciplina'] == $fields['Curso']) {

                //busca as disciplinas
                $select_expression = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                            , e089.Descricao
                                             , e094.GrupoAulaID
                                             , e089.SubCategoriaAulaID as DisciplinaID
                                             , e089.DtInicio as DtInicio
                                             , e088.CategoriaAulaID as CategoriaID
                                             , '' as TemMensagem
                                        from E089_SubCategoriasAulas e089
                                        inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                        inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                        inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                        where e094.GrupoAulaID = ". $fields['GrupoAulaID'];

                // TODO: FDD-429 - UNSAFE QUERY
                $response = $this->getAvaMySQL()->query($select_expression);
                $dados = $response->result_array();


                for ($i = 0; count($dados) > $i; $i++) {

                    //busca aulas
                    $select_expression2 = "select e091.SubCategoriaID as DisciplinaID                                                 
                                                 , LPAD(e091.Ordem,4,0) as Ordem
                                                 , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                                                 , e068.*
                                                 
                                            from E068_Aulas e068
                                            inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                            where e091.SubCategoriaID = ". $dados[$i]['DisciplinaID'];
                    // TODO: FDD-429 - UNSAFE QUERY
                    $response2 = $this->getAvaMySQL()->query($select_expression2);
                    $dados2 = $response2->result_array();

                    for ($a = 0; count($dados2) > $a; $a++) {

                        //busca as anotaçoes usando pessoaid e aulaid
                        $select_expression3 = "select * from D018_Anotacoes_" . $this->configuracoes[0]['Base'] . " where VideoAulaAcaoID = '" . $this->pessoaid . $dados2[$a]['AulaID'] . "' and Situacao = 'A'";
                        // TODO: FDD-429 - UNSAFE QUERY
                        $response3 = $this->getAvaMySQL()->query($select_expression3);
                        $dados3 = $response3->result_array();


                        for ($x = 0; count($dados3) > $x; $x++) {

                            $dt = explode(' ', $dados3[$x]['DtAnotacao']);
                            $dtAnotacao = dataextenso($dt[0]);

                            $obj = new stdClass();

                            $obj->SubCategoriaAulId = $dados[$i]['DisciplinaID'];
                            $obj->Descricao = $dados[$i]['Descricao'];
                            $obj->AulaID = $dados2[$a]['AulaID'];
                            $obj->Tema = $dados2[$a]['Tema'];
                            $obj->Anotacoes = $dados3[$x]['Anotacoes'];
                            $obj->DtAnotacao = $dtAnotacao;


                            $result[] = $obj;
                        }
                    }
                }

                //busca anotacoes por disciplina
            } else {
                $acaoAulaID = explode(',', str_replace("'", "", $fields['Disciplina']));

                for ($i = 0; count($acaoAulaID) > $i; $i++) {

                    //busca aulaid da anotacoes
                    $select_expression = "select * from D018_Anotacoes_" . $this->configuracoes[0]['Base'] . " where VideoAulaAcaoID = '" . $acaoAulaID[$i] . "' and Situacao = 'A'";
                    // TODO: FDD-429 - UNSAFE QUERY
                    $response = $this->getAvaMySQL()->query($select_expression);
                    $dados = $response->result_array();

                    for ($a = 0; count($dados) > $a; $a++) {

                        //busca dados da aula
                        $select_expression2 = "select e091.SubCategoriaID as DisciplinaID                                                     
                                                     , LPAD(e091.Ordem,4,0) as Ordem
                                                     , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                                                     , e068.*                                                     
                                                from E068_Aulas e068
                                                inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                                where e068.AulaID = ". $dados[$a]['AulaID'];
                        // TODO: FDD-429 - UNSAFE QUERY
                        $response2 = $this->getAvaMySQL()->query($select_expression2);
                        $dados2 = $response2->result_array();

                        //busca dados disciplina

                        $select_expression3 = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                            , e089.Descricao
                                             , e094.GrupoAulaID
                                             , e089.SubCategoriaAulaID as DisciplinaID
                                             , e089.DtInicio as DtInicio
                                             , e088.CategoriaAulaID as CategoriaID
                                             , '' as TemMensagem
                                        from E089_SubCategoriasAulas e089
                                        inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                        inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                        inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                        where e094.GrupoAulaID = ". $fields['GrupoAulaID'] ."
                                          and e089.SubCategoriaAulaID = ". $dados2[0]['DisciplinaID'];

                        // TODO: FDD-429 - UNSAFE QUERY
                        $response3 = $this->getAvaMySQL()->query($select_expression3);
                        $dados3 = $response3->result_array();

                        $dt = explode(' ', $dados[$a]['DtAnotacao']);
                        $dtAnotacao = dataextenso($dt[0]);

                        $obj = new stdClass();

                        $obj->SubCategoriaAulId = $dados3[0]['DisciplinaID'];
                        $obj->Descricao = $dados3[0]['Descricao'];
                        $obj->AulaID = $dados2[0]['AulaID'];
                        $obj->Tema = $dados2[0]['Tema'];
                        $obj->Anotacoes = $dados[$a]['Anotacoes'];
                        $obj->DtAnotacao = $dtAnotacao;

                        $result[] = $obj;
                    }
                }
            }

            return $result;
        }
    }

    function inserir_acaoVideoAula($AulaID) {

        $id = $this->session->userdata('pessoaid') . $AulaID;

        $dados = array('PessoaID' => $this->pessoaid,
            'AulaID' => $AulaID,
            'AulaAssistida' => 'N',
            'DtCad' => date('Y-m-d H:i:s'));


        $domain = 'D017_VideoAulasAcoes_' . $this->configuracoes[0]['Base'];
        $this->getAvaMySQL()->where('id',$id);
        return $this->getAvaMySQL()->update($domain,$dados);

    }

    function finalizar_videoAula($fields) {


        if ($fields['situacaoVideoAula'] == 'S')
            $situacaoVideoAula = 'N';
        else
            $situacaoVideoAula = 'S';

        $id = $this->session->userdata('pessoaid') . $fields['aulaID'];

        $dados = array('AulaAssistida' => $situacaoVideoAula);

        $domain = 'D017_VideoAulasAcoes_' . $this->configuracoes[0]['Base'];
        $this->getAvaMySQL()->where('id',$id);
        return $this->getAvaMySQL()->update($domain,$dados);

    }

    function busca_motivos() {

        $select_expression = "SELECT  MotivoID, Descricao , Observacao from E354_MotivosDescurtirVideoAulas where Situacao = 'A'";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($select_expression);

        return $query->result();
    }

    // TODO: FDD-429 - VERIFICAR SE AINDA FAZ SENTIDO, NAO USAMOS ANOTACOES NO SAE
    function insere_anotacaoVideoAula($fields) {

        $id = time();

        $dados = array('VideoAulaAcaoID' => $fields['videoAulaAcaoID'],
            'Anotacoes' => utf8_decode($fields['anotacao']),
            'Situacao' => 'A',
            'DtAnotacao' => date('Y-m-d H:i:s'),
            'PessoaID' => $this->pessoaid,
            'AulaID' => $fields['aulaID']
        );

        $domain = 'D018_Anotacoes_' . $this->configuracoes[0]['Base'];
        $this->getAvaMySQL()->where('id',$id);
        return $this->getAvaMySQL()->update($domain,$dados);

    }

    // TODO: FDD-429 - VERIFICAR SE AINDA FAZ SENTIDO, NAO USAMOS ANOTACOES NO SAE
    function edita_anotacaoVideoAula($fields) {

        //busca o id da anotacao
        $select_expression = "select * from D018_Anotacoes_" . $this->configuracoes[0]['Base'] . " where id = '" . $fields['AnotacoesVideoAulaID'] . "'";
        $result = $this->getAvaMySQL()->query($select_expression);
        $data = $result->result_array();

        //altera a situacao da anotacao antiga e insere uma nova
        if ($data) {

            $dados = array('Situacao' => 'I');

            $domain = 'D018_Anotacoes_' . $this->configuracoes[0]['Base'];
            $this->getAvaMySQL()->where('id',$data[0]['id']);
            //$this->simpledb->addsItem($domain, $data[0]['id'], $dados, TRUE);
            $checkupdate = $this->getAvaMySQL()->update($domain,$dados);
            if ($checkupdate) {

                $id = time();

                $dados = array('VideoAulaAcaoID' => $fields['videoAulaAcaoID'],
                    'Anotacoes' => utf8_decode($fields['anotacao']),
                    'Situacao' => 'A',
                    'DtAnotacao' => date('Y-m-d H:i:s'),
                    'PessoaID' => $this->pessoaid,
                    'AulaID' => $fields['aulaID']
                );

                //$response = $this->sdb->put_attributes('D018_Anotacoes_' . $this->configuracoes[0]['Base'], $id, $dados, TRUE);

                $domain = 'D018_Anotacoes_' . $this->configuracoes[0]['Base'];
                $this->getAvaMySQL()->where('id',$data[0]['id']);
                //$this->simpledb->addsItem($domain, $data[0]['id'], $dados, TRUE);
                $checkupdate = $this->getAvaMySQL()->update($domain,$dados);
                //$this->simpledb->addsItem($domain, $id, $dados, TRUE);
                //$checkinsert = $this->simpledb->checkInsert($domain, $id, $dados);
                return $checkinsert;
            }
            return FALSE;
        }
        return FALSE;

    }

    // TODO: FDD-429 - VERIFICAR SE AINDA FAZ SENTIDO, NAO USAMOS ANOTACOES NO SAE
    function verifica_AnotacoesVideoAula($AulaID, $videoAulaAcaoID = null) {

        if ($videoAulaAcaoID) {
            $select_expression = "select * from D018_Anotacoes_" . $this->configuracoes[0]['Base'] . " where VideoAulaAcaoID = '" . $videoAulaAcaoID . "' and Situacao = 'A'";
        } else {
            $select_expression = "select * from D018_Anotacoes_" . $this->configuracoes[0]['Base'] . " where AulaID = '" . $AulaID . "' and Situacao = 'A' and PessoaID = '" . $this->pessoaid . "' and id is not null order by id desc";
        }
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($select_expression);
        $dados = $result->result_array();

        if ($dados) {
            for ($i = 0; count($dados) > $i; $i ++) {
                $dados[$i]['AnotacoesVideoAulaID'] = $dados[$i]['id'];
            }
        }

        return $dados;
    }

    function getPdfGrupoAluno($matricula, $grupo, $tipo = 'M') {

        if ($tipo == 'C') {

            $sql = "SELECT distinct e093.Descricao as Titulo, e103.Descricao, 'http://www.portalava.com.br/ava/includes/concursos_pdf/' + e103.Arquivo as Arquivo
							FROM E103_PdfGrupoAula as e103
							INNER JOIN E093_GruposAulas e093 ON e093.GrupoAulaID = e103.GrupoAulaID
							WHERE e103.GrupoAulaID = $grupo
							  AND E103.Tipo = 'C'
							  AND E103.situacao = 'A' ";
        } else {

            $sql = "SELECT distinct e093.Descricao as Titulo, e103.Descricao, 'http://www.portalava.com.br/ava/includes/concursos_pdf/' + e103.Arquivo as Arquivo
							FROM E086_AssinaturasMatricula as e086
							INNER JOIN E103_PdfGrupoAula as e103 ON e103.GrupoAulaID = e086.GrupoAulaID
							INNER JOIN E093_GruposAulas e093 ON e093.GrupoAulaID = e086.GrupoAulaID
							WHERE e086.GrupoAulaID = $grupo AND e086.Situacao = 'A'
							  AND E103.Tipo = '$tipo'
							  AND E103.situacao = 'A' "; /* condição where removido MatriculaID = $matricula  */
        }

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getMaterialGrupoAluno($GrupoAulaID, $DisciplinaID = False) {

        if ($DisciplinaID) {
            $DisciplinaID = " and DisciplinaID = '$DisciplinaID' ";
        }

        $select_expression = "select * from D012_Materiais_Adicionais where GrupoAulaID = '" . $GrupoAulaID . "'  $DisciplinaID  and Situacao = 'A' and OrdemMaterial is not null and DescricaoMaterial != '' order by OrdemMaterial";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($select_expression);
        return $result->result_array();

    }

    public function buscaVideoAulas($descricaoVideoAula = null) {

        if ($descricaoVideoAula) {

            $dados = $this->verificaDisciplinas($this->session->userdata('grupoAulaID'));

            $videoaulas = array();
            foreach ($dados as $key => $value) {

                if (((!isset($value['DtInicio'])) || ($value['DtInicio'] == '-')) || (strtotime(date('Y-m-d H:i:s')) >= strtotime($value['DtInicio']))) {

                    $select_expression = "select  e068.AulaID
                                                 , e091.SubCategoriaID as DisciplinaID
                                                 , e068.Tema
                                                 , LPAD(e091.Ordem,4,0) as Ordem
                                                 , e068.Video
                                                 , e068.Duracao      
                                                 , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName                                           
                                                 
                                            from E068_Aulas e068
                                            inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                            where e091.SubCategoriaID = ". $value['DisciplinaID'] ."
                                            and e091.Ordem != ''
                                            and e068.Tema like '%". $descricaoVideoAula ."%'
                                            order by ABS(e091.Ordem) ASC";

                    $videoaulas[$value['Descricao']]['aulas'] = array();
                    $next_token = null;
                    // TODO: FDD-429 - VERFIICAR SE ISSO AINDA FUNCIONA, NAO USAMOS MAIS SIMPLE DB
                    do {
                        if ($next_token) {
                            $response = $this->sdb->select($select_expression, array(
                                'NextToken' => $next_token,
                            ));
                        } else {
                            $response = $this->sdb->select($select_expression);
                        }

                        $returnsdb = formataArraydeObjetos($response->body->SelectResult);

                        if ($returnsdb)
                            $videoaulas[$value['Descricao']]['aulas'] = array_merge($videoaulas[$value['Descricao']]['aulas'], $returnsdb);
                        else
                            unset($videoaulas[$value['Descricao']]);

                        $next_token = isset($response->body->SelectResult->NextToken) ? (string) $response->body->SelectResult->NextToken : null;
                    } while ($next_token);
                }
            }
        }

        return $videoaulas;
    }

    // TODO: FDD-429 - VERIFICAR SE AINDA FAZ SENTIDO
    function verificaBannerSimulado($pacoteid = 0) {
        $selectExpression = "select * from D013_Banners
                              where
                                    Tipo = 'S'
                                    and DtInicioSimulado <= '" . date('Y-m-d') . "'
                                    and PacoteID = '$pacoteid'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    // TODO: FDD-429 - INVESTIGAR
    function getDadosUsuario() {

        $select_usuario = "select * from D001_Login_" . $this->configuracoes[0]['Base'] . " where PessoaPerfilID = '" . $this->session->userdata('pessoaperfilid') . "'";
        //$respUsuario = $this->sdb->select($select_usuario);
        //$dadosUsuario = formataArraydeObjetos($respUsuario->body->SelectResult);
        //monta array com os dados para enviar ao serviço de login
        //$login['nome'] = $dadosUsuario[0]['Nome'];
        $login['_username'] = 'tiago.fedatto@iesde.com.br'; //$dadosUsuario[0]['Email'];
        $login['_password'] = '123'; //$dadosUsuario[0]['Senha'];


        return $login;
    }

    public function buscaDadosUsuario($id) {
        $alunoData = SaeDigital::make(ObterAlunoPorIdNextAva::class)->handle($id);

        //$selectExpression = "select * from D019_Ava_Sae where itemName = '{$id}'";
        // TODO: FDD-429 - UNSAFE QUERY
        //$result = $this->getAvaMySQL()->query($selectExpression);
        return $alunoData;

    }

    function gravaQuestoesAluno($dados) {

        return $this->getAvaMySQL()->insert('R001_RespostasQuestoes', $dados);
    }

    function verificarQuestoesAlunos($questoes, $idAluno) {
        $questoes = implode(",", $questoes);
        $selectExpression2 = "select  QuestaoID                                 
        from R001_RespostasQuestoes
        where QuestaoID IN (". $questoes .")
        and UsuarioID = $idAluno";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression2);
        return $result->result_array();
    }


    function gravaQuestoesAlunoReforco($dados) {

        return $this->getAvaMySQL()->insert('R002_RespostasQuestoesReforco', $dados);
    }

    function gravaRespostaAluno($dados, $where) {
        return $this->getAvaMySQL()->update('R001_RespostasQuestoes', $dados, $where);
    }

    function verificaRespondida($where){
        $this->getAvaMySQL()->select('RespostaCorreta, Resposta, DtConclusao');
        $query = $this->getAvaMySQL()->get_where('R001_RespostasQuestoes',$where);
        if ($query->row()) {
            return $query->row();
        }

        return [];
    }

    /**
     * @param int|string $questaoId
     *
     * @return array
     */
    function buscaRespostaCorreta($questaoId, $classificacao)
    {
        $questao = $this->CarregaQuestaoAPI($questaoId, $classificacao);

        if (isset($questao['success']) && $questao['success'] == 0) {
            return $questao;
        }

        $resposta_correta = array_pop(array_filter($questao['message']['questao']['alternativas'],
            function ($resposta) {
                return (strval($resposta['opcaoCorreta']) === '1');
            }
        ));

        return [
            'id' => (string)$resposta_correta['id'],
            'valor_opcao' => $resposta_correta['valorOpcao']
        ];
    }



    function buscaQuestoesAluno($id, $grupoAula, $aula = null, $respondida = false, $vista = false, $tipo = null, $respostaCorreta = false, $assunto = null) {

        $sql = '';

        if ($respondida) {
            $sql .= " and RespostaCorreta is not null ";
        }

        if ($respostaCorreta) {
            $sql .= " and RespostaCorreta = 'S'";
        }

        if ($vista) {
            $sql .= " and VideoAulaAssistida = 'S' ";
        }

        if ($tipo) {
            $sql .= " and Tipo = '$tipo'";
        }

        if ($aula) {
            $sql .= " and AulaID = '$aula' ";
        }

        if ($assunto) {
            $sql .= " and AssuntoID = '$assunto' ";
        }

        $selectExpression = "select * from R001_RespostasQuestoes where Situacao = 'A' and UsuarioID = '$id' and DisciplinaID = $grupoAula " . $sql;

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($selectExpression);

        return $query->result();
    }

    function getVideoAulasPacote($DisciplinaID) {

        $selectExpression2 = "select  e091.SubCategoriaID as DisciplinaID
                                     , LPAD(e091.Ordem,4,0) as Ordem
                                     , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                                     , e068.*                                     
                                from E068_Aulas e068
                                inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                where e091.SubCategoriaID = ". $DisciplinaID ."
                                and e068.Tipo = 'N'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression2);
        return $result->result_array();
    }

    function getConfiguracoesescola($escolaid, $tipo = 'S', $serie = false) {

        $sql = '';
        if ($tipo != 'S') {
            $sql = "and Tipo = '" . $tipo . "'";
        }

        if ($serie) {
            $sql .= " and Serie = '$serie'";
        }

        $selectExpression = "select EscolaID,Serie,Meta,Percentual,QuestaoProfessor,AgendaProfessor,QuestaoCoordenador,AgendaCoordenador,DtFimProfessor,DtFimCoordenador,Tipo, RespostaFinalAgendamentoAluno, NotiRespTarefaRealizada, AgendamentoDisciplinasLote
    						 from D023_Ava_Sae_Configuracoes where EscolaID = '" . $escolaid . "' " . $sql;
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();

    }

    function getAgendamento($escola, $disciplina, $frente, $assunto, $turma, $aluno = '') {

        $selectExpression = "Select itemName, EscolaID, DisciplinaID, FrenteID, AssuntoID, 
                        DtInicio, DtFim, AlunoID, DtCad
    	                     from D024_Ava_Sae_Agenda
                             where EscolaID = '" . $escola . "' and DisciplinaID = '" . $disciplina . "' and FrenteID = '" . $frente . "'
                and AssuntoID = '" . $assunto . "' and TurmaID = '" . $turma . "'";

        if ($aluno != ''){
            $selectExpression .= " and AlunoID = '$aluno'";
        }
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();

    }

    function getDadosAgendamento($id) {

        $selectExpression = "Select EscolaID, DisciplinaID, FrenteID, AssuntoID, TurmaID
    	                     from D024_Ava_Sae_Agenda where itemName = '$id'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();

    }

    function gravaDados($domain, $id, $dados, $replace = TRUE) {
        if ( $replace ){
            $this->getAvaMySQL()->where('itemName',$id);
            return $this->getAvaMySQL()->update($domain,$dados);
        }else{
            $dados['itemName'] = $id;
            return $this->getAvaMySQL()->insert($domain,$dados);
        }
    }

    public function DadosAssunto($assunto)
    {
        $sql = "select e089.*
                from E089_SubCategoriasAulas e089
                where e089.SubCategoriaAulaID = ". $assunto;
        $result = $this->getAvaMySQL()->query($sql)->result_array();
        return $result;
    }

    public function DadosTurma($turma)
    {
        $sql = "select d021.Descricao
                from D021_Ava_Sae_Turmas d021
                where d021.itemName = '". $turma ."'";
        $result = $this->getAvaMySQL()->query($sql)->result_array();
        return $result;
    }

    public function removeAgendamentos($domain,$escolaID, $assuntoID,$frenteID, $disciplinaID, $turmaID = Null, $automatico = false){
        // TODO: FDD-429 - UNSAFE QUERY
        $turma_antes = $turmaID;
        $turma = ($turmaID) ? " and TurmaID = '$turmaID'" : "";

        if(!$automatico)
        {
            $dadosAssunto = $this->curso->DadosAssunto($assuntoID);
            $dadosTurma = $this->curso->DadosTurma($turmaID);

            $acao = "Removido agendamento da atividade ". $dadosAssunto[0]['Descricao'] ." para a turma ". $dadosTurma[0]['Descricao'] ." (". $turma_antes .")";

            $log['loginid'] = $this->session->userdata['pessoaid'];
            $log['login'] = $this->session->userdata['login'];
            $log['acao'] = ($acao);
            $log['nomeescola'] = ($this->session->userdata['nomeEscola']);
            $log['escola'] = ($this->session->userdata['escola']);
            $log['disciplina'] = $disciplinaID;
            $log['assunto'] = $assuntoID;

            $log['codigo'] = '7'; // Removeu atividade

            $this->load->model('Log_model','logacesso');

            $this->logacesso->GravaLog($log);
        }

        return $this->getAvaMySQL()->query("delete from $domain where EscolaID = '$escolaID' and FrenteID = $frenteID and AssuntoID = $assuntoID and DisciplinaID = $disciplinaID".$turma);
    }

    /**
     * @param $idAgenda = itemName tabela D024
     * @param $idAluno = AlunoId tabela D024
     *
     * @return mixed
     */
    public function removerAgendamento($idAgenda, $idAluno)
    {
        try {
            return $this->getAvaMySQL()->delete(
                'D024_Ava_Sae_Agenda',
                [
                    'itemName' => $idAgenda,
                    'AlunoID' => $idAluno
                ]
            );

        } catch (\Exception $e) {
            log_error($e->getMessage());

            return false;
        }
    }

    /**
     * @param $idAgenda
     * @param $idAluno
     *
     * @return mixed
     */
    public function buscarAgendamento($idAgenda, $idAluno)
    {
        $query = $this->getAvaMySQL()->get_where('D024_Ava_Sae_Agenda', [
            'itemName' => $idAgenda,
            'AlunoID' => $idAluno
        ]);

        return $query->result_array();
    }

    function deleteDados( $domain, $id ){
        $this->getAvaMySQL()->where('itemName',$id);
        return $this->getAvaMySQL()->delete($domain);
    }

    public function verificaAssuntos($GrupoAulaID = null, $DisciplinaID = FALSE, $CategoriaID = FALSE) {

        if ($GrupoAulaID) {

            if ($DisciplinaID) {
                $DisciplinaID = " and e089.SubCategoriaAulaID = '$DisciplinaID' ";
            }

            $Categoria = '';
            if ($CategoriaID) {
                $Categoria = " and e088.CategoriaAulaID = '$CategoriaID' ";
            }

            $select_expression = "select e089.Descricao
                                     , e094.GrupoAulaID
                                     , e089.SubCategoriaAulaID as DisciplinaID
                                     , e089.DtInicio as DtInicio
                                     , e088.CategoriaAulaID as CategoriaID
                                     , '' as TemMensagem
                                from E089_SubCategoriasAulas e089
                                inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                where e094.GrupoAulaID = ". $GrupoAulaID ."
                                  ". $DisciplinaID ."
                                  ". $CategoriaID ."
                                  and e089.Descricao != ''
                                order by e089.Descricao ASC";

            // TODO: FDD-429 - UNSAFE QUERY
            $result = $this->getAvaMySQL()->query($select_expression);
            return $result->result_array();
        }

        return '';
    }

    /**
     * verifica se existem as questoes para um usuario
     * @param unknown $usuarioid
     * @param unknown $questaoid
     */
    function verificaExisteQuestao($usuarioid, $questaoid, $assuntoid = null) {

		$andAssunto = $assuntoid ?: "and AssuntoID = '{$adduntoid}'";
		// $andAssunto = $assuntoid ? "and AssuntoID = '{$adduntoid}'" : '';

        $sql = "select COUNT(*) as Existe
                from R001_RespostasQuestoes
				where UsuarioID = '{$usuarioid}'
					$andAssunto
                    and QuestaoID = {$questaoid}";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->row();
    }

    /**
     * Busca os alunos de uma turma
     * @param string $escola
     * @param string $turma
     * @param string $disciplina
     * @return array
     */
    function getAlunosTurma($escola = '', $turma = '', $disciplina = '') {

        if (empty($alunos)) {
            $selectExpression = "select itemName, Nome
                                 from D019_Ava_Sae
                                 where Perfil = '273' and Situacao = 'A'
                                	and Escola = '$escola'
                                	and Turma = '$turma'";

            // TODO: FDD-429 - UNSAFE QUERY
            $result = $this->getAvaMySQL()->query($selectExpression);
            $alunos = $result->result_array();
        }

        return $alunos;
    }

    /*
     * Reenvio
     */

    function atualizaEnviosEmailsSms($dados) {
        $data = array(
            'Situacao' => 'I'
        );

        $where['EscolaID'] = $dados['EscolaID'];
        $where['TurmaID'] = $dados['TurmaID'];
        $where['DisciplinaID'] = $dados['DisciplinaID'];
        $where['TipoID'] = 1;

        if (isset($where['UsuarioID'])) {
            $where['UsuarioID'] = $dados['UsuarioID'];
        }

        $this->getAvaMySQL()->update('T004_EnviosEmailsSms', $data, $where);
        return $this->getAvaMySQL()->affected_rows();
    }


    public function verificaDisciplinasCategoria($GrupoAulaID = null, $DisciplinaID = FALSE, $CategoriaID = FALSE) {

        $return = '';

        $Disciplina = '';
        if ($DisciplinaID) {
            $Disciplina = " and e089.SubCategoriaAulaID = '$DisciplinaID' ";
        }

        $Categoria = '';
        if ($CategoriaID) {
            $Categoria = " and e088.CategoriaAulaID = '$CategoriaID' ";
        }

        $select_expression = "select  e089.Descricao
                                     , e094.GrupoAulaID
                                     , e089.SubCategoriaAulaID as DisciplinaID
                                     , e089.DtInicio as DtInicio
                                     , e088.CategoriaAulaID as CategoriaID
                                     , '' as TemMensagem
                                from E089_SubCategoriasAulas e089
                                inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                where e094.GrupoAulaID = ". $GrupoAulaID ."
                                  ". $Disciplina ."
                                  ". $Categoria ."
                                  and e089.Descricao != ''
                                order by e089.Descricao ASC";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($select_expression);
        $return = $result->result_array();

        return $return;
    }

    public function verificaConfigSerie($escolaid,$serieID) {

        $selectExpression = "select ExibeMenuLD from D023_Ava_Sae_Configuracoes where EscolaID = '".$escolaid."' and Serie = '".$serieID."'";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($selectExpression);
        $result = $query->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);

        if(!$result){
            $sql = "SELECT SerieID,Descricao,Situacao,ExibeMenuLD,CategoriaID from T001_Series where Situacao = 'A' and SerieID = ".$serieID;
            // TODO: FDD-429 - UNSAFE QUERY
            $query = $this->getAvaMySQL()->query($sql);

            $result =  $query->result();

            if($result){
                $return = $result[0]->ExibeMenuLD;
            }
        }else{
            $return = isset($result[0]['ExibeMenuLD']) ? $result[0]['ExibeMenuLD'] : 'S';
        }

        return $return;

    }

    /**
     * Busca agendamentos ativo para a Turma ou Aluno
     * @param $turma
     * @param $disciplinaId
     * @param int|false $tipoAgendamento
     * @return mixed
     */
    public function agendamentosAtivos($turma, $disciplinaId, $tipoAgendamento = false)
    {
        $tipoAgendamentoStr = '';
        if ($tipoAgendamento) {
            $tipoAgendamentoStr = "AND tipo_agendamento = {$tipoAgendamento}";
        }

        $sql = "SELECT 
                    COUNT(id) qtdAgendamentosAtivos
                FROM
                    D024_Ava_Sae_Agenda
                WHERE
                    TurmaID = '{$turma}'
                        AND DisciplinaID = {$disciplinaId}
                        AND DtFim >= DATE_FORMAT(NOW(), '%Y-%m-%d')
                        AND (AlunoID IS NULL OR AlunoID = '{$this->pessoaid}')
                        {$tipoAgendamentoStr}
                ;";

        $query = $this->getAvaMySQL()->query($sql);

        return $query->result_array();


    }

    function getVideoAula($usuario_id, $aula_id, $disciplina_id){
        $this->getAvaMySQL()->select('RespostaQuestaoID, PercentualVideo, InicioVideo, FimVideo, VideoAulaAssistida, DtAgendaFim, YEAR(DtAlt) as year');
        $this->getAvaMySQL()->where('DisciplinaID', $disciplina_id);
        $this->getAvaMySQL()->where('AulaID', $aula_id);
        $this->getAvaMySQL()->where('UsuarioID', $usuario_id);
        $this->getAvaMySQL()->where('Tipo', 'N');
        $this->getAvaMySQL()->where('Situacao', 'A');
        $query = $this->getAvaMySQL()->get('R001_RespostasQuestoes');
        return $query->row();
    }

    function atualizaPorcentagemVideoNovaTabela($usuario_id, $turma_id, $assunto_id, $disciplina_id, $percentual_video, $inicio_video, $fim_video) {

        $where = array(
            'UsuarioID' => $usuario_id,
            'TurmaID' => $turma_id,
            'AssuntoID' => $assunto_id,
            'DisciplinaID' => $disciplina_id,
            'Tipo' => 'N',
            'Situacao' => 'A'
        );
        if (intval($percentual_video) > 99){
            $this->getAvaMySQL()->set('DtConclusao', date('Y-m-d H:i:s'));
        }
        if(intval($percentual_video) > 100){
            $percentual_video = 100;
        }
        $this->getAvaMySQL()->set('PercentualVideo', $percentual_video);
        $this->getAvaMySQL()->set('InicioVideo', $inicio_video);
        $this->getAvaMySQL()->set('FimVideo', $fim_video);
        $this->getAvaMySQL()->set('DtAlt', (new \DateTime())->format('Y-m-d H:i:s'));
        $this->getAvaMySQL()->where($where);
        $query = $this->getAvaMySQL()->update('R001_RespostasQuestoes');
        return $query;
    }

    function verificaQuestoesRespondidas($disciplinaid , $assuntoid, $alunoid, $aulaid = false, $tipo = false){
        $this->getAvaMySQL()->select('Tipo ,Meta, RespostaCorreta, TotalQuestoesAula, DescAssunto, DescAula, DescDisciplina, AulaID');
        $this->getAvaMySQL()->where('DisciplinaID', $disciplinaid);
        $this->getAvaMySQL()->where('AssuntoID', $assuntoid);
        if ($aulaid) {
            $this->getAvaMySQL()->where('AulaID', $aulaid);
        }
        if ($tipo) {
            $this->getAvaMySQL()->where('Tipo', $tipo);
        }
        $this->getAvaMySQL()->where('UsuarioID', $alunoid);
        $query = $this->getAvaMySQL()->get('R001_RespostasQuestoes');
        return $query->result();
    }

    function verificaEmailResponsavel($alunoid){
        $select_expression = "select Email from `D019_Ava_Sae` where Aluno ='$alunoid' and (Email is not null and Email != '')";
        $query = $this->getAvaMySQL()->query($select_expression);
        return $query->result_array();
        //return $this->simpledb->selectsItems($select_expression);
    }

    function getLinkVideo($disciplinaid){
        $select_expression = "select e068.AulaID
                                     , e091.SubCategoriaID as DisciplinaID
                                     , e068.Tema                                                                          
                                from E068_Aulas e068
                                inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                where e091.SubCategoriaID = ". $disciplinaid ."
                                and e068.Tipo = 'N'
                                and e068.Situacao = 'A'";
        $query = $this->getAvaMySQL()->query($select_expression);
        return $query->result_array();
        //return $this->simpledb->selectsItems($select_expression);
    }

    function getTipoQuestao($aulaID){
        $select_expression = "select  e068.Tipo                                     
                                from E068_Aulas e068
                                inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                                where e091.AulaId = ". $aulaID;
        $query = $this->getAvaMySQL()->query($select_expression);
        return $query->result_array();
    }



    protected function quantidadeDeAcertos($dados){
        foreach ($dados as $key => $dado){
            if ($dado->Tipo == 'Q'){
                $this->trigger['TotalAcertoQuestoes'] += (!is_null($dado->RespostaCorreta) AND $dado->RespostaCorreta == 'S') ? 1 : 0;
                $this->trigger['TotalQuestoes']++;
                $this->trigger['Tipo'][$dado->QuestaoID] = $dado->Tipo;
            }
            if ($dado->Tipo == 'R'){
                $this->trigger['TotalAcertosQuestoesRevisao'] += (!is_null($dado->RespostaCorreta) AND $dado->RespostaCorreta == 'S') ? 1 : 0;
                $this->trigger['TotalQuestoesRevisao']++;
                $this->trigger['MetaQuestoes'] = $dado->Meta;
            }
            if ($dado->Tipo == 'N'){
                $this->trigger['MetaVideos'] = (!is_null($dado->Meta)) ? $dado->Meta : 0;
                $this->trigger['TotalVideos']++;
            }
            $this->trigger['NomeAluno'] = $dado->NomeAluno;
            $this->trigger['DescDisciplina'] = $dado->DescDisciplina;
            $this->trigger['DescFrente'] = $dado->DescFrente;
            $this->trigger['DescAssunto'] = $dado->DescAssunto;
            $this->trigger['NomeEscola'] = $dado->NomeEscola;
            $this->trigger['DescTurma'] = $dado->DescTurma;
            $this->trigger['FrenteID'] = $dado->FrenteID;
            $this->trigger['EscolaID'] = $dado->EscolaID;
            $this->trigger['SerieID'] = $dado->SerieID;
            $this->trigger['UsuarioID'] = $dado->UsuarioID;
            $this->trigger['DisciplinaID'] = $dado->DisciplinaID;
            $this->trigger['TurmaID'] = $dado->TurmaID;
            $this->trigger['AssuntoID'] = $dado->AssuntoID;
            $this->trigger['DtAgendaInicio'] = $dado->DtAgendaInicio;
            $this->trigger['DtAgendaFim'] = $dado->DtAgendaFim;
        }
    }

    function captaMetaVideo($Escola = false, $AlunoID)
    {
        $select_expression = "select id, Serie, Escola from `D019_Ava_Sae` where itemName = '". $AlunoID ."'";
        $query = $this->getAvaMySQL()->query($select_expression);
        $idAluno = $query->result_array($query);

        if (!$Escola){
            $Escola = $idAluno[0]['Escola'];
        }

        $select_expression = "select Percentual from `D023_Ava_Sae_Configuracoes` where EscolaID = '". $Escola ."' and Serie = '". $idAluno[0]['Serie'] ."'";
        $query2 = $this->getAvaMySQL()->query($select_expression);
        return $query2->result_array();
        //return $this->simpledb->selectsItems($select_expression);
    }

    function AtualizaMetaVideo($AlunoID, $Escola, $AssuntoID)
    {
        $meta = $this->captaMetaVideo($Escola, $AlunoID);

        $sql = "update R001_RespostasQuestoes set Meta = '". $meta[0]['Percentual'] ."' where Tipo = 'N' and UsuarioID = '". $AlunoID ."' and EscolaID = '". $Escola ."' and AssuntoID = '". $AssuntoID ."'";
        $this->getAvaMySQL()->query($sql);

        return $meta[0]['Percentual'];
    }

    function calculaTempoVideoAoSair($params){
        if(!is_array($params)){
            $to_array = json_decode($params, true);
        }

        $convertido = array();
        foreach( $to_array as $val ){
            $item = array_values($val);
            if ( $item[0] != "" ){
                $convertido['resposta'][key($val)] = $item[0];
            }
        }

        return $this->getDadosAluno( $convertido['resposta'] );
    }

    function getDadosAluno( $param ){
        $sql = "SELECT * FROM R001_RespostasQuestoes WHERE UsuarioID = '{$param['usuarioID']}' and AssuntoID = '{$param['assuntoID']}' AND TIPO = 'N'  and Situacao = 'A'";
        $rs = $this->getAvaMySQL()->query($sql);
        return $rs->row();
    }

    function getTempoVideo( $param ){
        $sql = "SELECT * FROM R001_RespostasQuestoes WHERE UsuarioID = '{$_SESSION['pessoaid']}' and AssuntoID = '{$param['info']['DisciplinaID']}' AND TIPO = 'N' and Situacao = 'A'";
        $rs = $this->getAvaMySQL()->query($sql);
        $retorno = $rs->result_array();
        if ( isset($retorno[0]) ){
            return $retorno[0]['PercentualVideo'];
        }
        return 0;
    }

    function sendMail(){
        $config = array(
            'protocol' => 'smtp', // 'mail', 'sendmail', or 'smtp'
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            'smtp_user' => 'mundofragoso@gmail.com', // change it to yours
            'smtp_pass' => '', // change it to yours
            'smtp_crypto' => 'ssl', //can be 'ssl' or 'tls' for example
            'mailtype' => 'html', //plaintext 'text' mails or 'html'
            'smtp_timeout' => '4', //in seconds
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );

        $message = '';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->from('mundofragoso@gmail.com'); // change it to yours
        $this->email->to('wallace.fragoso@saedigital.com.br');// change it to yours
        $this->email->subject('Resume from JobsBuddy for your Job posting');
        $this->email->message($message);
        if($this->email->send()){
            echo 'Email enviado.';
        }else{
            show_error($this->email->print_debugger());
        }
    }

    function salvarErroVideo( $dados ){
        $data = array();
        $data['assuntoid'] = $dados['assuntoID'];
        $data['frenteid'] = $dados['frenteID'];
        $data['descFrente'] = $dados['DescFrente'];
        $data['ancora'] = $dados['Ancora'];
        $data['usuarioid'] = $dados['usuarioid'];
        $data['segmento'] = implode("/",$this->uri->segment_array());
        $data['dtcadastro'] = date('Y-m-d H:m:s');

        $this->cadastro->salvaDados('D043_Log_Erro_Video', Null, $data, TRUE);
    }

    function showModal (){
        $html = '<div id="alerta_video_nao_encontrado" class="modal fade" role="dialog">
            <div class="modal-dialog">

              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Atenção</h4>
                </div>
                <div class="modal-body">
                  <p style="font-size: 2em;">O vídeo encontra-se indisponível. <br>Aguarde algumas horas.</p>
                </div>
                <div class="modal-footer">
                  <button type="button" onclick="window.location = \'' . base_url() . 'curso/' . $this->session->userdata('Ancora') . '\';" class="btn btn-default" data-dismiss="modal">Fechar</button>
                </div>
              </div>

            </div>
          </div>
        <script>setTimeout(function(){ $("#alerta_video_nao_encontrado").modal("show");},2000);</script>  
        ';

        return $html;
    }

    // TODO: Erro encontrado no graylog
    public function CarregaQuestaoAPI($questaoID, $classificacao = null, $assuntoId = null)
    {
        $versaoConteudo = (int) $_SESSION['versao_conteudo_id'];
        $questaoID = (int) $questaoID;

        $isJarvis = SaeDigital::make(BuscarEstruturaQuestao::class)->handle($versaoConteudo, $questaoID, $assuntoId);
        if (((int)$classificacao === ClassificacaoConteudo::CONTEUDO_GERAL) || ((int)$classificacao === ClassificacaoConteudo::PLATAFORMA_LITERARIA && $isJarvis)) {
            $itemId = $questaoID;
            if (!empty($isJarvis['JarvisItemID']) || !is_null($isJarvis['JarvisItemID'])) {
                $itemId = $isJarvis['JarvisItemID'];
            }

            try {
                $jarvisItem = $this->getJarvisItem($itemId);

                if (is_array($jarvisItem)) {
                    $gabarito = '';
                    foreach ($jarvisItem['alternativas'] as $alternativa) {
                        if ($alternativa['opcaoCorreta'] == 1) {
                            $gabarito = $alternativa['valorOpcao'];
                        }
                    }

                    return [
                        'success' => 1,
                        'message' => [
                            'questao' => $jarvisItem
                        ],
                        'gabarito' => $gabarito
                    ];
                }
            } catch (BadGatewayException $e) {
                return [
                    'success' => 0,
                    'code' => $e->getCode(),
                    'message' => 'Ocorreu um problema ao carregar a questão, por favor, recarregue a página!'
                ];
            } catch (NotFoundException $e) {
                return [
                    'success' => 0,
                    'code' => $e->getCode(),
                    'message' => 'Questão não foi encontrada!'
                ];
            } catch (\Exception $e) {
                return [
                    'success' => 0,
                    'code' => $e->getCode(),
                    'message' => 'Ocorreu um problema ao carregar a questão, por favor tente novamente!'
                ];
            }
        }

        if ((int)$classificacao !== ClassificacaoConteudo::PLATAFORMA_LITERARIA) {
            return [
                'success' => 0,
                'message' => 'Conteúdo não encontrado!'
            ];
        }

        $sql = "select qst.id
                     , qst.enunciado
                     , qst.texto_associado
                     , qst.data_cadastro
                     , qst.revisada
                     , qst.anulada
                     , qst.desatualizada

                     , qtr.nome as tipo_resposta

                     , qdf.nome as dificuldade

                     , qor.id as id_alternativa
                     , qor.opcao as alternativa
                     , qor.valor_opcao as valoropcao
                     , qor.opcao_correta opcaocorreta		

                     , pro.nome as busca_prova
                     , pro.nome as nome_prova
                     , pro.slug as slug_prova
                     , pro.data_aplicacao as dtplicacao_prova		

                from questao qst
                   , questao_tipo_resposta qtr
                   , questao_dificuldade qdf
                   , questao_opcao_resposta qor
                   , questao_prova qpv
                   , prova pro

                where qst.id = ". $questaoID ."
                
                and qst.questao_tipo_resposta_id = qtr.id
                and qst.questao_dificuldade_id = qdf.id
                and qst.id = qor.questao_id
                and qst.id = qpv.questao_id
                and pro.id = qpv.prova_id";

        $rs = $this->getAvaMySQLQuestoes()->query($sql);
        $q = $rs->result_array();


        if(count($q) > 0)
        {

            $ret['success'] = 1;
            $ret['message']['questao']['id'] = $q[0]['id'];
            $ret['message']['questao']['enunciado'] = $q[0]['enunciado'];
            $ret['message']['questao']['textoAssociado'] = $q[0]['texto_associado'];
            $ret['message']['questao']['dataCadastro'] = $q[0]['data_cadastro'];
            $ret['message']['questao']['revisada'] = $q[0]['revisada'];
            $ret['message']['questao']['anulada'] = $q[0]['anulada'];
            $ret['message']['questao']['desatualizada'] = $q[0]['desatualizada'];
            $ret['message']['questao']['tipoResposta']['nome'] = $q[0]['tipo_resposta'];
            $ret['message']['questao']['dificuldade']['nome'] = $q[0]['dificuldade'];

            for($i=0; $i<count($q); $i++) {
                $ret['message']['questao']['alternativas'][$i]['id'] = $q[$i]['id_alternativa'];
                $ret['message']['questao']['alternativas'][$i]['opcao'] = $q[$i]['alternativa'];
                $ret['message']['questao']['alternativas'][$i]['valorOpcao'] = $q[$i]['valoropcao'];
                $ret['message']['questao']['alternativas'][$i]['opcaoCorreta'] = $q[$i]['opcaocorreta'];
            }

            $sql2 = "select pro.id as id_prova
                        , pro.nome as busca_prova
                        , pro.nome as nome_prova
                        , pro.slug as slug_prova
                        , pro.data_aplicacao as dtplicacao_prova		
                        , pof.nome as area_formacao
                        , paa.nome as area_atuacao
                    from questao qst                   
                        , questao_prova qpv
                        , prova pro
                        , prova_area_formacao pof
                        , prova_area_atuacao paa
                    where qst.id = ". $questaoID ."
                    and qst.id = qpv.questao_id
                    and pro.id = qpv.prova_id
                    and pro.prova_area_formacao_id = pof.id
                    and pro.prova_area_atuacao_id = paa.id
                    ";
            $rs2 = $this->getAvaMySQLQuestoes()->query($sql2);
            $p = $rs2->result_array();

            for($i=0;$i<count($p);$i++)
            {
                $ret['message']['questao']['prova'][$i]['busca'] = $p[$i]['busca_prova'];
                $ret['message']['questao']['prova'][$i]['nome'] = $p[$i]['nome_prova'];
                $ret['message']['questao']['prova'][$i]['slug'] = $p[$i]['slug_prova'];
                $dataapl = explode("/",$p[$i]['dtplicacao_prova']);
                $ret['message']['questao']['prova'][$i]['ano'] = $dataapl[1];
            }

            $sql3 = "select pof.nome as area_formacao                      

                    from prova pro
                       , prova_area_formacao pof

                    where pro.id = ". $p[0]['id_prova'] ."

                    and pro.prova_area_formacao_id = pof.id
                    ";
            $rs3 = $this->getAvaMySQLQuestoes()->query($sql3);
            $p2 = $rs3->result_array();

            for($i=0;$i<count($p2);$i++)
            {
                $ret['message']['questao']['areaFormacao'][$i]['nome'] = $p2[$i]['area_formacao'];
            }

            $sql4 = "select paa.nome as area_atuacao

                    from prova pro
                       , prova_area_atuacao paa

                    where pro.id = ". $p[0]['id_prova'] ."

                    and pro.prova_area_atuacao_id = paa.id
                    ";
            $rs4 = $this->getAvaMySQLQuestoes()->query($sql4);
            $p3 = $rs4->result_array();

            for($i=0;$i<count($p3);$i++)
            {
                $ret['message']['questao']['areaAtuacao'][$i]['nome'] = $p3[$i]['area_atuacao'];
            }

            $sql5 = "select car.nome as busca_cargo
                          , car.nome as nome_cargo

                    from prova pro
                       , cargo car

                    where pro.id = ". $p[0]['id_prova'] ."
                      and pro.cargo_id = car.id";
            $rs5 = $this->getAvaMySQLQuestoes()->query($sql5);
            $cargo = $rs5->result_array();

            for($i=0;$i<count($cargo);$i++)
            {
                $ret['message']['questao']['cargo'][$i]['busca'] = $cargo[$i]['busca_cargo'];
                $ret['message']['questao']['cargo'][$i]['nome'] = $cargo[$i]['nome_cargo'];
            }

            $sql6 = "select esc.nome as nome_escolaridade

                    from prova pro
                       , escolaridade esc

                    where pro.id = ". $p[0]['id_prova'] ."

                    and pro.escolaridade_id = esc.id";
            $rs6 = $this->getAvaMySQLQuestoes()->query($sql6);
            $esc = $rs6->result_array();

            for($i=0;$i<count($esc);$i++)
            {
                $ret['message']['questao']['escolaridade'][$i]['nome'] = $esc[$i]['nome_escolaridade'];
            }

            $sql7 = "select con.nome as nome_concurso
                          , con.nome as busca_concurso
                          , con.id as id_concurso

                    from prova pro
                       , concurso con

                    where pro.id = ". $p[0]['id_prova'] ."
                      and pro.concurso_id = con.id
                ";
            $rs7 = $this->getAvaMySQLQuestoes()->query($sql7);
            $con = $rs7->result_array();

            for($i=0;$i<count($con);$i++)
            {
                $ret['message']['questao']['concurso'][$i]['busca'] = $con[$i]['busca_concurso'];
                $ret['message']['questao']['concurso'][$i]['nome'] = $con[$i]['nome_concurso'];
            }

            $sql8 = "select concat(dom.nome,' - ', ins.descricao) as ins_busca
                            , ins.descricao as ins_nome
                            , ins.sigla as ins_sigla
                            , concat(dom.nome,' - ', ins.descricao) as busca_sinonimo
                            , dom.nome as dominio

                    from concurso con
                       , instituicao ins
                        , dominio dom

                    where con.id = ". $con[0]['id_concurso'] ."
                     and con.instituicao_id = ins.id
                     and dom.instituicao_id = ins.id";

            $rs8 = $this->getAvaMySQLQuestoes()->query($sql8);
            $ins = $rs8->result_array();

            for($i=0;$i<count($ins);$i++)
            {
                $ret['message']['questao']['instituicao'][$i]['busca'] = $ins[$i]['ins_busca'];
                $ret['message']['questao']['instituicao'][$i]['nome'] = $ins[$i]['ins_nome'];
                $ret['message']['questao']['instituicao'][$i]['sigla'] = $ins[$i]['ins_sigla'];
                $ret['message']['questao']['instituicao'][$i]['buscaSinonimo'] = $ins[$i]['busca_sinonimo'];
                $ret['message']['questao']['instituicao'][$i]['dominio'] = $ins[$i]['dominio'];
            }

            $sql9 = "select ass.nome as nome_assunto
                          , ass.nome as busca_assunto
                    from questao_assunto qas
                       , questao qst
                       , assunto ass
                    where qst.id = ". $q[0]['id'] ."
                      and qst.id = qas.questao_id
                      and qas.assunto_id = ass.id";

            $rs9 = $this->getAvaMySQLQuestoes()->query($sql9);
            $ass = $rs9->result_array();

            for($i=0;$i<count($ass);$i++)
            {
                $ret['message']['questao']['assunto'][$i]['busca'] = $ass[$i]['busca_assunto'];
                $ret['message']['questao']['assunto'][$i]['nome'] = $ass[$i]['nome_assunto'];
            }

            $sql10 = "select dis.nome as nome_disciplina
                        , dis.nome as busca_disciplina
                        , dis.slug as slug_disciplina
                   from questao_disciplina qdi
                      , questao qst
                      , disciplina dis
                   where qst.id = ". $q[0]['id'] ."
                     and qst.id = qdi.questao_id
                     and qdi.disciplina_id = dis.id";

            $rs10 = $this->getAvaMySQLQuestoes()->query($sql10);
            $dis = $rs10->result_array();

            for($i=0;$i<count($dis);$i++)
            {
                $ret['message']['questao']['disciplina'][$i]['busca'] = $dis[$i]['busca_disciplina'];
                $ret['message']['questao']['disciplina'][$i]['nome'] = $dis[$i]['nome_disciplina'];
                $ret['message']['questao']['disciplina'][$i]['slug'] = $dis[$i]['slug_disciplina'];
            }

            $sql11 = "select cba.nome as busca_banca
                           , cba.nome as nome_banca
                           , cba.sigla as sigla_banca
                     from concurso_banca cba
                        , concurso con   
                     where con.id = ". $con[0]['id_concurso'] ."
                       and con.concurso_banca_id = cba.id";

            $rs11 = $this->getAvaMySQLQuestoes()->query($sql11);
            $ban = $rs11->result_array();

            for($i=0;$i<1;$i++)
            {
                $ret['message']['questao']['banca'][$i]['busca'] = $ban[$i]['busca_banca'];
                $ret['message']['questao']['banca'][$i]['nome'] = $ban[$i]['nome_banca'];
                $ret['message']['questao']['banca'][$i]['sigla'] = $ban[$i]['sigla_banca'];
            }

            $ret['message']['questao']['respostas'] = '';
            $ret['message']['questao']['respondidaAnteriormente'] = '';
            $ret['message']['questao']['acertouAnteriormente'] = '';
            $ret['message']['questao']['acompanhando'] = '';
            $ret['message']['questao']['responderMaisTarde'] = '';
            $ret['message']['questao']['clientePermissaoVideo'] = '';
            $ret['message']['questao']['urlVideo'] = '';
            $ret['message']['questao']['videoClassificou'] = '';
            $ret['message']['questao']['videoClassificacaoPositiva'] = '';
            $ret['message']['questao']['videoClassificacaoNegativa'] = '';
            $ret['message']['questao']['videoClassificacaoPositivaTitle'] = '';
            $ret['message']['questao']['videoClassificacaoNegativaTitle'] = '';

            $sql13 = "select valor_opcao
                        from questao qst
                           , questao_opcao_resposta qor
                        where qst.id = ". $questaoID ."
                            and qst.id = qor.questao_id
                    ";

            $rs13 = $this->getAvaMySQLQuestoes()->query($sql13);
            $gab = $rs13->result_array();

            $ret['message']['gabarito'] = $gab[0]['valor_opcao'];

            return $ret;
        }
        else
        {
            $ret['success'] = 0;
            $ret['message'] = "Questão não localizada!";
            return $ret;
        }
    }

    private function getJarvisItem($itemId)
    {
        $item = SaeDigital::make(JarvisApi::class)->getItem($itemId);

        $correct = reset(array_filter($item['attributes'], function ($attribute) {
            return ($attribute['attribute']['id'] == JarvisApi::ALTERNATIVA_CORRETA ? true : false);
        }));

        $question = [
            'id' => (isset($item['legacy']['legacy_id']) ? $item['legacy']['legacy_id'] : $item['id']),
            'jarvisItemId' => $item['id'],
            'enunciado' => $item['title'],
            'textoAssociado' => null,
            'dataDadastro' => $item['created_at'],
            'revisada' => 0,
            'anulada' => 0,
            'desatualizada' => 0,
            'tipoResposta' => [
                'nome' => 'Múltipla-Escolha'
            ],
            'dificuldade' => [
                'nome' => ''
            ],
            'alternativas' => array_map(
                function ($option) use ($correct) {
                    return [
                        'id' => (isset($option['legacy']['legacy_id']) ? $option['legacy']['legacy_id'] : $option['id']),
                        'opcao' => $option['value'],
                        'valorOpcao' => chr(ord('a') + ($option['attribute']['id']-1)),
                        'opcaoCorreta' => ($option['attribute']['id'] == $correct['value'] ? 1 : 0)
                    ];
                }, array_filter($item['attributes'], function ($attribute) {
                    return (in_array($attribute['attribute']['id'], [
                        JarvisApi::ALTERNATIVA_1,
                        JarvisApi::ALTERNATIVA_2,
                        JarvisApi::ALTERNATIVA_3,
                        JarvisApi::ALTERNATIVA_4,
                        JarvisApi::ALTERNATIVA_5
                    ]) ? true : false);
                })
            )
        ];

        return $question;
    }

    public function verificaProximaVideoAula($disciplina, $aulaNumero){
        $sql = "
select  e068.AulaID
, e091.SubCategoriaID as DisciplinaID
, e068.Tema
, LPAD(e091.Ordem,4,0) as Ordem
, e068.Video
, e068.Duracao
, e068.DtCad
, e068.Tipo
, concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
from E068_Aulas e068
inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
where e091.SubCategoriaID = ".$disciplina."
and e068.Tipo = 'N' 
and (e068.Situacao is null or e068.Situacao = 'A')  
Order by ABS(e091.Ordem) ASC";
        $result = $this->getAvaMySQL()->query($sql);
        $resultado = $result->result_array();
        return  isset($resultado[$aulaNumero]) ? $resultado[$aulaNumero] : null;

    }

    /**
     * @param $turmaid
     * @param $frenteid
     *
     * @return mixed
     */
    public function dadosAssuntoPlataformaLiteraria($turmaid, $frenteid)
    {
        $this->getAvaMySQL()->select('AssuntoID, DisciplinaID');
        $this->getAvaMySQL()->where('TurmaID', $turmaid);
        $this->getAvaMySQL()->where('FrenteID', $frenteid);
        $this->getAvaMySQL()->group_by("AssuntoID");
        $query = $this->getAvaMySQL()->get('R001_RespostasQuestoes');
        return $query->result_array();
    }

    /**
     * @param $idAluno
     * @param $idAssunto
     *
     * @return bool
     */
    public function validarLiberacaoDeAtividades($idAluno, $idAssunto, $idTurma, $tipoAtividade)
    {
        $where = '';

        if ($tipoAtividade == 'R') {
            $where .= " AND resposta.Tipo = 'N' ";
        } elseif ($tipoAtividade == 'N') {
            return true;
            $where .= " AND resposta.Tipo = 'Q' ";
            $where .= " AND resposta.Resposta IS NOT NULL ";
            $where .= " HAVING COUNT(resposta.RespostaQuestaoID) >= 4 ";
        } else {
            $where .= " AND resposta.Tipo = '{$tipoAtividade}' ";
        }

        $sql = "SELECT 
                    COUNT(resposta.RespostaQuestaoID) > 0 liberarAtividade
                FROM
                    R001_RespostasQuestoes resposta
                WHERE
                    resposta.Situacao = 'A'
                    -- AND resposta.TurmaID = '{$idTurma}'
                    AND resposta.UsuarioID = '{$idAluno}'
                    AND resposta.AssuntoID = '{$idAssunto}'
                    {$where};";
                    
		$query = $this->getAvaMySQL()->query($sql);
		$result = $query->result_array();

        $liberar = intval($result[0]['liberarAtividade']);

        return ($liberar > 0);
    }

    public function buscarAgendamentoTurmaAssunto($turma, $assuntoId, $tipoAgendamento = null, $alunoId = null)
    {
        if (!$tipoAgendamento) $tipoAgendamento = TipoAgendamento::TRILHA;

        $this->getAvaMySQL()->where('TurmaID', $turma);
        $this->getAvaMySQL()->where('AssuntoID', $assuntoId);
        $this->getAvaMySQL()->where('AlunoID', $alunoId);
//        $this->getAvaMySQL()->where('tipo_agendamento', $tipoAgendamento);

        $query = $this->getAvaMySQL()->get('D024_Ava_Sae_Agenda');

        return $query->result_array();
    }

    public function buscarAgendamentoAlunoTurmaAssunto($usuarioId, $turma, $assuntoId, $tipoAgendamento = null)
    {
        if (!$tipoAgendamento) $tipoAgendamento = TipoAgendamento::TRILHA;

        $this->getAvaMySQL()->where('TurmaID', $turma);
        $this->getAvaMySQL()->where('AssuntoID', $assuntoId);
        $this->getAvaMySQL()->where('AlunoID', $usuarioId);
//        $this->getAvaMySQL()->where('tipo_agendamento', $tipoAgendamento);

        $query = $this->getAvaMySQL()->get('D024_Ava_Sae_Agenda');

        return $query->result_array();
    }

    public function validarAgendamentoPlataformaLiteraria($turma, $idAssunto, $frenteId)
    {
        $sql = "SELECT 
                    agenda.itemName, bimestre.CategoriaAulaID, bimestre.Descricao
                FROM
                    D024_Ava_Sae_Agenda agenda
                        INNER JOIN
                    E088_CategoriasAulas bimestre ON (agenda.FrenteID = bimestre.CategoriaAulaID)
                WHERE
                    agenda.TurmaID = '{$turma}'
                    AND agenda.AssuntoID = {$idAssunto}
                    AND agenda.FrenteID = {$frenteId};";

        $query = $this->getAvaMySQL()->query($sql);

        $result = $query->result_array()[0];

        return (strpos($result['Descricao'], 'Plataforma') !== false);
    }

    public function validarAgendamentoPlataformaLiterariaD024($turma, $idAssunto, $frenteId)
    {
        $sql = "SELECT 
                    agenda.itemName, bimestre.CategoriaAulaID, bimestre.Descricao
                FROM
                    D024_Ava_Sae_Agenda agenda
                        INNER JOIN
                    E088_CategoriasAulas bimestre ON (agenda.FrenteID = bimestre.CategoriaAulaID)
                WHERE
                    agenda.TurmaID = '{$turma}'
                    AND agenda.AssuntoID = {$idAssunto}
                    AND agenda.FrenteID = {$frenteId}
                    AND agenda.tipo_agendamento = 3;";

        $query = $this->getAvaMySQL()->query($sql);

        $result = $query->result_array()[0];

        return (bool)(sizeof($result) > 0);
    }

}

