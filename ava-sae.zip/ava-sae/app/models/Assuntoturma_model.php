<?php

$obj = &get_instance();
$obj->load->model('RespostaQuestaoAgregada_model');

class AssuntoTurma_model extends RespostaQuestaoAgregada_model
{

    public $AssuntoID;
    public $DescricaoAssunto;
    public $TurmaID;
    public $PercentualAssunto;
    public $FezQuestao;
    public $ViuVideo;
    public $FezRevisao;
    public $QntDivisao;


}