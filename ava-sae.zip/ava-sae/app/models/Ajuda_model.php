<?php

class Ajuda_model extends MY_Model {

    function __construct() {
        parent::__construct();
    }

    /**
     * Grava Reclamação
     *
     * Recebe os parâmetros dos usuário através de um $_POST e verifica no simpleDB
     * da Amazon se existe, caso exista retorna um array formatado, caso não retorna vazio.
     *
     * @access	public
     * @param	array           array com dados dos usuários enviado através do controller.
     * @param	string		contento nome do dominio
     * @return	array           com conteúdo ou vazio
    */
    public function gravaReclamacao($dados, $assinaturaMatriculaID) {

            $nome     = utf8_decode($dados['nome']);
            $email    = utf8_decode($dados['email']);
            $telefone = $dados['telefone'];
            $tel = '';

            if ($telefone != '') {
                    $tel_  = explode("-", $dados['telefone']);
                    $tel_0 = str_replace('(', '', $tel_[0]);
                    $tel_1 = str_replace(')', '', $tel_0);
                    $tel_1 = str_replace(' ', '', $tel_1);
                    $tel = $tel_1.$tel_[1];

            }

            $curso  = $dados['curso'];
            $mensagem = utf8_decode($dados['mensagem']);
            $dtCad = date("Y/m/d H:i:s");

            $versaoBrowser = $dados['versaoBrowser'] != "" ? $dados['versaoBrowser'] : 'NULL';
            $versaoFlash = $dados['versaoFlash'] != "" ? $dados['versaoFlash'] : 'NULL';

            $ipInterno = $dados['ipInterno'] != "" ? $dados['ipInterno'] : 'NULL';
            $ipExterno = $dados['ipExterno'] != "" ? $dados['ipExterno'] : 'NULL';

            $versaoSO = $dados['versaoSO'] != "" ? $dados['versaoSO'] : 'NULL';
            $tipoConexao = $dados['tipoConexao'] != "" ? $dados['tipoConexao'] : 'NULL';
            $velocidadeConexao = $dados['velocidadeConexao'] != "" ? $dados['velocidadeConexao'] : 'NULL';
            $operadora = $dados['operadora'] != "" ? $dados['operadora'] : 'NULL';

            // Questões
            $formaConexao = utf8_decode($dados['formaConexao']);
            $localidade   = utf8_decode($dados['localidade']);
            $dispositivos = utf8_decode($dados['dispositivos']);
            $limite       = utf8_decode($dados['limite']);
            $dificuldade  = utf8_decode($dados['dificuldade']);
            $conjuntodevideos = utf8_decode($dados['conjuntodevideos']);
            $duracaodificuldade = utf8_decode($dados['duracaodificuldade']);
            $outrocomputador    = utf8_decode($dados['outrocomputador']);
            $outraconexao       = utf8_decode($dados['outraconexao']);
            $conectarcabo       = utf8_decode($dados['conectarcabo']);
            $requisitosminimos  = utf8_decode($dados['requisitosminimos']);

            // TODO: FDD-429 - UNSAFE QUERY
            $sql = "insert into e996_ReclameAquiVideoAula(AssinaturaMatriculaID, Email, Telefone, Mensagem, DtCad, versaoBrowser, versaoFlash, versaoSO,
                            tipoConexao, velocidadeConexao, operadora, ipInterno, ipExterno, Questao2, Questao5, Questao6, Questao7, Questao8, Questao9,
                            Questao10, Questao11, Questao12, Questao13, Questao14)
                            values($assinaturaMatriculaID, '$email', '$tel', '$mensagem', '$dtCad', '$versaoBrowser', $versaoFlash, '$versaoSO', '$tipoConexao',
                            '$velocidadeConexao', '$operadora', '$ipInterno', '$ipExterno', '".$formaConexao."', '".$localidade."',
                            '".$dispositivos."', '".$limite."', '".$dificuldade."', '".$conjuntodevideos."',
                            '".$duracaodificuldade."', '".$outrocomputador."', '".$outraconexao."', '".$conectarcabo."',
                            '".$requisitosminimos."')";

            $query = $this->getAvaMySQL()->query($sql);
            return $query;
    }
}
