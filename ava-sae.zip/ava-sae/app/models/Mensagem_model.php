<?php

/**
 * Mensagem_model (ISO-8859-1)
 * Created: 18/11/2013
 *
 * @author Maria C. Dadalt
 */
class Mensagem_model extends MY_Model {

    function __construct() {
        parent::__construct();


    }

    // TODO: FDD-429 - VER COMO ISSO FUNCIONA, NAO USAMOS MAIS SIMPLE DB
    function getMessages($user, $package, $disciplinas = array(), $limit = 0, $select = '*', $date = NULL, $dateOperator = '>=')
    {

        $messages = array();
        // SimpleDb nao aceita muitos parametros, entao a consulta por disciplina foi dividida
        $sqlInicio = "SELECT {$select} FROM D010_Mensagens WHERE Situacao = 'A' AND ";

        if ($date === NULL) {
            $sqlInicio .= "DtCad IS NOT NULL AND ";
        } else {
            $sqlInicio .= "DtCad {$dateOperator} '{$date}' AND ";
        }

        //$sql .= " OR (Enviar = 'D' AND DisciplinaID in ('".implode("','",$disciplinas)."')) ";

        $sqlFim = " ORDER BY DtCad DESC ";

        if ($limit > 0) {
            $sqlFim .= "LIMIT {$limit}";
        }

        // Se tiver pacotes
        if ($package) {

            //busca a menor data de liberação
            $dt = array();
            $pacotes = array();
            foreach ($package as $item => $value) {

                // TODO: temporario, só para nao dar erro nos cookies já criados.
                if (isset($value->date)) {
                    $dt[] = $value->date;
                } else {
                    $dt[] = $value;
                }
                $pacotes[] = $item;
            }

            $menorData = min($dt);
            $maiorData = max($dt);
            $msg = array();


            //Para alunos atuais
            //foreach ($package as $item => $value){

            $sql1 = $sqlInicio . " (Alunos = 'A' and ((DtAgendamento is null and DtCad >= '$menorData' ) or DtAgendamento >= '$menorData') and (Enviar in ('G')
													or (Enviar = 'A' AND PessoaID = '{$user}'))
								   )";


            $sql1 .= $sqlFim;

            // TODO: FDD-429 - NAO USAMOS MAIS SIMPLE DB
            $response = $this->sdb->select($sql1);

            if ($response->isOk()) {
                $messages += $this->formatMessage($response->body->SelectResult, $user);
            }


            // Para pacotes e alunos atuais
            foreach ($package as $item => $value) {

                // TODO: temporario, só para nao dar erro nos cookies já criados.
                if (isset($value->date)) {
                    $dtPack = $value->date;
                } else {
                    $dtPack = $value;
                }

                $sql4 = $sqlInicio . "   Alunos = 'A' and Enviar = 'P'
										AND  GrupoAulaID = '$item'
										and ((DtAgendamento is null and DtCad >= '$dtPack') or DtAgendamento >= '$dtPack')";
                $sql4 .= $sqlFim;

                // TODO: FDD-429 - NAO USAMOS MAIS SIMPLE DB
                $response4 = $this->sdb->select($sql4);

                if ($response4->isOk()) {
                    $messages += $this->formatMessage($response4->body->SelectResult, $user);
                }
            }

            //para alunos atuais e futuros
            $sql3 = $sqlInicio . " (DtAgendamento is null or DtAgendamento < '" . date('Y-m-d H:i:s') . "') AND (Alunos = 'F' or Alunos is null)";
            $sql3 .= " and ( (Enviar in ('G')) or
							((Enviar = 'P' AND GrupoAulaID IN ('" . implode("','", $pacotes) . "') ) or
							(Enviar = 'A' AND PessoaID = '{$user}') )
							)";

            $sql3 .= $sqlFim;

            // TODO: FDD-429 - NAO USAMOS MAIS SIMPLE DB
            $response3 = $this->sdb->select($sql3);

            if ($response3->isOk()) {
                $messages += $this->formatMessage($response3->body->SelectResult, $user);
            }


            if (!empty($disciplinas)) {

                foreach ($disciplinas as $grupo => $value) {

                    // maximo valores permitido no in
                    $maxdisciplina = @array_chunk($value, 20);

                    if ($maxdisciplina) {
                        foreach ($maxdisciplina as $disc) {

                            $sql2 = $sqlInicio . " Enviar = 'D' and DisciplinaID in ('" . implode("','", $disc) . "')
												and ((Alunos = 'F' or Alunos is null )
														or (Alunos = 'A' AND ((DtAgendamento is null and DtCad >= '" . $package[$grupo] . "') or DtAgendamento >= '" . $package[$grupo] . "'))
													)
									";
                            $sql2 .= $sqlFim;

                            // TODO: FDD-429 - NAO USAMOS MAIS SIMPLE DB
                            $response2 = $this->sdb->select($sql2);

                            if ($response2->isOk()) {
                                $messages += $this->formatMessage($response2->body->SelectResult, $user);
                            }
                        }
                    }
                }

            }


        } else {

            $sql1 = $sqlInicio . " (Alunos = 'F' or Alunos is null)
				AND ( (Enviar in ('G')) or (Enviar = 'A' AND PessoaID = '{$user}'))";
            $sql1 .= $sqlFim;
            $sqlInicio = "SELECT * FROM D010_Mensagens WHERE Situacao = 'A' limit 10";

            // TODO: FDD-429 - NAO USAMOS MAIS SIMPLE DB
            $response = $this->sdb->select($sqlInicio);

            if ($response->isOk()) {
                $messages += $this->formatMessage($response->body->SelectResult, $user);
            }

        }

        if (!empty($messages)) {
            krsort($messages);

            if ($limit > 0) {
                $result = array_chunk($messages, $limit);

                return reset($result);
            }
            return $messages;
        } else {
            return FALSE;
        }
    }

    function getUnreadNumber($userID, $package, $disciplinas = array()) {

        $messages = $this->getMessages($userID, $package, $disciplinas, 0, 'count(*)');
		$msgs = 0;
		if ($messages) {
			foreach($messages as $key => $value) {
				$msgs += $value['Count'];
			}
        }
        if ($msgs == 0) {
            return 0;
        }

        $sql = "SELECT count(*) FROM D011_Log_Mensagens WHERE PessoaID = '{$userID}'";

        // TODO: FDD-429 - NAO USAMOS MAIS SIMPLE DB
        $unread = $this->sdb->select($sql);

        if ($unread->isOk()) {
            $num = (int) $unread->body->SelectResult->Item->Attribute->Value;
            return $msgs - $num;
        } else {
            return 0;
        }
    }

    function readMessage($itemID) {
        // TODO: FDD-429 - NAO USAMOS MAIS SIMPLE DB
        $response = $this->sdb->get_attributes('D010_Mensagens', $itemID);
        if ($response->isOk()) {
            return $this->formatResponse($response->body->GetAttributesResult);
        } else {
            return $sql;
        }
    }

    function isMessageRead($msg, $pessoa) {
        $sql = "SELECT * FROM D011_Log_Mensagens WHERE MensagemID = '{$msg}' AND PessoaID = '{$pessoa}'";
        // TODO: FDD-429 - NAO USAMOS MAIS SIMPLE DB
        $response = $this->sdb->select($sql);
        if ($response->isOk()) {
            if ($response->body->SelectResult->Item) {
                return TRUE;
            } else {
                return FALSE;
            }
        } else {
            return FALSE;
        }
    }

    function markAsRead($msg, $pessoa) {
        $date = new DateTime();
        $timeStamp = $date->format('U');

        $dados = array();
        $dados['MensagemID'] = $msg;
        $dados['PessoaID'] = $pessoa;
        $dados['Lida'] = 'S';
        $dados['DtLeitura'] = $date->format('Y-m-d H:i:s');

        // TODO: FDD-429 - NAO USAMOS MAIS SIMPLE DB
        $result = $this->sdb->put_attributes('D011_Log_Mensagens', $timeStamp . $pessoa . $msg, $dados);

        if ($result->isOk()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function formatResponse($response) {

        if (!$response->Attribute) {
            return FALSE;
        }

        $array = array();
        foreach ($response->Attribute as $attr) {
            if ($attr->Name == 'DtCad') {
                $data = new DateTime($attr->Value);
                $array["{$attr->Name}"] = date_format($data, 'd/m/Y');
            } else {
                $array["{$attr->Name}"] = (string) $attr->Value;
            }
        }
        return $array;
    }

    function formatMessage($result, $user) {
        $i = 0;
        $return = array();

        foreach ($result->Item as $key => $value) {
			$id = utf8_decode((string) $value->Name);

			// id para ordernar apos consultar mensagens por disciplinas
			if (is_numeric($id)) {
				$index = $id;
			} else {
				$index = time();
			}

		    foreach ($value->Attribute as $attr) {
                @$return[$index]["$attr->Name"] = utf8_decode(current($attr->Value));
            }

            @$return[$index]["id"] = utf8_decode((string) $value->Name);
            if($this->isMessageRead($return[$index]["id"], $user)){
                $return[$index]["Unread"] = FALSE;
            } else {
                $return[$index]["Unread"] = TRUE;
            }
            $i++;
        }

        return $return;
    }
}
