<?php

class Disciplina_model extends MY_Model {

    public $pessoaid;

    function __construct() {
        parent::__construct();

        $this->pessoaid = $this->session->userdata('pessoaid');
    }

    public function verificaCategoria($GrupoAulaID) {

   	    $selectExpression = "select  e088.Descricao
                                 , e088.CategoriaAulaID as CategoriaID
                                 , e094.Ordem as OrdemCategoria
                            from E088_CategoriasAulas e088
                            inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                            where e094.GrupoAulaID = ". $GrupoAulaID ."
                            and e094.Ordem is not null 
                            order by e094.Ordem ASC";

   	    // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
    	return $result->result_array();
    }

    public function verificaDisciplinas($GrupoAulaID = null, $CategoriaID = null) {

        $return = '';
        if ($GrupoAulaID) {

            $Categoria = '';
            if ($CategoriaID) {
                $Categoria = " and e088.CategoriaAulaID = '$CategoriaID' ";
            }

            $select_expression = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                        , e089.Descricao
                                         , e094.GrupoAulaID
                                         , e089.SubCategoriaAulaID as DisciplinaID
                                         , e089.DtInicio
                                         , e088.CategoriaAulaID as CategoriaID
                                         , '' as TemMensagem
                                         , e090.Ordem as OrdemDisciplina
                                    from E089_SubCategoriasAulas e089
                                    inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                    inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                    inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                    where e094.GrupoAulaID = ". $GrupoAulaID ."
                                      ". $Categoria ."
                                      and e089.Descricao != ''
                                    and (e089.Situacao is null or e089.Situacao = 'A')
                                    order by e090.Ordem ASC";

            // TODO: FDD-429 - UNSAFE QUERY
            $result = $this->getAvaMySQL()->query($select_expression);
            $return = $result->result_array();

            $selectExpression = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                        , e089.Descricao
                                         , e094.GrupoAulaID
                                         , e089.SubCategoriaAulaID as DisciplinaID
                                         , e089.DtInicio
                                         , e088.CategoriaAulaID as CategoriaID
                                         , '' as TemMensagem
                                         , e090.Ordem as OrdemDisciplina
                                    from E089_SubCategoriasAulas e089
                                    inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                    inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                    inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                    where e094.GrupoAulaID = ". $GrupoAulaID ."
                                      ". $Categoria ."
                                      and e089.Descricao != ''
                                    and (e089.Situacao is null or e089.Situacao = 'A')
                                    order by e090.Ordem ASC";

            // TODO: FDD-429 - UNSAFE QUERY
            $query = $this->getAvaMySQL()->query($selectExpression);
            $discOrdem = $query->result_array();

            if ($discOrdem) {
                $return = array_merge($discOrdem, $return);
            }
        }

        return $return;
    }

    public function getDisciplinas($GrupoAulaID, $DisciplinaID) {

        $select_expression = "select  e089.Descricao
                                     , e094.GrupoAulaID
                                     , e089.SubCategoriaAulaID as DisciplinaID
                                     , e089.DtInicio
                                     , e088.CategoriaAulaID as CategoriaID
                                from E089_SubCategoriasAulas e089
                                inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                where e094.GrupoAulaID = ". $GrupoAulaID ."
                                  and e089.SubCategoriaAulaID = ". $DisciplinaID ."
                                  and e089.Descricao != ''                                
                                  and (e089.Situacao is null or e089.Situacao = 'A') 
                                order by e089.Descricao ASC";
        // TODO: FDD-429 - UNSAFE QUERY
      $query = $this->getAvaMySQL()->query($select_expression);
      return $query->result_array();
    }

    function buscaDadosAulas($disciplinaid,$tipo = null,$ordem = null, $prep = null){

    	$sql = '';
    	$sqlTipo = '';

    	if($tipo){
    		$sqlTipo = " and e068.Tipo = '".$tipo."' ";
    	}

    	if($ordem){
    		$sql = " Order by ABS(e091.Ordem) " . $ordem ." ";
    	}

    	if(!$prep)
        {
            $retsql = " case when e068.Tipo = 'N' then e089.Descricao else e068.Tema end as Tema ";
        }
        else
        {
            $retsql = " e068.Tema ";
        }

    	$select = "select  e068.AulaID
                         , e091.SubCategoriaID as DisciplinaID
                         , ". $retsql ."
                         , LPAD(e091.Ordem,4,0) as Ordem
                         , e068.Video
                         , e068.Duracao
                         , e068.DtCad
                         , e068.Tipo
                         , concat(LPAD(e091.SubCategoriaID,7,0),LPAD(e068.AulaID,7,0)) as itemName
                         
                    from E068_Aulas e068
                    inner join E091_AulasSubCategorias e091 on e091.AulaId = e068.AulaID
                    inner join E089_SubCategoriasAulas e089 on e089.SubCategoriaAulaID = e091.SubCategoriaID
                    where e091.SubCategoriaID = ". $disciplinaid ."
                    ". $sqlTipo ."
                    and (e068.Situacao is null or e068.Situacao = 'A') 
                    And Case When e068.Tipo = 'N' Then (e068.Video Is Not Null Or e068.Video <> '') 
                    Else (e068.Video Is Null Or e068.Video = '') End ". $sql;
    	// TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($select);
        return $query->result_array();
    }

    function buscaQuestoesAluno($id, $grupoAula, $aula = null, $respondida = false, $vista = false, $tipo = null, $respostaCorreta = false, $assunto = null) {

    	$sql = '';

    	if ($respondida) {
    		$sql .= " and RespostaCorreta is not null ";
    	}

    	if ($respostaCorreta) {
    		$sql .= " and RespostaCorreta = 'S'";
    	}

    	if ($vista) {
    		$sql .= " and VideoAulaAssistida = 'S' ";
    	}

    	if ($tipo) {
    		$sql .= " and Tipo = '$tipo'";
    	}

    	if ($aula) {
    		$sql .= " and AulaID = '$aula' ";
    	}

    	if ($assunto) {
    		$sql .= " and AssuntoID = '$assunto' ";
    	}

    	$selectExpression = "select RespostaQuestaoID,UsuarioID,QuestaoID,Resposta,RespostaCorreta,
            TurmaID,EscolaID,NomeEscola,DescTurma,AulaID,AssuntoID,DisciplinaID,SerieID,DescSerie,VigenciaTurma,TotalQuestoesAula,
            DescAssunto,FrenteID,DescFrente,Tipo,Meta,DescAula,Gabarito,DescDisciplina,DtCad,
            DtAlt,DtConclusao,VideoAulaAssistida,DtAgendaInicio,DtAgendaFim,NomeAluno,TipoQuestaoID,Situacao 
        from R001_RespostasQuestoes where Situacao = 'A' and UsuarioID = '$id' and DisciplinaID = $grupoAula " . $sql;
    	// TODO: FDD-429 - UNSAFE QUERY
    	$query = $this->getAvaMySQL()->query($selectExpression);

    	return $query->result();
    }

    function buscaQuestoesAula($aula,$GrupoAulaID){
        $select_questoes = "select e359.QuestaoID
                                 , e359.Similar
                                 , e359.GrupoSimilar
                                 , e359.JarvisItemId
                            from E359_AulaQuestoes e359
                            inner join E358_EstruturaAulasQuestoes e358 on e358.EstruturaAulaID = e359.EstruturaAulaID
                            where e358.AulaID = ". $aula ."
                              and e358.GrupoAulaID = ". $GrupoAulaID.' order by e359.GrupoSimilar';

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($select_questoes);
        return $query->result_array();
    }

    /**
     * @param $escola
     * @param $disciplina
     * @param $frente
     * @param $assunto
     * @param $turma
     * @param string $aluno
     * @param int|false $tipoAgendamento
     * @return mixed
     */
    function getAgendamento($escola, $disciplina, $frente, $assunto, $turma, $aluno = '', $tipoAgendamento = false) {

        $strAluno = 'AND AlunoID IS NULL';
        if (!empty($aluno)) {
            $strAluno = "AND (AlunoID IS NULL OR AlunoID = '{$aluno}')";
        }

        $tipoAgendamentoStr = '';
        if ($tipoAgendamento) {
            $tipoAgendamentoStr = "AND tipo_agendamento = {$tipoAgendamento}";
        }

    	$selectExpression = "
            SELECT ItemName, 
                   EscolaID, 
                   DisciplinaID, 
                   FrenteID, 
                   AssuntoID, 
                   DtInicio, 
                   DtFim, 
                   AlunoID, 
                   DtCad
            FROM D024_Ava_Sae_Agenda
            WHERE EscolaID = '{$escola}' 
                AND DisciplinaID = '{$disciplina}' 
                AND FrenteID = '{$frente}'
				AND DtCad IS NOT NULL
                AND AssuntoID = {$assunto} 
                AND TurmaID = '{$turma}'
                {$strAluno}
                {$tipoAgendamentoStr}
                order by DtCad DESC limit 1";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($selectExpression);
        return $query->result_array();

    }

    public function questoesReforco($params, $GrupoAulaID) {

    	$disciplinaID =  $params[0]['DisciplinaID'];
    	// tratamento para as questões similares:
    	$select_questoes = "select e359.QuestaoID
                                 , e359.Similar
                                 , e359.GrupoSimilar
                            from E359_AulaQuestoes e359
                            inner join E358_EstruturaAulasQuestoes e358 on e358.EstruturaAulaID = e359.EstruturaAulaID
                            where e358.SubCategoriaID = ". $disciplinaID ."
                              and e359.is_parent = 0
                              and e358.GrupoAulaID = {$GrupoAulaID}
                            GROUP BY e359.EstruturaAulaID, e359.GrupoSimilar
                            ORDER BY RAND();";
    	// TODO: FDD-429 - UNSAFE QUERY

        $query = $this->getAvaMySQL()->query($select_questoes);
        $questoesSDB = $query->result_array();

    	if (!empty($questoesSDB)) {
            // format response questões com a questãoid como chave array
            foreach ($questoesSDB as $key => $value) {
                $questoesSDBFormat[$value['QuestaoID']] = $value;
            }

            for ($i = 0; count($params) > $i; $i++) {
                if ($params[$i]['Tipo'] === 'R' || $params[$i]['Tipo'] === 'Q') {
                    $result = $this->buscaQuestoesAluno($this->session->userdata('pessoaid'), $GrupoAulaID);
                    if (count($result) >= 1) {
                        foreach ($result as $key => $value) {
                            if (!is_null($value->Resposta)) {
                                // remove questões reservadas que foram respondidas
                                unset($questoesSDBFormat[$result[$key]->QuestaoID]);
                            }
                        }
                    }
                }
            }
    	} else {
            return false;
    	}

    	return array_values($questoesSDBFormat);
    }

    public function getMetaAluno($usuarioid, $assuntoid){
        $this->getAvaMySQL()->select('Meta');
        $this->getAvaMySQL()->where('UsuarioID', $usuarioid);
        $this->getAvaMySQL()->where('AssuntoID', $assuntoid);
        $this->getAvaMySQL()->where('Tipo', "N");
        $query = $this->getAvaMySQL()->get('R001_RespostasQuestoes');
        return $query->row('Meta');
    }
}
