<?php

class Livrodigital_model extends MY_Model {

    function __construct() {
        parent::__construct();

    }

    function buscaDispositivos($usuario){
        $selectExpression = "select * from D030_Ava_Sae_LD_Dispositivo where Usuario = '". $usuario. "' and (Situacao is null or Situacao = 'A') and Servico = '1'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function excluiDispositivo($dados, $id){
        $this->getAvaMySQL()->where('itemName',$id);
        return $this->getAvaMySQL()->update('D030_Ava_Sae_LD_Dispositivo',$dados);
       
    }
}
