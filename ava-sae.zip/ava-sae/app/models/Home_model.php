<?php

use Ava\App\Support\ClassificacaoConteudo;
use Ava\App\Support\Situacao;

class Home_model extends MY_Model {

    function __construct() {
        parent::__construct();
    }

    /**
     * Verifica Programa da Semana
     *
     * Consulta no dominio do simpleDB da Amazon o iframe do v?deo.
     *
     * @access	public
     * @return	string  iframe do v?deo
     */
    public function verificaProgramadaSemana() {

        $selectExpression = "select id,ProgSemana from D000_Configuracoes where Subdominio = '" .HOST. "'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //return $this->simpledb->selectsItems($selectExpression);

    }

    /**
     * Verifica Not?cias
     *
     * Verifica no simpleDB da Amazon se existe dados cadastrados, caso exista retorna um array formatado.
     *
     * @access	public
     * @return	array           com conte?do ou vazio
     */
    public function verificaNoticias() {

        $selectExpression = "select Conteudo, Data, Link, Titulo  from D002_Noticias limit 3";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //return $this->simpledb->selectsItems($selectExpression);
    }

    /**
     * Verifica Pacotes
     *
     * Recebe os par?metros dos usu?rio campos e base, verifica no simpleDB
     * da Amazon se existe dados correspondentes, caso exista retorna um array formatado, caso n?o retorna vazio.
     *
     * @access	public
     * @param	array           array com dados dos usu?rios enviado atrav?s do controller.
     * @param	string		contento nome do dominio
     * @return	array           com conte?do / vazio
     */
    public function verificaPacotes($fields = null, $Base = 'Aprovaconcursos', $assinaturaSiteID = null) {
        $selectExpression = "select * from D019_Ava_Sae where id = '".$fields['id']."'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function verificaDisciplinas($fields = null, $Base = 'Aprovaconcursos',$situacao = null) {

    	$sql = '';
    	if ($situacao) {
    		$sql .= " and Situacao = '" . $situacao . "'  ";
    	}

    	if($this->session->has_userdata('perfil')){
    		$sql .= " and Perfil = '" . $this->session->userdata('perfil') . "'  ";
    	}

    	$selectExpression = "select itemName,id, DescricaoTurma, DescricaoSerie, Turma, VigenciaTurma, Serie, Categoria, DescricaoCategoria, TO_BASE64(CONCAT(Login, ':', Senha)) as AppQrcode from D019_Ava_Sae where Login = '".utf8_encode($fields['Login'])."'" . $sql;
    	// TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

	/**
     * Verifica Grupo Aula
     *
     * Recebe par?metros do pacote do usu?rio, verifica no simpleDB
     * da Amazon se existe dados correspondentes, caso exista retorna um array formatado, caso n?o retorna vazio.
     *
     * @access	public
     * @param	int           grupoAulaID do pacote enviado atrav?s do controller.
     * @return	array         com conte?do / vazio
     */
	public function verificaGrupoAula($serieID, $dtInicio = null) {

		$dtInicio = $dtInicio ? $dtInicio : date('Y');

		$sql = '';
		if($this->session->userdata('perfil') == PERFIL_ALUNO){
			$sql = " and ClassificacaoID in ('10','11')";
		}

		$selectExpression = "select e093.Controller
                                 , e093.QtdPacotesSimultaneos
                                 , e093.ClassificacaoID
                                 , e093.DtInicio
                                 , e093.DtFim
                                 , e093.Ancora
                                 , e093.TipoPDF
                                 , e093.Descricao
                                 , e093.Duracao
                                 , e093.Valor
                                 , e093.DtInicioAssinatura
                                 , e093.GrupoAulaID as itemName
                            from E093_GruposAulas e093
                            where e093.SerieID = '". $serieID ."'
                            and e093.DtInicio like '%". $dtInicio ."%'
                            and (e093.Situacao is null or e093.Situacao = 'A')
                            and ClassificacaoID in (10,11) ". $sql;
		// TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
	}

	public function verificaGrupoAulaProf($disciplina) {

		$selectExpression = "select e093.*
										from E093_GruposAulas e093
										where e093.GrupoAulaID = '".$disciplina."'";
		// TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
	}

    public function pegaDisciplinaArrayIds($ids) {
        if($ids) {
            $selectExpression = "SELECT * FROM E093_GruposAulas WHERE GrupoAulaID IN (" . implode(",", $ids) . ")";
            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
        } else {
            return [];
        }
    }

	public function verificaGrupoAulaAncora($ancora) {
            if (is_numeric($ancora)) {
                $tipo = 'e093.GrupoAulaID';
            } else {
                $tipo = 'e093.Ancora';
            }
            $selectExpression = "select e093.GrupoAulaID as itemName, e093.* from E093_GruposAulas e093 where $tipo = '".$ancora."'";
            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
	}

	public function verificaPacotesAluno($fields = null, $Base = 'Aprovaconcursos', $assinaturaSiteID = null) {

		$sql = '';
		$condicao = '';

		if (isset($fields['Ancora']) && !empty($fields['Ancora'])) {
			$condicao = "and Ancora = '" . $fields['Ancora'] . "'  ";
		}

		if (isset($fields['AssinaturaMatriculaID']) && !empty($fields['AssinaturaMatriculaID'])) {
			$condicao .= " and id =  '" . $fields['AssinaturaMatriculaID'] . "'";
		}

		if($Base == 'Parceiros'){
			$sql = " and AssinaturaSiteID = '".$assinaturaSiteID."'" ;
		}

		if (isset($fields['Ancora']) || isset($fields['AssinaturaMatriculaID']) || isset($fields['matriculaID']))
		{
			$selectExpression = "select Rec, MatriculaID, DtFim, BoletoID, DtInicio, GrupoAulaID, DescricaoPacote, Ancora,
					Situacao, ValorPacote, DuracaoPacote, QtdAcessosSimultaneos, DiasAcesso, AssinaturaSistemaID,
					ValorPago, ContratoID, CompraRecorrente
					from D003_PacotesAluno_Aprovaconcursos
					where
					Situacao = 'A'
					and MatriculaID = '" . $fields['matriculaID'] . "' $condicao". $sql;

			// TODO: FDD-429 - UNSAFE QUERY
            $result = $this->getAvaMySQL()->query($selectExpression);
            return $result->result_array();
		}
        return '';
	}

	public function verificaTurmas($id = null,$escolaid = null) {

		$sql = '';

		if($escolaid){
			$sql .= " and EscolaID = '".$escolaid."'";
		}

        $selectExpression = "select * from D021_Ava_Sae_Turmas where itemName in ('" . $id . "') AND (Vigencia = 2020 OR Vigencia = 2021)  AND Situacao = 'A'" . $sql;
		// TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();

	}

    public function RetornaSerieTurma($turmaID)
    {
        $selectExpression = "SELECT SerieID, DescricaoSerie FROM D021_Ava_Sae_Turmas WHERE itemName IN ('" . $turmaID . "') AND Situacao = 'A'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();

    }

    public function verificaCategoriaTurmas($categorias) {
        $selectExpression = "select * from D021_Ava_Sae_Turmas where CategoriaTurmaID in ('".$categorias."') AND Situacao = 'A'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();

	}

	public function verificaDisciplinasUsuario($turma , $situacao = null) {
        $sql = '';

        $perfilID = $this->session->userdata('perfil');

        if ($perfilID != 271) {
            $sql = "and Login = '" . $this->session->userdata('login') . "'";
        }
        if ($situacao) {
            $sql .= " and Situacao = '$situacao'";
        }

        $selectExpression = "select Disciplina from D019_Ava_Sae where Perfil = '272' and Turma = '".$turma."'" . $sql;
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
	}

	public function verificaDisciplinaVigencia($disciplinas = null, $dtInicio = null,$serieid = null, $classificacaoId = null) {

        $dtInicio = $dtInicio ? $dtInicio : date('Y');
        
        $strVigencia = "and e093.DtInicio like '%".$dtInicio."%'";


        if($dtInicio == '2021') {
            $strVigencia = "and (e093.DtInicio like '%2020%' OR e093.DtInicio like '%2021%' )";
        }

		$sql = "and e093.Situacao != 'I'";

		if(!empty($disciplinas)){
			$sql .= " and e093.GrupoAulaID in ('".$disciplinas."')";
		}

		if(!empty($serieid)){
			$sql .= " and e093.SerieID = '".$serieid."'";
		}

		if ($classificacaoId) {
		    $sql .= " AND e093.ClassificacaoID = '{$classificacaoId}'";
        }

		$selectExpression = "select e093.GrupoAulaID as itemName,e093.Controller, e093.QtdPacotesSimultaneos, e093.ClassificacaoID, e093.DtInicio, e093.DtFim ,e093.Ancora,
		                                      e093.TipoPDF, e093.Descricao, e093.Duracao, e093.Valor, e093.DtInicioAssinatura, e093.SerieID
										from E093_GruposAulas e093
										where e093.ClassificacaoID is not null {$strVigencia} and (e093.AvaSaeDisciplinaEspecifica = 'N' or e093.AvaSaeDisciplinaEspecifica is null) " .$sql ." order by e093.ClassificacaoID ASC";

		// TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
	}

    public function verificaProfessor($turma, $disciplina)
    {
        $sql = '';
        $sqlDisciplina = '';

        $perfilID = trim($this->session->userdata('perfil'));

        if (($perfilID != '271') && ($perfilID != '270')) {
            $sql = "and Login = '" . $this->session->userdata('login') . "'";
        }
        if (!empty($disciplina)) {
            $sqlDisciplina = "and Disciplina = '" . $disciplina . "'";
        }

        $selectExpression = "select Nome, DescricaoDisciplina, Disciplina from D019_Ava_Sae where Perfil = '272' and Situacao = 'A' and Turma = '" . $turma . "'" . $sql . " " . $sqlDisciplina;

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();

    }

    public function buscaLogo($escolaid)
    {
        $this->getAvaMySQL()->select("Logo");
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->where('itemName', $escolaid);
        $query = $this->getAvaMySQL()->get();
        return $query->result_array()[0];
    }

    public function verificaPacotesBoxVerde($serieid)
    {
        $versaoConteudo = $this->session->userdata('versao_conteudo_id');
        $selectExpression = "SELECT
                  e093.GrupoAulaID AS itemName,
                  e093.*
                FROM  E093_GruposAulas e093
                INNER JOIN  T002_SeriesDisciplinas t002 on t002.DisciplinaID = e093.GrupoAulaID
                WHERE t002.versao_conteudo_id = {$versaoConteudo}
                AND t002.SerieID = {$serieid}
                AND e093.ClassificacaoID = '12'
                AND (e093.SerieID NOT LIKE '%|{$serieid}|%')
                AND e093.Situacao = 'A'
                UNION ALL
                SELECT
                  e093.GrupoAulaID AS itemName,
                  e093.*
                FROM E093_GruposAulas e093
                WHERE e093.ClassificacaoID = '12' AND (e093.SerieID LIKE '%|{$serieid}|%') AND
                      (e093.AvaSaeDisciplinaEspecifica IS NULL OR e093.AvaSaeDisciplinaEspecifica = 'N') AND e093.Situacao = 'A'";


        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function getDisciplinasExclusivas($escolaid, $serieid, $classificacao = null)
    {
        $sql = '';
        if ($classificacao) {
            $sql .= " and ClassificacaoID = '$classificacao'";
        } else {
            $sql .= " and ClassificacaoID != '12'";
        }
        $selectExpression = "select DisciplinaID from D034_Ava_Sae_DisciplinasExclusivas where SerieID = '$serieid' and EscolaID = '$escolaid' and Situacao = 'A' " . $sql;
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function buscaDisciplinasExclusivas($disciplinaid)
    {
        $selectExpression = "select e093.GrupoAulaID as itemName, e093.* from E093_GruposAulas e093 where e093.GrupoAulaID = '$disciplinaid'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getAgendamentosTurma($turmaid)
    {

        $ano = Date('Y');
        $turmaid = str_replace(",", "", $turmaid);
        $selectExpression = "select DisciplinaID, AssuntoID, DtFim from D024_Ava_Sae_Agenda where (YEAR(DtCad) = 2020 OR YEAR(DtCad) = 2021) and TurmaID = '$turmaid' and DtInicio <= '" . date('Y-m-d') . "' and DtInicio != '-' and DtFim  is not null order by DtFim Desc";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getDescricaoDisciplina($disciplinaid)
    {
        $selectExpression = "select e093.Descricao, e093.Ancora, e093.Controller, e093.ClassificacaoID from E093_GruposAulas e093 where e093.GrupoAulaID = '$disciplinaid' and e093.Situacao = 'A'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    /**
     * @param int $serieid
     *
     * @return array
     */
    function getDisciplinasPermanentes($serieid)
    {
        $situacao = Situacao::ATIVO;
        $classificacao = ClassificacaoConteudo::ARRASE_ENEM;
        $versaoConteudo = $this->session->userdata('versao_conteudo_id');
        $selectExpression = "
            SELECT 
                disciplina.GrupoAulaID AS id, disciplina.*
            FROM
                E093_GruposAulas disciplina
                    INNER JOIN 
                      T002_SeriesDisciplinas disciplina_serie ON disciplina.GrupoAulaID = disciplina_serie.DisciplinaID
                        AND (
                          disciplina.SerieID = disciplina_serie.SerieID
			                OR FIND_IN_SET(disciplina_serie.SerieID, TRIM(BOTH ',' FROM REPLACE(disciplina.SerieID, '|', ','))) > 0
                        )
                        AND disciplina_serie.versao_conteudo_id = {$versaoConteudo}
                    INNER JOIN 
                      T001_Series serie ON disciplina_serie.SerieID = serie.SerieID AND serie.versao_conteudo_id = {$versaoConteudo}
            WHERE
                disciplina.ClassificacaoID = {$classificacao}
                    AND serie.SerieID = {$serieid}
                    AND disciplina.Situacao = '{$situacao}'
                    AND (disciplina.AvaSaeDisciplinaEspecifica IS NULL
                    OR disciplina.AvaSaeDisciplinaEspecifica = 'N');";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);

        return $result->result_array();
    }

    public function getTurmasSeriesPorLogin($login){
        $this->getAvaMySQL()->select('Turma, DescricaoTurma, SerieID');
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->join('D021_Ava_Sae_Turmas',
            'D019_Ava_Sae.Turma = D021_Ava_Sae_Turmas.itemName'
        );
        $this->getAvaMySQL()->where('Login', $login);
        $this->getAvaMySQL()->where('D021_Ava_Sae_Turmas.Situacao', 'A');
        $this->getAvaMySQL()->group_by('Turma');
        $query = $this->getAvaMySQL()->get();
        return $query->result();

    }
}
