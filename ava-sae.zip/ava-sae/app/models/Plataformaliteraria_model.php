<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Plataformaliteraria_model extends MY_Model
{

    function __construct()
    {
        parent::__construct();

        $this->pessoaid = $this->session->userdata('pessoaid');
    }

    //TODO: Passar funcoes de tela para plataforma literaria lib (funcoes comuns)
    function getInfoAulaPlataformaLiteraria($array)
    {
        $turmaid = $array['TurmaID'];
        $usuarioid = $array['UsuarioID'];
        $grupoaulaid = $array['GrupoAulaID'];
        $disciplinaid = $array['DisciplinaID'];
        $aula = new stdClass();
        $aula->ancora = $array['ancora'];
        $aula->GrupoAulaID = $grupoaulaid;
        $aula->UsuarioID = $usuarioid;
        $aula->DisciplinaID = $array["info"]['DisciplinaID'];
        $aula->DtInicio = $array["info"]['DtInicio'];
        $aula->DtFim = $array["info"]['DtFim'];
        $aula->AulaID = $array["aulas"][0]['AulaID'];
        $aula->Tema = $array["aulas"][0]['Tema'];
        $aula->Ordem = $array["aulas"][0]['Ordem'];
        $aula->Duracao = $array["aulas"][0]['Duracao'];
        $aula->Tipo = $array["aulas"][0]['Tipo'];
        $aula->TurmaID = $turmaid;

        if ($aula->Tipo == 'N') {
            $aula->PercentualVideo = 0;
            $videoAulaInfo = $this->getVideoAula($aula->UsuarioID, $aula->AulaID, $aula->DisciplinaID);
            if($videoAulaInfo->year === (new DateTime)->format("Y")){
                $aula->PercentualVideo = isset($videoAulaInfo->PercentualVideo) ? $videoAulaInfo->PercentualVideo : 0;
            }
            $aula->TempoTotalVideos = $array["info"]['TempoTotalVideos'];
            $aula->QtdVideosAssistidos = $array["info"]['QtdVideosAssistidos'];
            $aula->QtdVideos = $array["info"]['QtdVideos'];
            $aula->Video = $array["aulas"][0]['Video'];

        }
        elseif($aula->Tipo == 'Q'){
            $aula->QtdQuestoes = $array["aulas"][0]['QtdQuestoes'];
            $aula->QtdQuestoesRespondidas = $array["aulas"][0]['QtdQuestoesRespondidas'];
            $aula->QtdRespostaCorretas = $array["aulas"][0]['QtdRespostaCorretas'];
        }
        elseif($aula->Tipo == 'D'){
            $aula->QuestoesDiscursivas = $array["aulas"][0]['questoes-discursivas'];
            $aula->QtdeTotalQuestoesDiscursivas = $array["info"]['totalQuestoesDiscursivas'];
            $aula->QtdeRespondidaQuestoesDiscursivas = $this->getTotalRespondidoQuestaoDiscursiva($turmaid, $usuarioid, $grupoaulaid, $disciplinaid);
        }
        return $aula;
    }

    function getHtmlDetalhesAula($aula)
    {
        if ($aula->Tipo == 'Q')
            return $this->getHtmlQuestao($aula);
        elseif ($aula->Tipo == 'N')
            return $this->getHtmlVideo($aula);
        elseif ($aula->Tipo == 'D')
            return $this->getHtmlQuestoesDiscursivas($aula);
    }

    function getHtmlQuestao($aula)
    {
        $SequenciaI = 1;

        $url = base_url().'curso/'.$aula->ancora.'/'.encodeString($aula->Tema).'/'.str_pad($aula->DisciplinaID, 7, '0', 0)
            .str_pad($aula->AulaID, 7, '0', 0).'/'.$SequenciaI .'?questao=true';
        $html = '<li class="etapa">
                    <a href="'.$url.'"  title="'.$aula->Tema.'" class="aula">
                        <input type="hidden" class="type-content" value="question">
                        <input type="hidden" class="question-total" value="'.$aula->QtdQuestoes.'">
                        <input type="hidden" class="question-answered" value="'.$aula->QtdQuestoesRespondidas.'">
                        <div class="charts">
                            <span class="ct-chart percentage question"></span>
                        </div>
                        <div class="labels">
                            <span>Questões</span>
                        </div>
                    </div>
                </li>';
        return $html;
    }

    function getHtmlVideo($aula)
    {
        $SequenciaI = 1;
        $url = base_url().'curso/'.$aula->ancora.'/'.encodeString($aula->Tema).'/'.str_pad($aula->DisciplinaID, 7, '0', 0)
            .str_pad($aula->AulaID, 7, '0', 0).'/'.$SequenciaI;

        $html = '<li class="etapa">
                    <a href="'.$url.'"  title="'.$aula->Tema.'" class="aula">
                        <input type="hidden" class="type-content" value="video">
                        <input type="hidden" class="video-percentage" value="'.$aula->PercentualVideo.'">
                        <div class="charts">
                            <span class="ct-chart percentage video"></span>
                            <svg class="play-button-svg" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5 3L19 12L5 21V3Z" stroke="#2E48CD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </div>
                        <div class="labels">
                            <span>Vídeo</span>
                            <span>'.$aula->Duracao.'</span>
                        </div>
                    </div>
                </li>';
        return $html;
    }

    function getHtmlQuestoesDiscursivas($aula){
        $url = base_url().'curso-plataforma-literaria/questoes_discursivas_aluno/'.$aula->AulaID.'/'.$aula->GrupoAulaID.'/'.$aula->DisciplinaID;
        $html = '<li class="etapa">
                    <a href="'.$url.'"  title="'.$aula->Tema.'" class="aula">
                        <input type="hidden" class="type-content" value="discursive">
                        <input type="hidden" class="question-total" value="'.$aula->QtdeTotalQuestoesDiscursivas.'">
                        <input type="hidden" class="question-answered" value="'.$aula->QtdeRespondidaQuestoesDiscursivas.'">
                        <div class="charts">
                            <span class="ct-chart percentage discursive"></span>
                        </div>
                        <div class="labels">
                            <span>Questões</span>
                        </div>
                    </div>
                </li>';
        return $html;
    }

    function getVideoAula($usuario_id, $aula_id, $assuntoid)
    {
        $this->getAvaMySQL()->select('RespostaQuestaoID, PercentualVideo, InicioVideo, FimVideo, VideoAulaAssistida, Year(DtAlt) as year');
        $this->getAvaMySQL()->where('AssuntoID', $assuntoid);
        $this->getAvaMySQL()->where('AulaID', $aula_id);
        $this->getAvaMySQL()->where('UsuarioID', $usuario_id);
        $this->getAvaMySQL()->where('Tipo', 'N');
        $this->getAvaMySQL()->where('Situacao', 'A');
        $query = $this->getAvaMySQL()->get('R001_RespostasQuestoes');
        return $query->row();
    }

    //FIXME: Funcoes do Relatorio
    function getTurmaAgendamentoAula($turmaid, $disciplinaid, $frenteid=null, $assuntoid=null){
         
        
        $sql = "SELECT                     
                d024.DtInicio, d024.DtFim, d024.FrenteID, d024.DisciplinaID, d024.AssuntoID
                FROM D024_Ava_Sae_Agenda d024

                WHERE d024.TurmaID = '" . $turmaid . "' AND d024.DisciplinaID = '" . $disciplinaid . "'";
                

        // if($frenteid)
        //     $sql .= "AND d024.FrenteID = '" . $frenteid . "'";
        if ($assuntoid){
            $sql .= "AND d024.AssuntoID = '" . $assuntoid . "'";
        }

        $query = $this->getAvaMySQL()->query($sql);

        return $query->result();
    }

    function getTurmasProfessorPorLogin($login, $turmaid = false, $plataforma = false)
    {
        $this->getAvaMySQL()->from('D019_Ava_Sae');
        $this->getAvaMySQL()->join('D021_Ava_Sae_Turmas', 'D019_Ava_Sae.Turma = D021_Ava_Sae_Turmas.itemName');
        if (!$turmaid && $plataforma) {
            $this->getAvaMySQL()->join('E093_GruposAulas', 'D019_Ava_Sae.Disciplina = E093_GruposAulas.GrupoAulaID');
            $this->getAvaMySQL()->like('E093_GruposAulas.Descricao', 'Plataforma');
        }
        $this->getAvaMySQL()->where('D019_Ava_Sae.Login', $login);
        $this->getAvaMySQL()->where('D019_Ava_Sae.Perfil <>', PERFIL_RESPONSAVEL);
        $this->getAvaMySQL()->where('D019_Ava_Sae.Situacao', 'A');
        if ($turmaid && !$plataforma) {
            $this->getAvaMySQL()->where('D019_Ava_Sae.Turma', $turmaid);
        }

        return $this->getAvaMySQL()->group_by('D019_Ava_Sae.Turma')->get()->result();
    }

    function getSerieTurmaPorLogin($login, $turmaid=null){
        $sql = "select 
                        d021.SerieID, d019.Turma, d019.itemName, d019.versao_conteudo_id
                    from D019_Ava_Sae d019, D021_Ava_Sae_Turmas d021
                        where d019.Turma = d021.itemName and d019.Situacao = 'A'
                        and d019.Login = '".$login."'";
        if ($turmaid)
            $sql .=  " and d019.Turma = '".$turmaid."'";

        $sql .= " group by d019.Turma";
        $query = $this->getAvaMySQL()->query($sql);
        $result = $query->result();
        return $result;
    }

    function getTotalQuestoes($grupoaulaid, $subcategoriaid){
        $sql = 'select count(QuestaoID) as TotalQuestoes
                    from E359_AulaQuestoes
                    where EstruturaAulaID in (select EstruturaAulaID
                                                from 
                                                  E358_EstruturaAulasQuestoes 
                                                where GrupoAulaID = '.$grupoaulaid.' 
                                                and SubCategoriaID = '.$subcategoriaid.')
                    and Situacao = "A"
                    group by EstruturaAulaID';
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getTotalRespondidoQuestaoDiscursiva($turmaid, $alunoid, $grupoaulaid, $disciplinaid){
        $respostas = $this->getRespostasDiscursivasPorAssunto($turmaid, $alunoid, $grupoaulaid, $disciplinaid, null);
        $total = 0;
        foreach ($respostas as $resposta) {
            if($resposta->Resposta != '')
                $total += 1;
        }
        return $total;
    }

    function getNotaTotalQuestaoDiscursiva($turmaid, $alunoid, $grupoaulaid, $disciplinaid)
    {
        $respostas = $this->getRespostasDiscursivasPorAssunto($turmaid, $alunoid, $grupoaulaid, $disciplinaid, null);
        $notaTotal = 0;

        foreach ($respostas as $resposta) {
            if (!is_null($resposta->Nota)) {
                $notaTotal += $resposta->Nota;
            }
        }

        return $notaTotal;
    }

    function getTotalQuestoesDiscursivas($aulaid, $grupoaulaid, $disciplinaid){
        $discursivas = $this->getQuestoesDiscursivas($grupoaulaid, $aulaid,$disciplinaid);
        return count($discursivas);
    }

    function getRespostaAlunoQuestoes($usuarioid, $grupoaulaid, $categoriaid){
        $sql = "select 
                        r01.AulaID, 
                        r01.FrenteID as CategoriaAulaID,
                        r01.DisciplinaID as GrupoAulaID,
                        r01.TotalQuestoesAula,
                        sum(case when r01.RespostaCorreta='S' then 1 else  0 end) as QtdeAcertos,
                        sum(case when r01.RespostaCorreta='N' then 1 else  0 end) as QtdeErradas,
                        count(r01.RespostaCorreta) as TotalRespondido,
                        r01.DescAula,
                        r01.DescAssunto,
                        r01.PercentualVideo,
                        r01.Meta,
                        r01.DtAgendaFim,
                        r01.DtAgendaInicio                       
                    from 
                        R001_RespostasQuestoes r01	
                    where
                        r01.Situacao = 'A'
                        and r01.UsuarioID = '".$usuarioid."'
                        and r01.FrenteID = ".$categoriaid."
                        and r01.DisciplinaID = ".$grupoaulaid."	                      
                    group by r01.AulaID";
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getAssuntosPlataformaLiterariaPorLoginSerie($itemname, $serieid){
        $sql = "select e88.Descricao, e93.GrupoAulaID, e88.CategoriaAulaID, e68.AulaID, e90.Ordem
                from
                    E068_Aulas e68
                    inner join E091_AulasSubCategorias e91 on e68.AulaID = e91.AulaId
                    inner join E090_CategoriasSubCategoriasAulas e90 on e91.SubCategoriaID = e90.SubCategoriaID
                    inner join E088_CategoriasAulas e88 on e90.CategoriaID = e88.CategoriaAulaID
                    inner join E094_GruposCategoriasAulas e94 on e88.CategoriaAulaID = e94.CategoriaAulaID
                    inner join E093_GruposAulas e93 on e94.GrupoAulaID = e93.GrupoAulaID
                    inner join D024_Ava_Sae_Agenda d24 on e93.GrupoAulaID = d24.disciplinaid
                    inner join D019_Ava_Sae d19 on d19.turma = d24.turmaid
                where e93.ClassificacaoID = 11
                    and e93.Situacao = 'A'
                    and d19.ItemName = '".$itemname."'                       
                    and (e93.SerieID = '".$serieid."' or e93.SerieID LIKE '%|".$serieid."|%')
                    and (e93.AvaSaeDisciplinaEspecifica is null or e93.AvaSaeDisciplinaEspecifica = 'N')                        					
                group by e88.Descricao, e93.Descricao
                order by e90.Ordem ASC";
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();

    }


    function getAulaAssuntoPlataformaLiteraria($grupoaulaid, $categoriaid){
        $sql = "select 
                        e68.AulaID, e93.GrupoAulaID, e88.CategoriaAulaID, e90.SubCategoriaID, e68.Duracao, e68.Tipo, 
                        e68.Tema, e90.Ordem, e88.Descricao 
                    from
                        E068_Aulas e68,
                        E090_CategoriasSubCategoriasAulas e90,
                        E091_AulasSubCategorias e91,
                        E088_CategoriasAulas e88,
                        E094_GruposCategoriasAulas e94,
                        E093_GruposAulas e93
                    where
                        e68.AulaID = e91.AulaId
                        and e91.SubCategoriaID = e90.SubCategoriaID
                        and e90.CategoriaID = e88.CategoriaAulaID
                        and e88.CategoriaAulaID = e94.CategoriaAulaID
                        and e94.GrupoAulaID = e93.GrupoAulaID
                        and e93.ClassificacaoID = 11
                        and e93.Situacao = 'A'
                        and e90.CategoriaID = ".$categoriaid."
                        and e93.GrupoAulaID = ".$grupoaulaid."
                        group by e68.AulaID
                        order by e90.Ordem, e88.Descricao
				";
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getAssuntosPlataformaLiterariaPorSerie($serieid, $questoesDissertativas = false, $escolaId)
    {
        // if (!$versaoConteudo) {
        //     $versaoConteudo = $this->session->userdata('versao_conteudo_id');
        // }

        $questoesDissertativas =
            ($questoesDissertativas) ? " inner join E089_SubCategoriasAulas e89 on (e89.SubCategoriaAulaID = e90.SubCategoriaID and e68.Tipo = 'D') " : '';

        $sql = "select e88.Descricao, e93.GrupoAulaID, e88.CategoriaAulaID, e91.AulaId, e90.SubCategoriaID, agenda.AssuntoID
                    from
                        E068_Aulas e68 
                        inner join E091_AulasSubCategorias e91 on e68.AulaID = e91.AulaId
                        inner join E090_CategoriasSubCategoriasAulas e90 on e91.SubCategoriaID = e90.SubCategoriaID
                        inner join E088_CategoriasAulas e88 on e90.CategoriaID = e88.CategoriaAulaID
                        inner join E094_GruposCategoriasAulas e94 on e88.CategoriaAulaID = e94.CategoriaAulaID
                        inner join E093_GruposAulas e93 on e94.GrupoAulaID = e93.GrupoAulaID
                        inner join T002_SeriesDisciplinas serie on e93.GrupoAulaID = serie.DisciplinaID
                        {$questoesDissertativas}                      
                        inner JOIN D024_Ava_Sae_Agenda agenda ON e89.SubCategoriaAulaID = agenda.AssuntoID
                    where e93.ClassificacaoID = 11
                        and e93.Situacao = 'A'                       
                        and (e93.SerieID = '" . $serieid . "' or e93.SerieID LIKE '%|" . $serieid . "|%')
                        and (e93.AvaSaeDisciplinaEspecifica is null or e93.AvaSaeDisciplinaEspecifica = 'N')	                      					
                        AND agenda.EscolaID = {$escolaId}";
        $query = $this->getAvaMySQL()->query($sql);

        return $query->result();
    }

    function getAlunosPorTurma($turmaid){
        $sql = "select Turma, itemName, Nome, NomeAluno, NomeEscola, Perfil, Disciplina, VigenciaTurma 
                    from D019_Ava_Sae
                    where
                    Turma = '".$turmaid."'
                    and Situacao = 'A'
                    and Perfil = 273
                    and PrimeiroLogin = 'N'
                    order by Nome";
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getAlunosAtivosPorTurma($turmaid, $disciplinaid){
        $sql = "select d019.itemName, d019.Nome, r01.UsuarioID, r01.NomeAluno
                from
                  R001_RespostasQuestoes r01  inner join D019_Ava_Sae d019
                  on r01.UsuarioID = d019.itemName
                where r01.TurmaID = '".$turmaid."'
                  and r01.DisciplinaID = ".$disciplinaid."
                  and d019.Situacao = 'A'
                group by r01.UsuarioID
                order by r01.NomeAluno";
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }


    //FIXME: CADASTROS
    public function getAssuntoPorGrupoAula($grupoaulaid) {
        $sql = "select concat(LPAD(e088.CategoriaAulaID,7,'0'),LPAD(e094.GrupoAulaID,7,'0')) as ItemName
                                     , e088.Descricao
                                     , e088.CategoriaAulaID as CategoriaID
                                     , e094.Ordem as OrdemCategoria
                                from E088_CategoriasAulas e088
                                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                where e094.GrupoAulaID = ". $grupoaulaid ."
                                and e094.Ordem is not null
                                order by e094.Ordem ASC";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($sql);
        return $result->result();
    }

    public function getAulaTipoDiscursiva($grupoaulaid, $categoriaid){
        $sql = "select 
                        e68.AulaID, e93.GrupoAulaID, e88.CategoriaAulaID, e90.SubCategoriaID, e68.Duracao, e68.Tipo, 
                        e68.Tema, e90.Ordem, e88.Descricao 
                    from
                        E068_Aulas e68,
                        E090_CategoriasSubCategoriasAulas e90,
                        E091_AulasSubCategorias e91,
                        E088_CategoriasAulas e88,
                        E094_GruposCategoriasAulas e94,
                        E093_GruposAulas e93
                    where
                        e68.AulaID = e91.AulaId
                        and e91.SubCategoriaID = e90.SubCategoriaID
                        and e90.CategoriaID = e88.CategoriaAulaID
                        and e88.CategoriaAulaID = e94.CategoriaAulaID
                        and e94.GrupoAulaID = e93.GrupoAulaID
                        and e93.ClassificacaoID = 11
                        and e93.Situacao = 'A'
                        and e68.Tipo = 'D'
                        and e90.CategoriaID = ".$categoriaid."
                        and e93.GrupoAulaID = ".$grupoaulaid."
                        group by e68.AulaID
                        order by e90.Ordem, e88.Descricao
				";
        $query = $this->getAvaMySQL()->query($sql);
        $result = $query->result();
        return $result;
    }

    public function getQuestoesDiscursivasPorTurma($turmaid, $usuarioid, $grupoaulaid, $disciplinaid){
        $this->getAvaMySQL()->select('QuestaoDiscursivaID, Enunciado, AulaID, AssuntoID, GrupoAulaID');
        $this->getAvaMySQL()->where('GrupoAulaID', $grupoaulaid);
        $this->getAvaMySQL()->where('TurmaID', $turmaid);
        $this->getAvaMySQL()->where('AssuntoID', $disciplinaid);
        $this->getAvaMySQL()->where('Situacao', 'A');
        $query = $this->getAvaMySQL()->get('SAE_Questoes_Discursivas');
        $result = $query->result();
        return $result;
    }

    public function getQuestoesDiscursivas($grupoaulaid, $aulaid=null, $assuntoid=null){
        $this->getAvaMySQL()->select('QuestaoDiscursivaID, Enunciado, AulaID, AssuntoID, GrupoAulaID');
        $this->getAvaMySQL()->where('GrupoAulaID', $grupoaulaid); //disciplinaid
        $this->getAvaMySQL()->where('Situacao', 'A');
        if($aulaid)
            $this->getAvaMySQL()->where('AulaID', $aulaid);
        if ($assuntoid)
            $this->getAvaMySQL()->where('AssuntoID', $assuntoid);

        $query = $this->getAvaMySQL()->get('SAE_Questoes_Discursivas');
        $result = $query->result();
        return $result;
    }

    public function getQuestaoDiscursivaPorID($questaodiscursivaid){
        $this->getAvaMySQL()->select('QuestaoDiscursivaID, Enunciado, AulaID, AssuntoID, GrupoAulaID');
        $this->getAvaMySQL()->where('QuestaoDiscursivaID', $questaodiscursivaid);
        $this->getAvaMySQL()->where('Situacao', 'A');
        $query = $this->getAvaMySQL()->get('SAE_Questoes_Discursivas');
        return $query->row();
    }

    public function getQuestaoDiscursivaPorJarvisItemID($jarvisItemID){
        $this->getAvaMySQL()->select('QuestaoDiscursivaID, Enunciado, AulaID, AssuntoID, GrupoAulaID, JarvisItemID');
        $this->getAvaMySQL()->where('JarvisItemID', $jarvisItemID);
        $this->getAvaMySQL()->where('Situacao', 'A');
        $query = $this->getAvaMySQL()->get('SAE_Questoes_Discursivas');
        return $query->result();
    }

    public function getQuestoesDiscursivasPorGrupoAula($grupoaulaid){
        $assuntos = $this->getAssuntoPorGrupoAula($grupoaulaid);
        $aulas = array();
        foreach ($assuntos as $key => $assunto){
            $questaoTipoDiscursiva = $this->getAulaTipoDiscursiva($grupoaulaid, $assunto->CategoriaID);
            if (isset($questaoTipoDiscursiva)){
                $aulaid = $questaoTipoDiscursiva[0]->AulaID;
                $subcategoriaid = $questaoTipoDiscursiva[0]->SubCategoriaID;
                $categoriaid = $questaoTipoDiscursiva[0]->CategoriaAulaID;
                $discursivas = $this->getQuestoesDiscursivas($grupoaulaid, $aulaid, $subcategoriaid);
                $questoesdiscursivas = array();
                foreach ($discursivas as $keyDiscursiva => $discursiva){
                    $questaodiscursivaid = $discursiva->QuestaoDiscursivaID;
                    $assuntoid = $discursiva->AssuntoID;
                    $aulaid = $discursiva->AulaID;
                    $url = $grupoaulaid.'/'.$assuntoid.'/'.$aulaid.'/'.$questaodiscursivaid;
                    $questaodiscursiva = new stdClass();
                    $questaodiscursiva->URL = $url;
                    array_push($questoesdiscursivas, $questaodiscursiva);
                }
            }

            $aulaplataformaliteraria = new stdClass();
            $aulaplataformaliteraria->Titulo = $questaoTipoDiscursiva[0]->Tema;
            $aulaplataformaliteraria->Descricao = $assunto->Descricao;
            $aulaplataformaliteraria->Questoes = $questoesdiscursivas;
            $aulaplataformaliteraria->Total = count($questoesdiscursivas);
            $aulaplataformaliteraria->CategoriaID = $categoriaid;
            array_push($aulas, $aulaplataformaliteraria);
        }
        return $aulas;
    }

    public function getRespostasDiscursivasPorAssunto($turmaid, $alunoid, $grupoaulaid, $assuntoid, $questaodiscursivaid=null){
        $this->getAvaMySQL()->select('Nota, TurmaID, FrenteID, GrupoAulaID, AssuntoID, Resposta, Enunciado, 
                                      QuestaoDiscursivaID, RespostaID');
        $this->getAvaMySQL()->where('TurmaID', $turmaid);
        $this->getAvaMySQL()->where('AlunoID', $alunoid);
        $this->getAvaMySQL()->where('GrupoAulaID', $grupoaulaid);
        $this->getAvaMySQL()->where('AssuntoID', $assuntoid);
        $this->getAvaMySQL()->where('Situacao', 'A');
        if($questaodiscursivaid)
            $this->getAvaMySQL()->where('QuestaoDiscursivaID', $questaodiscursivaid);
        $query = $this->getAvaMySQL()->get('SAE_Respostas_Questoes_Discursivas');
        $result = $query->result();
        return $result;
    }

    public function  getAlunosRespostasQuestoesDiscursivasPorTurma($turmaid, $categoriaaulaid, $grupoaulaid){
        $this->getAvaMySQL()->select('AlunoID, FrenteID, GrupoAulaID, AssuntoID, TurmaID,
                    RespostaID,QuestaoDiscursivaID,
                    Nota, Enunciado, Resposta, EscolaID, NomeAluno, 
                    DescricaoAssunto, DescricaoEscola, DescricaoTurma, DescricaoFrente');
        $this->getAvaMySQL()->where('TurmaID', $turmaid);
        $this->getAvaMySQL()->where('AssuntoID', $categoriaaulaid);
        $this->getAvaMySQL()->where('GrupoAulaID', $grupoaulaid);
        $this->getAvaMySQL()->where('Situacao', 'A');
        $this->getAvaMySQL()->group_by('AlunoID');
        $query = $this->getAvaMySQL()->get('SAE_Respostas_Questoes_Discursivas');
        $result = $query->result();
        return $result;
    }

    public function getAlunoRespostasQuestoesDiscursivasPorTurma($turmaid, $grupoaulaid, $frenteid){
        $sql = "select 
                resp.AlunoID, resp.DescricaoAssunto, resp.Enunciado,
                d19.Nome, d19.NomeEscola, resp.TurmaID, resp.GrupoAulaID,
                resp.AssuntoID, resp.FrenteID
                from SAE_Respostas_Questoes_Discursivas resp inner join D019_Ava_Sae d19 on resp.AlunoID = d19.itemName
                where resp.Situacao = 'A'
                and resp.TurmaID = '".$turmaid."'
                and resp.FrenteID = '".$frenteid."'
                and resp.GrupoAulaID = ".$grupoaulaid."
                group by resp.AlunoID";
        $query = $this->getAvaMySQL()->query($sql);
        $result = $query->result();
        return $result;
    }

    public function salvarQuestoesDiscursivas($questaodiscursivaid=null, $enunciado, $grupoaulaid, $assuntoid, $aulaid, $usuarioid, $jarvisItemId = null){
        $result = null;
        $now = date('Y-m-d H:i:s');
        if($questaodiscursivaid){ //update
            $this->getAvaMySQL()->set('UsuarioAlt', $usuarioid);
            $this->getAvaMySQL()->set('DtAlt', $now);
            $this->getAvaMySQL()->set('Enunciado', $enunciado);
            $this->getAvaMySQL()->where('QuestaoDiscursivaID', $questaodiscursivaid);
            $this->getAvaMySQL()->where('Situacao', 'A');
            $this->getAvaMySQL()->update('SAE_Questoes_Discursivas');

        }else{ //insert
            $fields['AssuntoID'] = $assuntoid;
            $fields['AulaID'] = $aulaid;
            $fields['GrupoAulaID'] = $grupoaulaid;
            $fields['Enunciado'] = $enunciado;
            $fields['Situacao'] = 'A';
            $fields['DtCad'] = $now;
            $fields['UsuarioCad'] = $usuarioid;

            if ($jarvisItemId) {
                $fields['JarvisItemID'] = $jarvisItemId;
            }

            $fields['QuestaoDiscursivaID'] =$this->iesdeuuid->getIdRandom();
            $result = $this->getAvaMySQL()->insert('SAE_Questoes_Discursivas', $fields);
        }
        return $result;
    }

    public function salvarRespostaQuestoesDiscursivas($respostaid=null,$questaodiscursivaid,
                                                      $resposta, $alunoid, $frenteid, $turmaid,
                                                      $grupoaulaid, $assuntoid, $nota = null, $descricaofrente = null,
                                                      $escolaid=null,$enunciadoquestao=null, $descricaoturma =null,
                                                      $descricaoassunto=null, $descricaoescola=null, $nomealuno=null){

        $usuarioid = $this->session->userdata('pessoaid');
        $login = $this->session->userdata('login');
        $now = date('Y-m-d H:i:s');

        //insere
        if (is_null($respostaid)){
            $fields['QuestaoDiscursivaID'] = $questaodiscursivaid;
            $fields['Resposta'] = trim($resposta);
            $fields['Enunciado'] = trim($enunciadoquestao);
            $fields['TurmaID'] = $turmaid;
            $fields['DescricaoTurma'] = $descricaoturma;
            $fields['AlunoID'] = $alunoid;
            $fields['NomeAluno'] = $nomealuno;
            $fields['EscolaID'] = $escolaid;
            $fields['DescricaoEscola'] = $descricaoescola;
            $fields['FrenteID'] = $frenteid;
            $fields['DescricaoFrente'] = $descricaofrente;
            $fields['AssuntoID'] = $assuntoid;
            $fields['DescricaoAssunto'] = $descricaoassunto;
            $fields['GrupoAulaID'] = $grupoaulaid;
            $fields['Nota'] = $nota;
            $fields['DtCad'] = $now;
            $fields['DtAlt'] = $now;
            $fields['UsuarioAlt'] = $usuarioid;
            $fields['Situacao'] = 'A';
            $result = $this->getAvaMySQL()->insert('SAE_Respostas_Questoes_Discursivas', $fields);
        }
        //atualiza
        else{
            if ($this->session->userdata('perfil') == PERFIL_ALUNO) {
                $fields['Resposta'] = trim($resposta);
            }
            $fields['Nota'] = $nota;
            $fields['DtAlt'] = $now;
            $fields['UsuarioAlt'] = $usuarioid;
            $fields['Situacao'] = 'A';
            $this->getAvaMySQL()->where('RespostaID',$respostaid);
            $result = $this->getAvaMySQL()->update('SAE_Respostas_Questoes_Discursivas',$fields);
        }
    }

    function getInfoAula($aulaid){
        $this->getAvaMySQL()->select('AulaID, Tema, Duracao, Disciplina, Tipo');
        $this->getAvaMySQL()->where('AulaID', $aulaid);
        $this->getAvaMySQL()->where('Situacao', 'A');
        $query = $this->getAvaMySQL()->get('E068_Aulas');
        return $query->result();
    }


    /*TODO: salvar log de ações da plataforma literaria
    */
    public function salvarLogAcoesPlataformaLiteraria( $tipo = 6, $acao, $usuariocad, $usuarioid, $descricao, $grupoaulaid=null, $assuntoid=null,
                                                       $aulaid=null, $escolaid=null, $turmaid=null){
        $fields = array();
        $fields['DtLog'] = date('Y-m-d H:i:s');
        $fields['UsuarioID'] = $usuarioid;
        $fields['Acao'] = $acao;
        $fields['Descricao'] = $descricao;
        $fields['TipoLog'] = $tipo;
        $fields['EscolaID'] = $escolaid;
        $fields['TurmaID'] = $turmaid;
        $fields['AssuntoID'] = $assuntoid;
        $fields['AulaID'] = $aulaid;
        $fields['GrupoAulaID'] = $grupoaulaid;
        $fields['UsuarioCad'] = $usuariocad;

        $result = $this->getAvaMySQL()->insert('SAE_Log_Acao', $fields);
        return $result;
    }

    function removeDuplicadasPl($assuntoid, $aulaid, $grupoaulaid, $alunoid){

        $this->getAvaMySQL()->select('QuestaoDiscursivaID, RespostaID');
        $this->getAvaMySQL()->where('AlunoID', $alunoid);
        $this->getAvaMySQL()->where('AssuntoID', $assuntoid);
        $this->getAvaMySQL()->where('GrupoAulaID', $grupoaulaid);
        $queryAluno = $this->getAvaMySQL()->get('SAE_Respostas_Questoes_Discursivas');
        $respostasAluno = $queryAluno->result_array();

        if (count($respostasAluno) > 0) {
             $respostasManter = $this->unique_multidim_array($respostasAluno,'QuestaoDiscursivaID');
            $respostasManter = array_map([$this, "map"], $respostasManter);
            $this->getAvaMySQL()->where('alunoid', $alunoid);
            $this->getAvaMySQL()->where('AssuntoID', $assuntoid);
            $this->getAvaMySQL()->where('GrupoAulaID', $grupoaulaid);
            $this->getAvaMySQL()->where_not_in('RespostaID', $respostasManter);
            $this->getAvaMySQL()->delete('SAE_Respostas_Questoes_Discursivas');
        }

    }

    private function unique_multidim_array($array, $key) {
        $temp_array = array();
        $i = 0;
        $key_array = array();

        foreach($array as $val) {
            if (!in_array($val[$key], $key_array)) {
                $key_array[$i] = $val[$key];
                $temp_array[$i] = $val;
            }
            $i++;
        }
        return $temp_array;
    }

    private function map($array = [])
    {
        return $array["RespostaID"];
    }


}
