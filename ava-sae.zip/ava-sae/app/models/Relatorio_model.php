<?php

use Ava\App\Support\ClassificacaoConteudo;

class Relatorio_model extends MY_Model {


    public $SELECT_R001 = "SELECT 
                            R001.RespostaQuestaoID as RespostaQuestaoAgregadaID, 
                            R001.UsuarioID as UsuarioID,
                            R001.NomeAluno as NomeUsuario,
                            R001.DisciplinaID as DisciplinaID,
                            R001.DescDisciplina as DescricaoDisciplina,
                            R001.FrenteID as FrenteID,
                            R001.DescFrente as DescricaoFrente,
                            R001.AssuntoID as AssuntoID,
                            R001.DescAssunto as DescricaoAssunto,
                            R001.TurmaID as TurmaID,
                            R001.SerieID as SerieID,
                            R001.EscolaID as EscolaID,
                            R001.NomeEscola as DescricaoEscola,
                            SUM(R001.Tipo='Q') as TotalQuestoes,
                            SUM(case when R001.Tipo='Q' and R001.RespostaCorreta='S' THEN 1 when R001.Tipo='Q' and R001.RespostaCorreta='N' then 0 else NULL end) as TotalAcertoQuestoes,
                            SUM(R001.Tipo='N') as TotalVideos,
                            MAX(CASE WHEN R001.Tipo = 'N' THEN R001.PercentualVideo ELSE NULL END) as PercentualTotalVideo,
                            SUM(R001.Tipo='R') as TotalQuestoesRevisao,
                            SUM(case when R001.Tipo='R' and R001.RespostaCorreta='S'  THEN 1 when R001.Tipo='R' and R001.RespostaCorreta='N' then 0 else NULL end) as TotalAcertosQuestoesRevisao,
                            MAX(CASE WHEN R001.Tipo = 'Q' THEN R001.Meta END) as MetaQuestoes,
                            MAX(CASE WHEN R001.Tipo = 'N' THEN R001.Meta END) as MetaVideos,
                            R001.DtAgendaInicio as DtInicioAtividade,
                            R001.DtAgendaFim as DtFimAtividade,
                            if(SUM(case when R001.Tipo='Q' and R001.RespostaCorreta IS NOT NULL then 1 else 0 end),  SUM(case when R001.Tipo='Q' and R001.RespostaCorreta='S'  then 1 else 0 end) * 100 / SUM(R001.Tipo='Q'), null) as PercentualQuestao,
                            if(SUM(case when R001.Tipo='R' and R001.RespostaCorreta IS NOT NULL then 1 else 0 end),  SUM(case when R001.Tipo='R' and R001.RespostaCorreta='S'  then 1 else 0 end) * 100 / SUM(R001.Tipo='R'), null) as PercentualRevisao,
                            R001.DescTurma as DescricaoTurma
                        FROM R001_RespostasQuestoes R001";


    function __construct() {
        parent::__construct();

        $this->load->model('RespostaQuestaoAgregada_model', 'RespostaQuestaoAgregada');
        $this->load->model('MediaFrenteAlunoFinal_model', 'MediaFrenteAlunoFinal');
        $this->load->model('AssuntoTurma_model', 'AssuntoTurma');
        $this->load->model('AlunoAssunto_model', 'AlunoAssunto');

    }

    public function getDadosUsuario($login = null,$pessoaid = null ) {

    	$sql = '';

    	if($login){
            $sql .= " and Login = '".utf8_encode($login)."'";
    	}

    	if($pessoaid){
            $sql .= " and id = '".$pessoaid."'";
    	}

    	$selectExpression = "select * from D019_Ava_Sae where Situacao = 'A'".$sql;
        
    	// TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    	
    }

    // TODO: FDD-429 - REVER, PROVAVELMENTE NAO ESTA SENDO USADO EM LUGAR NENHUM
    public function verificaDisciplinas($fields = null, $Base = 'Aprovaconcursos',$situacao = null) {

    	$sql = '';
    	if ($situacao) {
    		$sql = "and Situacao = '" . $situacao . "'  ";
    	}

    	$selectExpression = "select * from D019_Ava_Sae where Login = '". utf8_encode($fields['Login'])."'" . $sql;
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function verificaTurmas($id = null,$escolaid = null) {

    	$sql = '';

    	if($escolaid){
    		$sql .= " and EscolaID = '".$escolaid."'";
    	}

    	$selectExpression = "select * from D021_Ava_Sae_Turmas where itemName in ('".$id."') ".$sql;

    	// TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function verificaTurmasDiretor($escolaid)
    {
        $vigencia = Date('Y');

        $sql = "SELECT 
                    Descricao, DescricaoSerie, itemName
                FROM
                    D021_Ava_Sae_Turmas
                WHERE
                    EscolaID = '{$escolaid}' AND Situacao = 'A'
                        AND Vigencia = {$vigencia}
                ORDER BY DescricaoSerie, Descricao;";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($sql);
        return $result->result_array();

    }

    public function verificaSeriesDiretor($fields = null,$Base = 'Aprovaconcursos', $situacao = null) {

    	$sql = '';

    	if($situacao){
    		$sql .= " and Situacao = '".$situacao."'";
    	}

    	$selectExpression = "select DescricaoSerie, SerieID from D021_Ava_Sae_Turmas where EscolaID in ('".$fields['Escola']."') ".$sql;
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function verificaDisciplinaDiretor($serie){
        $classificacaoConteudo = ClassificacaoConteudo::CONTEUDO_GERAL;
        $versaoConteudo = $this->session->userdata('versao_conteudo_id');

        $selectExpression = "SELECT 
                                disciplina.GrupoAulaID AS itemName, TRIM(disciplina.Descricao) Descricao
                            FROM
                                T001_Series serie
                                    INNER JOIN
                                T002_SeriesDisciplinas serieDisciplina ON (serie.SerieID = serieDisciplina.SerieID)
                                    INNER JOIN
                                E093_GruposAulas disciplina ON serieDisciplina.DisciplinaID = disciplina.GrupoAulaID
                            WHERE
                                disciplina.Situacao = 'A'
                                    AND serie.SerieID = {$serie}
                                    AND disciplina.SerieID = {$serie}
                                    AND serie.versao_conteudo_id = {$versaoConteudo}
                                    AND serieDisciplina.versao_conteudo_id = {$versaoConteudo}
                                    AND disciplina.ClassificacaoID = {$classificacaoConteudo}
                                ORDER BY TRIM(disciplina.Descricao)";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getDisciplinas($login ,$turma){
        $selectExpression = "select itemName,Disciplina from D019_Ava_Sae where Login = '$login' and Turma = '$turma' and Situacao = 'A'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getTurmasProfessor($login){
        $selectExpression = "select itemName, Turma, DescricaoTurma, Categoria from D019_Ava_Sae where Login = '$login' and Situacao = 'A' and Perfil != '274'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function buscaDisciplinas($disciplina){
        $selectExpression = "select e093.GrupoAulaID as itemName,e093.Descricao from E093_GruposAulas e093 where e093.GrupoAulaID = '$disciplina'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getTurmasByCategoria($categoria){
        $selectExpression = "select itemName, Descricao, DescricaoSerie from D021_Ava_Sae_Turmas where CategoriaTurmaID = '$categoria' and Situacao = 'A'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getSerieID($turma){
        $selectExpression = "select SerieID, Vigencia from D021_Ava_Sae_Turmas where itemName = '$turma' and Situacao = 'A'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getDisciplinasbySerie($serieID){
        $selectExpression = "select e093.GrupoAulaID as itemName, e093.Descricao from E093_GruposAulas e093 where e093.SerieID = '$serieID' and e093.ClassificacaoID in ('10','12') and e093.Situacao = 'A' and (e093.AvaSaeDisciplinaEspecifica = 'N' or e093.AvaSaeDisciplinaEspecifica is null)";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getDadosRelatorioDiario($usuarioid){
        $where = array(
            'UsuarioID' => $usuarioid,
        );

        $sql = $this->SELECT_R001 . "
                where UsuarioID = '$usuarioid'
                and DtAgendaInicio is not null
                and Situacao = 'A'
                group by UsuarioID, DisciplinaID, AssuntoID, TurmaID";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result('RespostaQuestaoAgregada_model');
    }

    private function buscarMediaEscolaSerie($alunoId)
    {
        $sql = "SELECT 
                    d23.Meta meta,
                    d23.Percentual metaVideo
                FROM
                    D019_Ava_Sae d19
                        INNER JOIN
                    D023_Ava_Sae_Configuracoes d23 ON (d19.Escola = d23.EscolaID AND d19.Serie = d23.Serie)
                WHERE
                    d23.Tipo = 'S'
                    AND d19.itemName = '{$alunoId}';";

        $query = $this->getAvaMySQL()->query($sql);

        return $query->result_array()[0];
    }

    public function buscarRelatorioAluno($alunoId, $relatorioDiario = false)
    {
        $configEscola = $this->buscarMediaEscolaSerie($alunoId);
        if (is_null($configEscola)) {
            show_404();
        }
        $metaVideo = $configEscola['metaVideo'];

        $groupBySubQuery = 'AssuntoID';
        $groupBy = 'bimestre.CategoriaAulaID';
        $orderBy = 'TRIM(bimestre.Descricao)';

        if ($relatorioDiario) {
            $groupBySubQuery = 'UsuarioID, DisciplinaID, AssuntoID, TurmaID';
            $groupBy = 'aluno.itemName, agenda.DisciplinaID, agenda.AssuntoID, agenda.TurmaID, bimestre.CategoriaAulaID';
            $orderBy = 'agenda.DtInicio, ' . $orderBy;
        }

        $sql = "SELECT
                    bimestre.CategoriaAulaID FrenteID,
                    agenda.DtInicio DtInicioAtividade,
                    agenda.DtFim DtFimAtividade,
                    agenda.AssuntoID AssuntoID,
                    agenda.DisciplinaID DisciplinaID,
                    
                    video.PercentualVideo PercentualTotalVideo,
                    
                    configuracao.Meta MetaQuestoes,
                    configuracao.Percentual MetaVideos,
                    
                    TRIM(bimestre.Descricao) DescricaoFrente,
                    TRIM(respostas.DescDisciplina) DescricaoDisciplina,
                    TRIM(COALESCE(respostas.DescAssunto, assunto.Descricao)) DescricaoAssunto,
                    
                    COUNT(agenda.AssuntoID) TotalAssuntos,
                    
                    SUM(COALESCE( 
                        CASE
                            WHEN respostas.mediaQuestoes >= configuracao.Meta
                                THEN 1
                            ELSE 0
                        END
                    , 0)) TotalQuestoesMetaAtingida,
                    
                     SUM(COALESCE( 
                        CASE
                            WHEN respostas.mediaRevisoes >= configuracao.Meta
                                THEN 1
                            ELSE 0
                        END
                    , 0)) TotalRevisoesMetaAtingida,
                    
                    COUNT(agenda.AssuntoID) * 4 TotalQuestoes,
                    SUM(COALESCE(respostas.tentativaQuestao, 0)) TentativaQuestao,
                    SUM(COALESCE(respostas.questoesCorretas, 0)) TotalAcertoQuestoes,
                    
                    COUNT(agenda.AssuntoID) * 3 TotalQuestoesRevisao,
                    SUM(COALESCE(respostas.tentativaRevisao, 0)) TentativaRevisao,
                    SUM(COALESCE(respostas.revisoesCorretas, 0)) TotalAcertosQuestoesRevisao,
                    
                    COUNT(agenda.AssuntoID) TotalVideos,
                    SUM(COALESCE(respostas.tentativaVideo, 0)) TentativaVideo,
                    SUM(COALESCE(respostas.videoAssistido, 0)) TotalVideosAssistidos,

                    COALESCE(
                        CASE
                            WHEN respostas.mediaQuestoes >= configuracao.Meta
                                THEN SUM(respostas.mediaQuestoes) / COUNT(agenda.AssuntoID)
                            WHEN (respostas.videoAssistido AND respostas.mediaRevisoes >= configuracao.Meta)
                                THEN SUM(respostas.mediaRevisoes) / COUNT(agenda.AssuntoID)
                            ELSE
                                SUM(IF(respostas.mediaQuestoes >= respostas.mediaRevisoes, respostas.mediaQuestoes, respostas.mediaRevisoes)) /  COUNT(agenda.AssuntoID)
                        END, 0
                    ) Desempenho
                FROM
                    D019_Ava_Sae aluno
                        INNER JOIN D023_Ava_Sae_Configuracoes configuracao ON (aluno.Escola = configuracao.EscolaID AND aluno.Serie = configuracao.Serie AND configuracao.Tipo = 'S')
                        INNER JOIN D024_Ava_Sae_Agenda agenda ON (agenda.TurmaID = aluno.Turma AND agenda.AlunoID IS NULL)
                        INNER JOIN E089_SubCategoriasAulas assunto ON agenda.AssuntoID = assunto.SubCategoriaAulaID
                        INNER JOIN E090_CategoriasSubCategoriasAulas assuntoBimestre  ON assunto.SubCategoriaAulaID = assuntoBimestre.SubCategoriaID
                        INNER JOIN E088_CategoriasAulas bimestre ON assuntoBimestre.CategoriaID = bimestre.CategoriaAulaID
                        INNER JOIN E094_GruposCategoriasAulas bimestreDisciplina ON (bimestre.CategoriaAulaID = bimestreDisciplina.CategoriaAulaID)
                        INNER JOIN E093_GruposAulas disciplina ON (bimestreDisciplina.GrupoAulaID = disciplina.GrupoAulaID)
                        INNER JOIN T002_SeriesDisciplinas series ON (disciplina.GrupoAulaID = series.DisciplinaID AND series.SerieID = aluno.serie)
                        LEFT JOIN
                            (SELECT
                                PercentualVideo,
                                TurmaID turmaId,
                                AssuntoID assuntoId
                            FROM
                                R001_RespostasQuestoes
                            WHERE
                                UsuarioID = '{$alunoId}'
                                    AND DescAssunto IS NOT NULL
                                    AND Tipo = 'N'
                            GROUP BY UsuarioID , DisciplinaID , AssuntoID , TurmaID) AS video ON (video.TurmaID = agenda.TurmaID AND video.assuntoId = agenda.AssuntoID AND agenda.AlunoID IS NULL)
                        LEFT JOIN (
                            SELECT
                                SUM(IF(Tipo = 'Q' AND RespostaCorreta = 'S', 1, 0)) questoesCorretas,
                                SUM(IF(Tipo = 'Q' AND Resposta IS NOT NULL, 1, 0)) tentativaQuestao,
                                ROUND(SUM(IF(Tipo = 'Q' AND RespostaCorreta = 'S', 1, 0)) / 4 * 100) mediaQuestoes,
                                
                                SUM(IF(Tipo = 'R' AND RespostaCorreta = 'S', 1, 0)) revisoesCorretas,
                                SUM(IF(Tipo = 'R' AND Resposta IS NOT NULL, 1, 0)) tentativaRevisao,
                                ROUND(SUM(IF(Tipo = 'R' AND RespostaCorreta = 'S', 1, 0)) / 3 * 100) mediaRevisoes,
                                
                                SUM(IF(Tipo = 'N' AND PercentualVideo = {$metaVideo}, 1, 0)) videoAssistido,
                                SUM(IF(Tipo = 'N' AND (FimVideo IS NOT NULL OR PercentualVideo IS NOT NULL), 1, 0)) tentativaVideo,
                                
                                PercentualVideo,
                                FimVideo,
                                Resposta,
                                UsuarioID usuarioId,
                                DescDisciplina,
                                DescAssunto,
                                FrenteID frenteId,
                                DisciplinaID disciplinaId,
                                AssuntoID assuntoId,
                                TurmaID turmaId
                            FROM
                                R001_RespostasQuestoes
                            WHERE
                                UsuarioID = '{$alunoId}'
                                AND assuntoId IS NOT NULL
                            GROUP BY {$groupBySubQuery}
                        ) AS respostas ON (respostas.TurmaID = agenda.TurmaID AND respostas.assuntoId = agenda.AssuntoID AND agenda.AlunoID IS NULL)
                WHERE
                    aluno.itemName = '{$alunoId}'
                GROUP BY {$groupBy}
                ORDER BY {$orderBy};";

        $query = $this->getAvaMySQL()->query($sql);

        return $relatorioDiario ? $query->result('RespostaQuestaoAgregada_model') : $query->result();
    }

    /*** Refatorar a query do getFrente ***/
    function getFrenteFinal($alunoid){
        $sql = "select
                    DescricaoFrente,DescricaoDisciplina,FrenteID,
                    PercentualRevisao,PercentualQuestao,
                    AssuntoID,TotalAcertoQuestoes,
                    TotalAcertosQuestoesRevisao,PercentualTotalVideo
                from 
                
                
                (
					{$this->SELECT_R001}
					where 
						UsuarioID = '$alunoid'
						and DtAgendaInicio is not null
						and Situacao = 'A'
						group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                ) as X
                order by X.DescricaoFrente";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        $rs = $query->result();

        $existeFrente = array();
        $listaObjs = array();
        $indice = 0;
        foreach($rs as $obj){
            if ( !in_array($obj->FrenteID,$existeFrente) ){
                array_push($existeFrente,$obj->FrenteID);
                $gClass = new stdClass();
                $gClass->DescricaoFrente = $obj->DescricaoFrente;
                $gClass->DescricaoDisciplina = $obj->DescricaoDisciplina;
                $gClass->FrenteID = $obj->FrenteID;


                // Verifica se o percentual revisão não é nulo
                if ( floatval($obj->PercentualRevisao) > floatval($obj->PercentualQuestao) ){
                    // se não for nulo, ele atribui o percentualrevisao para calcular.
                    $gClass->PercentualFrente = intval($obj->PercentualRevisao);
                } else {
                    // se for nulo, ele atribui o percentualquestao para calcular.
                    $gClass->PercentualFrente = intval($obj->PercentualQuestao);
                }

                // Calcula a quantidade de assunto que existe na lista, começando com 1
                $gClass->TotalAssunto = $this->getTotalAssunto( $alunoid, $obj->FrenteID );

                // Calcula a quantidade de questão respondidas
                if ( $obj->TotalAcertoQuestoes !== null ){
                    // se não for nulo, ele atribui o 1(um) para inciciar o calculo
                    $gClass->AssuntosRespondidos = 1;
                } else {
                    // se for nulo, ele atribui o 0(zero).
                    $gClass->AssuntosRespondidos = 0;
                }

                // Calcula a quantidade de questão respondidas em revisão
                if ( $obj->PercentualRevisao !== null ){
                    // se não for nulo, ele atribui o 1(um) para inciciar o calculo
                    $gClass->TotalAssuntoRevisaoRespondida = 1;
                } else {
                    // se for nulo, ele atribui o 0(zero).
                    $gClass->TotalAssuntoRevisaoRespondida = 0;
                }

                // Calcula a quantidade de videos que foram assistidos
                if ( floatval($obj->PercentualTotalVideo) > 0 ){
                    // se não for nulo, ele atribui o 1(um) para inciciar o calculo
                    $gClass->PercentualTotalVideo = 1;
                } else {
                    // se for nulo, ele atribui o 0(zero).
                    $gClass->PercentualTotalVideo = 0;
                }

                @array_push($listaObjs, $gClass);
                $indice = count($listaObjs) - 1;
            }else{
                // Verifica se o percentual revisão não é nulo
                // Muda o percentual de acordo com a maior valor entre PercentualQuestao e PercentualRevisao
                if ( floatval($obj->PercentualRevisao) > floatval($obj->PercentualQuestao) ){
                    // se não for nulo, ele atribui o percentualrevisao para calcular.
                    $listaObjs[$indice]->PercentualFrente += $obj->PercentualRevisao;
                } else{
                    // se for nulo, ele atribui o percentualquestao para calcular.
                    $listaObjs[$indice]->PercentualFrente += $obj->PercentualQuestao;
                }

                // Calcula a quantidade de questão respondidas
                if ( $obj->TotalAcertoQuestoes !== null){
                    // se não for nulo, ele atribui incrementa.
                    $listaObjs[$indice]->AssuntosRespondidos++;
                }

                // Calcula a quantidade de questão respondidas em revisão
                if ( $obj->PercentualRevisao !== null ){
                    // se não for nulo, ele atribui incrementa.
                    $listaObjs[$indice]->TotalAssuntoRevisaoRespondida++;
                }

                // Calcula a quantidade de videos que foram assistidos
                if ( floatval($obj->PercentualTotalVideo) > 0 ){
                    // se não for nulo, ele atribui incrementa.
                    $listaObjs[$indice]->PercentualTotalVideo++;
                }

            }
        }
        return $listaObjs;
    }

    /*** Refatorar a query do getMediaFrenteAluno ***/
    function getMediaFrenteAlunoFinal($turmaid){
        $sql = "select
                    DescricaoFrente,DescricaoDisciplina,FrenteID,
                    PercentualRevisao,PercentualQuestao,
                    AssuntoID,TotalAcertoQuestoes,
                    TotalAcertosQuestoesRevisao,PercentualTotalVideo
                from 
                (
					{$this->SELECT_R001}
					where 
						TurmaID = '$turmaid'
						and DtAgendaInicio is not null
						and Situacao = 'A'
						group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                ) as X
                order by X.DescricaoFrente";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);

        /* @var MediaFrenteAlunoFinal_model $MediaFrenteAlunoFinal */
        $MediaFrenteAlunoFinal = $this->MediaFrenteAlunoFinal;
        return $MediaFrenteAlunoFinal::processarFrentes($query->result('MediaFrenteAlunoFinal_model'));
    }

    function getTbodyAssunto($frenteid, $alunoid){
        $sql = "select
                    AssuntoID,
                    DescricaoAssunto,
                    TotalQuestoes,
                    TotalAcertoQuestoes,
                    TotalVideos,
                    TotalQuestoesRevisao,
                    TotalAcertosQuestoesRevisao,
                    PercentualTotalVideo,
                    PercentualRevisao,
                    DATE_FORMAT(DtFimAtividade, '%d/%m/%Y') as DtFimAtividade,
                    case when PercentualRevisao is not null and PercentualRevisao > PercentualQuestao then PercentualRevisao else PercentualQuestao end as PercentualAssunto,
                    MetaQuestoes,
                    MetaVideos,
                    TurmaID
                from 
                (
					{$this->SELECT_R001}
					where UsuarioID = '$alunoid'
                        and FrenteID = '$frenteid'
                        and DtAgendaInicio is not null
                        and Situacao = 'A'
					group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
				) as X";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result('RespostaQuestaoAgregada_model');
    }

    function getMediaAssuntoAluno($frenteid){
        $sql = "select
                    AssuntoID,
                    DescricaoAssunto,
                    sum(case when PercentualRevisao is not null and PercentualRevisao > PercentualQuestao then PercentualRevisao else PercentualQuestao end) as PercentualAssunto,
                    count(AssuntoID) as QntDivisao
                from
                (
					{$this->SELECT_R001}
					where EscolaID = '". $this->session->userdata('escola') ."'
                        and FrenteID = '$frenteid'
						and DtAgendaInicio is not null
						and Situacao = 'A'
					group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                ) as X
                group by X.AssuntoID, X.DescricaoAssunto";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    /* QUERYS UTILIZADAS PARA MONTAR O RELATORIO DO PROFESSOR, COORDENADOR E DO DIRETOR(TURMA) */
    function getFrenteRelatorioProfessor($turmaid, $disciplinaid){
        $sql = "select
                    DescricaoFrente ,
                    FrenteID,
                    sum(t.PercentualTotalAluno/t.QntDivisao) as PercentualAssunto,
                    count(if(DtInicioAtividade is not null AND PercentualTotalAluno > 0,AssuntoID,null)) as QntAssuntos
                   --  sum(case when PercentualTotalAluno is not null then 1 else 0 end) as QntAssuntos
                from (
                    select
                        DescricaoAssunto,
                        FrenteID,
                        DescricaoFrente,
                        AssuntoID,
                        DtInicioAtividade,
                        sum(case when PercentualRevisao is not null and PercentualRevisao > PercentualQuestao then COALESCE(PercentualRevisao, 0) else COALESCE(PercentualQuestao, 0) end) as PercentualTotalAluno,
                        sum(case when TotalAcertoQuestoes is not null or TotalAcertosQuestoesRevisao is not null then 1 else null end) as QntDivisao
                    from (
                            {$this->SELECT_R001}
                            inner join D024_Ava_Sae_Agenda D024 on (R001.TurmaID = D024.TurmaID and R001.AssuntoID = D024.AssuntoID and R001.DisciplinaID = D024.DisciplinaID)
                            where R001.TurmaID = '$turmaid'
                            and R001.DisciplinaID = '$disciplinaid'
                            and R001.Situacao = 'A'
                            group by R001.UsuarioID, R001.DisciplinaID, R001.AssuntoID, R001.TurmaID
                    ) as X
                    group by X.FrenteID, X.DescricaoFrente, X.DescricaoAssunto, X.AssuntoID) as t
                group by DescricaoFrente, FrenteID";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getMediaFrente($disciplina){
        $sql = "select
                    DescricaoFrente ,
                    FrenteID,
                    sum(t.PercentualTotalAluno/t.QntDivisao) as PercentualMediaAssunto,
                    -- count(frenteid) as QntAssuntosMedia
                    sum(case when PercentualTotalAluno is not null then 1 else 0 end) as QntAssuntosMedia
                from (
                    select
                        FrenteID,
                        DescricaoFrente,
                        AssuntoID,
                        sum(case when PercentualRevisao is not null and PercentualRevisao > PercentualQuestao then PercentualRevisao else PercentualQuestao end) as PercentualTotalAluno,
                        sum(case when TotalAcertoQuestoes is not null or TotalAcertosQuestoesRevisao is not null then 1 else null end) as QntDivisao
                    from
                      ( 
                        {$this->SELECT_R001}
                        where EscolaID = '". $this->session->userdata("escola") ."'
                            and DisciplinaID = '$disciplina'
                            and Situacao = 'A'
                        group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                    ) as X
                    group by X.FrenteID, X.DescricaoFrente, X.DescricaoAssunto, X.AssuntoID) as t
                group by DescricaoFrente, FrenteID";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getAssuntosTurma($frenteid, $turmaid, $disciplinaid){
        $sql = "select
                    AssuntoID,
                    DescricaoAssunto,
                    TurmaID,
                    sum(case when PercentualRevisao is not null and PercentualRevisao > PercentualQuestao then PercentualRevisao else PercentualQuestao end) as PercentualAssunto,
                    sum(case when TotalAcertoQuestoes is not null then 1 else 0 end) as FezQuestao,
                    sum(case when PercentualTotalVideo is not null then 1 else 0 end) as ViuVideo,
                    sum(case when TotalAcertosQuestoesRevisao is not null then 1 else 0 end) as FezRevisao,
                    sum(case when TotalAcertoQuestoes is not null or TotalAcertosQuestoesRevisao is not null then 1 else null end) as QntDivisao
                from 
                (
					{$this->SELECT_R001}
					INNER JOIN D019_Ava_Sae D019 on D019.itemName = R001.UsuarioID
					where TurmaID = '$turmaid'
                        and FrenteID = '$frenteid'
                        and DisciplinaID = '$disciplinaid'
						and DtAgendaInicio is not null
						and R001.Situacao = 'A'
						group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                ) as X
                group by X.AssuntoID, X.DescricaoAssunto";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result('AssuntoTurma_model');
    }

    function getAgendamentosTurmaFrente($frenteid, $turmaid){
        $sql = "select AssuntoID, DisciplinaID
                from D024_Ava_Sae_Agenda
                where TurmaID = '$turmaid' and FrenteID = '$frenteid' and DtInicio <= '".date("Y-m-d")."'";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getMediaAssunto($frenteid, $disciplinaid){
        $sql = "SELECT
                    t.AssuntoID,
                    t.DescricaoAssunto,
                    sum(round(t.PercentualTotalAluno/t.QntDivisao,0)) as PercentualTurma,
                    count(t.AssuntoID) as QntTurmas
                from
                    (select
                            AssuntoID,
                            DescricaoAssunto,
                            sum(case when PercentualRevisao is not null and PercentualRevisao > PercentualQuestao then PercentualRevisao else PercentualQuestao end) as PercentualTotalAluno,
                            sum(case when TotalAcertoQuestoes is not null or TotalAcertosQuestoesRevisao is not null then 1 else null end) as QntDivisao
                    from (
                        {$this->SELECT_R001}
                        where EscolaID = '". $this->session->userdata('escola') ."'
                            and FrenteID = '$frenteid'
                            and DisciplinaID = '$disciplinaid'
                            and DtAgendaInicio is not null
                            and Situacao = 'A'
                            group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                    ) as X
                    group by X.AssuntoID, X.DescricaoAssunto, X.TurmaID) as t
                group by AssuntoID, DescricaoAssunto";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getAlunosAssunto($assuntoid, $turmaid, $disciplinaid){
        $sql = "select
                    AssuntoID,
                    UsuarioID,
                    FrenteID,
                    TurmaID,
					EscolaID,
					DisciplinaID,
                    NomeUsuario,
                    TotalQuestoes,
                    TotalAcertoQuestoes,
                    TotalVideos,
                    PercentualTotalVideo,
                    TotalQuestoesRevisao,
                    TotalAcertosQuestoesRevisao,
                    MetaQuestoes,
                    MetaVideos,
                    case when PercentualRevisao is not null and PercentualRevisao > PercentualQuestao then PercentualRevisao else PercentualQuestao end as PercentualAssunto,
                    DATE_FORMAT(DtFimAtividade, '%d/%m/%Y')  as DtFimAtividade
                from (
					SELECT 
                            RespostaQuestaoID as RespostaQuestaoAgregadaID, 
                            UsuarioID as UsuarioID,
                            D019.Nome as NomeUsuario,
                            DisciplinaID as DisciplinaID,
                            DescDisciplina as DescricaoDisciplina,
                            FrenteID as FrenteID,
                            DescFrente as DescricaoFrente,
                            AssuntoID as AssuntoID,
                            DescAssunto as DescricaoAssunto,
                            TurmaID as TurmaID,
                            SerieID as SerieID,
                            EscolaID as EscolaID,
                            R001.NomeEscola as DescricaoEscola,
                            SUM(Tipo='Q') as TotalQuestoes,
                            SUM(case when Tipo='Q' and RespostaCorreta='S' THEN 1 when Tipo='Q' and RespostaCorreta='N' then 0 else NULL end) as TotalAcertoQuestoes,
                            SUM(Tipo='N') as TotalVideos,
                            MAX(CASE WHEN Tipo = 'N' THEN PercentualVideo ELSE NULL END) as PercentualTotalVideo,
                            SUM(Tipo='R') as TotalQuestoesRevisao,
                            SUM(case when Tipo='R' and RespostaCorreta='S'  THEN 1 when Tipo='R' and RespostaCorreta='N' then 0 else NULL end) as TotalAcertosQuestoesRevisao,
                            MAX(CASE WHEN Tipo = 'Q' THEN Meta END) as MetaQuestoes,
                            MAX(CASE WHEN Tipo = 'N' THEN Meta END) as MetaVideos,
                            DtAgendaInicio as DtInicioAtividade,
                            DtAgendaFim as DtFimAtividade,
                            if(SUM(case when Tipo='Q' and RespostaCorreta IS NOT NULL then 1 else 0 end),  SUM(case when Tipo='Q' and RespostaCorreta='S'  then 1 else 0 end) * 100 / SUM(Tipo='Q'), null) as PercentualQuestao,
                            if(SUM(case when Tipo='R' and RespostaCorreta IS NOT NULL then 1 else 0 end),  SUM(case when Tipo='R' and RespostaCorreta='S'  then 1 else 0 end) * 100 / SUM(Tipo='R'), null) as PercentualRevisao,
                            DescTurma as DescricaoTurma
                        FROM R001_RespostasQuestoes R001
                    INNER JOIN D019_Ava_Sae D019 on D019.itemName = R001.UsuarioID
                        where AssuntoID = '$assuntoid'
                        AND R001.TurmaID = '$turmaid'
                        AND R001.DisciplinaID = '$disciplinaid'
                        AND D019.Situacao = 'A'
                        and R001.Situacao = 'A'
                    group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                ) as X
                order by X.NomeUsuario asc";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result('Alunoassunto_model');
    }

    /* QUERYS UTILIZADAS PARA MONTAR O RELATORIO DO DIRETOR */

    function getFrenteRelatorioDiretor($serie, $disciplina){
        $sql = "select
                    te.FrenteID,
                    te.DescricaoFrente,
                    sum(round(te.PercentualAssunto/te.TotalTurma,0)) as PercentualFrente,
                    count(FrenteID) as TotalAssunto
                from (
                    select
                        AssuntoID ,
                        DescricaoAssunto,
                        FrenteID,
                        DescricaoFrente,
                        sum(round(t.PercentualTurma/t.QntAlunos,0)) as PercentualAssunto,
                        count(TurmaID) as TotalTurma
                    from (
                        select
                            AssuntoID,
                            FrenteID,
                            DescricaoFrente,
                            DescricaoAssunto,
                            TurmaID,
                            sum(case when PercentualRevisao is not null or PercentualQuestao is not null then 1 else 0 end) as QntAlunos,
                            sum(case when PercentualRevisao is not null then COALESCE(PercentualRevisao, 0) else COALESCE(PercentualQuestao, 0) end) as PercentualTurma
                        from 
                        (
                            {$this->SELECT_R001}
                            where SerieID = '$serie'
                            and DisciplinaID = '$disciplina'
                            and EscolaID = '". $this->session->userdata('escola') ."'
                                and DtAgendaInicio is not null
                                and Situacao = 'A'
                            group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                        ) as X
                        group by X.AssuntoID, X.TurmaID, X.DescricaoAssunto,  X.EscolaID, X.FrenteID, X.DescricaoFrente) as t
                    group by AssuntoID, DescricaoAssunto, FrenteID, DescricaoFrente) as te
                group by frenteid, descricaofrente";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);

        return $query->result();
    }

    function getMediaFrenteRelatorioDiretor($serieid, $disciplinaid){
        $sql = "select
                    te.FrenteID,
                    te.DescricaoFrente,
                    sum(round(te.PercentualAssunto/te.TotalTurma,0)) as PercentualFrente,
                    count(FrenteID) as TotalAssunto
                from (
                    select
                            AssuntoID ,
                            DescricaoAssunto,
                            FrenteID,
                            DescricaoFrente,
                            sum(round(t.PercentualTurma/t.QntAlunos,0)) as PercentualAssunto,
                            count(TurmaID) as TotalTurma
                    from (
                            select
                                    AssuntoID,
                                    FrenteID,
                                    DescricaoFrente,
                                    DescricaoAssunto,
                                    TurmaID,
                                    sum(case when PercentualRevisao is not null or PercentualQuestao is not null then 1 else 0 end) as QntAlunos,
                                    sum(case when PercentualRevisao is not null then COALESCE(PercentualRevisao, 0) else COALESCE(PercentualQuestao, 0) end) as PercentualTurma
                            from 
                            (
								{$this->SELECT_R001}
								where SerieID = '$serieid'
                                    and DisciplinaID = '$disciplinaid'
                                    -- and EscolaID in ('5f62fd1e273716dddb683e5dc11c8185', '816ab7fda24367198b8b6af5c1544fd0', 'a5c92745c40d0ea532770b82ebd69cca')
                                    and DtAgendaInicio is not null
                                    and Situacao = 'A'
								group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                            ) as X
                            where X.TotalAcertoQuestoes is not null
                            group by X.AssuntoID, X.TurmaID, X.DescricaoAssunto,  X.EscolaID, X.FrenteID, X.DescricaoFrente) as t
                    group by AssuntoID, DescricaoAssunto, FrenteID, DescricaoFrente) as te
                group by frenteid, descricaofrente";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getAssuntosRelatorioDiretor($serieid, $frenteid){
        $sql = "select
                    AssuntoID ,
                    DescricaoAssunto,
                    sum(round(t.PercentualTurma/t.QntAlunos,0)) as PercentualAssunto,
                    count(TurmaID) as TotalTurma
                from (
                   select
                                AssuntoID,
                                DescricaoAssunto,
                        TurmaID,
                        sum(case when PercentualRevisao is not null or PercentualQuestao is not null then 1 else 0 end) as QntAlunos,
                        sum(case when PercentualRevisao is not null then PercentualRevisao else PercentualQuestao end) as PercentualTurma
                    from 
                    (
						{$this->SELECT_R001}
						where FrenteID = '$frenteid'
                            and SerieID = '$serieid'
                            and EscolaID = '". $this->session->userdata('escola') ."'
                            and Situacao = 'A'
						group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                    ) as X
                    group by X.AssuntoID, X.TurmaID, X.DescricaoAssunto, X.EscolaID) as t
                group by AssuntoID, DescricaoAssunto";

        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getMediaAssuntosRelatorioDiretor($frente, $serie){
        $sql = "select
                    AssuntoID ,
                    DescricaoAssunto,
                    sum(round(t.PercentualTurma/t.QntAlunos,0)) as PercentualAssunto,
                    count(TurmaID) as TotalTurma
                from (
                   select
                                AssuntoID,
                                DescricaoAssunto,
                        TurmaID,
                        sum(case when PercentualRevisao is not null or PercentualQuestao is not null then 1 else 0 end) as QntAlunos,
                        sum(case when PercentualRevisao is not null then PercentualRevisao else PercentualQuestao end) as PercentualTurma
                    from 
                    (
						{$this->SELECT_R001}
						where FrenteID = '$frente'
                            and SerieID = '$serie'
							-- and EscolaID in ('5f62fd1e273716dddb683e5dc11c8185', '816ab7fda24367198b8b6af5c1544fd0', 'a5c92745c40d0ea532770b82ebd69cca')
							and Situacao = 'A'
						group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                    ) as X
                    group by X.AssuntoID, X.TurmaID, X.DescricaoAssunto,  X.EscolaID) as t
                group by AssuntoID, DescricaoAssunto";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getTurmasRelatorioDiretor($assuntoid){
        $sql = "select
                    TurmaID,
                    DescricaoTurma,
                    sum(case when PercentualRevisao is not null or PercentualQuestao is not null then 1 else 0 end) as QntAlunos,
                    sum(case when PercentualRevisao is not null then PercentualRevisao else PercentualQuestao end) as PercentualTurma
                from 
                (
					{$this->SELECT_R001}
					where AssuntoID = '$assuntoid'
                        and EscolaID = '". $this->session->userdata('escola') ."'
                        and Situacao = 'A'
					group by UsuarioID, DisciplinaID, AssuntoID, TurmaID
                ) as X
                group by X.AssuntoID, X.TurmaID, X.DescricaoAssunto,  X.EscolaID, X.DescricaoTurma";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($sql);
        return $query->result();
    }

    function getTodosAlunosTurma($turmaid){
        $selectExpression = "select itemName,Nome,DtCad from D019_Ava_Sae where Turma = '$turmaid' and Perfil = '273' and Situacao = 'A' AND PrimeiroLogin = 'N'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();

    }

    function buscaTurmaAluno($alunoid){
        $selectExpression = "select Turma from D019_Ava_Sae where itemName = '$alunoid'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getConfigMediaEscola($escolaid){
        $selectExpression = "select MediaTurmaRelatorio from D023_Ava_Sae_Configuracoes where EscolaID = '$escolaid' and Tipo = 'G'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        
    }

    function getInfoDisciplina( $disciplinaid ){
        $selectExpression = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                                        , e089.Descricao
                                         , e094.GrupoAulaID
                                         , e089.SubCategoriaAulaID as DisciplinaID
                                         , e089.DtInicio as DtInicio
                                         , e088.CategoriaAulaID as CategoriaID
                                         , '' as TemMensagem
                                         , null as SemQuestoes 
                                    from E089_SubCategoriasAulas e089
                                    inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                                    inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                                    inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                                    where e089.SubCategoriaAulaID = ". $disciplinaid ."
                                      limit 1";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }
    
    function gerarDadosAssunto($dadosAssunto){
        $dadosAssunto_turma = $this->getAgendamentosTurmaFrente($this->input->post('frenteid', true), $dadosAssunto[0]->TurmaID);
        $lista_assunto = array();
        
        foreach ( $dadosAssunto as $addassunto ){
            $lista_assunto[] = $addassunto->AssuntoID;
        }
        
        foreach($dadosAssunto_turma as $assunto){
            if (!in_array($assunto->AssuntoID, $lista_assunto)) {
                    $dadosAssunto[] = new $this->RespostaQuestaoAgregada(array(
                        'AssuntoID' => $assunto->AssuntoID,
                        'DescricaoAssunto' => $this->getDescricaoDisciplinas( $assunto ),
                        'TotalQuestoes' => $dadosAssunto[0]->TotalQuestoes,
                        'PercentualAssunto' => $dadosAssunto[0]->PercentualAssunto,
                        'PercentualRevisao' => $dadosAssunto[0]->PercentualRevisao,
                        'TotalAcertoQuestoes' => $dadosAssunto[0]->TotalAcertoQuestoes,
                        'TotalVideos' => $dadosAssunto[0]->TotalVideos,
                        'PercentualTotalVideo' => $dadosAssunto[0]->PercentualTotalVideo,
                        'DtFimAtividade' => $dadosAssunto[0]->DtFimAtividade,
                        'TotalQuestoesRevisao' => $dadosAssunto[0]->TotalQuestoesRevisao,
                        'TotalAcertosQuestoesRevisao' => $dadosAssunto[0]->TotalAcertosQuestoesRevisao,
                        'MetaQuestoes' => $dadosAssunto[0]->MetaQuestoes,
                        'MetaVideos' => $dadosAssunto[0]->MetaVideos,
                        'TurmaID' => $dadosAssunto[0]->TurmaID
                    ));
                }
        }
        
        return $dadosAssunto;
    }
    
    function gerarDadosAssuntoTurma($dadosAssunto){
        $dadosAssunto_turma = $this->getAgendamentosTurmaFrente($this->input->post('frenteid', true), $dadosAssunto[0]->TurmaID);
        $lista_assunto = array();
        
        foreach ( $dadosAssunto as $addassunto ){
            $lista_assunto[] = $addassunto->AssuntoID;
        }
        
        foreach($dadosAssunto_turma as $assunto){
            if (!in_array($assunto->AssuntoID, $lista_assunto)) {
                    $dadosAssunto[] = new $this->AssuntoTurma(array(
                        'AssuntoID' => $assunto->AssuntoID,
                        'DescricaoAssunto' => $this->getDescricaoDisciplinas( $assunto ),
                        'TurmaID' => $dadosAssunto[0]->TurmaID,
                        'PercentualAssunto' => 0,
                        'FezQuestao' => 0,
                        'ViuVideo' => 0,
                        'FezRevisao' => 0,
                        'QntDivisao' => 0
                    ));
                }
        }
        
        return $dadosAssunto;
    }
    
    function gerarDadosAssuntoDiario($dadosAssunto){
        $dadosAssunto_turma = $this->getAgendamentosTurmaFrente($this->input->post('frenteid', true), $dadosAssunto[0]->TurmaID);
        $lista_assunto = array();
        
        foreach ( $dadosAssunto as $addassunto ){
            $lista_assunto[] = $addassunto->AssuntoID;
        }
        
        foreach($dadosAssunto_turma as $assunto){
            if (!in_array($assunto->AssuntoID, $lista_assunto)) {
                    $dadosAssunto[] = (object)[
                        'AssuntoID' => $assunto->AssuntoID,
                        'DescricaoAssunto' => $this->getDescricaoDisciplinas( $assunto ),
                        'TurmaID' => $dadosAssunto[0]->TurmaID,
                        'PercentualAssunto' => 0,
                        'FezQuestao' => 0,
                        'ViuVideo' => 0,
                        'FezRevisao' => 0,
                        'QntDivisao' => 0
                    ];
                }
        }
        
        return $dadosAssunto;
    }
    
    function getDescricaoDisciplinas( $dados ){
        $sql = "select concat(lpad(e089.SubCategoriaAulaID,7,0),lpad(e094.GrupoAulaID,7,0)) as itemName
                    , e089.Descricao
                     , e094.GrupoAulaID
                     , e089.SubCategoriaAulaID as DisciplinaID
                     , e089.DtInicio as DtInicio
                     , e088.CategoriaAulaID as CategoriaID
                     , '' as TemMensagem
                     , e089.Situacao
                from E089_SubCategoriasAulas e089
                inner join E090_CategoriasSubCategoriasAulas e090 on e090.SubCategoriaID = e089.SubCategoriaAulaID
                inner join E088_CategoriasAulas e088 on e088.CategoriaAulaID = e090.CategoriaID
                inner join E094_GruposCategoriasAulas e094 on e094.CategoriaAulaID = e088.CategoriaAulaID
                where e094.GrupoAulaID = ". $dados->DisciplinaID ."
                  and e089.SubCategoriaAulaID = ". $dados->AssuntoID;

        $result = $this->getAvaMySQL()->query($sql);
        $return = $result->result_array();
        return $return[0]['Descricao'];
    }
    
    function getTotalAssunto( $usuarioid, $frente ){
    	$sql = "select
			count(AssuntoID) as total
		from 
		(
			SELECT 
				AssuntoID as AssuntoID
			FROM R001_RespostasQuestoes R001
			where UsuarioID = '{$usuarioid}'
				and FrenteID = '{$frente}'
				and DtAgendaInicio is not null
				and Situacao = 'A'
			group by AssuntoID
		) as X";
		
        $result = $this->getAvaMySQL()->query($sql);
        $return = $result->result_array();
        return $return[0]['total'];
    }

	public function getRelatorioAlunoQuestoes($turmaid, $disciplinaid){
        $sql = "					select
                    NomeUsuario,
                     DescAssunto,
                    DescFrente,
                         UsuarioID,
                        DisciplinaID,
                        FrenteID,
                       AssuntoID,
                        TurmaID,
                        EscolaID,
                        DescricaoEscola,
                        TotalQuestoes,
                        TotalAcertoQuestoes,
                        TotalVideos,
                        PercentualTotalVideo,
                        TotalQuestoesRevisao,
                        TotalAcertosQuestoesRevisao,
                        MetaQuestoes,
                        MetaVideos,
                        DtInicioAtividade,
                        DtFimAtividade,
                        PercentualQuestao,
                        PercentualRevisao,
                        DescTurma,
                    	NomeEscola,
                    	DescricaoSerie,
                    case when PercentualRevisao is not null and PercentualRevisao > PercentualQuestao then PercentualRevisao else PercentualQuestao end as PercentualAssunto,
                    DATE_FORMAT(DtFimAtividade, '%d/%m/%Y')  as DtFimAtividade
                from (
                    SELECT
						E088.Descricao as DescFrente,
                        E089.Descricao as DescAssunto,
                         D019.itemName as UsuarioID,
                        D019.Nome as NomeUsuario,
                        D024.DisciplinaID as DisciplinaID,
                        D024.FrenteID as FrenteID,
                        D024.AssuntoID as AssuntoID,
                        D024.TurmaID as TurmaID,
                        D024.EscolaID as EscolaID,
                        D019.NomeEscola as DescricaoEscola,
                        SUM(Tipo='Q') as TotalQuestoes,
                        SUM(case when Tipo='Q' and RespostaCorreta='S' THEN 1 when Tipo='Q' and RespostaCorreta='N' then 0 else NULL end) as TotalAcertoQuestoes,
                        SUM(Tipo='N') as TotalVideos,
                        MAX(CASE WHEN Tipo = 'N' THEN PercentualVideo ELSE NULL END) as PercentualTotalVideo,
                        SUM(Tipo='R') as TotalQuestoesRevisao,
                        SUM(case when Tipo='R' and RespostaCorreta='S'  THEN 1 when Tipo='R' and RespostaCorreta='N' then 0 else NULL end) as TotalAcertosQuestoesRevisao,
                        MAX(CASE WHEN Tipo = 'Q' THEN Meta END) as MetaQuestoes,
                        MAX(CASE WHEN Tipo = 'N' THEN Meta END) as MetaVideos,
                        D024.DtInicio as DtInicioAtividade,
                        D024.DtFim as DtFimAtividade,
                        if(SUM(case when Tipo='Q' and RespostaCorreta IS NOT NULL then 1 else 0 end),  
                        SUM(case when Tipo='Q' and RespostaCorreta='S'  then 1 else 0 end) * 100 / SUM(Tipo='Q'), null) as PercentualQuestao,
                        if(SUM(case when Tipo='R' and RespostaCorreta IS NOT NULL then 1 else 0 end),  
                        SUM(case when Tipo='R' and RespostaCorreta='S'  then 1 else 0 end) * 100 / SUM(Tipo='R'), null) as PercentualRevisao,
                        D019.DescricaoTurma as DescTurma,
                    	D019.NomeEscola as NomeEscola,
                    	D019.DescricaoSerie as DescricaoSerie
                    FROM D019_Ava_Sae D019
                    INNER JOIN D024_Ava_Sae_Agenda AS D024 on D024.TurmaId = D019.Turma
					INNER JOIN E088_CategoriasAulas as E088 on E088.CategoriaAulaID = D024.FrenteID
                    INNER JOIN E089_SubCategoriasAulas AS E089 ON E089.SubCategoriaAulaID = D024.AssuntoID
                    left JOIN R001_RespostasQuestoes  R001 on D019.itemName = R001.UsuarioID 
													AND R001.DisciplinaID = '".$disciplinaid."'
                                                     and R001.Situacao = 'A'
													 and D024.turmaid = R001.turmaid
                                                     and D024.assuntoid = R001.assuntoid
                                                     and D024.frenteid = R001.frenteid
                    where D024.TurmaID = '".$turmaid."'
                        and D019.Turma = '".$turmaid."' 
					and D019.Perfil = '273'
					and D019.Situacao = 'A' 
					AND D019.PrimeiroLogin = 'N'
					and D024.DisciplinaID = '".$disciplinaid."'
                    group by 
						
                       E088.Descricao,
                        E089.Descricao,
                         D019.itemName ,
                        D019.Nome ,
                        D024.DisciplinaID,
                        D024.FrenteID ,
                        D024.AssuntoID ,
                        D024.TurmaID ,
                        D024.EscolaID ,
                        D019.NomeEscola ,
                        D024.DtInicio ,
                        D024.DtFim ,
                         D019.DescricaoTurma ,
                    	D019.NomeEscola ,
                    	D019.DescricaoSerie
                      
                    
                ) as X
                order by FrenteID ,
                    AssuntoID,
                    NomeUsuario";
        $query = $this->getAvaMySQL()->query($sql);
        $lista_resultado = $query->result('Alunoassunto_model');
        return $lista_resultado;
    }

    function getTodosAlunosTurmaXLS($turmaid){
        $selectExpression = "select itemName,Nome,DtCad from D019_Ava_Sae where Turma = '$turmaid' and Perfil = '273' and Situacao = 'A' AND PrimeiroLogin = 'N'";
        //p($selectExpression);die;
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //return $this->simpledb->selectsItems($selectExpression);
    }

    function getDadosTurma($turmaid){
        $selectExpression = "select * from D021_Ava_Sae_Turmas
                    where itemName = '".$turmaid."'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //return $this->simpledb->selectsItems($selectExpression);
    }

    function getDadosFrente($frenteid){
        $selectExpression = "select* from E088_CategoriasAulas
                    where itemName = '".$frenteid."'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //return $this->simpledb->selectsItems($selectExpression);
    }

    function getDadosAluno($param ){
       $selectExpression = "select* from D019_Ava_Sae
                    where itemName = '".$param."'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function buscarDadosRelatorioFrenteID($frenteI, $alunoId)
    {
        $configEscola = $this->buscarMediaEscolaSerie($alunoId);
        $metaVideo = $configEscola['metaVideo'];

        $sql = "SELECT
                    agenda.AssuntoID,
                    assunto.Descricao DescricaoAssunto,
                    DATE_FORMAT(agenda.DtFim, '%d/%m/%Y') AS DtFimAtividade,

                    COUNT(agenda.AssuntoID) * 4 TotalQuestoes,
                    SUM(COALESCE(respostas.tentativaQuestao, 0)) TentativaQuestao,
                    SUM(COALESCE(respostas.questoesCorretas, 0)) TotalAcertoQuestoes,
                    COUNT(agenda.AssuntoID) TotalVideos,
                    SUM(COALESCE(respostas.tentativaVideo, 0)) TentativaVideo,
                    SUM(COALESCE(respostas.videoAssistido, 0)) TotalVideosAssistidos,
                    COUNT(agenda.AssuntoID) * 3 TotalQuestoesRevisao,
                    SUM(COALESCE(respostas.tentativaRevisao, 0)) TentativaRevisao,
                    SUM(COALESCE(respostas.revisoesCorretas, 0)) TotalAcertosQuestoesRevisao,
                    COALESCE(video.PercentualVideo, 0) PercentualTotalVideo,
                    ROUND((COALESCE(respostas.revisoesCorretas, 0) / COALESCE((COUNT(agenda.AssuntoID) * 3), 0)) * 100) PercentualRevisao,
                    ROUND((COALESCE(respostas.questoesCorretas, 0) / COALESCE((COUNT(agenda.AssuntoID) * 4), 0)) * 100) PercentualQuestao,
                    
                    CASE
                        WHEN
                            ROUND((COALESCE(respostas.revisoesCorretas, 0) / COALESCE((COUNT(agenda.AssuntoID) * 3), 0)) * 100) >= ROUND((COALESCE(respostas.questoesCorretas, 0) / COALESCE((COUNT(agenda.AssuntoID) * 4), 0)) * 100) 
                        THEN
                            ROUND((COALESCE(respostas.revisoesCorretas, 0) / COALESCE((COUNT(agenda.AssuntoID) * 3), 0)) * 100)
                        ELSE ROUND((COALESCE(respostas.questoesCorretas, 0) / COALESCE((COUNT(agenda.AssuntoID) * 4), 0)) * 100)
                    END AS PercentualAssunto,
                    
                    configuracao.Meta MetaQuestoes,
                    configuracao.Percentual MetaVideos,
                    agenda.TurmaID
                FROM
                    D019_Ava_Sae aluno
                        INNER JOIN D023_Ava_Sae_Configuracoes configuracao ON (aluno.Escola = configuracao.EscolaID AND aluno.Serie = configuracao.Serie AND configuracao.Tipo = 'S')
                        INNER JOIN D024_Ava_Sae_Agenda agenda ON (agenda.TurmaID = aluno.Turma AND agenda.AlunoID IS NULL)
                        INNER JOIN E089_SubCategoriasAulas assunto ON agenda.AssuntoID = assunto.SubCategoriaAulaID
                        INNER JOIN E090_CategoriasSubCategoriasAulas assuntoBimestre  ON assunto.SubCategoriaAulaID = assuntoBimestre.SubCategoriaID
                        INNER JOIN E088_CategoriasAulas bimestre ON assuntoBimestre.CategoriaID = bimestre.CategoriaAulaID
                        INNER JOIN E094_GruposCategoriasAulas bimestreDisciplina ON (bimestre.CategoriaAulaID = bimestreDisciplina.CategoriaAulaID)
                        INNER JOIN E093_GruposAulas disciplina ON (bimestreDisciplina.GrupoAulaID = disciplina.GrupoAulaID)
                        INNER JOIN T002_SeriesDisciplinas series ON (disciplina.GrupoAulaID = series.DisciplinaID AND series.SerieID = aluno.serie)
                        LEFT JOIN
                            (SELECT
                                PercentualVideo,
                                TurmaID turmaId,
                                AssuntoID assuntoId
                            FROM
                                R001_RespostasQuestoes
                            WHERE
                                UsuarioID = '{$alunoId}'
                                    AND DescAssunto IS NOT NULL
                                    AND Tipo = 'N'
                            GROUP BY UsuarioID , DisciplinaID , AssuntoID , TurmaID) AS video ON (video.TurmaID = agenda.TurmaID AND video.assuntoId = agenda.AssuntoID AND agenda.AlunoID IS NULL)
                        LEFT JOIN (
                            SELECT
                                SUM(IF(Tipo = 'Q' AND RespostaCorreta = 'S', 1, 0)) questoesCorretas,
                                SUM(IF(Tipo = 'Q' AND Resposta IS NOT NULL, 1, 0)) tentativaQuestao,
                                ROUND(SUM(IF(Tipo = 'Q' AND RespostaCorreta = 'S', 1, 0)) / 4 * 100) mediaQuestoes,
                                
                                SUM(IF(Tipo = 'R' AND RespostaCorreta = 'S', 1, 0)) revisoesCorretas,
                                SUM(IF(Tipo = 'R' AND Resposta IS NOT NULL, 1, 0)) tentativaRevisao,
                                ROUND(SUM(IF(Tipo = 'R' AND RespostaCorreta = 'S', 1, 0)) / 3 * 100) mediaRevisoes,
                                
                                SUM(IF(Tipo = 'N' AND PercentualVideo = {$metaVideo}, 1, 0)) videoAssistido,
                                SUM(IF(Tipo = 'N' AND (FimVideo IS NOT NULL OR PercentualVideo IS NOT NULL), 1, 0)) tentativaVideo,
                                
                                PercentualVideo,
                                FimVideo,
                                Resposta,
                                UsuarioID usuarioId,
                                DescDisciplina,
                                DescAssunto,
                                FrenteID frenteId,
                                DisciplinaID disciplinaId,
                                AssuntoID assuntoId,
                                TurmaID turmaId
                            FROM
                                R001_RespostasQuestoes
                            WHERE
                                UsuarioID = '{$alunoId}'
                                AND DescAssunto IS NOT NULL
                                AND FrenteID = {$frenteI}
                            GROUP BY UsuarioID, DisciplinaID, AssuntoID, TurmaID
                        ) AS respostas ON (respostas.TurmaID = agenda.TurmaID AND respostas.assuntoId = agenda.AssuntoID AND agenda.AlunoID IS NULL)
                WHERE
                    aluno.itemName = '{$alunoId}'
                    AND agenda.FrenteID = {$frenteI}
                GROUP BY aluno.itemName, agenda.DisciplinaID, agenda.AssuntoID, agenda.TurmaID, bimestre.CategoriaAulaID
                ORDER BY TRIM(bimestre.Descricao);";

        $query = $this->getAvaMySQL()->query($sql);

        return $query->result('RespostaQuestaoAgregada_model');
    }

}
