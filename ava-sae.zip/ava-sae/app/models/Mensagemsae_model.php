<?php

class Mensagemsae_model extends MY_Model {

    function __construct() {
        parent::__construct();
        

    }  
    
    public function CarregaListaRecados($itemName)
    {
        $selectExpression = "select ifnull(a.Finalizado,'N') as Concluidas, a.* , b.RetornoTecnico

                            from D036_Mensagens_Sae a
                               , D037_Erros         b

                            where a.Situacao = 'A' 
                            and a.DtCad is not null 
                            and a.Envio = 'D' 
                            and a.UsuarioAlvo = '". $itemName ."' 

                            and a.Erro = b.itemName

                            order by a.DtCad DESC";

        $result = $this->getAvaMySQL()->query($selectExpression);
        $lista = $result->result_array();      

        //print_pre($lista);die();
        if($lista)
        {
            foreach($lista as $key => $msg)
            {
                $retorno = $this->CarregaRetornoTecnico($msg['Erro']);
                //print_pre($retorno);die();
                if(isset($retorno[0]['RetornoTecnico']))
                {
                    $lista[$key]['RetornoTecnico'] = $retorno[0]['RetornoTecnico'];
                }
            }
        }

        return $lista;
    }

    public function CarregaListaRecadosPop($id = null)
    {

        $selectExpression = "select * from D036_Mensagens_Sae where Situacao = 'A' and DtCad is not null and Lido = 'N' and UsuarioAlvo = '". $id ."' order by DtCad ASC";
        //return $selectExpression;
        $result = $this->getAvaMySQL()->query($selectExpression);
        $lista = $result->result_array();
    	
        return $lista;
    }

    public function CarregaListaRecadosGeral($ordem = 'ASC', $lido = null)
    {
        if(isset($lido))
        {
            $selectExpression = "select * from D036_Mensagens_Sae where Situacao = 'A' and Lido = '". $lido ."' order by DtCad ". $ordem;
        }
        else
        {
            $selectExpression = "select * from D036_Mensagens_Sae where Situacao = 'A' order by DtCad ". $ordem;
        }
        //return $selectExpression;
      $result = $this->getAvaMySQL()->query($selectExpression);
      $lista = $result->result_array();
    	//$lista = $this->simpledb->selectsItems($selectExpression);
        return $lista;
    }

    public function MensagemLida($id, $dados)
    {
        $this->getAvaMySQL()->where('itemName',$id);
        $this->getAvaMySQL()->update('D036_Mensagens_Sae',$dados);
    }

    public function GravaErro($info)
    {
        header ('Content-type: text/html; charset=ISO-8859-1');
        $idErro = $this->iesdeuuid->getIdRandom();

        $a = $this->mensagem->GetMaxid();

        $dados['ID'] = $a;
        $dados['Situacao'] = 'A';
        $dados['DtCad'] = date('Y-m-d H:i:s');
        $dados['DtFinalizado'] = NULL;
        //$dados['Observacao'] = '';
        $dados['UsuarioLogin'] = $info['usuario'];
        $dados['EscolaID'] = $info['escola'];
        $dados['EmailReclamante'] = $info['emailreclamante'];
        $dados['Assunto'] = $info['assunto'];
        $dados['GrupoResponsavel'] = $info['caterro'];
        $dados['ErroMensagem'] = $info['descricaoerro'];        
        $dados['TurmaID'] = $info['turma'];
        $dados['UserAgent'] = $info['user_agent'];
        $dados['TurmaDesc'] = $info['turmaDesc'];
        $dados['EscolaItemName'] = $info['Escolaid'];
        $dados['DescricaoSerie'] = $info['DescricaoSerie'];
        $dados['Bimestre'] = $info['Bimestre'];
        $dados['Segmento'] = $info['Segmento'];
        $dados['ConnectionInfo'] = $info['ConnectionInfo'];

        $infoerr = $this->session->userdata('infoErro');

        if(isset($infoerr['questao']))
        {
            $dados['QuestaoID'] = $infoerr['questao'];
        }
        if(isset($infoerr['curso']))
        {
            $dados['Curso'] = $infoerr['curso'];
        }
        if(isset($infoerr['conteudo']))
        {
            $dados['Conteudo'] = $infoerr['conteudo'];
        }

        $idMSG = $this->GravaMensagem('S', null, null, null, $idErro, $dados['UsuarioLogin'], $dados['ErroMensagem']);        
        
        $dados['MensagemID'] = $idMSG;
        $dados['itemName'] = $idErro;

        $this->salvaDados('D037_Erros', $idErro, $dados, FALSE);        
    }

    public function GravaMensagem($GeraAuto = 'S', $userCad = null, $titulo = null, $mensagem = null, $erro = null, $userAlvo, $msgErro = null)
    {
        $id = $this->iesdeuuid->getIdRandom();

        if($GeraAuto == 'N')
        {
            $usuarioCad = $userCad;
        }

        if($GeraAuto == 'S')
        {
            $dados['Tipo'] = 'A';
        }
        else
        {
            $dados['Tipo'] = 'C';
        }

        $dados['Situacao'] = 'A';
        $dados['DtCad'] = date('Y-m-d H:i:s');

        if(isset($mensagem))
        {
            $dados['Mensagem'] = $mensagem;
        }
        else
        {
            $dados['Mensagem'] = 'Seu erro está em análise. Em até 72h daremos um retorno.';

        }

        $dados['Envio'] = 'D';
        $dados['Lido'] = 'N';

        if($GeraAuto == 'S')
        {
            $dados['Titulo'] = 'Informativo de Erro';
        }
        else
        {
            $dados['Titulo'] = $titulo;
        }

        $idUserAlvo = $this->getidByLogin($userAlvo);
        $dados['UsuarioAlvo'] = $idUserAlvo[0]['itemName'];

        if($GeraAuto == 'S')
        {
            $dados['Erro'] = $erro;
        }

        if($GeraAuto == 'S')
        {
            $dados['MensagemErro'] = $msgErro;
        }
        
        $dados['itemName'] = $id;
                
        $this->salvaDados('D036_Mensagens_Sae', $id, $dados, FALSE);

        return $id;
    }

    public function salvaDados($domain,$id,$dados,$replace=TRUE){

      if ($replace){
        $this->getAvaMySQL()->where('itemName',$id);
        return $this->getAvaMySQL()->update($domain,$dados);
      }
      return $this->getAvaMySQL()->insert($domain,$dados);
    }

    public function getidByLogin($login)
    {
        $selectExpression = "select itemName from D019_Ava_Sae where Login = '". $login ."'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);
    	  //return $result;
    }

    public function CarregaMensagem($idMensagem)
    {
        $selectExpression = "select * 

                            from D036_Mensagens_Sae a 
                               , D037_Erros b

                            where a.itemName = '". $idMensagem ."'
                            and a.Erro = b.itemName";
        
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function CarregaRetornoTecnico($idMensagem)
    {
        $selectExpression = "select RetornoTecnico from `D037_Erros` where MensagemID = '". $idMensagem ."'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);

    	//return $result;
    }

    public function CarregaDescricaoTurma($idTurma)
    {
        $selectExpression = "select Descricao from `D021_Ava_Sae_Turmas` where id = '". $idTurma ."'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);

    	//return $result;
    }

     public function CarregaEscolas()
    {
        $selectExpression = "select * from `D019_Ava_Sae` where Perfil = '269'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);

    	//return $result;
    }
    
    public function CarregaTurmas( $dados ){
        if(isset($dados['erros']) && count($dados['erros']) > 0 ){
            foreach($dados['erros'] as $key => $value){
                if( $value['TurmaDesc'] != "" ){
                    $array_turma = $this->mensagem->CarregaDescricaoTurma($value['TurmaID']);
                    if($array_turma)
                        $dados['erros'][$key]['TurmaDesc'] = $array_turma[0]['Descricao'];
                }
            }
        }
        
        return $dados;
    }
    
    public function BuscaBimestre($pConteudo)
    {
        $selectExpression = "select e088.Descricao

                        from E089_SubCategoriasAulas e089
                           , E090_CategoriasSubCategoriasAulas e090
                           , E088_CategoriasAulas e088

                        where e089.Descricao = '". $pConteudo ."'

                          and e089.SubCategoriaAulaID = e090.SubCategoriaID
                          and e090.CategoriaID = e088.CategoriaAulaID";
        
        $query = $this->getAvaMySQL()->query($selectExpression)->result();

        return $query['Descricao'];
    }
    
    public function CarregaDescricaoTurmaByLogin($login)
    {
        $selectExpression = "select * from `D019_Ava_Sae` where Login = '". $login ."'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);

    	//return $result;
    }

    public function CarregaEscolaIDByLogin($login)
    {
        $selectExpression = "select Escola from `D019_Ava_Sae` where Login = '". $login ."' limit 1";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);

    	//return $result;
    }

    public function ListaErros($idEscola = null, $antigos = null, $categoria = null, $responsavel = null, $id = null, $login = null)
    {
        $selectExpression = "select * from `D037_Erros` where 1=1 ";

        if($idEscola)
        {   
            $selectExpression .= " and Escolaid = '". $idEscola ."' ";
        }

        if($categoria)
        {
            $selectExpression .= " and Assunto = '". $categoria ."' ";
        }

        if($id)
        {
            $selectExpression .= " and ID = '". $id ."' ";
        }

        if($login)
        {
            $selectExpression .= " and UsuarioLogin = '". $login ."' ";
        }

        $selectExpression .= " and DtCad >= '2017-03-26' and DtCad is not null and Situacao = 'A' order by id_ DESC";
        
        $result = $this->getAvaMySQL()->query($selectExpression);

        return $result->result_array();
    }

    public function ListaErrosExport($idEscola = null, $antigos = null, $categoria = null, $responsavel = null, $id = null, $login = null, $finalizado = null, $indeferido = null)
    {
        $selectExpression = "select * from `D037_Erros` where ";

        $selectExpression .= " DtCad >= '".date("Y")."-00-00' ";

        if($idEscola)
        {
            $selectExpression .= " and Escolaid = '". $idEscola ."' ";
        }

        if($categoria)
        {
            $selectExpression .= " and Assunto = '". $categoria ."' ";
        }

        if($id)
        {
            $selectExpression .= " and ID = '". $id ."' ";
        }

        if($login)
        {
            $selectExpression .= " and UsuarioLogin = '". $login ."' ";
        }
        
        if ( $finalizado ){
            $selectExpression .= " and DtFinalizado IS NOT NULL ";
        }
        
        if ( $indeferido ){
            $selectExpression .= " and Indeferido = 1 ";
        }

        $selectExpression .= " and DtCad >= '2017-03-25' and DtCad is not null and Situacao = 'A' order by DtCad DESC";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function ListaErrosTriagem($idEscola = null, $antigos = null, $categoria = null, $responsavel = null)
    {
        $selectExpression = "select * from `D037_Erros` where ";

        if(!$idEscola)
        {
            if(!$antigos)
            {
                $selectExpression .= " RetornoTecnico is null ";
            }
        }
        else
        {
            if(!$antigos)
            {
                $selectExpression .= " Escolaid = '". $idEscola ."' and RetornoTecnico is null ";
            }
            else
            {
                //$selectExpression .= " Escolaid = '". $idEscola ."' and RetornoTecnico is not null ";
                $selectExpression .= " Escolaid = '". $idEscola ."' ";
            }
        }

        if($categoria)
        {
            $selectExpression .= " and Assunto = '". $categoria ."' ";
        }

        if($responsavel)
        {
            $selectExpression .= " and GrupoResponsavel = '". $responsavel ."' ";
        }

        $selectExpression .= " and DtCad >= '2017-03-25' and DtCad is not null and Situacao = 'A' order by DtCad DESC";

        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);

    	//return $result;
    }

    public function ListaErrosConcluidos($idEscola = null, $antigos = null, $categoria = null, $responsavel = null)
    {
        return [];
        
//         $selectExpression = "select * from `D037_Erros` where ";

//         if(!$idEscola)
//         {
//             $selectExpression .= " RetornoTecnico is not null ";
//         }
//         else
//         {
//             $selectExpression .= " Escolaid = '". $idEscola ."' and RetornoTecnico is not null ";
//         }

//         if($categoria)
//         {
//             $selectExpression .= " and Assunto = '". $categoria ."' ";
//         }

//         if($responsavel)
//         {
//             $selectExpression .= " and (GrupoResponsavel = '". $responsavel ."' or GrupoResponsavel is null) ";
//         }

// //        $selectExpression .= " and RetornoTecnico is not null ";

//         $selectExpression .= " and DtCad like '2017%' and Situacao = 'A'  order by DtCad DESC";

//         $result = $this->getAvaMySQL()->query($selectExpression);
//         return $result->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);

    	//return $result;
    }

    public function GetConteudoErros($idErro)
    {
        $selectExpression = "SELECT D37.*, D19.Nome  FROM D037_Erros D37 INNER JOIN D019_Ava_Sae D19 ON D19.Login = D37.UsuarioLogin AND D19.Escola = D37.EscolaItemName WHERE D37.itemName = '". $idErro ."'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }
    
    public function getNomeUsuario ( $dados ) {
        $selectExpression = "select * from `D019_Ava_Sae` where login = '{$dados['UsuarioLogin']}' and escola = '{$dados['EscolaItemName']}'";
        $result = $this->getAvaMySQL()->query($selectExpression);
        $rs = $result->result_array();
        
        return $rs[0]['Nome'];
    }
    
    public function FinalizaErro($itemNameErro, $dados, $dadosmsg = null)
    {        
        $this->salvaDados('D037_Erros', $itemNameErro, $dados, TRUE);
        
        $dadosmsg2['Lido'] = 'N';
        
        if($dadosmsg['MensagemID'])
        {
            $this->salvaDados('D036_Mensagens_Sae', $dadosmsg['MensagemID'], $dadosmsg2, TRUE);
        
            $fin['Finalizado'] = 'S';
        
            $this->salvaDados('D036_Mensagens_Sae', $dadosmsg['MensagemID'], $fin, TRUE);
        }
    }

    public function EncaminhaErro($idErro, $dados)
    {
        $this->salvaDados('D037_Erros', $idErro, $dados, TRUE);
    }

    public function ExcluirErros($idErro, $dados)
    {
        $this->salvaDados('D037_Erros', $idErro, $dados, TRUE);
    }
   
    public function ExcluirMensagemErros($itemNameErro, $dados)
    {
        $selectExpression = "select MensagemID from `D037_Erros` where itemName = '". $itemNameErro ."'";                
        $result = $this->getAvaMySQL()->query($selectExpression)->result_array();
        
        $itemNameMSG = $result[0]['MensagemID'];
        $this->salvaDados('D036_Mensagens_Sae', $itemNameMSG, $dados, TRUE);
    }
    
    public function iso_utf(&$a){
        if (is_array($a)){
            foreach ($a as $k => $v) {
                if (!is_array($v)){
                    $a[$k] = utf8_encode($a[$k]);
                } else {
                    $this->iso_utf($a[$k]);
                }
            }
        } else {
            $a = utf8_encode($a);
        }
        return $a;
    }


    public function utf_iso(&$a){
        if (is_array($a)){
            foreach ($a as $k => $v) {
                if (!is_array($v)){
                    $a[$k] = utf8_decode($a[$k]);
                } else {
                    utf_iso($a[$k]);
                }
            }
        } else {
            $a = utf8_decode($a);
        }
        return $a;
    }

    public function ListaErrosTemp()
    {
        $selectExpression = "select * from `D037_Erros` where DtCad is not null and ID is null order by DtCad limit 140";

        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
        //$result = $this->simpledb->selectsItems($selectExpression);

    	//return $result;
    }

    public function GetMaxid()
    {
        $selectExpression = "select ID from D037_Erros order by cast(ID as DECIMAL) DESC limit 1";

        $result = $this->getAvaMySQL()->query($selectExpression)->result_array();
        $id = $result[0]['ID']+1;
        
    	return $id;
    }

    public function GravaErroTemp($pid, $id)
    {
        $dados['ID'] = $id;

        $this->salvaDados('D037_Erros', $pid, $dados);
    }

    public function GravaErroManual($info)
    {
        header ('Content-type: text/html; charset=ISO-8859-1');
        $itemNameErro = $this->iesdeuuid->getIdRandom();
                                        
        $a = $this->mensagem->GetMaxID();
        
        $dados['ID'] = $a;
        $dados['Situacao'] = 'A';
        $dados['DtCad'] = date('Y-m-d H:i:s');
        $dados['DtFinalizado'] = NULL;
        $dados['UsuarioLogin'] = $info['usuario'];
        $dados['EscolaID'] = $info['escola'];
        $dados['EmailReclamante'] = $info['emailreclamante'];
        $dados['Assunto'] = '-';
        $dados['ErroMensagem'] = $info['descricaoerro'];        
        $dados['TurmaID'] = $info['turmaID'];        
        $dados['GrupoResponsavel'] = $info['responsavel'];
        $dados['ObservacaoEncaminhar'] = $info['obs'];
        $dados['Conteudo'] = $info['conteudo'];
        $dados['TurmaDesc'] = $info['turma'];
        $dados['EscolaItemName'] = $info['EscolaItemName'];
        $dados['itemName'] = $itemNameErro;
                        
        if(isset($info['questao']))
        {        
            $dados['QuestaoID'] = $info['questao'];
        }                               
        if(isset($info['disciplina']))
        {        
            $dados['Curso'] = $info['disciplina'];
        }                               
        if(isset($info['assunto']))
        {        
            $dados['Conteudo'] = $info['assunto'];
        }                                         
        
        $this->salvaDados('D037_Erros', $itemNameErro, $dados, FALSE);
    }
    
    public function VerificaLoginExiste($pLogin)
    {
        $selectExpression = "select * from `D019_Ava_Sae` where Login = '". $pLogin ."'";    
        $result = $this->getAvaMySQL()->query($selectExpression)->result_array();
        
        if($result)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    
    public function QuantidadeErrosConteudo()
    {
        $selectExpression = "select count(*) from `D037_Erros` where GrupoResponsavel = 'S|N|N' and DtCad > '2017-03-26' and Situacao = 'A'";
        $result = $this->simpledb->selectsItems($selectExpression);
        
        return $result;
    }
    
    public function QuantidadeErrosTecnico()
    {
        $selectExpression = "select count(*) from `D037_Erros` where GrupoResponsavel = 'N|N|S' and DtCad > '2017-03-26' and Situacao = 'A'";
        $result = $this->simpledb->selectsItems($selectExpression);
        
        return $result;
    }
    
    public function ErrosConteudo()
    {
        $sql = "select * from D037_Erros where GrupoResponsavel = 'S|N|N' and DtCad > '2017-03-26' and Situacao = 'A'";
        $result = $this->simpledb->selectsItems($sql);
        
        return $result;
    }
    
    public function ErrosTecnico()
    {
        $sql = "select * from D037_Erros where GrupoResponsavel = 'N|N|S' and DtCad > '2017-03-26' and Situacao = 'A'";
        $result = $this->simpledb->selectsItems($sql);
        
        return $result;
    }
    
    public function getQueryPagination ($limit, $start, $where) {
        $this->getAvaMySQL()->select('*, (select Nome from D019_Ava_Sae where login = UsuarioLogin and escola = EscolaItemName LIMIT 1) as Nome');
        //p($where);
        $this->addFiltros ( $where );
        $this->getAvaMySQL()->where('DtCad >=', '2017-03-26');
        $this->getAvaMySQL()->where('DtCad IS NOT NULL');
        $this->getAvaMySQL()->where('Situacao', 'A');
        
        $this->getAvaMySQL()->order_by("DtCad", "asc");
        
        $this->getAvaMySQL()->limit($limit, $start);
        
        $rs = $this->getAvaMySQL()->get('D037_Erros');
        return $rs->result_array();
    }
    
    public function record_count( $triagem = false ) {
        $this->getAvaMySQL()->select('*');
        $this->addFiltros ( $triagem );
        $this->getAvaMySQL()->where('DtCad >=', '2017-03-26');
        $this->getAvaMySQL()->where('DtCad IS NOT NULL');
        $this->getAvaMySQL()->where('Situacao', 'A');
        
        $query = $this->getAvaMySQL()->get('D037_Erros');
        $num = $query->num_rows();
        return $num;
    }
    
    protected function addFiltros ( $where = null ){
        $filtros = array(
            'EscolaID'          => (isset($where['escola']) && $where['escola'] != "todos")?         $where['escola'] : '',
            'Assunto'           => (isset($where['categoria']) && $where['categoria'] != 'Todas' && $where['categoria'] != 'todos')?      $where['categoria'] : '',
            'ID'               => isset($where['idErro'])?         $where['idErro'] : '',
            'GrupoResponsavel'  => isset($where['filtroTriagem'])?  $where['filtroTriagem'] : '',         
            'DtFinalizado'      => isset($where['finalizado'])?     $where['finalizado'] : '',
            'UsuarioLogin'      => isset($where['loginPesq'])?      $where['loginPesq'] : ''
        );
        
        if ( !isset($where['filtroTriagem']) && isset($_SESSION['filtroTriagem']) ){
            $filtros['GrupoResponsavel'] = $_SESSION['filtroTriagem'];
        }
        
        if ( !isset($where['finalizado']) && isset($_SESSION['finalizado']) ){
            $filtros['finalizado'] = $_SESSION['finalizado'];
        }
        
        if ( !isset($where['indeferido']) && isset($_SESSION['indeferido']) ){
            $this->getAvaMySQL()->where( 'Indeferido', 1);
        }else if ( isset($where['indeferido']) && $where['indeferido'] != "" ){
            $this->getAvaMySQL()->where( 'Indeferido', 1);
        }
        
        foreach( $filtros as $key => $filtro ){
            if ( $filtro != "" ){
                if ( trim($key) == "GrupoResponsavel" && trim($filtro) == "tecnico" ){
                    $this->getAvaMySQL()->where( $key, 'N|N|S');
                }else if ( trim($key) == "GrupoResponsavel" && trim($filtro) == "conteudo" ){
                    $this->getAvaMySQL()->where( $key, 'S|N|N');
                }else if ( trim($key) == "GrupoResponsavel" && trim($filtro) == "cadastro" ){
                    $this->getAvaMySQL()->where( $key, 'N|S|N');
                }else if ( trim($key) == "GrupoResponsavel" ){
                    $this->getAvaMySQL()->where( $key, 'N|N|N');
                }else{
                    if ( ( trim($key) == "DtFinalizado" || trim($key) == "finalizado" ) && $filtro = 'sim' )
                        $this->getAvaMySQL()->where( 'DtFinalizado IS NULL');
                    else if ( ( trim($key) == "indeferido" || trim($key) == "indeferido" ) && $filtro = 'sim' )
                        $this->getAvaMySQL()->where( 'Indeferido', 1);
                    else
                        $this->getAvaMySQL()->where( $key, $filtro);
                }
            }
        }
    }
    
    function carregaInfoAluno( $data ){
        $this->getAvaMySQL()->select('*');
        $this->getAvaMySQL()->where('Login', $this->session->userdata['login']);
        $this->getAvaMySQL()->where('Situacao', 'A');
        $query = $this->getAvaMySQL()->get('D019_Ava_Sae')->result_array();
        
        preg_match('/[0-9]{6}/', $data['descricaoErro'], $matches);
        
        $data['DescricaoSerie'] = $query[0]['DescricaoSerie'];
        if(count($matches) > 0){
            $data['Bimestre'] = $this->listaBimestre($matches[0]);
        }
        $data['Segmento'] = $this->getSegmento ( $query[0]['Serie'] );
        return $data;
    }
    
    function listaBimestre( $questaoid ){

        $sql = "SELECT E088.Descricao
                FROM E068_Aulas E068
                INNER JOIN E091_AulasSubCategorias E091 ON E068.AulaID = E091.AulaId
                INNER JOIN E090_CategoriasSubCategoriasAulas E090 ON E091.SubCategoriaID = E090.SubCategoriaID
                INNER JOIN E088_CategoriasAulas E088 ON E090.CategoriaID = E088.CategoriaAulaID
                INNER JOIN E358_EstruturaAulasQuestoes e358 on e358.AulaID = E068.AulaID
                inner join E359_AulaQuestoes e359 on e358.EstruturaAulaID = e359.EstruturaAulaID
                where e359.QuestaoID = ". $questaoid;

        $query = $this->getAvaMySQL()->query($sql);

        $descricao = $query->result_array()[0]['Descricao'];
        
        $bimestre = explode("série: ", $descricao);
        return $bimestre[0];
    }
    
    function getSegmento ( $serie ){
        if ( $serie >= 1 && $serie <= 5 ){
            return "EF I";
        }else if ( $serie >= 6 && $serie <= 9 ){
            return "EF II";
        }else if ( $serie >= 10 && $serie <= 11 ){
            return "EM";
        }else if ( $serie >= 13 ){
            return "MEGA";
        }else {
            return "Sem informação";
        }
    }

    /**
     * @param $ticketId
     * @param $userId
     *
     * @return mixed
     */
    public function salvarNotificacaoDeMensagemNaoLida($ticketId, $userId)
    {
        /** @var \DateTime $dtCad */
        $dtCad = new \DateTime();

        $data = [
            'Titulo' => $ticketId,
            'itemName' => md5(uniqid(rand(), true)),
            'UsuarioAlvo' => $userId,
            'Lido' => 'N',
            'Tipo' => 'Z',
            'Situacao' => 'A',
            'Mensagem' => 'Notificação Zendesk, ticket: ' . $ticketId,
            'DtCad' => $dtCad->format('Y-m-d H:i:s')
        ];

        return $this->getAvaMySQL()->insert('D036_Mensagens_Sae', $data);
    }

    /**
     * @param $ticketId
     * @param $usuarioAlvo
     */
    public function removerNotificacaoDeMensagemNaoLida($ticketId, $usuarioAlvo)
    {
        $this->getAvaMySQL()->delete('D036_Mensagens_Sae', [
            'Titulo' => $ticketId,
            'UsuarioAlvo' => $usuarioAlvo,
            'Tipo' => 'Z',
            'Lido' => 'N'
        ]);
    }


    /**
     * @param $userId
     *
     * @return mixed
     */
    public function buscarMensagensNaoLidas($userId)
    {
        $query = $this->getAvaMySQL()->get_where('D036_Mensagens_Sae', [
            'UsuarioAlvo' => $userId,
            'Lido' => 'N',
            'Tipo' => 'Z'
        ]);

        return $query->result();
    }
}
