<?php

class Api_model extends MY_Model
{
    public function ListarQuestoesSimilaridadeSae($idCurso, $pSubCat = null)
    {

        $sql = "select cd.id as disciplina, c.id as curso, ca.id as aula, caq.questao_id as questao  ,
        
                (	select group_concat(qs.questao_similar_id  SEPARATOR ',') 
                	from aprovaquestoes.questao_similar qs 
                	WHERE qs.questao_id=caq.questao_id ) as similar, 
                	
                (	select group_concat(qs.questao_id  SEPARATOR ',') 
                	from aprovaquestoes.questao_similar qs 
                	WHERE qs.questao_similar_id=caq.questao_id ) as similarInverso 
                	
                from aprovaquestoes.curso c 
                    join aprovaquestoes.curso_categoria cc on cc.curso_id = c.id
                    join aprovaquestoes.curso_disciplina cd on cd.id = cc.curso_disciplina_id
                    join aprovaquestoes.curso_aula ca on ca.curso_disciplina_id = cd.id
                    left join aprovaquestoes.curso_aula_questao caq on caq.curso_aula_id = ca.id
                where c.id = ". $idCurso;

        if($pSubCat)
        {
            $sql .= " and cd.id = ". $pSubCat;
        }

        $sql .= " group by cd.id, c.id, ca.id, caq.questao_id
                order by cd.id, c.id, ca.id, caq.questao_id";

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($sql)->result_array();

        $return=array();        
        if(count($result))
        {            
            $return['success'] = 1;
            foreach ($result as $linha){
//                print_pre($similares);die();

                $curso=intval($idCurso);
                $disciplina=intval($linha['disciplina']);
                $aula=intval($linha['aula']);
                $questao=intval($linha['questao']);
                $similares = array("$questao");

                if($linha['similar']){
                    $similar = explode(',',$linha['similar']);
                    $similares = array_merge($similar, $similares);
                }

                if($linha['similarInverso']){
                    $similarInverso = explode(',',$linha['similarInverso']);
                    $similares = array_merge($similarInverso, $similares);
                }

                $return['message']['disciplina'][$disciplina]['aula'][$aula]['questoes'][]=array_values(array_unique($similares));
            }
        }
        else
        {
            $return['success'] = 0;
            $return['message'] = "Curso não encontrado!";
        }
        
        return $return;
    }
}
