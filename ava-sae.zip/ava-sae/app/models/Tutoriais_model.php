<?php

class Tutoriais_model extends MY_Model {

    function __construct() {
        parent::__construct();
    }

    function getTutoriais($perfil){
        $selectExpression = "select * from D032_TutoriaisVideos where Perfil = '". $perfil. "' and Ordem is not null order by Ordem asc";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    function getVideo($tutorialid){
        $selectExpression = "select * from D032_TutoriaisVideos where id= '". (int)$tutorialid . "'";
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }
}
