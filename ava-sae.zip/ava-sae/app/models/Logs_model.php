<?php

// TODO: FDD-429 - VERIFICAR SE ISSO AINDA PRECISA EXISTIR
class Logs_model extends MY_Model {

    function __construct() {
        parent::__construct();
    }

    function getSistemaID($baseurl){
        $this->getLogAcesso()->select('sistemaid');
        $this->getLogAcesso()->from('MY001_Sistemas');
        $this->getLogAcesso()->where('url', $baseurl);
        $query = $this->getLogAcesso()->get();
       
        if($query->row())
        {
            return $query->row()->sistemaid;        
        }
        else
        {
            return 3;
        }
    }

}

