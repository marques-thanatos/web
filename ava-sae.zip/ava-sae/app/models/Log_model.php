<?php

class Log_model extends MY_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function salvaDados($domain, $id, $dados, $replace = TRUE)
    {
        if ($replace){
            return $insert = $this->getAvaMySQL()->insert($domain, $dados);
        }else{
            $this->getAvaMySQL()->where('itemName',$id);
            return $this->getAvaMySQL()->update($domain,$dados);
        }
    }

    public function GravaLog($param)
    {
        $id = $this->iesdeuuid->getIdRandom();

        $dados['LoginID'] = $param['loginid'];
        $dados['Login'] = $param['login'];
        $dados['Acao'] = $param['acao'];
        $dados['NomeEscola'] = $param['nomeescola'];
        $dados['EscolaID'] = $param['escola'];
        $dados['DtLog'] = date('Y-m-d H:i:s');
        $dados['itemName'] = md5(date('Y-m-d H:m:s')); //Corrigir o bug do mysql 

        if(isset($param['disciplina']))
        {
            $dados['DisciplinaID'] = $param['disciplina'];
            $dados['AssuntoID'] = $param['assunto'];
            $dados['AulaID'] = $param['aula'];
        }

        $dados['CodigoLog'] = $param['codigo'];

        $this->salvaDados('D039_Logs', $id, $dados, TRUE);
    }

    public function RetornaEixoY($escola, $dataini, $datafim)
    {
        if($escola == null)
        {
            $selectExpression = 'select DtLog from D039_Logs where (DtLog >= "'. $dataini .'" and DtLog <= "'. $datafim .'") and CodigoLog = "1"';
        }
        else
        {
            $selectExpression = 'select DtLog from D039_Logs where EscolaID = "'. $escola .'" and (DtLog >= "'. $dataini .'" and DtLog <= "'. $datafim .'") and CodigoLog = "1"';
        }
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function RetornaEixoYMensal($escola, $data)
    {
        if($escola == null)
        {
            $selectExpression = 'select DtLog from D039_Logs where DtLog >= "'.$data.' 00:00:00" and DtLog <= "'.$data.' 23:59:59" and CodigoLog = "1"';
        }
        else
        {
            $selectExpression = 'select DtLog from D039_Logs where EscolaID = "'. $escola .'" and DtLog >= "'.$data.' 00:00:00" and DtLog <= "'.$data.' 23:59:59" and CodigoLog = "1"';
        }

        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function RetornaEixoXPorValor($data, $escola)
    {
        if($escola == null)
        {
            $selectExpression = 'select Login from D039_Logs where DtLog >= "'.$data.' 00:00:00" and DtLog <= "'.$data.' 23:59:59" and CodigoLog = "1"';
        }
        else
        {
            $selectExpression = 'select Login from D039_Logs where EscolaID = "'. $escola .'" and DtLog >= "'.$data.' 00:00:00" and DtLog <= "'.$data.' 23:59:59" and CodigoLog = "1"';
        }
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

    public function RetornaDadosGrafico($escola, $dataini, $datafim)
    {
        if($escola == null)
        {
            $selectExpression = 'select Dtlog,count(login_data) as numero_acessos
            from    (select date(DtLog) as Dtlog, Login as login_data from D039_Logs 
                where (DtLog >= "'.$dataini.'" and DtLog <= "'.$datafim.'") 
                and CodigoLog = "1") AS X
            group by Dtlog
            order by Dtlog;';
        }
        else
        {
            $selectExpression = 'select Dtlog,count(login_data) as numero_acessos
            from    (select date(DtLog) as Dtlog, Login as login_data from D039_Logs 
                where EscolaID = "'.$escola.'" 
                and (DtLog >= "'.$dataini.'" and DtLog <= "'.$datafim.'") 
                and CodigoLog = "1") AS X
            group by Dtlog
            order by Dtlog;';
        }
        // TODO: FDD-429 - UNSAFE QUERY
        $result = $this->getAvaMySQL()->query($selectExpression);
        return $result->result_array();
    }

}
