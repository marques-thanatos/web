<?php

$obj = &get_instance();
$obj->load->model('RespostaQuestaoAgregada_model');

class MediaFrenteAlunoFinal_model extends RespostaQuestaoAgregada_model
{

    public $DescricaoFrente;
    public $DescricaoDisciplina;
    public $FrenteID;
    public $PercentualRevisao;
    public $PercentualQuestao;
    public $AssuntoID;
    public $TotalAcertoQuestoes;
    public $TotalAcertosQuestoesRevisao;
    public $PercentualTotalVideo;


    public static function processarFrentes($frentes){
        $existeFrente = array();
        $listaObjs = array();
        $indice = 0;

        foreach($frentes as $frente){
            if ( !in_array($frente->FrenteID,$existeFrente) ){
                array_push($existeFrente,$frente->FrenteID);
                $gClass = new stdClass();
                $gClass->DescricaoFrente = $frente->DescricaoFrente;
                $gClass->DescricaoDisciplina = $frente->DescricaoDisciplina;
                $gClass->FrenteID = $frente->FrenteID;

                // Verifica se o percentual revisão não é nulo
                if (is_float($frente->PercentualRevisao)) {
                    // se não for nulo, ele atribui o percentualrevisao para calcular.
                    $gClass->PercentualFrente = intval($frente->PercentualRevisao);
                } else {
                    // se for nulo, ele atribui o percentualquestao para calcular.
                    $gClass->PercentualFrente = intval($frente->PercentualQuestao);
                }

                // Calcula a quantidade de assunto que existe na lista, começando com 1
                if ($frente->AssuntoID != "") {
                    // se não for nulo, ele atribui o 1(um) para inciciar o calculo
                    $gClass->TotalAssunto = 1;
                } else {
                    // se for nulo, ele atribui o 0(zero).
                    $gClass->TotalAssunto = 0;
                }

                // Calcula a quantidade de questão respondidas
                if (is_numeric($frente->TotalAcertoQuestoes)) {
                    // se não for nulo, ele atribui o 1(um) para inciciar o calculo
                    $gClass->AssuntosRespondidos = 1;
                } else {
                    // se for nulo, ele atribui o 0(zero).
                    $gClass->AssuntosRespondidos = 0;
                }

                // Calcula a quantidade de questão respondidas em revisão
                if (is_numeric($frente->TotalAcertosQuestoesRevisao)) {
                    // se não for nulo, ele atribui o 1(um) para inciciar o calculo
                    $gClass->TotalAssuntoRevisaoRespondida = 1;
                } else {
                    // se for nulo, ele atribui o 0(zero).
                    $gClass->TotalAssuntoRevisaoRespondida = 0;
                }

                // Calcula a quantidade de videos que foram assistidos
                if (is_float($frente->PercentualTotalVideo)) {
                    // se não for nulo, ele atribui o 1(um) para inciciar o calculo
                    $gClass->PercentualTotalVideo = 1;
                }
                else {
                    // se for nulo, ele atribui o 0(zero).
                    $gClass->PercentualTotalVideo = 0;
                }

                @array_push($listaObjs, $gClass);
                $indice = count($listaObjs) - 1;
            }else{
                // Verifica se o percentual revisão não é nulo
                if (is_float($frente->PercentualRevisao)) {
                    // se não for nulo, ele atribui o percentualrevisao para calcular.
                    $listaObjs[$indice]->PercentualFrente += intval($gClass->PercentualFrente);
                }
                else {
                    // se for nulo, ele atribui o percentualquestao para calcular.
                    $listaObjs[$indice]->PercentualFrente += $frente->PercentualQuestao;
                }

                // Calcula a quantidade de assunto que existe na lista, começando com 1
                if ($frente->AssuntoID != "") {
                    // se não for nulo, ele atribui incrementa.
                    $listaObjs[$indice]->TotalAssunto++;
                }

                // Calcula a quantidade de questão respondidas
                if (is_numeric($frente->TotalAcertoQuestoes)) {
                    // se não for nulo, ele atribui incrementa.
                    $listaObjs[$indice]->AssuntosRespondidos++;
                }

                // Calcula a quantidade de questão respondidas em revisão
                if (is_numeric($frente->TotalAcertosQuestoesRevisao)) {
                    // se não for nulo, ele atribui incrementa.
                    $listaObjs[$indice]->TotalAssuntoRevisaoRespondida++;
                }

                // Calcula a quantidade de videos que foram assistidos
                if (is_float($frente->PercentualTotalVideo)) {
                    // se não for nulo, ele atribui incrementa.
                    $listaObjs[$indice]->PercentualTotalVideo++;
                }

            }
        }
        return $listaObjs;
    }
}