<?php

class Aula_model extends MY_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function buscarAulaPorID($idAula)
    {
        try {
            /** @var \PDO $pdo */
            $pdo = SaeDigital::make(PDO::class);

            $sql = "SELECT * FROM E068_Aulas WHERE AulaID = :idAula;";

            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':idAula', $idAula, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetch(PDO::FETCH_ASSOC);

        } catch (\PDOException $e) {

        } catch (\Exception $e) {

        }
    }

    public function buscarNomeCursoPorAulaID($idAula)
    {
        try {
            /** @var \PDO $pdo */
            $pdo = SaeDigital::make(PDO::class);

            $sql = "SELECT 
                    E093.Descricao cursoNome
                FROM
                    E091_AulasSubCategorias E091 
                        INNER JOIN E090_CategoriasSubCategoriasAulas E090 ON E091.SubCategoriaID = E090.SubCategoriaID
                        INNER JOIN E094_GruposCategoriasAulas E094 ON E090.CategoriaID = E094.CategoriaAulaID
                        INNER JOIN E093_GruposAulas E093 ON E093.GrupoAulaID = E094.GrupoAulaID
                WHERE
                    E091.AulaId = :idAula;";

            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':idAula', $idAula, PDO::PARAM_INT);
            $stmt->execute();

            $cursoNome = $stmt->fetch(PDO::FETCH_ASSOC);

            return $cursoNome['cursoNome'] ?: null;
        } catch (\PDOException $e) {

        } catch (\Exception $e) {

        }

    }
}