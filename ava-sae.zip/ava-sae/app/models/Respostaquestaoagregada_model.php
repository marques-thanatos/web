<?php

class RespostaQuestaoAgregada_model extends MY_Model{

    public $RespostaQuestaoAgregadaID;
    public $UsuarioID;
    public $NomeUsuario;
    public $DisciplinaID;
    public $TentativaQuestao;
    public $TentativaVideo;
    public $TentativaRevisao;
    public $DescricaoDisciplina;
    public $FrenteID;
    public $DescricaoFrente;
    public $AssuntoID;
    public $DescricaoAssunto;
    public $TurmaID;
    public $SerieID;
    public $EscolaID;
    public $DescricaoEscola;
    public $TotalQuestoes;
    public $TotalAcertoQuestoes;
    public $TotalVideos;
    public $PercentualTotalVideo;
    public $TotalQuestoesRevisao;
    public $TotalAcertosQuestoesRevisao;
    public $MetaQuestoes;
    public $MetaVideos;
    public $DtInicioAtividade;
    public $DtFimAtividade;
    public $PercentualQuestao;
    public $PercentualRevisao;
    public $DescricaoTurma;


    /**
     * RespostaQuestaoAgregadaModel constructor.
     */
    function __construct($params = null) {
        parent::__construct();

        if($params){
            foreach($params as $key => $value){
                $this->$key = $value;
            }
        }

        $this->validate();
    }

    public function validate(){
        $percentualRevisao = $this->percentualRevisao();
        $percentualTotalVideo = $this->percentualTotalVideo();

        if($percentualRevisao !== null and $percentualTotalVideo < 90 && $this->DtFimAtividade !== null){
            // O usuário já terminou a atividade, fez a revisão e os dados de video estão cadastrados errados
            // sendo assim atualizamos o registro de video para ficar com a meta correta

            if(
                $this->UsuarioID !== null &&
                $this->DisciplinaID !== null &&
                $this->AssuntoID !== null &&
                $this->TurmaID !== null
            ){
                // Atualizando somente se todos os dados necessários forem carregados do banco de dados
                $db = $this->getAvaMySQL();
                $db->where(array(
                    'UsuarioID' => $this->UsuarioID,
                    'DisciplinaID' => $this->DisciplinaID,
                    'AssuntoID' => $this->AssuntoID,
                    'TurmaID' => $this->TurmaID,
                    'Tipo' => 'N'
                ));
                $db->update('R001_RespostasQuestoes',array(
                    'PercentualVideo' => 100,
                ));
                $this->PercentualTotalVideo = 100;
            }

        }
    }

    public function getDataFormatada(){
        $data = strtotime($this->DtInicioAtividade);

        return 'Dia '. date('d/m', $this->data) .' - '. diasemana(date('Y-m-d', $data));
    }

    public function atingiuQuestao() {
        return ($this->TotalQuestoes > 0) ? $this->MetaQuestoes <= ($this->TotalAcertoQuestoes / $this->TotalQuestoes * 100) : false;
    }
    
    public function atingiuRevisao(){
        return ($this->TotalQuestoesRevisao > 0) ? $this->MetaQuestoes <= round($this->TotalAcertosQuestoesRevisao / $this->TotalQuestoesRevisao * 100) : false;
    }
    
    public function percentualQuestoes(){
        return ($this->TotalQuestoes > 0) ? round($this->TotalAcertoQuestoes / $this->TotalQuestoes * 100) : null;
    }
    
    public function percentualRevisao(){
        if($this->TotalAcertosQuestoesRevisao === null){
            return null;
        }
        return ($this->TotalQuestoesRevisao > 0) ? ($this->TotalAcertosQuestoesRevisao / $this->TotalQuestoesRevisao * 100) : null;
    }

    public function percentualTotalVideo(){
        if($this->PercentualTotalVideo >= 90)
        {
            return 100;
        }
        return $this->PercentualTotalVideo;
    }
    
    public function atingiuMetaVideo(){
        return ($this->TotalVideos > 0) ? $this->MetaVideos <= round($this->PercentualTotalVideo / $this->TotalVideos) : false;
    }


    public function passouDataAgendamento() {
        return (!empty($this->DtFimAtividade) && $this->dataMenorQueHoje($this->DtFimAtividade));
    }


    public function dataMenorQueHoje($dataInicio){
        // Padrão: XX/XX/XXXX
        if ( strstr($dataInicio,"/") ){
            $dt_explode = explode("/", $dataInicio);
        }

        // Data YYYY-MM-DD
        $dtinicio = strtotime($dt_explode[2] . "-" . $dt_explode[1] . "-" . $dt_explode[0]);
        // Hoje YYYY-MM-DD
        $dtfim = strtotime(date('Y-m-d'));

        return $dtinicio < $dtfim;
    }


    public function comecouAssistirVideo(){
        if (!is_null($this->TentativaVideo)) {
            return (int)$this->TentativaVideo > 0;
        }

        return $this->PercentualTotalVideo !== NULL;
    }

    public function comecouFazerRevisao(){
        if (!is_null($this->TentativaRevisao) && !is_null($this->TotalQuestoesRevisao)) {
            return (int)$this->TentativaRevisao >= (int)$this->TotalQuestoesRevisao;
        }

        return $this->TotalAcertosQuestoesRevisao !== NULL;
    }

    public function comecouFazerQuestao(){
        if (!is_null($this->TentativaQuestao) && !is_null($this->TotalQuestoes)) {
            return (int)$this->TentativaQuestao >= (int)$this->TotalQuestoes;
        }

        return $this->TotalAcertoQuestoes !== NULL;
    }

    public function tdsRelatorios(){
        $html = '';

        /* COLUNA DE QUESTÃO */
        if (!$this->comecouFazerQuestao() && $this->passouDataAgendamento()) {
            $html .= td(icon_remove('Tarefa Não Realizada'));
        } elseif ($this->atingiuQuestao()) {
            $html .= td(icon_success('Você acertou ' . $this->TotalAcertoQuestoes . ' das ' . $this->TotalQuestoes . ' questões. Você alcançou o objetivo esperado.'));
        } else {
            if ($this->comecouFazerQuestao()) {
                $html .= td(icon_ok('Você acertou ' . $this->TotalAcertoQuestoes . ' das ' . $this->TotalQuestoes . ' questões. Reforce seu estudo assistindo ao vídeo!'));
            } else {
                $html .= td(icon_remove('Tarefa Não Realizada'));
            }
        }




        /* COLUNA DE VÍDEO */
        if (!$this->comecouFazerQuestao()) {
            $html .= td();
        } elseif ($this->atingiuQuestao() && $this->comecouAssistirVideo()) {
            $html .= td(icon_video("Porcentagem assistida : {$this->percentualTotalVideo()}%"));
        } elseif (!$this->atingiuQuestao() && !$this->comecouAssistirVideo() && $this->passouDataAgendamento()) {
            $html .= td(icon_remove('Tarefa Não Realizada'));
        } else {
            if ($this->atingiuMetaVideo()) {
                $html .= td(icon_video("Agora só falta resolver as questões de revisão! Porcentagem assistida : {$this->percentualTotalVideo()}%"));
            } elseif (!$this->atingiuMetaVideo() && $this->comecouAssistirVideo()) {
                $html .= td(icon_video("Meta ainda não atingida! Porcentagem assistida : {$this->percentualTotalVideo()}%"));
            } else {
                $html .= td();
            }
        }

        /* COLUNA DE REVISÃO */
        if ($this->atingiuQuestao() && !$this->comecouFazerRevisao()) {
            $html .= td();
        } elseif (!$this->comecouFazerQuestao()) {
            $html .= td();
        } elseif (!$this->atingiuMetaVideo() && !$this->atingiuQuestao()) {
            $html .= td(icon_remove('Tarefa Não Realizada'));
        } elseif (!$this->atingiuRevisao() && !$this->comecouFazerRevisao() && $this->passouDataAgendamento() && !$this->atingiuQuestao()) {
            $html .= td(icon_remove('Tarefa Não Realizada'));
        } elseif ($this->atingiuMetaVideo() && $this->atingiuRevisao()) {
            $html .= td(icon_success("Você acertou {$this->TotalAcertosQuestoesRevisao} das {$this->TotalQuestoesRevisao} questões. Você alcançou o objetivo esperado. Parabéns!"));
        } elseif ($this->comecouFazerRevisao() && !$this->atingiuRevisao()) {
            $html .= td(icon_ok('Você acertou '. intval($this->TotalAcertosQuestoesRevisao) .' das '. $this->TotalQuestoesRevisao .' questões. Reforce seu estudo assistindo ao vídeo!'));
        } elseif (!$this->comecouFazerRevisao() && $this->passouDataAgendamento()) {
            $html .= td(icon_remove('Tarefa Não Realizada'));
        } else {
            $html .= td();
        }
        return $html;
    }
}
