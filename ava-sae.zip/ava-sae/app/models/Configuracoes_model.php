<?php

class Configuracoes_model extends MY_Model {

    function __construct() {
      parent::__construct();

    }

    /**
     * Configurações
     *
     * Retorna dados da base correspondente.
     *
     * @access	public
     * @param	void
     * @return	array
     */
    public function configuracoes() {

        $return = '';
        $sql = 'select * from D000_Configuracoes where Subdominio = "' . HOST . '"';
        $response = $this->getAvaMySQL()->query($sql);
        $response= $response->result_array();
        if ($response) {
            return $response;
        }
        return $return;
    }

    public function getConfiguracoesescola($escolaid) {

        $sql = "select EscolaID,Serie,Meta,Percentual,QuestaoProfessor,AgendaProfessor,QuestaoCoordenador,AgendaCoordenador,DtFimProfessor,DtFimCoordenador,Tipo, RespostaFinalAgendamentoAluno, NotiRespTarefaRealizada, AgendamentoDisciplinasLote
    						 from D023_Ava_Sae_Configuracoes where EscolaID = '" . $escolaid . "' ";
        // TODO: FDD-429 - UNSAFE QUERY
       $response = $this->getAvaMySQL()->query($sql);
       $response= $response->result_array();
       $return = false;

        if ($response) {
            $return = $response;
        }
        return $return;
    }

}
