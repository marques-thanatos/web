<?php

$obj = &get_instance();
$obj->load->model('RespostaQuestaoAgregada_model');

class AlunoAssunto_model extends RespostaQuestaoAgregada_model
{

    public $AssuntoID;
    public $UsuarioID;
    public $NomeUsuario;
    public $TotalQuestoes;
    public $TotalAcertoQuestoes;
    public $TotalVideos;
    public $PercentualTotalVideo;
    public $TotalQuestoesRevisao;
    public $TotalAcertosQuestoesRevisao;
    public $MetaQuestoes;
    public $MetaVideos;
    public $DtFimAtividade;


}