<?php

class Login_model extends MY_Model {

    function __construct() {
        parent::__construct();

    }

    /**
     * Verifica Login
     *
     * Recebe os parâmetros dos usuário através de um $_POST e verifica no simpleDB
     * da Amazon se existe, caso exista retorna um array formatado, caso não retorna vazio.
     *
     * @access	public
     * @param	array  $fields  array com dados dos usuários enviado através do controller.
     * @param	string	$base	contento nome do dominio
     * @return	array           com conteúdo ou vazio
    */
    public function verificaLogin($fields = null, $Base = 'Aprovaconcursos', $assinaturaSiteID = null) {

        $return = '';
        if ($fields) {
            $ano = Date("Y");
            $fields['usuario'] = $this->getAvaMySQL()->escape($fields['usuario']);
            $usuario = $fields['usuario'];
            $sql = "select *
                    from D019_Ava_Sae 
                    where (YEAR(DtCad) = 2020 or YEAR(DtCad) = 2021)  and 
                    Situacao = 'A' and 
                    Login = $usuario";

            // TODO: FDD-429 - UNSAFE QUERY
            $response = $this->getAvaMySQL()->query($sql)->result_array();
            return $response;
        }
    }

        /**
     * Traz o usuário pelo itemName
     *
     * Recebe os parâmetros dos usuário através de um $_POST e verifica no simpleDB
     * da Amazon se existe, caso exista retorna um array formatado, caso não retorna vazio.
     *
     * @access	public
     * @param	array  $fields  array com dados dos usuários enviado através do controller.
     * @param	string	$base	contento nome do dominio
     * @return	array           com conteúdo ou vazio
    */
    public function getColorMode($itemName) {

        $usuario = $this->getAvaMySQL()->escape($itemName);
        $sql = "select
                    colorMode
                FROM 
                    D019_Ava_Sae
                WHERE
                    itemName = $usuario";
        $result_array = $this->getAvaMySQL()->query($sql)->result_array();
        return $result_array[0];
    }

    /**
     * Traz o usuário pelo itemName
     *
     * Recebe os parâmetros dos usuário através de um $_POST e verifica no simpleDB
     * da Amazon se existe, caso exista retorna um array formatado, caso não retorna vazio.
     *
     * @access	public
     * @param	array  $fields  array com dados dos usuários enviado através do controller.
     * @param	string	$base	contento nome do dominio
     * @return	array           com conteúdo ou vazio
    */
    public function getUsuario($sessionData) {

        // Essa function não deveria mais ser chamada
        // Mas se for chamada, retorna a própria session mesmo

        return $sessionData->userdata;

        // $ano = Date("Y");
        // $usuario = $this->getAvaMySQL()->escape($itemName);
        // $sql = "select *
        //         from D019_Ava_Sae 
        //         where DtCad like '$ano%' and 
        //         Situacao = 'A' and 
        //         itemName = $usuario";

        // $result_array = $this->getAvaMySQL()->query($sql)->result_array();
        // return $result_array[0];
    }

    public function RetornaCriador($itemName)
    {
        $selectExpression = "select * from D019_Ava_Sae where itemName = '". $itemName . "'";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($selectExpression);
        $response = $query->result_array();
        if ($response){
          return $response;
        }
        return '';
    }

    /**
     * Busca e retorna registro da escola
     * @return array contendo o registro da escola no banco SimpleDB
     */
    public function getDadosEscola($id) {
        if ($id != '') {
            $selectExpression = "select * from D019_Ava_Sae where itemName = '{$id}'";
            $query = $this->getAvaMySQL()->query($selectExpression);
            $return = $query->result_array();
        }
        return $return;
    }

    function atualizaDados($domain,$id,$dados,$replace=TRUE){
         $this->getAvaMySQL()->where('id',$id);
         if($this->getAvaMySQL()->update($domain,$dados)){
           return true;
         }
         return false;
    }

    /**
     * Esqueci Senha
     *
     * Recebe os parâmetros dos usuário através de um array e verifica no simpleDB
     * da Amazon se existe, caso exista retorna um array formatado, caso não retorna vazio.
     *
     * @access	public
     * @param	array   $fields array com dados dos usuários enviado através do controller.
     * @param	string	$base   contento nome do dominio
     * @return	array|boolean           com conteúdo ou vazio
    */
    public function esqueciSenha($fields = null) {
        if ($fields) {
            $selectExpression = "select Escola,Perfil, Email from D019_Ava_Sae where Login = '{$fields['usuario']}' limit 1";
            // TODO: FDD-429 - UNSAFE QUERY
            $query = $this->getAvaMySQL()->query($selectExpression);
            return $query->result_array();
        }
        return false;
    }

    /**
     * Atualiza Senha
     *
     * Recebe os parâmetros dos usuário através de um array e verifica no simpleDB
     * da Amazon se existe, caso exista ou não retorna um valor boleando.
     *
     * @access	public
     * @param	array   $id array com dados dos usuários enviado através do controller.
     * @param	string	$dados    contento a senha do usuário enviado através do controller.
     * @return	boolean           true ou false;
    */
    public function atualizaSenha($id, $dados)
    {
        $this->getAvaMySQL()->where('id',$id);
        if($this->getAvaMySQL()->update('D019_Ava_Sae',$dados)){
          return true;
        }
        return false;
    }

    

    public function verificaAcessoLD($idescola = false) {

        $return[0]['AcessoLD'] = 'N';

        if ($idescola) {

            $selectExpression = "select AcessoLD from D023_Ava_Sae_Configuracoes where EscolaID = '$idescola' and Tipo = 'G'";
            // TODO: FDD-429 - UNSAFE QUERY
            $query = $this->getAvaMySQL()->query($selectExpression);
            $result = $query->result_array();
            if ($result) {
                return $result;
            }
            return $return;

        }

        return $return;
    }

    public function verificaConfigEscola($idescola) {

        $return[0]['SenhaAluno'] = 'N';

        $selectExpression = "select * from D023_Ava_Sae_Configuracoes where EscolaID = '$idescola' and Tipo = 'G'";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($selectExpression);
        $result = $query->result_array();
        if ($result) {
            return $result;
        }
        return $return;
    }

    public function buscaRecuperaSenha($id) {

        $selectExpression = "select * from D033_Ava_Sae_RecuperarSenha where itemName = '$id'";
        // TODO: FDD-429 - UNSAFE QUERY
        $query = $this->getAvaMySQL()->query($selectExpression);
        $result = $query->result_array();
        if ($result){
          return $result;
        }
        return false;

    }

    public function atualizaRecuperarSenha($id, $dados) {

        $this->getAvaMySQL()->where('itemName',$id);
        if($this->getAvaMySQL()->update('D033_Ava_Sae_RecuperarSenha',$dados)){
            return true;
        }
        return false;

    }

    public function verificaTodosLogins($login){
        $selectExpression = "select id from D019_Ava_Sae where Login = '$login'";
        $query = $this->getAvaMySQL()->query($selectExpression);
        $result = $query->result_array();
        if ($result){
          return $result;
        }
        return false;

    }

    public function getSessions($ip, $userId, $sessionId)
    {
        $this->getAvaMySQL()->select("ip_address, user_id, id");
        $this->getAvaMySQL()->where("user_id", $userId);
        $this->getAvaMySQL()->where("ip_address !=", $ip);
        $result = $this->getAvaMySQL()->get("ci_sessions");

        return $result->result_array();
    }

    public function deleteSessions($userId, $sessionId)
    {
        $this->getAvaMySQL()->where("user_id", $userId);
        $this->getAvaMySQL()->where("id !=", $sessionId);
        $result = $this->getAvaMySQL()->delete("ci_sessions");

        return $result;
    }

    public function deleteMySession($sessionId)
    {
        $this->getAvaMySQL()->where("id", $sessionId);
        $result = $this->getAvaMySQL()->delete("ci_sessions");

        return $result;
    }

    public function verifyEmailExists($login, $email)
    {
        $this->getAvaMySQL()->where("Login !=", $login);
        $this->getAvaMySQL()->where("Situacao", "A");
        $this->getAvaMySQL()->where("Email", $email);
        $result = $this->getAvaMySQL()->get("D019_Ava_Sae");

        return $result->num_rows();
    }

    public function updateEmail($login, $email)
    {
        $dados = [
            "Email" => $email,
            "EmailBounced" => "N"
        ];
        $this->getAvaMySQL()->where("Login", $login);
        $this->getAvaMySQL()->where("Situacao", "A");
        $result = $this->getAvaMySQL()->update('D019_Ava_Sae',$dados);

        return $result;
    }

}

