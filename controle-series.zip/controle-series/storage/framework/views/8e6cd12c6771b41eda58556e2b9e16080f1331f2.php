<?php if(!empty($mensagem)): ?>
    <div class="alert alert-success">
        <?php echo e($mensagem); ?>

    </div>
<?php endif; ?>
<?php /* C:\Users\Marques\Downloads\controle-series\resources\views/mensagem.blade.php */ ?>